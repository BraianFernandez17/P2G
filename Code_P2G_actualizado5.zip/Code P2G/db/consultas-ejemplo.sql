-- ============================================================
-- CONSULTAS DE EJEMPLO (SELECT)
-- Esto NO se ejecuta automáticamente al levantar la base (a
-- diferencia de schema.sql y seed.sql). Es solo documentación:
-- lo que el backend (NestJS) ejecutaría para conseguir los datos
-- que hoy tenemos hardcodeados en el frontend, para ir probando
-- a mano en psql o en Adminer mientras no existe ese backend.
-- Los IDs son los que carga db/seed.sql.
-- ============================================================

-- "Traeme el nombre y el % de perfil completo de María"
SELECT first_name, profile_completed
FROM students
WHERE id = '20000000-0000-0000-0000-000000000001';

-- "Traeme las pasantías publicadas, junto con el nombre de la empresa"
-- (el JOIN es lo que junta filas de dos tablas distintas)
SELECT internships.title, companies.legal_name, internships.modality, internships.duration_months
FROM internships
JOIN companies ON companies.id = internships.company_id
WHERE internships.status = 'published'
ORDER BY internships.published_at DESC;

-- "Contame cuántas postulaciones tiene María, agrupadas por estado"
-- (esto es lo que alimentaría las tarjetas de "Postulaciones" y "En revisión")
SELECT status, COUNT(*) AS cantidad
FROM applications
WHERE student_id = '20000000-0000-0000-0000-000000000001'
GROUP BY status;

-- "Traeme la agenda pública: las reservas ya aprobadas a futuro,
-- con el nombre del recurso y del profesor que la pidió"
-- (esto alimenta agenda-publica.html, que cualquiera puede ver sin login)
SELECT resources.name AS recurso, resources.type AS tipo,
       bookings.title, bookings.starts_at, bookings.ends_at,
       professors.first_name, professors.last_name
FROM bookings
JOIN resources ON resources.id = bookings.resource_id
JOIN professors ON professors.user_id = bookings.requested_by
WHERE bookings.status = 'approved' AND bookings.starts_at >= now()
ORDER BY bookings.starts_at ASC;

-- "Traeme las reservas pendientes de aprobar, para el panel del admin"
SELECT bookings.id, bookings.title, bookings.starts_at, bookings.ends_at,
       resources.name AS recurso
FROM bookings
WHERE bookings.status = 'pending'
ORDER BY bookings.starts_at ASC;

-- "Traeme las postulaciones seleccionadas que todavía no tienen
-- entrevista agendada" (esto alimenta la sección puente de
-- dashboard-admin.html: "Entrevistas de pasantía por agendar")
SELECT applications.id, students.first_name, students.last_name,
       internships.title, companies.legal_name
FROM applications
JOIN students ON students.id = applications.student_id
JOIN internships ON internships.id = applications.internship_id
JOIN companies ON companies.id = internships.company_id
WHERE applications.status = 'selected'
  AND NOT EXISTS (
    SELECT 1 FROM bookings
    WHERE bookings.related_application_id = applications.id
  );

-- "Traeme las empresas pendientes de aprobar, para el panel del admin"
-- (incluye el rubro/sector, para mostrar el chip de "tipo de empresa")
SELECT id, legal_name, sector
FROM companies
WHERE status = 'pending_approval';

-- "Contame cuántas empresas activas hay por rubro" (para un futuro
-- gráfico de "tipos de empresa" en el panel de admin)
SELECT sector, COUNT(*) AS cantidad
FROM companies
WHERE status = 'active'
GROUP BY sector
ORDER BY cantidad DESC;

-- "Traeme el inventario completo de salones, laboratorios y equipos,
-- agrupado por tipo" (alimenta la sección "Inventario de salones,
-- laboratorios y equipos" de dashboard-admin.html)
SELECT type AS tipo, COUNT(*) AS cantidad_de_items, SUM(total_quantity) AS unidades_totales
FROM resources
GROUP BY type;

-- Probar el EXCLUDE constraint a propósito: esto debería FALLAR
-- con un error de "conflicting key value" porque se solapa con la
-- reserva ya aprobada del Laboratorio de Física (ver seed.sql).
-- INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at)
-- VALUES (
--   '70000000-0000-0000-0000-000000000004',
--   '00000000-0000-0000-0000-000000000003',
--   'Otra clase que se pisa con la de Ana',
--   now() + interval '1 day' + interval '15 hours',
--   now() + interval '1 day' + interval '16 hours'
-- );
