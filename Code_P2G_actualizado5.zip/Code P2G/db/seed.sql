-- ============================================================
-- DATOS DE PRUEBA (seed)
-- Los mismos nombres que ya usa el frontend en sus mocks
-- (js/script.js, js/reservas.js, js/empresa.js, js/sesion.js),
-- pero ahora viviendo en tablas reales. Corre después de
-- schema.sql: usa IDs fijos (en vez de gen_random_uuid()) para
-- que sea fácil de leer y de referenciar desde otras consultas.
-- ============================================================

-- ---------- USERS ----------
-- La contraseña de todos, en esta demo, es literalmente el texto
-- "demo1234" ya "hasheado" con bcrypt (no hace falta instalar
-- bcrypt para probar esto: alcanza con saber que en la versión
-- real acá va bcrypt.hash(password, 10), nunca la contraseña posta).
INSERT INTO users (id, email, password_hash, role) VALUES
  ('00000000-0000-0000-0000-000000000001', 'admin@polotec.edu.uy',         '$2b$10$demoDemoDemoDemoDemoDe', 'admin'),
  ('00000000-0000-0000-0000-000000000002', 'ana@polotec.edu.uy',           '$2b$10$demoDemoDemoDemoDemoDe', 'professor'),
  ('00000000-0000-0000-0000-000000000003', 'diego@polotec.edu.uy',         '$2b$10$demoDemoDemoDemoDemoDe', 'professor'),
  ('00000000-0000-0000-0000-000000000007', 'lucia@polotec.edu.uy',         '$2b$10$demoDemoDemoDemoDemoDe', 'professor'),
  ('00000000-0000-0000-0000-000000000008', 'ruben@polotec.edu.uy',         '$2b$10$demoDemoDemoDemoDemoDe', 'professor'),
  ('00000000-0000-0000-0000-000000000009', 'valentina@polotec.edu.uy',     '$2b$10$demoDemoDemoDemoDemoDe', 'professor'),
  ('00000000-0000-0000-0000-000000000004', 'maria@estudiante.com',        '$2b$10$demoDemoDemoDemoDemoDe', 'student'),
  ('00000000-0000-0000-0000-00000000000a', 'facundo@estudiante.com',      '$2b$10$demoDemoDemoDemoDemoDe', 'student'),
  ('00000000-0000-0000-0000-00000000000b', 'camila@estudiante.com',       '$2b$10$demoDemoDemoDemoDemoDe', 'student'),
  ('00000000-0000-0000-0000-000000000005', 'contacto@techcorp.com',       '$2b$10$demoDemoDemoDemoDemoDe', 'company'),
  ('00000000-0000-0000-0000-000000000006', 'contacto@industriasnorte.com','$2b$10$demoDemoDemoDemoDemoDe', 'company'),
  ('00000000-0000-0000-0000-00000000000c', 'rrhh@agrotacua.com.uy',       '$2b$10$demoDemoDemoDemoDemoDe', 'company'),
  ('00000000-0000-0000-0000-00000000000d', 'contacto@clinicasalud.com.uy','$2b$10$demoDemoDemoDemoDemoDe', 'company');

-- ---------- COURSES ----------
-- Oferta educativa ampliada del Polo Tecnológico: además de
-- Informática, sumamos las tecnicaturas y bachilleratos técnicos
-- que suelen convivir en un Polo Tecnológico de UTU, para que el
-- selector de "Carrera" del registro de estudiante no muestre una
-- sola opción.
INSERT INTO courses (id, name) VALUES
  ('10000000-0000-0000-0000-000000000001', 'Tecnólogo en Informática'),
  ('10000000-0000-0000-0000-000000000002', 'Tecnólogo en Mecánica'),
  ('10000000-0000-0000-0000-000000000003', 'Tecnólogo en Electrónica'),
  ('10000000-0000-0000-0000-000000000004', 'Tecnólogo en Electromecánica'),
  ('10000000-0000-0000-0000-000000000005', 'Tecnólogo Químico'),
  ('10000000-0000-0000-0000-000000000006', 'Tecnólogo en Gestión de Empresas'),
  ('10000000-0000-0000-0000-000000000007', 'Tecnicatura en Análisis y Desarrollo de Software'),
  ('10000000-0000-0000-0000-000000000008', 'Tecnicatura en Administración y Contabilidad'),
  ('10000000-0000-0000-0000-000000000009', 'Bachillerato Tecnológico Agrario'),
  ('1000000a-0000-0000-0000-000000000010', 'Bachillerato Tecnológico en Turismo');

-- ---------- STUDENTS ----------
INSERT INTO students (id, user_id, first_name, last_name, course_id, profile_completed) VALUES
  ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000004',
   'María', 'González', '10000000-0000-0000-0000-000000000001', true),
  ('20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a',
   'Facundo', 'Pereira', '10000000-0000-0000-0000-000000000002', true),
  ('20000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000b',
   'Camila', 'Sosa', '10000000-0000-0000-0000-000000000006', false);

-- ---------- PROFESSORS ----------
-- Cinco docentes en vez de dos, para que el panel de admin y la
-- agenda pública se vean con movimiento real de varias personas
-- pidiendo salones, no solo una.
INSERT INTO professors (id, user_id, first_name, last_name) VALUES
  ('30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'Ana', 'Rodríguez'),
  ('30000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000003', 'Diego', 'Martínez'),
  ('30000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000007', 'Lucía', 'Fernández'),
  ('30000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000008', 'Rubén', 'Acosta'),
  ('30000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000009', 'Valentina', 'Silveira');

-- ---------- COMPANIES ----------
-- Cuatro empresas de rubros distintos (tecnología, industria,
-- agropecuaria, salud), para que "tipos de empresa" sea un dato
-- real y no un campo vacío. TechCorp y AgroTacuá ya están
-- aprobadas; Industrias del Norte y Clínica Salud quedan
-- pendientes a propósito, para poder probar la cola de aprobación
-- del admin con más de un caso.
INSERT INTO companies (id, user_id, legal_name, sector, status) VALUES
  ('40000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000005',
   'TechCorp Tacuarembó', 'tecnologia', 'active'),
  ('40000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000006',
   'Industrias del Norte', 'industria', 'pending_approval'),
  ('40000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000c',
   'AgroTacuá S.A.', 'agropecuaria', 'active'),
  ('40000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-00000000000d',
   'Clínica Salud Tacuarembó', 'salud', 'pending_approval');

-- ---------- INTERNSHIPS ----------
INSERT INTO internships (id, company_id, title, modality, duration_months, status, published_at) VALUES
  ('50000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000001',
   'Desarrollador Frontend Jr', 'remoto', 6, 'published', now() - interval '10 days'),
  ('50000000-0000-0000-0000-000000000002', '40000000-0000-0000-0000-000000000001',
   'Soporte de Datos', 'presencial', 4, 'published', now() - interval '3 days'),
  ('50000000-0000-0000-0000-000000000003', '40000000-0000-0000-0000-000000000003',
   'Asistente de Agroindustria', 'hibrido', 5, 'published', now() - interval '6 days');

-- ---------- APPLICATIONS ----------
-- María llegó a "selected" en la Frontend Jr: es justo el caso que
-- dispara la sección "Entrevistas de pasantía por agendar" en
-- dashboard-admin.html. Sumamos un par más para poblar el panel
-- de la empresa con distintos estados del embudo.
INSERT INTO applications (id, student_id, internship_id, status) VALUES
  ('60000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000001',
   '50000000-0000-0000-0000-000000000001', 'selected'),
  ('60000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000002',
   '50000000-0000-0000-0000-000000000002', 'under_review'),
  ('60000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000003',
   '50000000-0000-0000-0000-000000000003', 'submitted');

-- ---------- RESOURCES ----------
-- El inventario base que pide la letra del proyecto, más dos
-- espacios extra (Auditorio y Sala de Reuniones Docentes) para
-- que el panel de admin tenga más de "3 salones" para mostrar.
INSERT INTO resources (id, name, type, total_quantity) VALUES
  ('70000000-0000-0000-0000-000000000001', 'Biblioteca', 'espacio', 1),
  ('70000000-0000-0000-0000-000000000002', 'Sala de Informática', 'espacio', 1),
  ('70000000-0000-0000-0000-000000000003', 'Sala de Conferencias', 'espacio', 1),
  ('70000000-0000-0000-0000-000000000004', 'Laboratorio de Física', 'laboratorio', 1),
  ('70000000-0000-0000-0000-000000000005', 'Laboratorio de Química', 'laboratorio', 1),
  ('70000000-0000-0000-0000-000000000006', 'Laboratorio de Ciencias', 'laboratorio', 1),
  ('70000000-0000-0000-0000-000000000007', 'Proyector', 'equipo', 2),
  ('70000000-0000-0000-0000-000000000008', 'Televisión', 'equipo', 1),
  ('70000000-0000-0000-0000-000000000009', 'Auditorio', 'espacio', 1),
  ('7000000a-0000-0000-0000-000000000010', 'Sala de Reuniones Docentes', 'espacio', 1);

-- ---------- BOOKINGS ----------
-- Fechas relativas a "ahora" (en vez de fechas fijas) para que la
-- agenda pública siempre muestre algo "a futuro", sin importar
-- cuándo se corra este seed. Ahora con los 5 profesores pidiendo
-- salones distintos, para que la agenda y la cola de aprobación
-- del admin se vean con más movimiento.
INSERT INTO bookings (id, resource_id, requested_by, title, starts_at, ends_at, status) VALUES
  ('80000000-0000-0000-0000-000000000001', '70000000-0000-0000-0000-000000000004',
   '00000000-0000-0000-0000-000000000002', 'Práctico de mecánica - 2do año',
   now() + interval '1 day' + interval '14 hours', now() + interval '1 day' + interval '16 hours', 'approved'),
  ('80000000-0000-0000-0000-000000000002', '70000000-0000-0000-0000-000000000003',
   '00000000-0000-0000-0000-000000000002', 'Reunión de coordinación docente',
   now() + interval '3 days' + interval '10 hours', now() + interval '3 days' + interval '11 hours', 'pending'),
  ('80000000-0000-0000-0000-000000000003', '70000000-0000-0000-0000-000000000002',
   '00000000-0000-0000-0000-000000000003', 'Taller de programación',
   now() + interval '2 days' + interval '9 hours', now() + interval '2 days' + interval '12 hours', 'pending'),
  ('80000000-0000-0000-0000-000000000004', '70000000-0000-0000-0000-000000000005',
   '00000000-0000-0000-0000-000000000002', 'Práctico de titulación',
   now() + interval '6 days' + interval '14 hours', now() + interval '6 days' + interval '17 hours', 'pending'),
  ('80000000-0000-0000-0000-000000000005', '70000000-0000-0000-0000-000000000006',
   '00000000-0000-0000-0000-000000000007', 'Práctico de biología - Bach. Agrario',
   now() + interval '2 days' + interval '14 hours', now() + interval '2 days' + interval '16 hours', 'approved'),
  ('80000000-0000-0000-0000-000000000006', '70000000-0000-0000-0000-000000000009',
   '00000000-0000-0000-0000-000000000008', 'Charla de egresados de Electromecánica',
   now() + interval '4 days' + interval '18 hours', now() + interval '4 days' + interval '20 hours', 'approved'),
  ('80000000-0000-0000-0000-000000000007', '7000000a-0000-0000-0000-000000000010',
   '00000000-0000-0000-0000-000000000009', 'Reunión de coordinación de Gestión de Empresas',
   now() + interval '1 day' + interval '9 hours', now() + interval '1 day' + interval '10 hours', 'pending'),
  ('80000000-0000-0000-0000-000000000008', '70000000-0000-0000-0000-000000000001',
   '00000000-0000-0000-0000-000000000003', 'Club de lectura técnica',
   now() + interval '5 days' + interval '15 hours', now() + interval '5 days' + interval '16 hours', 'pending');
