-- ============================================================
-- ESQUEMA DE BASE DE DATOS (PostgreSQL)
-- Esto es lo que en el documento técnico se llama "el diccionario
-- de datos". Son las tablas mínimas para que el dashboard que
-- armamos en HTML/CSS/JS pueda algún día mostrar datos reales
-- en vez de los datos de ejemplo escritos a mano en script.js.
-- ============================================================

-- Tabla raíz de login. Todos los usuarios (estudiante, empresa,
-- admin) tienen un registro acá, sin importar su rol.
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,        -- la contraseña nunca se guarda en texto plano
  role VARCHAR(20) NOT NULL CHECK (role IN ('student', 'company', 'admin')),
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

-- Carrera o tecnicatura que dicta el Polo. Existe antes que
-- cualquier estudiante, porque cada estudiante pertenece a una.
CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(150) NOT NULL  -- ej: "Tecnólogo en Informática"
);

-- Perfil del estudiante. Es 1 a 1 con users: cada estudiante
-- tiene exactamente un user, y cada user de rol "student" tiene
-- exactamente un registro acá.
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  course_id UUID NOT NULL REFERENCES courses(id),
  cv_url VARCHAR(500),               -- dónde está guardado el CV (no el archivo en sí)
  profile_completed BOOLEAN DEFAULT false
);

-- Perfil de la empresa. También 1 a 1 con users.
-- "sector" es el rubro de la empresa (lo que en el registro se ve
-- como "Tipo de empresa"): sirve para que el estudiante filtre
-- pasantías por rubro y para que el admin vea de un vistazo qué
-- tipo de organizaciones está sumando el Polo.
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  legal_name VARCHAR(200) NOT NULL,
  sector VARCHAR(30) NOT NULL DEFAULT 'servicios'
    CHECK (sector IN (
      'tecnologia', 'industria', 'agropecuaria', 'comercio',
      'servicios', 'educacion', 'salud', 'construccion',
      'turismo', 'logistica'
    )),
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval'
    CHECK (status IN ('pending_approval', 'active', 'suspended'))
);

-- Una oferta de pasantía publicada por una empresa.
CREATE TABLE internships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id),
  title VARCHAR(200) NOT NULL,
  modality VARCHAR(20) NOT NULL CHECK (modality IN ('remoto', 'presencial', 'hibrido')),
  duration_months SMALLINT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft', 'published', 'closed')),
  published_at TIMESTAMP
);

-- Cada vez que un estudiante se postula a una pasantía,
-- nace una fila acá. Un mismo estudiante no puede postularse
-- dos veces a la misma pasantía (ver el UNIQUE de abajo).
CREATE TABLE applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id),
  internship_id UUID NOT NULL REFERENCES internships(id),
  status VARCHAR(20) NOT NULL DEFAULT 'submitted'
    CHECK (status IN ('submitted', 'under_review', 'shortlisted', 'selected', 'rejected', 'withdrawn')),
  applied_at TIMESTAMP NOT NULL DEFAULT now(),
  UNIQUE (student_id, internship_id)
);

-- ============================================================
-- MÓDULO DE RESERVAS INSTITUCIONALES
-- Esto es lo que pide la consigna del proyecto: gestionar el uso
-- de espacios diferenciales (biblioteca, sala de informática, sala
-- de conferencias), laboratorios (física, química, ciencias) y
-- equipamiento móvil (proyectores, TV). Convive con las tablas de
-- pasantías de arriba porque comparten la misma tabla "users": un
-- mismo login sirve para todo el sistema, solo cambia el "role".
-- ============================================================

-- Ampliamos los roles posibles: además de estudiante, empresa y
-- admin, ahora existe "professor", que es quien pide las reservas
-- de salas y laboratorios. Un profesor no se postula a pasantías,
-- por eso es un rol nuevo y no lo mezclamos con "student".
ALTER TABLE users DROP CONSTRAINT users_role_check;
ALTER TABLE users ADD CONSTRAINT users_role_check
  CHECK (role IN ('student', 'company', 'admin', 'professor'));

-- Perfil mínimo del profesor. Es 1 a 1 con users, igual que
-- students y companies más arriba.
CREATE TABLE professors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL
);

-- El inventario de "cosas reservables" de la letra: cada fila es
-- un espacio, un laboratorio o un equipo. "total_quantity" existe
-- porque hay recursos de los que hay más de uno (ej: 2 proyectores),
-- y en el futuro eso permitiría reservar "1 de los 2 proyectores"
-- sin bloquear el otro.
CREATE TABLE resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(150) NOT NULL,                 -- ej: "Sala de Conferencias"
  type VARCHAR(20) NOT NULL
    CHECK (type IN ('espacio', 'laboratorio', 'equipo')),
  total_quantity SMALLINT NOT NULL DEFAULT 1,
  active BOOLEAN NOT NULL DEFAULT true         -- de baja temporalmente sin borrar el historial
);

-- El corazón del módulo: cada solicitud de uso de un recurso, en
-- cualquier punto del semáforo pending → approved/rejected, o
-- cancelled si el que la pidió se arrepiente antes de que el admin
-- decida (mismo semáforo de 4 estados que ya usamos en el módulo
-- de pasantías, para no inventar un vocabulario nuevo).
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_id UUID NOT NULL REFERENCES resources(id),
  requested_by UUID NOT NULL REFERENCES users(id),
  title VARCHAR(200) NOT NULL,                 -- motivo breve, ej: "Práctico de Física 2do año"
  starts_at TIMESTAMP NOT NULL,
  ends_at TIMESTAMP NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
  -- ESTE ES EL PUENTE ENTRE LOS DOS MÓDULOS: si esta reserva es
  -- para la entrevista presencial de una postulación puntual,
  -- queda enlazada acá. Si es NULL, es una reserva "normal" de
  -- un profesor (clase, laboratorio, etc.) sin nada que ver con
  -- pasantías. Así, cuando una empresa quiere entrevistar a un
  -- candidato en el Polo, usa el mismo motor de reservas que ya
  -- usan los profesores, en vez de coordinar la sala por afuera
  -- del sistema (por mail, como se hace hoy).
  related_application_id UUID REFERENCES applications(id),
  CHECK (ends_at > starts_at)
);

-- Este es EL criterio de aceptación más importante de la consigna:
-- "no puede haber dos reservas en el mismo lugar al mismo tiempo".
-- En vez de que el backend calcule esto a mano comparando fechas
-- (fácil de hacer mal), se lo delegamos a Postgres con un índice
-- de exclusión: le decimos "para un mismo resource_id, no permitas
-- dos filas cuyo rango de horario [starts_at, ends_at) se toque".
-- Si alguien intenta insertar una reserva que se solapa con otra
-- pending o approved para el mismo recurso, Postgres directamente
-- rechaza el INSERT con un error, sin que el backend tenga que
-- hacer el chequeo por su cuenta.
CREATE EXTENSION IF NOT EXISTS btree_gist;

ALTER TABLE bookings ADD CONSTRAINT no_solapamiento_de_horarios
  EXCLUDE USING gist (
    resource_id WITH =,
    tsrange(starts_at, ends_at) WITH &&
  )
  WHERE (status IN ('pending', 'approved'));

-- Las consultas de ejemplo (los SELECT que antes vivían acá abajo)
-- se mudaron a db/consultas-ejemplo.sql, para que este archivo sea
-- solo DDL (CREATE/ALTER) y se pueda ejecutar de punta a punta sin
-- errores. Si lo dejábamos acá, psql se frenaba en el primer SELECT
-- que usa 'ID-DEL-ESTUDIANTE' como placeholder, porque no es un
-- UUID real.