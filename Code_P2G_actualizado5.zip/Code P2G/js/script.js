/* ============================================================
   DATOS DE EJEMPLO (mock data) — DASHBOARD DEL ESTUDIANTE
   En la versión real, estos objetos NO se escriben a mano:
   vienen de pedirle datos al backend, por ejemplo:

     fetch("/api/v1/students/me")
       .then((res) => res.json())
       .then((data) => pintarSaludo(data));

   Por ahora los dejamos fijos para poder ver la pantalla
   funcionando sin tener un backend corriendo todavía.
   ============================================================ */
const estudiante = {
  nombre: "María",
  porcentajePerfil: 70, // de 0 a 100
};

const pasantiasRecomendadas = [
  {
    id: 1,
    titulo: "Desarrollador Frontend Jr",
    empresa: "TechCorp Tacuarembó",
    modalidad: "Remoto",
    duracionMeses: 6,
  },
  {
    id: 2,
    titulo: "Soporte de Datos",
    empresa: "Industrias del Norte",
    modalidad: "Presencial",
    duracionMeses: 4,
  },
  {
    id: 3,
    titulo: "Asistente de Agroindustria",
    empresa: "AgroTacuá S.A.",
    modalidad: "Híbrido",
    duracionMeses: 5,
  },
];

// A diferencia de antes (un número de "Postulaciones" fijo en las
// estadísticas), ahora es una lista real: se arranca con una
// postulación de ejemplo ya hecha, y "Postularme" desde el modal
// de una pasantía va sumando más acá. Las estadísticas de arriba
// se calculan a partir de esta lista, no al revés.
let misPostulaciones = [
  {
    id: "post1",
    titulo: "Soporte de Datos",
    empresa: "Industrias del Norte",
    estado: "pending",
  },
];

const ETIQUETA_ESTADO_POSTULACION = {
  pending: "En revisión",
  approved: "Aprobada",
  rejected: "Rechazada",
};

/* ============================================================
   FUNCIONES QUE "PINTAN" CADA PARTE DE LA PÁGINA
   Cada una agarra un dato y lo mete adentro del HTML que ya
   existe (los elementos con id="..." que dejamos vacíos en
   dashboard-estudiante.html).
   ============================================================ */

function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;
  // Si hay una sesión real (se creó al iniciar sesión o registrarse,
  // ver js/sesion.js), usamos ese nombre. Si alguien abre este
  // archivo directo sin pasar por el login, mostramos el mock de
  // "María" para que la pantalla siga siendo demostrable.
  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : estudiante.nombre;
  saludoEl.textContent = `Hola, ${nombre}`;
}

function pintarBarraDePerfil() {
  const fillEl = document.getElementById("barra-perfil-relleno");
  const porcentajeEl = document.getElementById("barra-perfil-porcentaje");
  if (!fillEl || !porcentajeEl) return;

  // Por las dudas, no dejamos que el valor se vaya de 0-100
  const porcentaje = Math.min(100, Math.max(0, estudiante.porcentajePerfil));

  fillEl.style.width = `${porcentaje}%`;
  porcentajeEl.textContent = `${porcentaje}%`;
}

// Antes estos tres números venían fijos a mano. Ahora "Postulaciones"
// y "En revisión" salen de misPostulaciones de verdad, así que se
// actualizan solos apenas alguien se postula desde el modal de abajo.
function pintarEstadisticas() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const enRevision = misPostulaciones.filter((p) => p.estado === "pending").length;

  const estadisticas = [
    { icono: "📄", tono: "accent", etiqueta: "Postulaciones", valor: misPostulaciones.length },
    { icono: "🔎", tono: "warning", etiqueta: "En revisión", valor: enRevision },
    { icono: "🔔", tono: "info", etiqueta: "Avisos nuevos", valor: 3 },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   MIS POSTULACIONES
   ============================================================ */
function pintarMisPostulaciones() {
  const listaEl = document.getElementById("lista-postulaciones");
  if (!listaEl) return;

  if (misPostulaciones.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no te postulaste a ninguna pasantía.</p>`;
    return;
  }

  listaEl.innerHTML = misPostulaciones
    .map(
      (postulacion) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${postulacion.titulo}</p>
          <p class="booking-card-meta">${postulacion.empresa}</p>
        </div>
        <span class="status-badge ${postulacion.estado}">${ETIQUETA_ESTADO_POSTULACION[postulacion.estado]}</span>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PASANTÍAS RECOMENDADAS (con filtro por modalidad)
   ============================================================ */
let filtroModalidad = "todas";

function pintarFiltrosModalidad() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-modalidad");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-modalidad";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const modalidades = ["todas", ...new Set(pasantiasRecomendadas.map((p) => p.modalidad))];
  filtrosEl.innerHTML = modalidades
    .map(
      (modalidad) => `
      <button type="button" class="filter-chip ${filtroModalidad === modalidad ? "active" : ""}" data-modalidad="${modalidad}">
        ${modalidad === "todas" ? "Todas" : modalidad}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-modalidad]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroModalidad = boton.dataset.modalidad;
      pintarPasantiasRecomendadas();
    });
  });
}

function pintarPasantiasRecomendadas() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  pintarFiltrosModalidad();

  const pasantias =
    filtroModalidad === "todas"
      ? pasantiasRecomendadas
      : pasantiasRecomendadas.filter((p) => p.modalidad === filtroModalidad);

  if (pasantias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay pasantías ${filtroModalidad.toLowerCase()} por ahora.</p>`;
    return;
  }

  listaEl.innerHTML = pasantias
    .map(
      (pasantia) => `
      <div class="internship-card">
        <div>
          <p class="internship-title">${pasantia.titulo}</p>
          <p class="internship-meta">
            ${pasantia.empresa} · ${pasantia.modalidad} · ${pasantia.duracionMeses} meses
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">
          Ver
        </button>
      </div>
    `
    )
    .join("");

  // Una vez que los botones "Ver" ya existen en el HTML,
  // les enganchamos el evento de click a todos de una.
  listaEl.querySelectorAll(".btn-view").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPasantia(boton.dataset.pasantiaId);
    });
  });
}

/* ============================================================
   MANEJADORES DE EVENTOS
   ============================================================ */

// Antes esto era un alert() con una sola línea de texto. Ahora abre
// el modal de confirmación compartido (js/ui.js) con el detalle de
// la pasantía y un botón real de "Postularme".
function verPasantia(pasantiaId) {
  const pasantia = pasantiasRecomendadas.find((p) => p.id === Number(pasantiaId));
  if (!pasantia) return;

  const yaPostulado = misPostulaciones.some((p) => p.titulo === pasantia.titulo);

  pedirConfirmacion(
    pasantia.titulo,
    `${pasantia.empresa} · ${pasantia.modalidad} · ${pasantia.duracionMeses} meses.` +
      (yaPostulado ? " Ya estás postulado a esta pasantía." : " ¿Querés postularte?"),
    yaPostulado ? null : () => postularme(pasantia),
    yaPostulado ? "Entendido" : "Postularme",
    yaPostulado ? null : "Cerrar"
  );
}

function postularme(pasantia) {
  // Versión real: POST /api/v1/internships/:id/applications
  misPostulaciones.push({
    id: `post${misPostulaciones.length + 1}`,
    titulo: pasantia.titulo,
    empresa: pasantia.empresa,
    estado: "pending",
  });

  pintarMisPostulaciones();
  pintarEstadisticas();
  mostrarToast(`Te postulaste a "${pasantia.titulo}". Queda en revisión.`, "success");
}

/* ============================================================
   PUNTO DE ENTRADA
   Esperamos a que todo el HTML esté cargado en el navegador
   antes de intentar tocarlo, para no buscar elementos que
   todavía no existen.
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  pintarSaludo();
  pintarBarraDePerfil();
  pintarEstadisticas();
  pintarMisPostulaciones();
  pintarPasantiasRecomendadas();
});
