/* ============================================================
   FUNCIONES DE AYUDA, REUTILIZABLES EN CUALQUIER FORMULARIO
   ============================================================ */

// Muestra un mensaje de error debajo de un campo puntual.
// idCampo tiene que coincidir con el id del <p class="form-error" id="...">
function mostrarError(idCampo, mensaje) {
  const errorEl = document.getElementById(`${idCampo}-error`);
  if (!errorEl) return;
  errorEl.textContent = mensaje;
  errorEl.classList.add("visible");
}

// Limpia todos los errores de un formulario antes de revalidar,
// para no dejar mensajes viejos de un intento anterior.
function limpiarErrores(formulario) {
  formulario.querySelectorAll(".form-error").forEach((el) => {
    el.textContent = "";
    el.classList.remove("visible");
  });
}

// Validación bien básica: solo chequea que el campo no esté vacío
// y, si es de tipo email, que tenga al menos un "@".
// El backend SIEMPRE vuelve a validar todo esto de nuevo del lado
// del servidor: nunca hay que confiar solo en la validación del
// navegador, porque alguien podría saltearse el formulario.
function validarCampo(input) {
  const valor = input.value.trim();

  if (input.required && valor === "") {
    mostrarError(input.id, "Este campo es obligatorio");
    return false;
  }

  if (input.type === "email" && !valor.includes("@")) {
    mostrarError(input.id, "Ingresá un email válido");
    return false;
  }

  if (input.type === "password" && valor.length < 6) {
    mostrarError(input.id, "La contraseña debe tener al menos 6 caracteres");
    return false;
  }

  return true;
}

// Recorre todos los inputs/selects de un formulario y valida cada uno.
// Devuelve true solo si TODOS pasaron la validación.
function validarFormulario(formulario) {
  limpiarErrores(formulario);

  const campos = formulario.querySelectorAll(".form-input, .form-select");
  let esValido = true;

  campos.forEach((campo) => {
    const campoValido = validarCampo(campo);
    if (!campoValido) esValido = false;
  });

  return esValido;
}

/* ============================================================
   INICIO DE SESIÓN
   ============================================================ */
const formularioLogin = document.getElementById("login-form");

if (formularioLogin) {
  formularioLogin.addEventListener("submit", (evento) => {
    // Frenamos el comportamiento por defecto del navegador
    // (que sería recargar la página), porque lo vamos a manejar
    // nosotros con JS.
    evento.preventDefault();

    if (!validarFormulario(formularioLogin)) return;

    const email = formularioLogin.querySelector("#email").value.trim();

    // Acá, en la versión real, en vez de buscar en CUENTAS_DEMO
    // (definido en js/sesion.js), hacemos el pedido real al backend:
    //
    // fetch("/api/v1/auth/login", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ email, password }),
    // })
    //   .then((res) => res.json())
    //   .then((data) => {
    //     // guardamos el token (no la cuenta entera) y redirigimos
    //   });

    const cuenta = CUENTAS_DEMO.find(
      (c) => c.email.toLowerCase() === email.toLowerCase()
    );

    if (!cuenta) {
      mostrarError(
        "email",
        "No encontramos una cuenta con ese email. Probá con una de las cuentas de ejemplo o registrate."
      );
      return;
    }

    // En esta demo no comparamos la contraseña de verdad (no hay
    // password_hash real para nadie); cualquier contraseña de al
    // menos 6 caracteres entra, como ya validó validarFormulario().
    guardarSesion(cuenta);
    window.location.href = PANEL_POR_ROL[cuenta.role];
  });
}

/* ============================================================
   REGISTRO DE ESTUDIANTE
   ============================================================ */
const formularioRegistroEstudiante = document.getElementById("register-student-form");

if (formularioRegistroEstudiante) {
  formularioRegistroEstudiante.addEventListener("submit", (evento) => {
    evento.preventDefault();

    if (!validarFormulario(formularioRegistroEstudiante)) return;

    const nuevoEstudiante = {
      nombre: formularioRegistroEstudiante.querySelector("#first-name").value.trim(),
      apellido: formularioRegistroEstudiante.querySelector("#last-name").value.trim(),
      email: formularioRegistroEstudiante.querySelector("#email").value.trim(),
      carreraId: formularioRegistroEstudiante.querySelector("#course").value,
      password: formularioRegistroEstudiante.querySelector("#password").value,
    };

    // Versión real: POST /api/v1/auth/register/student con nuevoEstudiante
    console.log("Nuevo estudiante:", nuevoEstudiante);

    guardarSesion({
      role: "student",
      name: nuevoEstudiante.nombre,
      email: nuevoEstudiante.email,
    });
    window.location.href = "dashboard-estudiante.html";
  });
}

/* ============================================================
   REGISTRO DE EMPRESA
   Ahora también pide el rubro/sector de la empresa (ver
   companies.sector en db/schema.sql), para que el estudiante y
   el admin puedan identificar de un vistazo qué tipo de
   organización es.
   ============================================================ */
const formularioRegistroEmpresa = document.getElementById("register-company-form");

if (formularioRegistroEmpresa) {
  formularioRegistroEmpresa.addEventListener("submit", (evento) => {
    evento.preventDefault();

    if (!validarFormulario(formularioRegistroEmpresa)) return;

    const nuevaEmpresa = {
      razonSocial: formularioRegistroEmpresa.querySelector("#legal-name").value.trim(),
      sector: formularioRegistroEmpresa.querySelector("#sector").value,
      email: formularioRegistroEmpresa.querySelector("#email").value.trim(),
      password: formularioRegistroEmpresa.querySelector("#password").value,
    };

    // Versión real: POST /api/v1/auth/register/company con nuevaEmpresa
    // La empresa queda con status "pending_approval" (ver schema.sql)
    // hasta que el admin la apruebe.
    console.log("Nueva empresa:", nuevaEmpresa);

    // La dejamos entrar a su panel igual: ahí es donde se ve
    // el aviso de "pendiente de aprobación", no en una alert que
    // se pierde apenas se cierra.
    guardarSesion({
      role: "company",
      name: nuevaEmpresa.razonSocial,
      sector: nuevaEmpresa.sector,
      email: nuevaEmpresa.email,
      status: "pending_approval",
    });
    window.location.href = "dashboard-empresa.html";
  });
}

/* ============================================================
   REGISTRO DE PROFESOR
   A diferencia de estudiante y empresa, el profesor no queda
   "pendiente de aprobación": puede pedir reservas apenas se
   registra (ver dashboard-profesor.html).
   ============================================================ */
const formularioRegistroProfesor = document.getElementById("register-professor-form");

if (formularioRegistroProfesor) {
  formularioRegistroProfesor.addEventListener("submit", (evento) => {
    evento.preventDefault();

    if (!validarFormulario(formularioRegistroProfesor)) return;

    const nuevoProfesor = {
      nombre: formularioRegistroProfesor.querySelector("#first-name").value.trim(),
      apellido: formularioRegistroProfesor.querySelector("#last-name").value.trim(),
      email: formularioRegistroProfesor.querySelector("#email").value.trim(),
      password: formularioRegistroProfesor.querySelector("#password").value,
    };

    // Versión real: POST /api/v1/auth/register/professor con nuevoProfesor
    console.log("Nuevo profesor:", nuevoProfesor);

    guardarSesion({
      role: "professor",
      name: `${nuevoProfesor.nombre} ${nuevoProfesor.apellido}`,
      email: nuevoProfesor.email,
    });
    window.location.href = "dashboard-profesor.html";
  });
}
