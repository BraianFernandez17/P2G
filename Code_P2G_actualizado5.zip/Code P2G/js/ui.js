/* ============================================================
   UI COMPARTIDA: TOASTS Y MODAL DE CONFIRMACIÓN
   Reemplazan a alert()/confirm() nativos por algo con la misma
   identidad visual del resto de la app. Vive en su propio archivo
   (en vez de repetirse en reservas.js, script.js y empresa.js)
   porque lo usan los tres: dashboard de estudiante, empresa,
   profesor y admin, más la agenda pública.

   Se inyectan una sola vez en el <body> la primera vez que hacen
   falta, así no hay que tocar cada HTML para tenerlos disponibles;
   con cargar este script alcanza.
   ============================================================ */
function asegurarContenedoresUI() {
  if (!document.getElementById("toast-container")) {
    const cont = document.createElement("div");
    cont.id = "toast-container";
    cont.className = "toast-container";
    document.body.appendChild(cont);
  }

  if (!document.getElementById("modal-overlay")) {
    const overlay = document.createElement("div");
    overlay.id = "modal-overlay";
    overlay.className = "modal-overlay";
    overlay.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <p id="modal-titulo" class="modal-title"></p>
        <p id="modal-texto" class="modal-text"></p>
        <div class="modal-actions">
          <button id="modal-cancelar" type="button" class="btn-secondary">Cancelar</button>
          <button id="modal-confirmar" type="button" class="btn-primary">Confirmar</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (evento) => {
      if (evento.target === overlay) cerrarModal();
    });
  }
}

function mostrarToast(mensaje, tipo = "success") {
  asegurarContenedoresUI();
  const contenedor = document.getElementById("toast-container");

  const toast = document.createElement("div");
  toast.className = `toast toast-${tipo}`;
  const icono = { success: "✓", error: "✕", info: "i" }[tipo] || "✓";
  toast.innerHTML = `<span class="toast-icon">${icono}</span><span>${mensaje}</span>`;
  contenedor.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("toast-saliendo");
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

function cerrarModal() {
  const overlay = document.getElementById("modal-overlay");
  if (overlay) overlay.classList.remove("visible");
}

// alConfirmar corre solo si la persona toca el botón de confirmar.
// textoConfirmar/textoCancelar dejan reusar el mismo modal tanto
// para confirmaciones destructivas ("Rechazar" / "Cancelar") como
// para diálogos informativos con una acción ("Postularme", "Ver
// postulantes"...), sin tener que escribir un modal por pantalla.
// Si se pasa textoCancelar = null, el botón de cancelar se oculta
// (para diálogos de solo información con un único botón de cierre).
function pedirConfirmacion(titulo, texto, alConfirmar, textoConfirmar = "Confirmar", textoCancelar = "Cancelar") {
  asegurarContenedoresUI();
  const overlay = document.getElementById("modal-overlay");
  document.getElementById("modal-titulo").textContent = titulo;
  document.getElementById("modal-texto").textContent = texto;
  overlay.classList.add("visible");

  const btnConfirmar = document.getElementById("modal-confirmar");
  const btnCancelar = document.getElementById("modal-cancelar");
  const nuevoConfirmar = btnConfirmar.cloneNode(true);
  btnConfirmar.replaceWith(nuevoConfirmar);
  const nuevoCancelar = btnCancelar.cloneNode(true);
  btnCancelar.replaceWith(nuevoCancelar);

  nuevoConfirmar.textContent = textoConfirmar;
  if (textoCancelar === null) {
    nuevoCancelar.style.display = "none";
  } else {
    nuevoCancelar.style.display = "";
    nuevoCancelar.textContent = textoCancelar;
  }

  nuevoConfirmar.addEventListener("click", () => {
    cerrarModal();
    if (alConfirmar) alConfirmar();
  });
  nuevoCancelar.addEventListener("click", cerrarModal);
}
