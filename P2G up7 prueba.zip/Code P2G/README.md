# Polo 2 Gestión

Sistema de **reserva de salones, laboratorios y equipos** del Polo Tecnológico,
con un módulo adicional de **pasantías**.

Es un mockup funcional: todo el frontend anda de punta a punta (HTML + CSS +
JavaScript, sin frameworks ni librerías externas), pero todavía **no hay
backend**. Los datos que se ven en pantalla están escritos a mano en los
archivos de `js/`, y la sesión se guarda en el `localStorage` del navegador.
En paralelo, en `db/` está el modelo de datos real en PostgreSQL, que es lo que
ese backend usaría cuando exista.

---

## Cómo probarlo

### Solo el frontend (lo más rápido)

No hace falta instalar nada: alcanza con abrir **`index.html`** en el navegador.

Si tenés Python instalado, conviene levantarlo con un servidor local para que
todo se comporte igual que en producción:

```bash
python3 -m http.server 5500
```

Y entrar a <http://localhost:5500>.

### La base de datos (opcional)

Para ver el modelo de datos andando de verdad hace falta
[Docker](https://www.docker.com/products/docker-desktop/):

```bash
docker compose up -d
```

Eso levanta PostgreSQL y carga solo, en orden, `db/schema.sql` (crea las
tablas) y `db/seed.sql` (mete los datos de prueba). Después queda **Adminer**
en <http://localhost:8080> para mirar las tablas desde el navegador:

| Campo         | Valor        |
| ------------- | ------------ |
| Sistema       | PostgreSQL   |
| Servidor      | `db`         |
| Usuario       | `polotec`    |
| Contraseña    | `polotec`    |
| Base de datos | `polotec`    |

Para borrar todo y volver a arrancar de cero (si editás `schema.sql` o
`seed.sql`, hace falta, porque los scripts de inicio solo corren la primera vez):

```bash
docker compose down -v && docker compose up -d
```

---

## Cuentas de prueba

En `login.html` se entra **solo con el email** (todavía no se validan
contraseñas: eso lo hará el backend comparando hashes, nunca texto plano).
Las cuentas están definidas en `js/sesion.js`:

| Rol        | Email                             | Entra a                       |
| ---------- | --------------------------------- | ----------------------------- |
| Estudiante | `maria@estudiante.com`            | `dashboard-estudiante.html`   |
| Profesor   | `ana@polotec.edu.uy`              | `dashboard-profesor.html`     |
| Empresa    | `contacto@techcorp.com`           | `dashboard-empresa.html`      |
| Empresa    | `contacto@industriasnorte.com`    | igual, pero pendiente de aprobación |
| Admin      | `admin@polotec.edu.uy`            | `dashboard-admin.html`        |

> La cuenta de Industrias del Norte sirve para ver el aviso de "cuenta
> pendiente de aprobación", que es el estado `pending_approval` de la tabla
> `companies`.

La **agenda pública** (`agenda-publica.html`) se puede ver sin iniciar sesión:
es la pantalla para alumnos y público general.

---

## Qué hace cada pantalla

### Reservas (lo principal)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-profesor.html` | Profesor | Pide un salón, laboratorio o equipo. Avisa en vivo si el horario está libre u ocupado antes de enviar, y deja cancelar los pedidos propios que siguen pendientes. |
| `dashboard-admin-reservas.html` | Admin | Aprueba o rechaza los pedidos, con filtros por tipo de recurso, y ve el inventario con la ocupación próxima de cada salón. |
| `agenda-publica.html` | Cualquiera | Muestra solo las reservas ya aprobadas y a futuro, en tabla o agrupadas por día. |

### Pasantías (módulo adicional)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-estudiante.html` | Estudiante | Ve pasantías recomendadas (con filtro por modalidad), se postula y sigue el estado de cada postulación. |
| `dashboard-empresa.html` | Empresa | Publica pasantías y revisa los postulantes de cada una. |
| `dashboard-admin-pasantias.html` | Admin | Aprueba empresas nuevas y agenda las entrevistas. |

`dashboard-admin.html` es el hub: el panel de entrada del admin, que resume las
dos áreas y lleva a cada una.

### El puente entre los dos módulos

Es la parte más interesante del diseño: cuando una postulación llega al estado
`selected`, necesita una sala para la entrevista. En vez de coordinarla por
mail, el admin la reserva con un clic desde
`dashboard-admin-pasantias.html`, y eso genera una reserva normal de la Sala de
Conferencias — el mismo motor, la misma tabla `bookings` — enlazada a la
postulación por `related_application_id`.

---

## Estructura del proyecto

```
Code P2G/
├── index.html                      Landing pública
├── login.html                      Ingreso (por email, mock)
├── registro-*.html                 Registro de estudiante / profesor / empresa
├── agenda-publica.html             Agenda sin login
├── dashboard-*.html                Un panel por rol
│
├── css/
│   └── styles.css                  Todo el diseño, con variables CSS
│
├── js/
│   ├── sesion.js                   Sesión, roles, buscador y menú (compartido)
│   ├── ui.js                       Avisos, modales y preferencias (compartido)
│   ├── perfil.js                   Menú de perfil: editar, configurar, salir (compartido)
│   ├── calendario.js               Calendario anual de reservas (compartido)
│   ├── autenticacion.js            Login y registros
│   ├── reservas.js                 Reservas + paneles del admin
│   ├── script.js                   Panel del estudiante
│   └── empresa.js                  Panel de la empresa
│
├── db/
│   ├── schema.sql                  Tablas, restricciones e índices
│   ├── seed.sql                    Datos de prueba
│   └── consultas-ejemplo.sql       Los SELECT que haría el backend
│
├── img/                            Logo y favicon
└── docker-compose.yml              PostgreSQL + Adminer
```

Cuatro archivos de `js/` se cargan en varias páginas y evitan repetir código:
**`sesion.js`** (control de acceso por rol, buscador del menú y navegación entre
secciones), **`ui.js`** (avisos, modales y preferencias, que reemplazan a los
`alert()` del navegador), **`perfil.js`** (el menú del avatar) y
**`calendario.js`** (el calendario anual).

### Menú de perfil

El avatar del navbar abre un menú con tres opciones:

- **Editar perfil** — cambia el nombre y el email de la cuenta; el saludo y el
  avatar se actualizan al instante, sin recargar.
- **Configuración** — preferencias que el resto de la app respeta de verdad:
  apagar los avisos emergentes, apagar las confirmaciones antes de acciones
  importantes, y elegir con qué vista abre la agenda pública.
- **Cerrar sesión** — ahora pide confirmación (antes el ícono cerraba la sesión
  de un clic, sin avisar).

### Calendario anual

Está en el panel del profesor (solo sus reservas), en el panel de reservas del
admin (todas) y en la agenda pública. Muestra los doce meses juntos, marca los
días con reservas —más intenso cuando hay tres o más—, señala el día de hoy, y
al tocar un día se despliega el detalle abajo. Se puede filtrar por estado y
cambiar de año.

> Las fechas de las reservas de ejemplo se calculan **relativas al día de hoy**
> (`fechaRelativa()` en `js/reservas.js`), no escritas a mano. Así la demo nunca
> se vence: si tuvieran fechas fijas, pasado ese mes la agenda quedaría vacía.

---

## Del mockup al backend

El frontend está escrito pensando en que los datos hoy hardcodeados se van a
reemplazar por llamadas HTTP. Cada acción tiene comentado, en el código, qué
endpoint le correspondería:

| Acción en pantalla | Endpoint futuro |
| ------------------ | --------------- |
| Pedir una reserva | `POST /api/v1/bookings` |
| Aprobar / rechazar reserva | `PATCH /api/v1/bookings/:id/approve` · `/reject` |
| Cancelar reserva propia | `PATCH /api/v1/bookings/:id/cancel` |
| Aprobar / rechazar empresa | `PATCH /api/v1/companies/:id/approve` · `/reject` |
| Publicar pasantía | `POST /api/v1/internships` |
| Postularse | `POST /api/v1/internships/:id/applications` |
| Iniciar sesión | `POST /api/v1/auth/login` (devuelve un JWT) |

Y en `db/consultas-ejemplo.sql` están escritos los `SELECT` que alimentarían
cada pantalla, para poder probarlos a mano en Adminer mientras el backend no
exista.

### Una decisión de diseño que vale la pena mirar

El choque de horarios se valida **dos veces, a propósito**. En el navegador
(`js/reservas.js`) para avisar al instante, y en la base con un
`EXCLUDE constraint` de PostgreSQL sobre `bookings`, que impide físicamente
guardar dos reservas superpuestas del mismo recurso. La validación del
navegador es comodidad; la que garantiza que el dato sea correcto es la de la
base, porque es la única que no se puede saltear.
