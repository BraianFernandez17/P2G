/* ============================================================
   MENÚ DE PERFIL (compartido por todos los dashboards)
   Antes el ícono de usuario del navbar cerraba la sesión de una,
   sin avisar: un clic sin querer y te sacaba. Ahora abre un menú
   con las tres opciones que se esperan de un perfil:

     · Editar perfil   → cambiar nombre y email de la cuenta
     · Configuración   → preferencias que el resto de la app respeta
     · Cerrar sesión   → ahora sí, pidiendo confirmación

   Se arma solo con JavaScript a partir del botón que ya existía
   (id="menu-perfil") en cada página, así no hay que repetir el
   mismo bloque de HTML en los seis dashboards.

   En la versión con backend, guardar el perfil sería
   PATCH /api/v1/users/me en vez de escribir en localStorage.
   ============================================================ */

// Iniciales para el avatar: "Ana Rodríguez" -> "AR"
function inicialesDe(nombre) {
  if (!nombre) return "?";
  return nombre
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((palabra) => palabra[0])
    .join("")
    .toUpperCase();
}

// Íconos del menú: vienen de js/iconos.js; si esa página no lo
// carga, el menú queda solo con texto en vez de romperse.
function iconoMenu(nombre) {
  return typeof icono === "function" ? icono(nombre, 17) : "";
}

/* ------------------------------------------------------------
   EL MENÚ DESPLEGABLE
   ------------------------------------------------------------ */
function construirMenuPerfil() {
  const boton = document.getElementById("menu-perfil");
  if (!boton) return;

  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : "Invitado";
  const email = sesion && sesion.email ? sesion.email : "Sin sesión iniciada";
  const rol = sesion && NOMBRE_DEL_ROL[sesion.role] ? NOMBRE_DEL_ROL[sesion.role] : "";

  // El avatar muestra las iniciales en vez del ícono genérico.
  boton.innerHTML = `<span class="avatar">${inicialesDe(nombre)}</span>`;

  // El menú se cuelga al lado del botón, dentro del mismo
  // contenedor posicionado (.profile-menu-wrapper).
  const contenedor = boton.parentElement;
  let menu = document.getElementById("menu-perfil-desplegable");
  if (!menu) {
    menu = document.createElement("div");
    menu.id = "menu-perfil-desplegable";
    menu.className = "profile-menu";
    contenedor.appendChild(menu);
  }

  menu.innerHTML = `
    <div class="profile-menu-header">
      <span class="avatar avatar-lg">${inicialesDe(nombre)}</span>
      <div class="profile-menu-identity">
        <p class="profile-menu-name">${nombre}</p>
        <p class="profile-menu-email">${email}</p>
        ${rol ? `<span class="profile-menu-role">${rol}</span>` : ""}
      </div>
    </div>
    <button type="button" class="profile-menu-item" data-accion="editar">
      ${iconoMenu("lapiz")} Editar perfil
    </button>
    <button type="button" class="profile-menu-item" data-accion="configuracion">
      ${iconoMenu("ajustes")} Configuración
    </button>
    <button type="button" class="profile-menu-item danger" data-accion="salir">
      ${iconoMenu("salir")} Cerrar sesión
    </button>
  `;

  const alternarMenu = (abrir) => {
    const visible = abrir === undefined ? !menu.classList.contains("visible") : abrir;
    menu.classList.toggle("visible", visible);
    boton.setAttribute("aria-expanded", String(visible));
  };

  // Estos manejadores se enganchan UNA sola vez. Antes se volvían a
  // enganchar cada vez que se refrescaba el perfil (por ejemplo, al
  // guardar "Editar perfil"): quedaban dos que abrían y cerraban el
  // menú en el mismo clic, y el avatar parecía no responder.
  if (!boton.dataset.enganchado) {
    boton.dataset.enganchado = "si";
    boton.setAttribute("aria-haspopup", "true");
    boton.setAttribute("aria-expanded", "false");
    boton.addEventListener("click", (evento) => {
      evento.stopPropagation();
      alternarMenu();
    });

    // Clic afuera o Escape: se cierra, como cualquier menú.
    document.addEventListener("click", (evento) => {
      if (!contenedor.contains(evento.target)) alternarMenu(false);
    });
    document.addEventListener("keydown", (evento) => {
      if (evento.key === "Escape") alternarMenu(false);
    });
  }

  menu.querySelectorAll(".profile-menu-item").forEach((item) => {
    item.addEventListener("click", () => {
      alternarMenu(false);
      if (item.dataset.accion === "editar") abrirEditarPerfil();
      if (item.dataset.accion === "configuracion") abrirConfiguracion();
      if (item.dataset.accion === "salir") confirmarCerrarSesion();
    });
  });
}

/* ------------------------------------------------------------
   EDITAR PERFIL
   Cambia el nombre y el email de la sesión. El nombre se ve al
   toque en el saludo del panel y en el avatar, sin recargar.
   ------------------------------------------------------------ */
function abrirEditarPerfil() {
  const sesion = obtenerSesion();
  if (!sesion) {
    mostrarToast("Iniciá sesión para editar tu perfil.", "error");
    return;
  }

  abrirModal({
    titulo: "Editar perfil",
    cuerpoHTML: `
      <div class="form-group">
        <label class="form-label" for="perfil-nombre">Nombre</label>
        <input type="text" id="perfil-nombre" class="form-input" value="${sesion.name || ""}" />
      </div>
      <div class="form-group">
        <label class="form-label" for="perfil-email">Email</label>
        <input type="email" id="perfil-email" class="form-input" value="${sesion.email || ""}" />
      </div>
      <p class="form-hint">Tu rol (${NOMBRE_DEL_ROL[sesion.role] || sesion.role}) lo administra el Polo y no se puede cambiar desde acá.</p>
    `,
    textoConfirmar: "Guardar cambios",
    alConfirmar: (cuerpo) => {
      const nombre = cuerpo.querySelector("#perfil-nombre").value.trim();
      const email = cuerpo.querySelector("#perfil-email").value.trim();

      if (!nombre) {
        mostrarToast("El nombre no puede quedar vacío.", "error");
        return false; // deja el modal abierto
      }
      // Validación simple: que tenga algo, una arroba y un punto.
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        mostrarToast("Revisá el email: no parece válido.", "error");
        return false;
      }

      // Versión real: PATCH /api/v1/users/me
      guardarSesion({ ...sesion, name: nombre, email });
      refrescarDatosDePerfil();
      mostrarToast("Perfil actualizado.", "success");
    },
  });
}

// Vuelve a pintar lo que depende del nombre/email sin recargar la
// página: el avatar, el menú y el saludo de cada panel.
function refrescarDatosDePerfil() {
  construirMenuPerfil();

  const sesion = obtenerSesion();
  const saludoEl = document.getElementById("saludo");
  if (saludoEl && sesion) {
    saludoEl.textContent = `Hola, ${sesion.name}`;
  }
}

/* ------------------------------------------------------------
   CONFIGURACIÓN
   Preferencias reales, no decorativas: las lee js/ui.js
   (obtenerPreferencias) y cambian cómo se comporta la app.
   ------------------------------------------------------------ */
function abrirConfiguracion() {
  const preferencias = obtenerPreferencias();

  abrirModal({
    titulo: "Configuración",
    cuerpoHTML: `
      <label class="switch-row">
        <input type="checkbox" id="pref-avisos" ${preferencias.avisos ? "checked" : ""} />
        <span>
          <strong>Avisos emergentes</strong>
          <small>Los mensajes de "reserva enviada", "perfil actualizado", etc.</small>
        </span>
      </label>

      <label class="switch-row">
        <input type="checkbox" id="pref-confirmaciones" ${preferencias.confirmaciones ? "checked" : ""} />
        <span>
          <strong>Pedir confirmación</strong>
          <small>Preguntar antes de cancelar, rechazar o cerrar sesión.</small>
        </span>
      </label>

      <label class="switch-row">
        <input type="checkbox" id="pref-asistente" ${preferencias.asistente ? "checked" : ""} />
        <span>
          <strong>Asistente de voz</strong>
          <small>El botón del borde derecho que te guía por el sitio.</small>
        </span>
      </label>

      <label class="switch-row">
        <input type="checkbox" id="pref-voz" ${preferencias.vozAsistente ? "checked" : ""} />
        <span>
          <strong>Respuestas habladas</strong>
          <small>Que el asistente conteste en voz alta, no solo por escrito.</small>
        </span>
      </label>

      <div class="form-group" style="margin-top: 14px;">
        <label class="form-label" for="pref-tema">Apariencia (Modo Oscuro)</label>
        <select id="pref-tema" class="form-select">
          <option value="auto" ${preferencias.tema === "auto" ? "selected" : ""}>Automático del sistema</option>
          <option value="claro" ${preferencias.tema === "claro" ? "selected" : ""}>Claro</option>
          <option value="oscuro" ${preferencias.tema === "oscuro" ? "selected" : ""}>Oscuro</option>
        </select>
      </div>

      <div class="form-group" style="margin-top: 14px;">
        <label class="form-label" for="pref-vista-agenda">Vista inicial de la agenda pública</label>
        <select id="pref-vista-agenda" class="form-select">
          <option value="tabla" ${preferencias.vistaAgenda === "tabla" ? "selected" : ""}>Tabla</option>
          <option value="dia" ${preferencias.vistaAgenda === "dia" ? "selected" : ""}>Por día</option>
        </select>
      </div>
    `,
    textoConfirmar: "Guardar",
    alConfirmar: (cuerpo) => {
      const nuevoTema = cuerpo.querySelector("#pref-tema").value;
      guardarPreferencias({
        avisos: cuerpo.querySelector("#pref-avisos").checked,
        confirmaciones: cuerpo.querySelector("#pref-confirmaciones").checked,
        asistente: cuerpo.querySelector("#pref-asistente").checked,
        vozAsistente: cuerpo.querySelector("#pref-voz").checked,
        vistaAgenda: cuerpo.querySelector("#pref-vista-agenda").value,
        tema: nuevoTema,
      });
      aplicarTemaVisual(nuevoTema);
      mostrarToast("Configuración guardada.", "success");

      // El asistente aparece o desaparece al instante, sin recargar.
      const asistenteEl = document.getElementById("asistente-voz");
      const quiereAsistente = cuerpo.querySelector("#pref-asistente").checked;
      if (!quiereAsistente && asistenteEl) asistenteEl.remove();
      if (quiereAsistente && !asistenteEl && typeof construirAsistente === "function") {
        construirAsistente();
      }
    },
  });
}

/* ------------------------------------------------------------
   CERRAR SESIÓN
   Ahora pregunta antes (salvo que la persona haya apagado las
   confirmaciones en Configuración).
   ------------------------------------------------------------ */
function confirmarCerrarSesion() {
  pedirConfirmacion(
    "Cerrar sesión",
    "Vas a volver a la pantalla de inicio de sesión.",
    () => cerrarSesion(),
    "Cerrar sesión"
  );
}

document.addEventListener("DOMContentLoaded", construirMenuPerfil);
