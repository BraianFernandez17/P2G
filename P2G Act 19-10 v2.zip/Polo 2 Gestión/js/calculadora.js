/* ============================================================
   CALCULADORA CIENTÍFICA
   Vive en el espacio de cada salón (salon.html). Dos partes:

   1. evaluarExpresion(): el motor. Lee el texto que escribió la
      persona y lo calcula con un analizador propio. NO usa eval()
      ni new Function(): lo que se escribe nunca se ejecuta como
      código, solo se interpreta como números y operaciones.

   2. montarCalculadora(): la pantalla (teclado de botones, historial
      y soporte de teclado físico).

   Gramática (de menor a mayor precedencia):
     expresion := termino (("+" | "-") termino)*
     termino   := unario (("*" | "/" | <multiplicación implícita>) unario)*
     unario    := ("-" | "+") unario | potencia
     potencia  := posfijo ("^" unario)?          (asocia a la derecha)
     posfijo   := primario ("!" | "%")*
     primario  := número | constante | función | "(" expresion ")"

   Por eso -2^2 da -4 (como en cualquier calculadora científica),
   2^3^2 da 512 y 2π, 3(4) o 2sin(30) multiplican solos.
   ============================================================ */

// sin(180°) en una computadora da 1.2e-16 y no 0 (el número π no cabe
// exacto en la máquina). Para que la calculadora diga lo que espera un
// alumno de física, un resultado ínfimo de seno/coseno en un ángulo
// "normal" se redondea a 0.
function limpiarTrig(r, anguloRad) {
  return Math.abs(r) < 1e-12 && Math.abs(anguloRad) > 1e-6 ? 0 : r;
}

const FUNCIONES_CALCULADORA = {
  sin: { f: (x, g) => { const a = g ? aRadianes(x) : x; return limpiarTrig(Math.sin(a), a); } },
  cos: { f: (x, g) => { const a = g ? aRadianes(x) : x; return limpiarTrig(Math.cos(a), a); } },
  tan: {
    f: (x, g) => {
      const a = g ? aRadianes(x) : x;
      return limpiarTrig(Math.tan(a), a);
    },
    // tan(90°), tan(270°)...: el coseno es 0, así que no está definida.
    dominio: (x, g) => Math.abs(Math.cos(g ? aRadianes(x) : x)) > 1e-12,
  },
  asin: { f: (x, g) => (g ? aGrados(Math.asin(x)) : Math.asin(x)), dominio: (x) => x >= -1 && x <= 1 },
  acos: { f: (x, g) => (g ? aGrados(Math.acos(x)) : Math.acos(x)), dominio: (x) => x >= -1 && x <= 1 },
  atan: { f: (x, g) => (g ? aGrados(Math.atan(x)) : Math.atan(x)) },
  ln: { f: (x) => Math.log(x), dominio: (x) => x > 0 },
  log: { f: (x) => Math.log10(x), dominio: (x) => x > 0 },
  sqrt: { f: (x) => Math.sqrt(x), dominio: (x) => x >= 0 },
  abs: { f: (x) => Math.abs(x) },
};

const CONSTANTES_CALCULADORA = { pi: Math.PI, e: Math.E };

function aRadianes(grados) {
  return (grados * Math.PI) / 180;
}
function aGrados(radianes) {
  return (radianes * 180) / Math.PI;
}

class ErrorDeCalculo extends Error {}

// Pasa el texto a una lista de "fichas" (números, nombres, símbolos).
function tokenizarExpresion(texto) {
  const limpio = texto
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/[−–]/g, "-")
    .replace(/π/g, "pi")
    .replace(/√/g, "sqrt")
    .replace(/,/g, ".");

  const fichas = [];
  let i = 0;
  while (i < limpio.length) {
    const c = limpio[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    // Número. Solo la "E" mayúscula es exponente (6.02E23): la "e"
    // minúscula es la constante de Euler, así que "2e" es 2 × e.
    const numero = limpio.slice(i).match(/^(\d+\.?\d*|\.\d+)(E[+-]?\d+)?/);
    if (numero) {
      fichas.push({ tipo: "num", valor: parseFloat(numero[0]) });
      i += numero[0].length;
      continue;
    }
    const nombre = limpio.slice(i).match(/^[A-Za-z]+/);
    if (nombre) {
      fichas.push({ tipo: "nombre", valor: nombre[0].toLowerCase() });
      i += nombre[0].length;
      continue;
    }
    if ("+-*/^!%()".includes(c)) {
      fichas.push({ tipo: "sim", valor: c });
      i++;
      continue;
    }
    throw new ErrorDeCalculo(`Símbolo no válido: "${c}"`);
  }
  return fichas;
}

function factorial(n) {
  if (!Number.isInteger(n) || n < 0) throw new ErrorDeCalculo("El factorial pide un entero mayor o igual a 0.");
  if (n > 170) throw new ErrorDeCalculo("El resultado es demasiado grande.");
  let r = 1;
  for (let k = 2; k <= n; k++) r *= k;
  return r;
}

/**
 * Calcula una expresión.
 * @param {string} texto   Ej: "2*sin(30)+3^2"
 * @param {boolean} grados true = ángulos en grados, false = radianes
 * @param {number} ans     Último resultado (se usa con la palabra "Ans")
 * @returns {number}
 * @throws {ErrorDeCalculo} con un mensaje pensado para mostrarse en pantalla
 */
function evaluarExpresion(texto, grados = true, ans = 0) {
  const fichas = tokenizarExpresion(texto);
  if (fichas.length === 0) throw new ErrorDeCalculo("Escribí una operación.");
  let pos = 0;

  const mirar = () => fichas[pos];
  const esSim = (s) => mirar() && mirar().tipo === "sim" && mirar().valor === s;
  const empiezaPrimario = () => {
    const f = mirar();
    return !!f && (f.tipo === "num" || f.tipo === "nombre" || (f.tipo === "sim" && f.valor === "("));
  };

  function expresion() {
    let v = termino();
    while (esSim("+") || esSim("-")) {
      const op = fichas[pos++].valor;
      const d = termino();
      v = op === "+" ? v + d : v - d;
    }
    return v;
  }

  function termino() {
    let v = unario();
    for (;;) {
      if (esSim("*") || esSim("/")) {
        const op = fichas[pos++].valor;
        const d = unario();
        if (op === "/" && d === 0) throw new ErrorDeCalculo("No se puede dividir por cero.");
        v = op === "*" ? v * d : v / d;
      } else if (empiezaPrimario()) {
        v = v * unario(); // multiplicación implícita: 2π, 3(4), 2sin(30)
      } else {
        return v;
      }
    }
  }

  function unario() {
    if (esSim("-")) {
      pos++;
      return -unario();
    }
    if (esSim("+")) {
      pos++;
      return unario();
    }
    return potencia();
  }

  function potencia() {
    const base = posfijo();
    if (esSim("^")) {
      pos++;
      const exp = unario();
      const r = Math.pow(base, exp);
      if (Number.isNaN(r)) throw new ErrorDeCalculo("Esa potencia no existe en los reales.");
      return r;
    }
    return base;
  }

  function posfijo() {
    let v = primario();
    while (esSim("!") || esSim("%")) {
      v = fichas[pos++].valor === "!" ? factorial(v) : v / 100;
    }
    return v;
  }

  function primario() {
    const f = mirar();
    if (!f) throw new ErrorDeCalculo("La expresión está incompleta.");

    if (f.tipo === "num") {
      pos++;
      return f.valor;
    }

    if (f.tipo === "nombre") {
      pos++;
      if (f.valor === "ans") return ans;
      if (f.valor in CONSTANTES_CALCULADORA) return CONSTANTES_CALCULADORA[f.valor];
      const fn = FUNCIONES_CALCULADORA[f.valor];
      if (!fn) throw new ErrorDeCalculo(`No conozco "${f.valor}".`);
      // sin(30) con paréntesis, o sin 30 sin ellos.
      let arg;
      if (esSim("(")) {
        pos++;
        arg = expresion();
        if (!esSim(")")) throw new ErrorDeCalculo("Falta cerrar un paréntesis.");
        pos++;
      } else {
        arg = potencia();
      }
      if (fn.dominio && !fn.dominio(arg, grados)) throw new ErrorDeCalculo(`${f.valor}: el valor está fuera de su dominio.`);
      return fn.f(arg, grados);
    }

    if (f.tipo === "sim" && f.valor === "(") {
      pos++;
      const v = expresion();
      if (!esSim(")")) throw new ErrorDeCalculo("Falta cerrar un paréntesis.");
      pos++;
      return v;
    }

    throw new ErrorDeCalculo(`No esperaba "${f.valor}" acá.`);
  }

  const resultado = expresion();
  if (pos < fichas.length) {
    const sobrante = fichas[pos].valor;
    throw new ErrorDeCalculo(sobrante === ")" ? "Sobra un paréntesis." : `No esperaba "${sobrante}" acá.`);
  }
  if (!Number.isFinite(resultado)) throw new ErrorDeCalculo("El resultado no es un número finito.");
  return resultado;
}

// 0.1 + 0.2 no debe verse como 0.30000000000000004, ni sin(180°)
// como 1.2e-16: se redondea a 12 cifras significativas, y los
// números muy grandes o muy chicos se muestran en notación 6.02E23
// (que la misma calculadora sabe volver a leer).
function formatearResultado(n) {
  if (n === 0) return "0";
  const redondeado = parseFloat(n.toPrecision(12));
  const abs = Math.abs(redondeado);
  if (abs >= 1e12 || abs < 1e-6) {
    return redondeado.toExponential().replace("e+", "E").replace("e-", "E-");
  }
  return String(redondeado);
}

/* ------------------------------------------------------------
   PANTALLA
   ------------------------------------------------------------ */
// [texto del botón, qué inserta, clase extra, etiqueta accesible, columnas que ocupa]
const TECLAS_CALCULADORA = [
  ["modo", null, "calc-tecla-modo", "Cambiar entre grados y radianes"],
  ["sin", "sin(", "calc-tecla-fn", "Seno"],
  ["cos", "cos(", "calc-tecla-fn", "Coseno"],
  ["tan", "tan(", "calc-tecla-fn", "Tangente"],
  ["AC", null, "calc-tecla-borrar", "Borrar todo"],
  ["⌫", null, "calc-tecla-borrar", "Borrar el último carácter"],

  ["π", "π", "calc-tecla-fn", "Pi"],
  ["sin⁻¹", "asin(", "calc-tecla-fn", "Arco seno"],
  ["cos⁻¹", "acos(", "calc-tecla-fn", "Arco coseno"],
  ["tan⁻¹", "atan(", "calc-tecla-fn", "Arco tangente"],
  ["(", "(", "calc-tecla-fn", "Abrir paréntesis"],
  [")", ")", "calc-tecla-fn", "Cerrar paréntesis"],

  ["e", "e", "calc-tecla-fn", "Número e"],
  ["ln", "ln(", "calc-tecla-fn", "Logaritmo natural"],
  ["log", "log(", "calc-tecla-fn", "Logaritmo en base 10"],
  ["√", "√(", "calc-tecla-fn", "Raíz cuadrada"],
  ["xʸ", "^", "calc-tecla-fn", "Elevado a"],
  ["÷", "÷", "calc-tecla-op", "Dividir"],

  ["Ans", "Ans", "calc-tecla-fn", "Último resultado"],
  ["7", "7", "", "7"],
  ["8", "8", "", "8"],
  ["9", "9", "", "9"],
  ["n!", "!", "calc-tecla-fn", "Factorial"],
  ["×", "×", "calc-tecla-op", "Multiplicar"],

  ["EXP", "E", "calc-tecla-fn", "Por diez a la, notación científica"],
  ["4", "4", "", "4"],
  ["5", "5", "", "5"],
  ["6", "6", "", "6"],
  ["x²", "^2", "calc-tecla-fn", "Al cuadrado"],
  ["−", "−", "calc-tecla-op", "Restar"],

  ["10ˣ", "10^", "calc-tecla-fn", "Diez elevado a"],
  ["1", "1", "", "1"],
  ["2", "2", "", "2"],
  ["3", "3", "", "3"],
  [".", ".", "", "Punto decimal"],
  ["+", "+", "calc-tecla-op", "Sumar"],

  ["0", "0", "calc-tecla-ancha", "0", 3],
  ["=", null, "calc-tecla-igual", "Calcular", 3],
];

function montarCalculadora(contenedor) {
  if (!contenedor) return;

  let grados = true;
  let ultimo = 0;
  let historial = [];

  contenedor.innerHTML = `
    <div class="calc">
      <div class="calc-pantalla">
        <label class="calc-etiqueta" for="calc-entrada">Operación</label>
        <input id="calc-entrada" class="calc-entrada" type="text" inputmode="none"
          autocomplete="off" autocapitalize="off" spellcheck="false"
          placeholder="Ej: 9,8 × 2,5² ÷ 2" />
        <p id="calc-resultado" class="calc-resultado" role="status" aria-live="polite">0</p>
        <p id="calc-error" class="calc-error" hidden></p>
      </div>
      <div class="calc-teclas" id="calc-teclas">
        ${TECLAS_CALCULADORA.map(([texto, , clase, etiqueta, ancho], i) =>
          `<button type="button" class="calc-tecla ${clase}" data-i="${i}" aria-label="${etiqueta}"${
            ancho ? ` style="grid-column: span ${ancho}"` : ""
          }>${texto}</button>`
        ).join("")}
      </div>
      <ol class="calc-historial" id="calc-historial" aria-label="Últimos cálculos"></ol>
    </div>
  `;

  const entrada = contenedor.querySelector("#calc-entrada");
  const resultadoEl = contenedor.querySelector("#calc-resultado");
  const errorEl = contenedor.querySelector("#calc-error");
  const historialEl = contenedor.querySelector("#calc-historial");
  const botonModo = contenedor.querySelector(".calc-tecla-modo");

  const pintarModo = () => {
    botonModo.textContent = grados ? "Deg" : "Rad";
    botonModo.setAttribute("aria-pressed", String(grados));
    botonModo.title = grados ? "Ángulos en grados (tocá para pasar a radianes)" : "Ángulos en radianes (tocá para pasar a grados)";
  };

  const mostrarError = (mensaje) => {
    errorEl.textContent = mensaje;
    errorEl.hidden = !mensaje;
  };

  // Inserta en la posición del cursor, sin abrir el teclado del celular.
  const insertar = (texto) => {
    const ini = entrada.selectionStart ?? entrada.value.length;
    const fin = entrada.selectionEnd ?? entrada.value.length;
    entrada.value = entrada.value.slice(0, ini) + texto + entrada.value.slice(fin);
    const nueva = ini + texto.length;
    entrada.setSelectionRange(nueva, nueva);
    mostrarError("");
  };

  const borrarUno = () => {
    const ini = entrada.selectionStart ?? entrada.value.length;
    const fin = entrada.selectionEnd ?? entrada.value.length;
    if (ini !== fin) {
      entrada.value = entrada.value.slice(0, ini) + entrada.value.slice(fin);
      entrada.setSelectionRange(ini, ini);
    } else if (ini > 0) {
      entrada.value = entrada.value.slice(0, ini - 1) + entrada.value.slice(ini);
      entrada.setSelectionRange(ini - 1, ini - 1);
    }
    mostrarError("");
  };

  const pintarHistorial = () => {
    historialEl.innerHTML = historial
      .map((h) => `<li><span class="calc-hist-expr"></span><span class="calc-hist-res"></span></li>`)
      .join("");
    // textContent y no innerHTML: lo que se escribe nunca se interpreta como HTML.
    historialEl.querySelectorAll("li").forEach((li, i) => {
      li.querySelector(".calc-hist-expr").textContent = historial[i].expr;
      li.querySelector(".calc-hist-res").textContent = `= ${historial[i].res}`;
    });
  };

  const calcular = () => {
    const texto = entrada.value.trim();
    if (!texto) return;
    try {
      const valor = evaluarExpresion(texto, grados, ultimo);
      const formateado = formatearResultado(valor);
      ultimo = parseFloat(formateado) || 0;
      resultadoEl.textContent = formateado;
      mostrarError("");
      historial = [{ expr: texto, res: formateado }, ...historial].slice(0, 5);
      pintarHistorial();
    } catch (error) {
      if (!(error instanceof ErrorDeCalculo)) throw error;
      mostrarError(error.message);
    }
  };

  contenedor.querySelector("#calc-teclas").addEventListener("click", (evento) => {
    const boton = evento.target.closest("button[data-i]");
    if (!boton) return;
    const [texto, inserta] = TECLAS_CALCULADORA[Number(boton.dataset.i)];

    if (texto === "AC") {
      entrada.value = "";
      resultadoEl.textContent = "0";
      mostrarError("");
    } else if (texto === "⌫") {
      borrarUno();
    } else if (texto === "=") {
      calcular();
    } else if (boton.classList.contains("calc-tecla-modo")) {
      grados = !grados;
      pintarModo();
    } else {
      insertar(inserta);
    }
  });

  entrada.addEventListener("keydown", (evento) => {
    if (evento.key === "Enter") {
      evento.preventDefault();
      calcular();
    }
  });
  entrada.addEventListener("input", () => mostrarError(""));

  pintarModo();
}

// Para poder probar el motor desde Node (ver README); en el navegador no hace nada.
if (typeof module !== "undefined") {
  module.exports = { evaluarExpresion, formatearResultado, ErrorDeCalculo };
}
