/* ============================================================
   DASHBOARD DE EMPRESA (mock)
   Mismo patrón que estudiante.js y reservas.js: datos de ejemplo
   a mano + funciones que pintan el HTML, para poder ver la
   pantalla funcionando sin backend todavía.
   ============================================================ */

// Rubros posibles de una empresa (mismo CHECK que companies.sector
// en db/schema.sql), con una etiqueta linda para mostrar en pantalla.
const ETIQUETA_SECTOR = {
  tecnologia: "Tecnología",
  industria: "Industria",
  agropecuaria: "Agropecuaria",
  comercio: "Comercio",
  servicios: "Servicios",
  educacion: "Educación",
  salud: "Salud",
  construccion: "Construcción",
  turismo: "Turismo",
  logistica: "Logística",
};

// Las pasantías y los postulantes ya no están acá: salen de la bolsa
// compartida (js/bolsa.js), la misma que lee el panel del estudiante.
// Así, cuando la empresa acepta a alguien, el estudiante lo ve.
const EMPRESA_DEMO = { email: "contacto@techcorp.com", name: "TechCorp Tacuarembó" };

function empresaActual() {
  const sesion = obtenerSesion();
  return sesion && sesion.role === "company" ? sesion : EMPRESA_DEMO;
}

function misPasantias() {
  return pasantiasDeEmpresa(empresaActual().email);
}

// Todas las postulaciones a pasantías de esta empresa, con el perfil
// del estudiante y la pasantía ya resueltos.
function misPostulantes() {
  return misPasantias().flatMap((pasantia) =>
    postulacionesDePasantia(pasantia.id).map((postulacion) => ({
      ...postulacion,
      pasantia,
      perfil: perfilDe(postulacion.estudianteEmail),
    }))
  );
}

function pintarSaludoEmpresa() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;

  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : "TechCorp Tacuarembó";
  saludoEl.textContent = `Hola, ${nombre}`;
}

// Muestra el rubro de la empresa como chip, al lado del saludo.
function pintarSectorEmpresa() {
  const sectorEl = document.getElementById("sector-empresa");
  if (!sectorEl) return;

  const sesion = obtenerSesion();
  const sector = sesion && sesion.sector ? sesion.sector : "servicios";
  sectorEl.textContent = ETIQUETA_SECTOR[sector] || sector;
}

// Este banner es el mismo caso de "pending_approval" que ya
// describe schema.sql para companies: mientras el admin no
// apruebe la cuenta, se lo recordamos en vez de escondérselo.
function pintarAvisoPendiente() {
  const avisoEl = document.getElementById("aviso-pendiente");
  if (!avisoEl) return;

  const sesion = obtenerSesion();
  avisoEl.style.display =
    sesion && sesion.status === "pending_approval" ? "block" : "none";
}

// Los tres números salen de la bolsa: se actualizan solos al
// publicar una pasantía o al aceptar y rechazar postulantes.
function pintarEstadisticasEmpresa() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const postulantes = misPostulantes();
  const estadisticas = [
    { icono: icono("megafono"), tono: "accent", etiqueta: "Pasantías publicadas", valor: misPasantias().length },
    { icono: icono("birrete"), tono: "info", etiqueta: "Postulantes por revisar", valor: postulantes.filter((p) => p.estado === "pending").length },
    { icono: icono("tilde"), tono: "success", etiqueta: "Seleccionados", valor: postulantes.filter((p) => p.estado === "approved").length },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   MIS PASANTÍAS (con filtro por modalidad, igual idea que el
   dashboard del estudiante)
   ============================================================ */
let filtroModalidadEmpresa = "todas";

function pintarFiltrosModalidadEmpresa() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-modalidad-empresa");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-modalidad-empresa";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const modalidades = ["todas", ...new Set(misPasantias().map((p) => p.modalidad))];
  filtrosEl.innerHTML = modalidades
    .map(
      (modalidad) => `
      <button type="button" class="filter-chip ${filtroModalidadEmpresa === modalidad ? "active" : ""}" data-modalidad="${modalidad}">
        ${modalidad === "todas" ? "Todas" : modalidad}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-modalidad]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroModalidadEmpresa = boton.dataset.modalidad;
      pintarMisPasantias();
    });
  });
}

function pintarMisPasantias() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  pintarFiltrosModalidadEmpresa();

  const pasantias =
    filtroModalidadEmpresa === "todas"
      ? misPasantias()
      : misPasantias().filter((p) => p.modalidad === filtroModalidadEmpresa);

  if (pasantias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no publicaste ninguna pasantía ${
      filtroModalidadEmpresa === "todas" ? "" : filtroModalidadEmpresa.toLowerCase()
    }.</p>`;
    return;
  }

  listaEl.innerHTML = pasantias
    .map((pasantia) => {
      const postulantes = postulacionesDePasantia(pasantia.id);
      const porRevisar = postulantes.filter((p) => p.estado === "pending").length;
      return `
      <div class="internship-card">
        <div>
          <p class="internship-title">${escaparHTML(pasantia.titulo)}</p>
          <p class="internship-meta">
            ${escaparHTML(pasantia.modalidad)} · ${pasantia.duracionMeses} meses · ${postulantes.length} postulante${postulantes.length === 1 ? "" : "s"}${porRevisar ? ` (${porRevisar} por revisar)` : ""}
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">Ver postulantes</button>
      </div>
    `;
    })
    .join("");

  listaEl.querySelectorAll("button[data-pasantia-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPostulantes(Number(boton.dataset.pasantiaId));
    });
  });
}

/* ============================================================
   POSTULANTES
   "Ver postulantes" de una pasantía baja hasta esta sección ya
   filtrada por esa pasantía. Cada fila abre la ficha completa del
   estudiante, donde se lo acepta o se lo rechaza.
   ============================================================ */
let filtroPostulantes = "todas";

function verPostulantes(pasantiaId) {
  filtroPostulantes = String(pasantiaId);
  pintarPostulantes();
  document.getElementById("seccion-postulantes")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function chipsCortos(perfil, cantidad = 3) {
  if (!perfil.capacidades.length) return "";
  const resto = perfil.capacidades.length - cantidad;
  return `<ul class="perfil-chips perfil-chips-chicos">${perfil.capacidades
    .slice(0, cantidad)
    .map((c) => `<li>${escaparHTML(c)}</li>`)
    .join("")}${resto > 0 ? `<li class="perfil-chip-mas">+${resto}</li>` : ""}</ul>`;
}

function pintarPostulantes() {
  const listaEl = document.getElementById("lista-postulantes");
  if (!listaEl) return;

  // Filtros: todas las pasantías o una sola
  let filtrosEl = document.getElementById("filtros-postulantes");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-postulantes";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }
  const pasantias = misPasantias();
  filtrosEl.innerHTML = [{ id: "todas", titulo: "Todas" }, ...pasantias]
    .map(
      (p) => `<button type="button" class="filter-chip ${filtroPostulantes === String(p.id) ? "active" : ""}" data-filtro="${p.id}">${escaparHTML(p.titulo)}</button>`
    )
    .join("");
  filtrosEl.querySelectorAll("button[data-filtro]").forEach((boton) =>
    boton.addEventListener("click", () => {
      filtroPostulantes = boton.dataset.filtro;
      pintarPostulantes();
    })
  );

  // Primero los que esperan respuesta
  const orden = { pending: 0, approved: 1, rejected: 2 };
  const postulantes = misPostulantes()
    .filter((p) => filtroPostulantes === "todas" || String(p.pasantiaId) === filtroPostulantes)
    .sort((a, b) => orden[a.estado] - orden[b.estado]);

  if (postulantes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía nadie se postuló${
      filtroPostulantes === "todas" ? " a tus pasantías" : " a esta pasantía"
    }. Mientras tanto, podés buscar en los perfiles de estudiantes.</p>`;
    return;
  }

  listaEl.innerHTML = postulantes
    .map((p) => {
      const meta = [p.pasantia.titulo, p.perfil.orientacion, p.perfil.nivel].filter(Boolean).map(escaparHTML).join(" · ");
      return `
      <div class="booking-card postulante-fila">
        <span class="avatar postulante-avatar" aria-hidden="true">${escaparHTML(inicialesPerfil(p.perfil.nombre))}</span>
        <div class="postulante-datos">
          <p class="booking-card-title">${escaparHTML(p.perfil.nombre)}</p>
          <p class="booking-card-meta">${meta}</p>
          ${chipsCortos(p.perfil)}
        </div>
        <div class="booking-card-actions">
          <span class="status-badge ${p.estado}">${ESTADO_POSTULACION[p.estado]}</span>
          <button type="button" class="btn-view" data-ver-perfil="${escaparHTML(p.estudianteEmail)}">Ver perfil</button>
          ${
            p.estado === "pending"
              ? `<button type="button" class="btn-approve" data-decidir="approved" data-email="${escaparHTML(p.estudianteEmail)}" data-pasantia="${p.pasantiaId}">Aceptar</button>
                 <button type="button" class="btn-reject" data-decidir="rejected" data-email="${escaparHTML(p.estudianteEmail)}" data-pasantia="${p.pasantiaId}">Rechazar</button>`
              : ""
          }
        </div>
      </div>`;
    })
    .join("");
}

// Aceptar o rechazar, desde la lista o desde la ficha.
function decidir(email, pasantiaId, estado) {
  const pasantia = pasantiaPorId(pasantiaId);
  const perfil = perfilDe(email);
  const hacer = () => {
    // Versión real: PATCH /api/v1/applications/:id  { status }
    decidirPostulacion(email, pasantiaId, estado);
    repintarTodo();
    mostrarToast(
      estado === "approved"
        ? `Aceptaste a ${perfil.nombre} para "${pasantia.titulo}". Ya lo ve en su panel.`
        : `Rechazaste la postulación de ${perfil.nombre}.`,
      estado === "approved" ? "success" : "info"
    );
  };
  // Rechazar pide confirmación (no se ve bien deshacerlo); aceptar no.
  if (estado === "rejected") {
    pedirConfirmacion("Rechazar postulación", `¿Rechazar a ${perfil.nombre} para "${pasantia.titulo}"?`, hacer, "Rechazar");
  } else {
    hacer();
  }
}

/* ============================================================
   FICHA DEL ESTUDIANTE
   El perfil completo y, abajo, una fila por cada pasantía de la
   empresa con el estado de este estudiante en ella: así se lo
   puede aceptar para la que se postuló o seleccionar para otra.
   ============================================================ */
function htmlDecisiones(email) {
  const filas = misPasantias().map((pasantia) => {
    const postulacion = postulacionDe(email, pasantia.id);
    const estado = postulacion ? postulacion.estado : null;
    const etiqueta = estado ? ESTADO_POSTULACION[estado] : "No se postuló";
    const botones =
      estado === "approved"
        ? ""
        : `<button type="button" class="btn-approve" data-decidir="approved" data-email="${escaparHTML(email)}" data-pasantia="${pasantia.id}">${
            estado ? "Aceptar" : "Seleccionar"
          }</button>${
            estado === "pending"
              ? `<button type="button" class="btn-reject" data-decidir="rejected" data-email="${escaparHTML(email)}" data-pasantia="${pasantia.id}">Rechazar</button>`
              : ""
          }`;
    return `
      <li class="decision-fila">
        <div>
          <p class="decision-titulo">${escaparHTML(pasantia.titulo)}</p>
          <span class="status-badge ${estado || "cancelled"}">${etiqueta}</span>
        </div>
        <div class="decision-botones">${botones}</div>
      </li>`;
  });
  return `
    <section class="perfil-decisiones" aria-label="Tus pasantías">
      <h3 class="perfil-subtitulo">Tus pasantías</h3>
      ${filas.length ? `<ul>${filas.join("")}</ul>` : `<p class="perfil-vacio">Publicá una pasantía para poder seleccionar estudiantes.</p>`}
    </section>`;
}

function verPerfilEstudiante(email) {
  const perfil = perfilDe(email);
  abrirModal({
    titulo: "Perfil del estudiante",
    amplio: true,
    textoConfirmar: null,
    textoCancelar: "Cerrar",
    cuerpoHTML: `<div class="perfil-ficha">${htmlPerfil(perfil)}</div><div id="decisiones-ficha" data-email="${escaparHTML(email)}">${htmlDecisiones(email)}</div>`,
  });
}

/* ============================================================
   DIRECTORIO DE PERFILES
   ============================================================ */
let busquedaPerfiles = "";

function pintarDirectorioPerfiles() {
  const grillaEl = document.getElementById("directorio-perfiles");
  if (!grillaEl) return;

  const termino = busquedaPerfiles.trim().toLowerCase();
  const perfiles = todosLosPerfiles()
    .filter((p) => {
      if (!termino) return true;
      return [p.nombre, p.orientacion, p.localidad, ...p.capacidades, ...p.cursos.map((c) => c.nombre), ...p.titulos.map((t) => t.nombre)]
        .join(" ")
        .toLowerCase()
        .includes(termino);
    })
    .sort((a, b) => completitudPerfil(b) - completitudPerfil(a));

  if (perfiles.length === 0) {
    grillaEl.innerHTML = `<p class="empty-state">Ningún perfil coincide con "${escaparHTML(busquedaPerfiles)}". Probá con otra capacidad u orientación.</p>`;
    return;
  }

  grillaEl.innerHTML = perfiles
    .map(
      (p) => `
      <article class="perfil-mini">
        <div class="perfil-mini-cabecera">
          <span class="avatar" aria-hidden="true">${escaparHTML(inicialesPerfil(p.nombre))}</span>
          <div>
            <h3 class="perfil-mini-nombre">${escaparHTML(p.nombre)}</h3>
            <p class="perfil-mini-meta">${[p.orientacion || "Orientación sin completar", p.nivel].filter(Boolean).map(escaparHTML).join(" · ")}</p>
          </div>
        </div>
        ${chipsCortos(p, 4)}
        <div class="perfil-mini-pie">
          <span class="perfil-mini-completo">Perfil al ${completitudPerfil(p)} %</span>
          <button type="button" class="btn-view" data-ver-perfil="${escaparHTML(p.email)}">Ver perfil</button>
        </div>
      </article>`
    )
    .join("");
}

function repintarTodo() {
  pintarEstadisticasEmpresa();
  pintarMisPasantias();
  pintarPostulantes();
  pintarDirectorioPerfiles();
  const decisiones = document.getElementById("decisiones-ficha");
  const abierta = document.querySelector("#modal-overlay.visible .perfil-ficha");
  if (decisiones && abierta) {
    decisiones.innerHTML = htmlDecisiones(decisiones.dataset.email);
  }
}

/* ============================================================
   PUBLICAR PASANTÍA (formulario real, en vez del alert() de antes)
   ============================================================ */
function alternarFormularioPasantia() {
  const formulario = document.getElementById("form-nueva-pasantia");
  const boton = document.getElementById("publicar-pasantia");
  if (!formulario || !boton) return;

  const abierto = formulario.style.display !== "none";
  formulario.style.display = abierto ? "none" : "block";
  boton.textContent = abierto ? "Publicar pasantía" : "Cancelar";
  if (!abierto) {
    document.getElementById("pasantia-titulo").focus();
  }
}

function manejarNuevaPasantia(evento) {
  evento.preventDefault();
  const formulario = evento.target;

  const titulo = formulario.querySelector("#pasantia-titulo").value.trim();
  const modalidad = formulario.querySelector("#pasantia-modalidad").value;
  const duracionMeses = Number(formulario.querySelector("#pasantia-duracion").value);

  if (!titulo || !modalidad || !duracionMeses) {
    mostrarToast("Completá todos los campos para publicar la pasantía.", "error");
    return;
  }

  // Versión real: POST /api/v1/internships
  const empresa = empresaActual();
  publicarPasantia({ titulo, modalidad, duracionMeses, empresa: empresa.name, empresaEmail: empresa.email });

  formulario.reset();
  alternarFormularioPasantia();
  repintarTodo();
  mostrarToast(`"${titulo}" publicada. Ya es visible para los estudiantes.`, "success");
}

document.addEventListener("DOMContentLoaded", () => {
  pintarSaludoEmpresa();
  pintarSectorEmpresa();
  pintarAvisoPendiente();
  pintarEstadisticasEmpresa();
  pintarMisPasantias();
  pintarPostulantes();
  pintarDirectorioPerfiles();

  // Un solo manejador para "Ver perfil", "Aceptar" y "Rechazar", estén
  // en la lista, en el directorio o adentro de la ficha abierta.
  document.addEventListener("click", (evento) => {
    const ver = evento.target.closest("[data-ver-perfil]");
    if (ver) {
      verPerfilEstudiante(ver.dataset.verPerfil);
      return;
    }
    const boton = evento.target.closest("[data-decidir]");
    if (boton) decidir(boton.dataset.email, Number(boton.dataset.pasantia), boton.dataset.decidir);
  });

  const buscador = document.getElementById("buscar-perfiles");
  if (buscador) {
    buscador.addEventListener("input", () => {
      busquedaPerfiles = buscador.value;
      pintarDirectorioPerfiles();
    });
  }

  // Si un estudiante actualiza su perfil en otra pestaña, se ve acá.
  window.addEventListener("storage", (evento) => {
    if (evento.key === CLAVE_BOLSA) repintarTodo();
  });

  const botonPublicar = document.getElementById("publicar-pasantia");
  if (botonPublicar) botonPublicar.addEventListener("click", alternarFormularioPasantia);

  // El link "Publicar pasantía" del menú de arriba hace lo mismo que
  // el botón de la sección, pero además baja hasta el formulario:
  // si ya estaba abierto no lo cierra, solo lleva hasta ahí.
  const linkPublicar = document.getElementById("nav-publicar-pasantia");
  if (linkPublicar) {
    linkPublicar.addEventListener("click", (evento) => {
      evento.preventDefault();
      const formulario = document.getElementById("form-nueva-pasantia");
      if (formulario && formulario.style.display === "none") {
        alternarFormularioPasantia();
      }
      const seccion = document.getElementById("seccion-mis-pasantias");
      if (seccion) seccion.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  const formNuevaPasantia = document.getElementById("form-nueva-pasantia");
  if (formNuevaPasantia) formNuevaPasantia.addEventListener("submit", manejarNuevaPasantia);
});
