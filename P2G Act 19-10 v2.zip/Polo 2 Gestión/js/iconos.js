/* ============================================================
   ÍCONOS
   Reemplazan a los emoji que se usaban antes en las tarjetas de
   métricas y en el inventario. Motivo: el emoji lo dibuja el
   sistema operativo, así que cambia de forma entre Windows, Mac y
   Android, no se puede teñir con los colores de la marca y no
   siempre está alineado con el texto. Un SVG hereda el color con
   currentColor y se ve igual en todos lados.

   Todos comparten la misma caja (24×24) y el mismo grosor de
   trazo, para que se lean como una familia y no como recortes
   sueltos de distintos lugares.
   ============================================================ */
const ICONOS = {
  // --- Reservas ---
  edificio: '<path d="M3.5 21h17"/><path d="M5.5 21V5.2a1 1 0 0 1 1-1h7.5a1 1 0 0 1 1 1V21"/><path d="M15 10.5h3.5a1 1 0 0 1 1 1V21"/><path d="M8.5 8h3.5M8.5 11.5h3.5M8.5 15h3.5"/>',
  reloj: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.2V12l3.2 2"/>',
  tilde: '<circle cx="12" cy="12" r="8.5"/><path d="m8.4 12.2 2.5 2.5 4.7-5"/>',
  calendario: '<rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 9.6h17M8.5 3.5V6.5M15.5 3.5V6.5"/>',
  persona: '<circle cx="12" cy="8.2" r="3.6"/><path d="M4.8 20c.6-3.8 3.6-5.9 7.2-5.9s6.6 2.1 7.2 5.9"/>',

  // --- Pasantías ---
  documento: '<path d="M6 3.5h7.5L19 9v11.5H6z"/><path d="M13.2 3.6V9H18.8"/><path d="M9 13h6M9 16.3h4"/>',
  lupa: '<circle cx="10.8" cy="10.8" r="6.3"/><path d="m15.4 15.4 4.1 4.1"/>',
  campana: '<path d="M6.5 10a5.5 5.5 0 0 1 11 0c0 4 1.4 5.4 1.4 5.4H5.1S6.5 14 6.5 10Z"/><path d="M10.3 18.7a2 2 0 0 0 3.4 0"/>',
  megafono: '<path d="M4 10.2v3.6a1.5 1.5 0 0 0 1.5 1.5H8l6.5 4V4.7L8 8.7H5.5A1.5 1.5 0 0 0 4 10.2Z"/><path d="M17.8 9.2a4 4 0 0 1 0 5.6"/>',
  birrete: '<path d="M12 4.2 2.8 8.5 12 12.8l9.2-4.3L12 4.2Z"/><path d="M6.4 10.6v4.2c0 1.4 2.5 2.6 5.6 2.6s5.6-1.2 5.6-2.6v-4.2"/>',

  // --- Tipos de recurso (inventario) ---
  salon: '<rect x="3.2" y="4.5" width="17.6" height="12.5" rx="1.6"/><path d="M8 20.5h8M12 17v3.5"/><path d="M6.8 9h6.4M6.8 12.4h4.2"/>',
  laboratorio: '<path d="M10 3.5h4"/><path d="M10.8 3.6v5.6L5.9 17.6A2 2 0 0 0 7.6 20.5h8.8a2 2 0 0 0 1.7-2.9l-4.9-8.4V3.6"/><path d="M8.4 14h7.2"/>',
  equipo: '<rect x="2.8" y="5" width="18.4" height="11" rx="1.6"/><path d="M7.5 20h9M12 16v4"/>',

  // --- Espacio de cada salón ---
  flecha: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  libro: '<path d="M5 4.5h10.5a2 2 0 0 1 2 2V20H7a2 2 0 0 1-2-2V4.5Z"/><path d="M5 18a2 2 0 0 1 2-2h10.5"/><path d="M9 8.5h5"/>',
  calculadora: '<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M8.5 7.5h7"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 15.5h.01M12 15.5h.01M15.5 15.5h.01"/>',
  escudo: '<path d="M12 3.5 5 6.2v5.3c0 4.2 2.8 7.3 7 9 4.2-1.7 7-4.8 7-9V6.2L12 3.5Z"/><path d="m9.3 12 2 2 3.6-3.8"/>',
  enlace: '<path d="M10 14a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-.8.8"/><path d="M14 10a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l.8-.8"/>',

  // --- Menú de perfil ---
  lapiz: '<path d="M15.2 5.2 18.8 8.8"/><path d="M4.5 19.5 5.4 15.6 15.9 5.1a1.8 1.8 0 0 1 2.5 0l.5.5a1.8 1.8 0 0 1 0 2.5L8.4 18.6 4.5 19.5Z"/>',
  ajustes: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2.2"/><circle cx="9" cy="17" r="2.2"/>',
  salir: '<path d="M10 4.5H6.5a1.5 1.5 0 0 0-1.5 1.5v12a1.5 1.5 0 0 0 1.5 1.5H10"/><path d="M14.5 8.5 18 12l-3.5 3.5M18 12H9.5"/>',
};

// Devuelve el SVG listo para meter en el HTML. Hereda el color
// del contenedor, así que el mismo ícono sirve en cualquier tono.
function icono(nombre, tamano = 20) {
  const trazos = ICONOS[nombre];
  if (!trazos) return "";
  return `<svg width="${tamano}" height="${tamano}" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"
    aria-hidden="true" focusable="false">${trazos}</svg>`;
}
