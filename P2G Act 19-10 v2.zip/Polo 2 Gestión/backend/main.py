from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
from datetime import datetime
import uuid

app = FastAPI(title="Polo 2 Gestión API", description="API para el sistema de reservas y pasantías del Polo Tecnológico")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_URL = "postgresql://polotec:polotec@localhost:5432/polotec"

@app.on_event("startup")
async def startup():
    try:
        app.state.pool = await asyncpg.create_pool(DB_URL)
    except Exception as e:
        print(f"Error connecting to database: {e}")
        app.state.pool = None

@app.on_event("shutdown")
async def shutdown():
    if app.state.pool:
        await app.state.pool.close()

# --- Modelos de Datos ---
class LoginRequest(BaseModel):
    email: str

class BookingCreate(BaseModel):
    resource_id: str
    requested_by: str
    title: str
    starts_at: datetime
    ends_at: datetime

class InternshipCreate(BaseModel):
    company_id: str
    title: str
    modality: str
    duration_months: int

# --- Rutas (Endpoints) ---

@app.post("/api/v1/auth/login")
async def login(req: LoginRequest):
    if not app.state.pool:
        raise HTTPException(status_code=500, detail="Database not connected")
    
    async with app.state.pool.acquire() as conn:
        user = await conn.fetchrow("SELECT id, email, role FROM users WHERE email = $1", req.email)
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        
        # En una app real acá generaríamos un JWT
        return {
            "token": f"fake-jwt-for-{user['id']}",
            "user": {
                "id": str(user['id']),
                "email": user['email'],
                "role": user['role']
            }
        }

@app.post("/api/v1/bookings")
async def create_booking(booking: BookingCreate):
    async with app.state.pool.acquire() as conn:
        try:
            booking_id = await conn.fetchval('''
                INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at, status)
                VALUES ($1::uuid, $2::uuid, $3, $4, $5, 'pending')
                RETURNING id
            ''', booking.resource_id, booking.requested_by, booking.title, booking.starts_at, booking.ends_at)
            return {"id": str(booking_id), "status": "pending"}
        except asyncpg.exceptions.ExclusionViolationError:
            raise HTTPException(status_code=409, detail="El horario se superpone con otra reserva aprobada o pendiente.")

@app.patch("/api/v1/bookings/{booking_id}/approve")
async def approve_booking(booking_id: str):
    async with app.state.pool.acquire() as conn:
        await conn.execute("UPDATE bookings SET status = 'approved' WHERE id = $1::uuid", booking_id)
        return {"status": "approved"}

@app.patch("/api/v1/bookings/{booking_id}/reject")
async def reject_booking(booking_id: str):
    async with app.state.pool.acquire() as conn:
        await conn.execute("UPDATE bookings SET status = 'rejected' WHERE id = $1::uuid", booking_id)
        return {"status": "rejected"}

@app.patch("/api/v1/bookings/{booking_id}/cancel")
async def cancel_booking(booking_id: str):
    async with app.state.pool.acquire() as conn:
        await conn.execute("UPDATE bookings SET status = 'cancelled' WHERE id = $1::uuid", booking_id)
        return {"status": "cancelled"}

@app.post("/api/v1/internships")
async def create_internship(internship: InternshipCreate):
    async with app.state.pool.acquire() as conn:
        internship_id = await conn.fetchval('''
            INSERT INTO internships (company_id, title, modality, duration_months, status)
            VALUES ($1::uuid, $2, $3, $4, 'published')
            RETURNING id
        ''', internship.company_id, internship.title, internship.modality, internship.duration_months)
        return {"id": str(internship_id), "status": "published"}

@app.patch("/api/v1/companies/{company_id}/approve")
async def approve_company(company_id: str):
    async with app.state.pool.acquire() as conn:
        await conn.execute("UPDATE companies SET status = 'active' WHERE id = $1::uuid", company_id)
        return {"status": "active"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
