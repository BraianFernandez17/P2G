/* ============================================================
   ASISTENTE DE VOZ DEL POLO ("Polo")
   Un guía que escucha una pregunta y, según cómo se la pidan,
   te lleva a la sección o simplemente te dice dónde está:

     "Llevame a reservar un salón"   → navega
     "¿Dónde está la agenda?"        → te lo explica y ofrece llevarte

   Tres aclaraciones importantes sobre cómo funciona:

   1. La voz la pone el NAVEGADOR, no un servicio externo: usa la
      Web Speech API (SpeechRecognition para escuchar,
      speechSynthesis para hablar). No se manda audio a ningún
      lado ni hace falta una clave de API.

   2. La interpretación es LOCAL: no hay un modelo de lenguaje
      atrás, sino un puntaje por palabras clave contra el mapa de
      destinos de acá abajo. Alcanza de sobra para "llevame a X" /
      "dónde está X", que es lo que se pide, y mantiene el
      proyecto sin backend como el resto del mockup.

   3. Respeta los roles: los destinos se filtran por la sesión
      activa. Un alumno no puede ser enviado al panel del profesor
      ni al del admin; si lo pide, el asistente se lo dice.

   OJO con el micrófono: los navegadores solo lo permiten en
   https:// o en localhost. Si se abre el HTML con doble clic
   (file://) el dictado no arranca, por eso el asistente siempre
   ofrece además escribir el pedido.
   ============================================================ */

/* ------------------------------------------------------------
   MAPA DE DESTINOS
   Cada entrada dice: cómo se llama, a qué archivo/ancla lleva,
   QUIÉN puede entrar (roles) y con qué palabras se lo suele
   nombrar. "ubicacion" es lo que contesta cuando solo preguntan
   dónde está, sin pedir que lo lleven.

   roles: "publico" = cualquiera, tenga o no sesión iniciada.
   ------------------------------------------------------------ */
const DESTINOS_ASISTENTE = [
  /* ---------- Público ---------- */
  {
    id: "inicio",
    nombre: "la página de inicio",
    archivo: "index.html",
    roles: ["publico"],
    ubicacion: "Es la portada del sitio: tocá el logo 'Polo 2 Gestión' arriba a la izquierda.",
    claves: ["inicio", "portada", "home", "principal", "landing", "pagina de inicio"],
  },
  {
    id: "agenda",
    nombre: "la agenda pública",
    archivo: "agenda-publica.html",
    roles: ["publico"],
    ubicacion:
      "Está en el menú de arriba, en el link 'Agenda pública'. La puede ver cualquiera, sin iniciar sesión.",
    claves: ["agenda", "agenda publica", "reservas aprobadas", "que hay reservado", "cartelera", "actividades"],
  },
  {
    id: "login",
    nombre: "el inicio de sesión",
    archivo: "login.html",
    roles: ["publico"],
    ubicacion: "El botón 'Iniciar sesión' está arriba a la derecha, en el menú.",
    claves: ["login", "iniciar sesion", "ingresar", "entrar", "loguearme", "acceder"],
  },
  {
    id: "registro-estudiante",
    nombre: "el registro de estudiante",
    archivo: "registro-estudiante.html",
    roles: ["publico"],
    ubicacion: "En la portada, en la tarjeta 'Estudiante', o desde el login con 'Crear cuenta'.",
    claves: ["registro estudiante", "registrarme como estudiante", "crear cuenta estudiante", "cuenta de alumno"],
  },
  {
    id: "registro-profesor",
    nombre: "el registro de profesor",
    archivo: "registro-profesor.html",
    roles: ["publico"],
    ubicacion: "En la portada, en la tarjeta 'Profesor', o desde el login con 'Crear cuenta'.",
    claves: ["registro profesor", "registrarme como profesor", "crear cuenta profesor", "cuenta docente"],
  },
  {
    id: "registro-empresa",
    nombre: "el registro de empresa",
    archivo: "registro-empresa.html",
    roles: ["publico"],
    ubicacion: "En la portada, en la tarjeta 'Empresa', o desde el login con 'Crear cuenta'.",
    claves: ["registro empresa", "registrarme como empresa", "crear cuenta empresa", "dar de alta mi empresa"],
  },

  /* ---------- Estudiante ---------- */
  {
    id: "est-inicio",
    nombre: "tu panel de estudiante",
    archivo: "dashboard-estudiante.html",
    ancla: "#seccion-inicio",
    roles: ["student"],
    ubicacion: "Es tu panel principal: el link 'Inicio' del menú de arriba.",
    claves: ["mi panel", "panel", "dashboard", "inicio", "resumen"],
  },
  {
    id: "est-perfil",
    nombre: "tu perfil profesional",
    archivo: "dashboard-estudiante.html",
    ancla: "#seccion-perfil",
    roles: ["student"],
    ubicacion:
      "En tu panel, en 'Tu perfil profesional', debajo de los números de arriba. El botón 'Editar perfil profesional' abre el editor. También está el link 'Mi perfil' en el menú.",
    claves: ["mi perfil", "perfil profesional", "editar perfil", "capacidades", "orientacion", "titulos", "cursos", "curriculum", "cv", "mi perfil academico"],
  },
  {
    id: "est-pasantias",
    nombre: "las pasantías recomendadas",
    archivo: "dashboard-estudiante.html",
    ancla: "#seccion-pasantias",
    roles: ["student"],
    ubicacion:
      "En tu panel, más abajo de tus postulaciones. También está el link 'Pasantías' en el menú de arriba.",
    claves: ["pasantias", "pasantia", "buscar pasantia", "practicas", "ofertas", "trabajo", "postularme"],
  },
  {
    id: "est-postulaciones",
    nombre: "tus postulaciones",
    archivo: "dashboard-estudiante.html",
    ancla: "#seccion-postulaciones",
    roles: ["student"],
    ubicacion:
      "En tu panel, en la sección 'Mis postulaciones', justo debajo de las tarjetas de arriba. También está el link 'Postulaciones' en el menú.",
    claves: ["postulaciones", "mis postulaciones", "estado de mi postulacion", "a que me postule", "seguimiento"],
  },

  /* ---------- Profesor ---------- */
  {
    id: "prof-panel",
    nombre: "tu panel de profesor",
    archivo: "dashboard-profesor.html",
    roles: ["professor"],
    ubicacion: "Es tu panel principal, donde pedís salones y ves tus reservas.",
    claves: ["mi panel", "panel", "dashboard", "inicio", "resumen", "panel de profesor"],
  },
  {
    id: "prof-nueva-reserva",
    nombre: "el formulario para reservar un salón",
    archivo: "dashboard-profesor.html",
    ancla: "#seccion-nueva-reserva",
    roles: ["professor"],
    ubicacion:
      "En tu panel, en la sección 'Pedir una reserva', arriba de todo. También está el link 'Nueva reserva' en el menú.",
    claves: [
      "reservar", "reserva", "reservar salon", "reserva de salones", "pedir un salon",
      "nueva reserva", "solicitar salon", "laboratorio", "equipo", "proyector",
      "salon", "sala", "reservar sala", "pedir reserva",
    ],
    // "cancelar" no va acá: eso se hace desde "Mis reservas".
    excluir: ["cancelar", "cancelo", "anular"],
  },
  {
    id: "prof-accion-reservar-rapido",
    nombre: "reserva rápida",
    roles: ["professor"],
    accion: "reservarRapido",
    ubicacion: "Te preparo la reserva para que solo confirmes.",
    claves: ["reserva el", "reservar el", "reserva la", "reservar la", "necesito reservar", "quiero reservar el"],
  },
  {
    id: "prof-mis-reservas",
    nombre: "tus reservas",
    archivo: "dashboard-profesor.html",
    ancla: "#seccion-mis-reservas",
    roles: ["professor"],
    ubicacion:
      "En tu panel, en 'Mis reservas', debajo del formulario. Desde ahí también podés cancelar las que sigan pendientes.",
    claves: [
      "mis reservas", "mis solicitudes", "que reserve", "estado de mi reserva",
      "cancelar", "cancelo", "cancelar reserva", "anular", "dar de baja",
    ],
  },
  {
    id: "prof-calendario",
    nombre: "el calendario anual",
    archivo: "dashboard-profesor.html",
    ancla: "#seccion-calendario",
    roles: ["professor"],
    ubicacion: "Al final de tu panel, en 'Calendario anual'. También está el link 'Calendario' en el menú.",
    claves: ["calendario", "calendario anual", "ver el año", "que dias hay libre", "disponibilidad"],
  },

  /* ---------- Empresa ---------- */
  {
    id: "emp-panel",
    nombre: "tu panel de empresa",
    archivo: "dashboard-empresa.html",
    roles: ["company"],
    ubicacion: "Es tu panel principal, donde publicás pasantías y ves los postulantes.",
    claves: ["mi panel", "panel", "dashboard", "inicio", "resumen", "panel de empresa"],
  },
  {
    id: "emp-pasantias",
    nombre: "tus pasantías publicadas",
    archivo: "dashboard-empresa.html",
    ancla: "#seccion-mis-pasantias",
    roles: ["company"],
    ubicacion:
      "En tu panel, en 'Mis pasantías publicadas'. Desde ahí entrás a los postulantes de cada una.",
    claves: ["mis pasantias", "pasantias publicadas", "mis avisos", "publicaciones"],
  },
  {
    id: "emp-postulantes",
    nombre: "los postulantes",
    archivo: "dashboard-empresa.html",
    ancla: "#seccion-postulantes",
    roles: ["company"],
    ubicacion:
      "En tu panel, en la sección 'Postulantes': ahí abrís el perfil de cada estudiante y lo aceptás o rechazás. También está en el menú de arriba.",
    claves: ["postulantes", "candidatos", "aceptar", "aceptar estudiante", "quien se postulo", "postulaciones"],
  },
  {
    id: "emp-perfiles",
    nombre: "los perfiles de estudiantes",
    archivo: "dashboard-empresa.html",
    ancla: "#seccion-perfiles",
    roles: ["company"],
    ubicacion:
      "En tu panel, en 'Perfiles de estudiantes', al final: podés buscar por capacidad u orientación y seleccionar a alguien para una pasantía.",
    claves: ["perfiles", "perfiles de estudiantes", "buscar estudiantes", "estudiantes", "alumnos", "talento", "capacidades"],
  },
  {
    id: "emp-publicar",
    nombre: "el formulario para publicar una pasantía",
    archivo: "dashboard-empresa.html",
    ancla: "#seccion-mis-pasantias",
    roles: ["company"],
    accion: "publicarPasantia",
    ubicacion:
      "Es el botón 'Publicar pasantía', al lado del título 'Mis pasantías publicadas', y también está en el menú de arriba.",
    claves: ["publicar", "publicar pasantia", "nueva pasantia", "crear pasantia", "ofrecer pasantia", "subir aviso"],
  },

  /* ---------- Admin ---------- */
  {
    id: "adm-panel",
    nombre: "el panel del admin",
    archivo: "dashboard-admin.html",
    roles: ["admin"],
    ubicacion: "Es tu panel principal: el link 'Panel' del menú de arriba.",
    claves: ["panel", "panel principal", "hub", "inicio", "dashboard"],
  },
  {
    id: "adm-reservas",
    nombre: "la gestión de reservas",
    archivo: "dashboard-admin-reservas.html",
    roles: ["admin"],
    ubicacion:
      "En el menú de arriba, en 'Reservas'. Ahí aprobás o rechazás los pedidos de los profesores y ves el inventario.",
    claves: [
      "reservas", "reserva de salones", "aprobar reservas", "pedidos", "cola de reservas",
      "salon", "salones", "inventario", "laboratorios", "equipos", "rechazar",
    ],
  },
  {
    id: "adm-calendario",
    nombre: "el calendario anual del Polo",
    archivo: "dashboard-admin-reservas.html",
    ancla: "#seccion-calendario",
    roles: ["admin"],
    ubicacion: "Al final de la pantalla 'Reservas', en 'Calendario anual del Polo'.",
    claves: ["calendario", "calendario anual", "ver el año", "ocupacion", "disponibilidad"],
  },
  {
    id: "adm-pasantias",
    nombre: "la gestión de pasantías",
    archivo: "dashboard-admin-pasantias.html",
    roles: ["admin"],
    ubicacion:
      "En el menú de arriba, en 'Pasantías'. Ahí aprobás empresas nuevas y agendás las entrevistas.",
    claves: ["pasantias", "empresas", "aprobar empresas", "entrevistas", "postulaciones", "agendar entrevista"],
  },

  /* ---------- Cualquiera con sesión ---------- */
  {
    id: "perfil",
    nombre: "la edición de tu perfil",
    roles: ["student", "professor", "company", "admin"],
    accion: "editarPerfil",
    ubicacion:
      "Tocá tu avatar, arriba a la derecha, y elegí 'Editar perfil'. Desde ahí cambiás tu nombre y tu email.",
    claves: ["perfil", "editar perfil", "cambiar mi nombre", "cambiar mi email", "mi cuenta", "mis datos"],
  },
  {
    id: "configuracion",
    nombre: "la configuración",
    roles: ["student", "professor", "company", "admin"],
    accion: "configuracion",
    ubicacion:
      "Tocá tu avatar, arriba a la derecha, y elegí 'Configuración'. Ahí se apagan los avisos, las confirmaciones y se elige cómo abre la agenda.",
    claves: ["configuracion", "ajustes", "preferencias", "opciones", "apagar avisos", "settings"],
  },
  {
    id: "salir",
    nombre: "cerrar sesión",
    roles: ["student", "professor", "company", "admin"],
    accion: "cerrarSesion",
    ubicacion: "Tocá tu avatar, arriba a la derecha, y elegí 'Cerrar sesión'.",
    claves: ["cerrar sesion", "salir", "desconectarme", "log out", "logout"],
  },
];

/* ------------------------------------------------------------
   INTERPRETACIÓN DE LO QUE SE PIDIÓ
   ------------------------------------------------------------ */

// Palabras que piden claramente "llevame ahí". Estas ganan
// siempre, incluso si la frase también dice "dónde"
// ("¿dónde está la agenda? llevame" → te lleva).
const VERBOS_LLEVAME = [
  "llevame", "llevarme", "llévame", "lleva me", "andate", "anda a", "andá a", "ir a",
  "vamos a", "abrime", "abrir", "abri", "abrí", "abre", "mostrame", "muestrame", "muéstrame",
  "mostrar", "entrar a", "entra a", "ingresar a", "navega", "navegar", "vamos", "llevar",
];

// Estas también apuntan a ir, pero más flojo: "quiero publicar una
// pasantía" es ir, y "quiero saber dónde está" NO lo es. Por eso
// solo cuentan cuando la frase no pregunta "dónde".
const VERBOS_LLEVAME_DEBILES = ["quiero", "necesito", "me gustaria", "me gustaría", "tengo que", "voy a"];

// Palabras que indican "solo decime dónde está".
const VERBOS_DONDE = [
  "donde", "dónde", "en que parte", "en qué parte", "como llego", "cómo llego", "como encuentro",
  "cómo encuentro", "donde queda", "dónde queda", "donde esta", "dónde está", "en donde",
  "como hago para encontrar", "ubicacion", "ubicación",
];

const AFIRMACIONES = ["si", "sí", "dale", "obvio", "claro", "por favor", "bueno", "ok", "okey", "llevame", "confirmo", "sip"];
const NEGACIONES = ["no", "nada", "cancelar", "despues", "después", "ahora no", "nop"];

// Saca tildes y signos para poder comparar sin que "dónde" y
// "donde" cuenten como palabras distintas.
function normalizarTexto(texto) {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!.,;:]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// Qué destinos puede usar quien está usando la página ahora.
function destinosPermitidos() {
  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;
  const rol = sesion ? sesion.role : null;

  return DESTINOS_ASISTENTE.filter((destino) => {
    if (destino.roles.includes("publico")) {
      // Con sesión iniciada no tiene sentido ofrecer login ni registros.
      if (rol && ["login", "registro-estudiante", "registro-profesor", "registro-empresa"].includes(destino.id)) {
        return false;
      }
      return true;
    }
    return rol ? destino.roles.includes(rol) : false;
  });
}

// Puntaje simple: cuántas palabras clave del destino aparecen en
// lo que se dijo. Las claves de varias palabras valen más, porque
// "reserva de salones" es mucho más específico que "reserva".
function puntuarDestino(destino, textoNormalizado) {
  // Algunas palabras descartan un destino aunque otras coincidan:
  // "cancelar una reserva" habla de "reserva", pero no del
  // formulario para pedir una nueva.
  if (destino.excluir && destino.excluir.some((p) => textoNormalizado.includes(normalizarTexto(p)))) {
    return 0;
  }

  let puntaje = 0;
  destino.claves.forEach((clave) => {
    const claveNorm = normalizarTexto(clave);
    if (textoNormalizado.includes(claveNorm)) {
      puntaje += claveNorm.split(" ").length * 2;
    }
  });
  // El nombre del destino también cuenta.
  const nombreNorm = normalizarTexto(destino.nombre);
  if (textoNormalizado.includes(nombreNorm)) puntaje += 3;
  return puntaje;
}

/* ------------------------------------------------------------
   MENCIÓN EXPLÍCITA DE OTRO PERFIL
   Caso aparte del puntaje por palabras clave: si alguien pide
   derecho "el panel de admin" o "la pestaña de profesor", hay que
   avisarle que esa parte no es suya, aunque alguna palabra suelta
   coincida con una sección propia ("panel" también está en las
   claves del panel del estudiante).

   Pedimos la forma completa ("panel de X", "pestaña de X") a
   propósito: si un admin dice "aprobar empresas", ahí "empresas"
   es lo que gestiona, no un panel ajeno, y no hay que bloquearlo.
   ------------------------------------------------------------ */
const ROL_POR_PALABRA = {
  admin: "admin",
  administrador: "admin",
  administracion: "admin",
  profesor: "professor",
  profesores: "professor",
  docente: "professor",
  docentes: "professor",
  empresa: "company",
  empresas: "company",
  estudiante: "student",
  estudiantes: "student",
  alumno: "student",
  alumnos: "student",
};

function rolAjenoMencionado(textoNormalizado, rolPropio) {
  const patron = /(panel|pestana|seccion|vista|dashboard|pagina|parte|zona|cuenta|perfil)\s+(?:de|del|de la)\s+(\w+)/;
  const coincidencia = textoNormalizado.match(patron);
  if (!coincidencia) return null;

  const rolPedido = ROL_POR_PALABRA[coincidencia[2]];
  if (!rolPedido) return null;
  return rolPedido === rolPropio ? null : rolPedido;
}

// Devuelve { destino, intencion, bloqueado } a partir del texto.
// intencion: "navegar" | "ubicar"
// bloqueado: el destino existe pero es de otro rol.
function interpretarPedido(texto) {
  const t = normalizarTexto(texto);
  if (!t) return { destino: null, intencion: "ubicar" };

  const quiereIrFuerte = VERBOS_LLEVAME.some((v) => t.includes(normalizarTexto(v)));
  const preguntaDonde = VERBOS_DONDE.some((v) => t.includes(normalizarTexto(v)));
  const quiereIrDebil = VERBOS_LLEVAME_DEBILES.some((v) => t.includes(normalizarTexto(v)));

  // "Llevame" gana siempre. "Quiero" solo cuenta si no preguntó
  // dónde: así "quiero saber dónde está X" explica en vez de ir.
  const intencion = quiereIrFuerte || (quiereIrDebil && !preguntaDonde) ? "navegar" : "ubicar";

  const permitidos = destinosPermitidos();

  // Antes que nada: ¿pidió derecho el panel de otro perfil?
  const sesionActual = typeof obtenerSesion === "function" ? obtenerSesion() : null;
  const rolAjeno = rolAjenoMencionado(t, sesionActual ? sesionActual.role : null);
  if (rolAjeno) {
    const destinoAjeno = DESTINOS_ASISTENTE.find((d) => d.roles.includes(rolAjeno));
    return { destino: destinoAjeno, intencion, bloqueado: true, rolPedido: rolAjeno };
  }

  const mejor = permitidos
    .map((destino) => ({ destino, puntaje: puntuarDestino(destino, t) }))
    .sort((a, b) => b.puntaje - a.puntaje)[0];

  if (mejor && mejor.puntaje > 0) {
    return { destino: mejor.destino, intencion };
  }

  // No encontramos nada permitido. ¿Será que pidió algo de otro rol?
  const ajeno = DESTINOS_ASISTENTE.filter((d) => !permitidos.includes(d))
    .map((destino) => ({ destino, puntaje: puntuarDestino(destino, t) }))
    .sort((a, b) => b.puntaje - a.puntaje)[0];

  if (ajeno && ajeno.puntaje > 0) {
    return { destino: ajeno.destino, intencion, bloqueado: true };
  }

  return { destino: null, intencion };
}

/* ------------------------------------------------------------
   ESTADO DEL ASISTENTE
   ------------------------------------------------------------ */
const asistente = {
  escuchando: false,
  hablando: false, // mientras contesta en voz alta (hace latir el hexágono)
  saludado: false, // para no repetir el saludo cada vez que se abre
  reconocimiento: null,
  // Cuando contesta "está en tal lado, ¿querés que te lleve?",
  // acá queda guardado el destino para el "sí" que venga después.
  pendiente: null,
};

/* ------------------------------------------------------------
   HABLAR (speechSynthesis)
   ------------------------------------------------------------ */
function hablar(texto) {
  const preferencias = typeof obtenerPreferencias === "function" ? obtenerPreferencias() : {};
  if (preferencias.vozAsistente === false) return;
  if (!("speechSynthesis" in window)) return;

  window.speechSynthesis.cancel();
  const mensaje = new SpeechSynthesisUtterance(texto);
  mensaje.lang = "es-UY";
  mensaje.rate = 1.03;
  mensaje.pitch = 1;

  // Si el sistema tiene alguna voz en español, la usamos.
  const vozEspanol = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith("es"));
  if (vozEspanol) mensaje.voice = vozEspanol;

  // asistente.hablando es lo que hace latir el hexágono mientras
  // contesta (lo lee dibujarHexagono).
  mensaje.onstart = () => {
    asistente.hablando = true;
    estadoAsistente("hablando");
  };
  mensaje.onend = () => {
    asistente.hablando = false;
    estadoAsistente("reposo", "tocá el hexágono y hablá");
  };

  window.speechSynthesis.speak(mensaje);
}

/* ------------------------------------------------------------
   RESPONDER: escribe en el panel y (si corresponde) lo dice
   ------------------------------------------------------------ */
function responderAsistente(texto, { conAccion = null } = {}) {
  const linea = agregarAlChat(texto, "polo");

  // Cuando además ofrece llevarte, el botón va dentro de la misma
  // burbuja, para que quede claro a qué respuesta pertenece.
  if (linea && conAccion) {
    const burbuja = linea.querySelector(".asistente-burbuja");
    const boton = document.createElement("button");
    boton.type = "button";
    boton.className = "asistente-accion";
    boton.textContent = conAccion.etiqueta;
    boton.addEventListener("click", () => {
      boton.remove();
      conAccion.alTocar();
    });
    burbuja.appendChild(boton);

    const logEl = document.getElementById("asistente-log");
    if (logEl) logEl.scrollTop = logEl.scrollHeight;
  }

  hablar(texto);
}

// Cambia el rótulo de estado de la cabecera ("reposo",
// "escuchando", "hablando") y el pie debajo del hexágono.
function estadoAsistente(estado, pie) {
  const estadoEl = document.getElementById("asistente-estado");
  if (estadoEl) estadoEl.textContent = estado;
  // El color del hexágono sigue al estado (lo pinta el CSS con
  // data-estado): también se ve con "reducir movimiento".
  const nucleo = document.getElementById("asistente-esfera-boton");
  if (nucleo) nucleo.dataset.estado = estado;
  const pieEl = document.getElementById("asistente-pie");
  if (pieEl && pie !== undefined) pieEl.textContent = pie;
}

/* ------------------------------------------------------------
   IR A UN DESTINO
   Algunos destinos no son una página sino una acción de la
   pantalla actual (abrir configuración, editar perfil...).
   ------------------------------------------------------------ */
function irADestino(destino) {
  if (destino.accion) {
    ejecutarAccion(destino);
    return;
  }

  const paginaActual = window.location.pathname.split("/").pop() || "index.html";
  const url = destino.archivo + (destino.ancla || "");

  // Si ya estamos en esa página, no recargamos: bajamos a la sección.
  if (destino.archivo === paginaActual) {
    const seccion = destino.ancla ? document.querySelector(destino.ancla) : null;
    if (seccion) {
      seccion.scrollIntoView({ behavior: "smooth", block: "start" });
      responderAsistente(`Listo, ahí tenés ${destino.nombre}.`);
      return;
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
    responderAsistente(`Ya estás en ${destino.nombre}.`);
    return;
  }

  responderAsistente(`Te llevo a ${destino.nombre}.`);
  // Le damos un momento para que se alcance a escuchar la frase.
  setTimeout(() => {
    window.location.href = url;
  }, 700);
}

function ejecutarAccion(destino) {
  const paginaActual = window.location.pathname.split("/").pop() || "index.html";

  // Las acciones de perfil existen en cualquier dashboard.
  if (destino.accion === "editarPerfil" && typeof abrirEditarPerfil === "function") {
    responderAsistente("Abro la edición de tu perfil.");
    setTimeout(abrirEditarPerfil, 400);
    return;
  }
  if (destino.accion === "configuracion" && typeof abrirConfiguracion === "function") {
    responderAsistente("Abro la configuración.");
    setTimeout(abrirConfiguracion, 400);
    return;
  }
  if (destino.accion === "cerrarSesion" && typeof confirmarCerrarSesion === "function") {
    responderAsistente("Te paso el cierre de sesión para que confirmes.");
    setTimeout(confirmarCerrarSesion, 400);
    return;
  }

  // Publicar pasantía solo tiene sentido en el panel de la empresa.
  if (destino.accion === "publicarPasantia") {
    if (paginaActual === "dashboard-empresa.html") {
      const link = document.getElementById("nav-publicar-pasantia");
      if (link) {
        responderAsistente("Te abro el formulario para publicar una pasantía.");
        setTimeout(() => link.click(), 400);
        return;
      }
    }
    responderAsistente("Te llevo a tu panel para publicar la pasantía.");
    setTimeout(() => {
      window.location.href = "dashboard-empresa.html";
    }, 700);
    return;
  }

  // Acción rápida: Reservar (intenta preseleccionar el formulario si ya estamos en el panel)
  if (destino.accion === "reservarRapido") {
    if (paginaActual === "dashboard-profesor.html") {
      responderAsistente("Acá tenés el formulario para completar los detalles de tu reserva.");
      setTimeout(() => {
        const formulario = document.querySelector("#seccion-nueva-reserva");
        if (formulario) formulario.scrollIntoView({ behavior: "smooth", block: "start" });
        // Foco visual para guiar al usuario
        const titulo = document.getElementById("recurso");
        if (titulo) setTimeout(() => titulo.focus(), 600);
      }, 400);
      return;
    }
    responderAsistente("Te llevo al formulario de reservas para que lo completes.");
    setTimeout(() => {
      window.location.href = "dashboard-profesor.html#seccion-nueva-reserva";
    }, 700);
    return;
  }

  // Si la acción no está disponible en esta pantalla, al menos
  // explicamos dónde encontrarla.
  responderAsistente(destino.ubicacion);
}

/* ------------------------------------------------------------
   PROCESAR UN PEDIDO (de voz o escrito)
   ------------------------------------------------------------ */
function procesarPedido(texto, { yaEnElChat = false } = {}) {
  // Lo que se dictó ya se fue mostrando en vivo en el chat, así
  // que no hay que volver a agregarlo.
  if (!yaEnElChat) agregarAlChat(texto, "yo");

  const t = normalizarTexto(texto);

  // ¿Es un "sí" respondiendo a "¿querés que te lleve?"
  if (asistente.pendiente) {
    const destinoPendiente = asistente.pendiente;
    if (AFIRMACIONES.some((palabra) => t === palabra || t.startsWith(palabra + " "))) {
      asistente.pendiente = null;
      irADestino(destinoPendiente);
      return;
    }
    if (NEGACIONES.some((palabra) => t === palabra || t.startsWith(palabra + " "))) {
      asistente.pendiente = null;
      responderAsistente("Listo, quedamos acá. Preguntame cuando quieras.");
      return;
    }
    // Si dijo otra cosa, seguimos con el pedido nuevo.
    asistente.pendiente = null;
  }

  // Saludos y ayuda
  if (["hola", "buenas", "hola polo", "que tal", "hey"].some((s) => t === s)) {
    responderAsistente("Hola. Preguntame dónde está algo, o pedime que te lleve.");
    return;
  }
  if (t.includes("ayuda") || t.includes("que podes hacer") || t.includes("que sabes hacer") || t.includes("opciones")) {
    const lista = destinosPermitidos()
      .slice(0, 5)
      .map((d) => d.nombre)
      .join(", ");
    responderAsistente(
      `Te puedo guiar por el sitio. Con tu cuenta podés ir a: ${lista}. Decime "llevame a..." o "¿dónde está...?".`
    );
    return;
  }

  const { destino, intencion, bloqueado, rolPedido } = interpretarPedido(texto);

  // Pidió algo que existe pero no es de su rol.
  if (bloqueado) {
    const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;

    if (!sesion) {
      responderAsistente(
        'Esa parte es para cuentas con sesión iniciada. Pedime "llevame al inicio de sesión" y te llevo.'
      );
      return;
    }

    const miRol = NOMBRE_DEL_ROL[sesion.role] || "tu cuenta";
    const rolDueño = NOMBRE_DEL_ROL[rolPedido || (destino && destino.roles[0])] || "otro perfil";
    responderAsistente(
      `Esa sección es del panel de ${rolDueño}, y tu cuenta es de ${miRol}. No te puedo llevar ahí. Preguntame por algo de tu panel y te guío.`
    );
    return;
  }

  if (!destino) {
    responderAsistente(
      'No entendí a qué parte querés ir. Probá con "llevame a reservar un salón" o "¿dónde está la agenda?".'
    );
    return;
  }

  if (intencion === "navegar") {
    irADestino(destino);
    return;
  }

  // Solo preguntó dónde está: lo explicamos y ofrecemos llevarlo,
  // tanto por voz (contestando "sí") como con el botón.
  asistente.pendiente = destino;
  responderAsistente(`${destino.ubicacion} ¿Querés que te lleve?`, {
    conAccion: {
      etiqueta: "Sí, llevame",
      alTocar: () => {
        asistente.pendiente = null;
        irADestino(destino);
      },
    },
  });
}

/* ------------------------------------------------------------
   ESCUCHAR (SpeechRecognition)
   ------------------------------------------------------------ */
function soportaDictado() {
  return "webkitSpeechRecognition" in window || "SpeechRecognition" in window;
}

function alternarEscucha() {
  if (!soportaDictado()) {
    responderAsistente(
      "Este navegador no permite dictado por voz. Escribime el pedido en el campo de abajo y te guío igual."
    );
    return;
  }

  if (asistente.escuchando) {
    asistente.reconocimiento.stop();
    return;
  }

  const Reconocimiento = window.SpeechRecognition || window.webkitSpeechRecognition;
  const reconocimiento = new Reconocimiento();
  reconocimiento.lang = "es-UY";
  reconocimiento.continuous = false;
  reconocimiento.interimResults = true;
  reconocimiento.maxAlternatives = 1;

  // Mientras dicta, lo que se va entendiendo aparece en vivo en
  // una burbuja provisoria, que al final queda como el mensaje.
  let burbujaEnVivo = null;

  reconocimiento.onstart = () => {
    asistente.escuchando = true;
    estadoAsistente("escuchando", "te escucho...");
  };

  reconocimiento.onresult = (evento) => {
    const resultado = evento.results[evento.results.length - 1];
    const texto = resultado[0].transcript;

    if (!burbujaEnVivo) burbujaEnVivo = agregarAlChat(texto, "yo en-vivo");
    else {
      burbujaEnVivo.querySelector(".asistente-burbuja").textContent = texto;
      const logEl = document.getElementById("asistente-log");
      if (logEl) logEl.scrollTop = logEl.scrollHeight;
    }

    if (resultado.isFinal) {
      if (burbujaEnVivo) burbujaEnVivo.classList.remove("en-vivo");
      burbujaEnVivo = null;
      procesarPedido(texto, { yaEnElChat: true });
    }
  };

  reconocimiento.onerror = (evento) => {
    asistente.escuchando = false;
    estadoAsistente("reposo", "tocá el hexágono y hablá");
    if (burbujaEnVivo) {
      burbujaEnVivo.remove();
      burbujaEnVivo = null;
    }
    if (evento.error === "not-allowed" || evento.error === "service-not-allowed") {
      responderAsistente(
        "No tengo permiso para usar el micrófono. Habilitalo en el navegador, o escribime el pedido acá abajo."
      );
    } else if (evento.error === "no-speech") {
      responderAsistente("No llegué a escuchar nada. Probá de nuevo.");
    } else {
      responderAsistente("Hubo un problema con el micrófono. Podés escribirme el pedido acá abajo.");
    }
  };

  reconocimiento.onend = () => {
    asistente.escuchando = false;
    if (!asistente.hablando) estadoAsistente("reposo", "tocá el hexágono y hablá");
    if (burbujaEnVivo) {
      burbujaEnVivo.remove();
      burbujaEnVivo = null;
    }
  };

  asistente.reconocimiento = reconocimiento;
  reconocimiento.start();
}

/* ============================================================
   EL HEXÁGONO
   El núcleo del asistente es un hexágono que se deforma con un
   filtro SVG de turbulencia: feTurbulence genera un ruido y
   feDisplacementMap usa ese ruido para correr los píxeles del
   borde, así la forma parece líquida.

   El estado del asistente decide cuánto se deforma:
   · en reposo casi nada, apenas respira;
   · escuchando se enciende en amarillo y ondula fuerte;
   · hablando late al ritmo de la respuesta.

   Solo se anima con el panel abierto: con el panel cerrado se
   corta el requestAnimationFrame y no gasta CPU ni batería.
   ============================================================ */

// El mismo polígono del ejemplo: hexágono de punta arriba en 128×128.
const PUNTOS_HEXAGONO = "64 128 8.574 96 8.574 32 64 0 119.426 32 119.426 96";

// Nombre propio (y no MENOS_MOVIMIENTO): movimiento.js ya declara
// esa constante en el ámbito global y repetirla sería un error.
const MENOS_MOVIMIENTO_ASISTENTE = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

const hexagono = {
  turbulencia: null,
  desplazamiento: null,
  animando: false,
  t: 0,
  energia: 0,
};

function dibujarHexagono() {
  if (!hexagono.animando) return;
  hexagono.t += 0.016;

  const objetivo = asistente.escuchando
    ? 1
    : asistente.hablando
    ? 0.55 + Math.sin(hexagono.t * 7) * 0.25
    : 0.14;
  // La energía persigue al objetivo de a poco: los cambios de estado
  // se ven como una transición, no como un salto.
  hexagono.energia += (objetivo - hexagono.energia) * 0.08;
  const E = hexagono.energia;

  // La frecuencia del ruido varía despacio (la forma "respira") y la
  // escala del desplazamiento dice cuánto se estira el borde.
  // Frecuencias bajas a propósito: arriba de ~0,015 la turbulencia de
  // dos octavas "rasga" el borde y el hexágono parece papel roto.
  const frecuencia = 0.005 + E * 0.005 + Math.sin(hexagono.t * 0.9) * 0.0015 * (0.4 + E);
  hexagono.turbulencia.setAttribute("baseFrequency", frecuencia.toFixed(4));
  hexagono.desplazamiento.setAttribute("scale", (3 + E * 12).toFixed(2));

  requestAnimationFrame(dibujarHexagono);
}

// Se mantienen los nombres de antes porque los usa alternarPanel.
function arrancarEsfera() {
  if (hexagono.animando || !hexagono.turbulencia || MENOS_MOVIMIENTO_ASISTENTE) return;
  hexagono.animando = true;
  requestAnimationFrame(dibujarHexagono);
}

function detenerEsfera() {
  hexagono.animando = false;
}

/* ============================================================
   EL CHAT
   Un hilo simple de burbujas: lo que se pidió y lo que contestó
   el asistente. Se guarda solo en memoria (se vacía al recargar),
   igual que el resto del mockup.
   ============================================================ */
function agregarAlChat(texto, quien) {
  const logEl = document.getElementById("asistente-log");
  if (!logEl) return null;

  const linea = document.createElement("div");
  linea.className = `asistente-linea ${quien}`;
  linea.innerHTML = `
    <span class="asistente-quien">${quien === "yo" ? "vos" : "✻"}</span>
    <div class="asistente-burbuja">${texto}</div>
  `;
  logEl.appendChild(linea);
  logEl.scrollTop = logEl.scrollHeight;
  return linea;
}

/* ============================================================
   EL PANEL
   Un botón chico pegado al borde derecho; al tocarlo se abre a su
   izquierda el panel con el hexágono y el chat.
   ============================================================ */
function construirAsistente() {
  const preferencias = typeof obtenerPreferencias === "function" ? obtenerPreferencias() : {};
  if (preferencias.asistente === false) return;
  if (document.getElementById("asistente-voz")) return;

  const contenedor = document.createElement("div");
  contenedor.id = "asistente-voz";
  contenedor.className = "asistente";
  contenedor.innerHTML = `
    <button id="asistente-boton" class="asistente-boton" aria-label="Abrir el asistente del Polo" title="Asistente del Polo">
      <svg class="asistente-boton-hex" viewBox="0 0 128 128" aria-hidden="true">
        <polygon points="${PUNTOS_HEXAGONO}" fill="currentColor" />
      </svg>
    </button>

    <section id="asistente-panel" class="asistente-panel" role="dialog" aria-label="Asistente del Polo">
      <header class="asistente-cabecera">
        <div class="asistente-marca">
          <i>✻</i>asistente<em> · polo</em>
        </div>
        <span class="asistente-estado" id="asistente-estado">reposo</span>
        <button id="asistente-cerrar" class="asistente-cerrar" aria-label="Cerrar">×</button>
      </header>

      <div class="asistente-nucleo">
        <button id="asistente-esfera-boton" class="asistente-esfera-boton" aria-label="Hablar" data-estado="reposo">
          <!-- El viewBox deja 16 de margen para que el borde deformado
               no se corte. baseFrequency y scale los anima
               dibujarHexagono(). -->
          <svg class="asistente-hexagono" viewBox="-16 -16 160 160" aria-hidden="true">
            <filter id="asistente-deformar" x="-25%" y="-25%" width="150%" height="150%">
              <feTurbulence type="turbulence" numOctaves="2" baseFrequency="0" result="turbulence" />
              <feDisplacementMap in2="turbulence" in="SourceGraphic" scale="1" xChannelSelector="R" yChannelSelector="G" />
            </filter>
            <g filter="url(#asistente-deformar)">
              <polygon class="hex-cuerpo" points="${PUNTOS_HEXAGONO}" fill="currentColor" />
              <polygon class="hex-filo" points="${PUNTOS_HEXAGONO}" fill="none" />
            </g>
          </svg>
        </button>
        <p class="asistente-pie" id="asistente-pie">tocá el hexágono y hablá</p>
      </div>

      <div class="asistente-log" id="asistente-log"></div>

      <div class="asistente-chips" id="asistente-sugerencias"></div>

      <div class="asistente-entrada">
        <input type="text" id="asistente-texto" placeholder="o escribí acá..." autocomplete="off" spellcheck="false" />
        <button type="button" id="asistente-enviar" aria-label="Enviar">→</button>
      </div>

      <p class="asistente-rol" id="asistente-rol"></p>
    </section>
  `;
  document.body.appendChild(contenedor);

  hexagono.turbulencia = contenedor.querySelector("feTurbulence");
  hexagono.desplazamiento = contenedor.querySelector("feDisplacementMap");

  const boton = document.getElementById("asistente-boton");
  const panel = document.getElementById("asistente-panel");

  const alternarPanel = (abrir) => {
    const visible = abrir === undefined ? !contenedor.classList.contains("abierto") : abrir;
    contenedor.classList.toggle("abierto", visible);
    panel.classList.toggle("visible", visible);
    boton.setAttribute("aria-expanded", String(visible));

    if (visible) {
      arrancarEsfera();
      // Saludo, solo la primera vez que se abre.
      if (!asistente.saludado) {
        asistente.saludado = true;
        agregarAlChat("Preguntame dónde está algo, o pedime que te lleve.", "polo");
      }
    } else {
      detenerEsfera();
      if (asistente.escuchando && asistente.reconocimiento) asistente.reconocimiento.stop();
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    }
  };

  boton.addEventListener("click", () => alternarPanel());
  document.getElementById("asistente-cerrar").addEventListener("click", () => alternarPanel(false));
  document.getElementById("asistente-esfera-boton").addEventListener("click", alternarEscucha);

  document.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape") alternarPanel(false);
  });

  const campoTexto = document.getElementById("asistente-texto");
  const enviar = () => {
    const texto = campoTexto.value.trim();
    if (!texto) return;
    campoTexto.value = "";
    procesarPedido(texto);
  };
  document.getElementById("asistente-enviar").addEventListener("click", enviar);
  campoTexto.addEventListener("keydown", (evento) => {
    if (evento.key === "Enter") enviar();
  });

  pintarContextoAsistente();
}

// Muestra con qué cuenta está entrando y ofrece atajos acordes al
// rol: así se ve de entrada que el asistente es distinto para un
// alumno, un profesor, una empresa o el admin.
function pintarContextoAsistente() {
  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;

  const rolEl = document.getElementById("asistente-rol");
  if (rolEl) {
    rolEl.textContent = sesion
      ? `guía para tu cuenta de ${(NOMBRE_DEL_ROL[sesion.role] || sesion.role).toLowerCase()}`
      : "guía del sitio · sin sesión iniciada";
  }

  const sugerenciasEl = document.getElementById("asistente-sugerencias");
  if (!sugerenciasEl) return;

  const ejemplos = destinosPermitidos()
    .filter((d) => !d.accion)
    .slice(0, 3);

  sugerenciasEl.innerHTML = ejemplos
    .map((destino) => `<button type="button" class="asistente-chip" data-id="${destino.id}">${destino.nombre}</button>`)
    .join("");

  sugerenciasEl.querySelectorAll("button[data-id]").forEach((chip) => {
    chip.addEventListener("click", () => {
      const destino = DESTINOS_ASISTENTE.find((d) => d.id === chip.dataset.id);
      if (!destino) return;
      agregarAlChat(`Llevame a ${destino.nombre}`, "yo");
      irADestino(destino);
    });
  });
}

document.addEventListener("DOMContentLoaded", construirAsistente);
