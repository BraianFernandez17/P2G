/* ============================================================
   MÓDULO DE RESERVAS DE SALONES (mock)
   Mismo espíritu que estudiante.js: datos de ejemplo escritos a
   mano, más funciones que "pintan" el HTML, para poder ver las
   pantallas del módulo (profesor, admin, agenda pública)
   funcionando sin backend todavía.

   En la versión real, esto se reemplaza por pedidos al backend:

     fetch("/api/v1/resources")
     fetch("/api/v1/bookings/me")
     fetch("/api/v1/bookings", { method: "POST", body: ... })
     fetch("/api/v1/bookings/:id/approve", { method: "PATCH" })

   y la regla de "no dos reservas en el mismo lugar al mismo
   tiempo" queda garantizada por Postgres (ver el EXCLUDE
   constraint en db/schema.sql), no por este JS.
   ============================================================ */

/* ------------------------------------------------------------
   INVENTARIO DE SALONES, LABORATORIOS Y EQUIPOS
   Calcado del inventario que pide la letra del proyecto, más el
   Auditorio y la Sala de Reuniones Docentes (ver db/seed.sql).
   ------------------------------------------------------------ */
const salones = [
  { id: "r1", nombre: "Biblioteca", tipo: "espacio" },
  { id: "r2", nombre: "Sala de Informática", tipo: "espacio" },
  { id: "r3", nombre: "Sala de Conferencias", tipo: "espacio" },
  { id: "r9", nombre: "Auditorio", tipo: "espacio" },
  { id: "r10", nombre: "Sala de Reuniones Docentes", tipo: "espacio" },
  { id: "r11", nombre: "Cancha Techada", tipo: "espacio" },
  { id: "r4", nombre: "Laboratorio de Física", tipo: "laboratorio" },
  { id: "r5", nombre: "Laboratorio de Química", tipo: "laboratorio" },
  { id: "r6", nombre: "Laboratorio de Ciencias", tipo: "laboratorio" },
  { id: "r12", nombre: "Laboratorio de Robótica", tipo: "laboratorio" },
  { id: "r7", nombre: "Proyector", tipo: "equipo", cantidad: 2 },
  { id: "r8", nombre: "Televisión", tipo: "equipo", cantidad: 1 },
  { id: "r13", nombre: "Notebooks (carro móvil)", tipo: "equipo", cantidad: 15 },
  { id: "r14", nombre: "Equipo de sonido", tipo: "equipo", cantidad: 1 },
];

const ETIQUETA_TIPO_SALON = {
  espacio: "Espacios diferenciales",
  laboratorio: "Laboratorios",
  equipo: "Equipamiento móvil",
};

// Los íconos vienen de js/iconos.js (SVG, no emoji: ver el
// comentario de ese archivo).
const ICONO_TIPO_SALON = {
  espacio: "salon",
  laboratorio: "laboratorio",
  equipo: "equipo",
};

/* ------------------------------------------------------------
   PROFESORES DEL POLO
   Cinco docentes en vez de uno solo, para que el panel de admin
   y la agenda pública se vean con movimiento real de varias
   personas pidiendo salones (ver db/seed.sql: professors).
   ------------------------------------------------------------ */
const profesores = [
  { id: "p1", nombre: "Ana", apellido: "Rodríguez" },
  { id: "p2", nombre: "Diego", apellido: "Martínez" },
  { id: "p3", nombre: "Lucía", apellido: "Fernández" },
  { id: "p4", nombre: "Rubén", apellido: "Acosta" },
  { id: "p5", nombre: "Valentina", apellido: "Silveira" },
];

/* ------------------------------------------------------------
   PROFESOR ACTUAL
   Simula a quién le mostramos "Mis reservas" en
   dashboard-profesor.html. relacionConPostulacionId != null es
   el PUENTE con el módulo de pasantías: esa reserva es para la
   entrevista de una postulación puntual, no una clase normal.
   ------------------------------------------------------------ */
const profesorActual = (() => {
  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;
  if (sesion && sesion.role === "professor") {
    const [nombre, ...resto] = sesion.name.split(" ");
    return { nombre, apellido: resto.join(" ") };
  }
  // Si se abre este archivo directo, sin pasar por el login, usamos
  // este mock para que la pantalla siga siendo demostrable.
  return { nombre: "Ana", apellido: "Rodríguez" };
})();

/* ------------------------------------------------------------
   FECHAS RELATIVAS AL DÍA DE HOY
   Antes las reservas tenían la fecha escrita a mano (agosto 2026).
   El problema es que un mock con fechas fijas se vence solo: pasado
   ese mes, la agenda pública (que filtra "aprobadas y a futuro")
   quedaba vacía y el calendario no mostraba nada.

   Con este ayudante, cada reserva se define como "tantos días
   desde hoy", así la demo siempre tiene movimiento: números
   negativos = pasado (historial), positivos = próximas.
   ------------------------------------------------------------ */
function fechaRelativa(diasDesdeHoy, hora) {
  const fecha = new Date();
  fecha.setHours(0, 0, 0, 0);
  fecha.setDate(fecha.getDate() + diasDesdeHoy);
  const pad = (n) => String(n).padStart(2, "0");
  return `${fecha.getFullYear()}-${pad(fecha.getMonth() + 1)}-${pad(fecha.getDate())}T${hora}:00`;
}

let reservas = [
  {
    id: "b1",
    salonId: "r4",
    motivo: "Práctico de mecánica - 2do año",
    desde: fechaRelativa(-33, "14:00"),
    hasta: fechaRelativa(-33, "16:00"),
    estado: "approved",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b2",
    salonId: "r3",
    motivo: "Reunión de coordinación docente",
    desde: fechaRelativa(2, "10:00"),
    hasta: fechaRelativa(2, "11:00"),
    estado: "pending",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b3",
    salonId: "r2",
    motivo: "Taller de programación",
    desde: fechaRelativa(1, "09:00"),
    hasta: fechaRelativa(1, "12:00"),
    estado: "pending",
    pedidaPor: "Diego Martínez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b4",
    salonId: "r5",
    motivo: "Práctico de titulación",
    desde: fechaRelativa(5, "14:00"),
    hasta: fechaRelativa(5, "17:00"),
    estado: "pending",
    pedidaPor: "Ana Rodríguez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b5",
    salonId: "r6",
    motivo: "Práctico de biología - Bach. Agrario",
    desde: fechaRelativa(1, "14:00"),
    hasta: fechaRelativa(1, "16:00"),
    estado: "approved",
    pedidaPor: "Lucía Fernández",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b6",
    salonId: "r9",
    motivo: "Charla de egresados de Electromecánica",
    desde: fechaRelativa(3, "18:00"),
    hasta: fechaRelativa(3, "20:00"),
    estado: "approved",
    pedidaPor: "Rubén Acosta",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b7",
    salonId: "r10",
    motivo: "Reunión de coordinación de Gestión de Empresas",
    desde: fechaRelativa(-2, "09:00"),
    hasta: fechaRelativa(-2, "10:00"),
    estado: "pending",
    pedidaPor: "Valentina Silveira",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b8",
    salonId: "r12",
    motivo: "Introducción a Arduino - 3er año",
    desde: fechaRelativa(6, "14:00"),
    hasta: fechaRelativa(6, "16:00"),
    estado: "approved",
    pedidaPor: "Diego Martínez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b9",
    salonId: "r13",
    motivo: "Evaluación con notebooks - Informática",
    desde: fechaRelativa(7, "08:00"),
    hasta: fechaRelativa(7, "10:00"),
    estado: "pending",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b10",
    salonId: "r11",
    motivo: "Clase de Educación Física - Torneo interno",
    desde: fechaRelativa(2, "15:00"),
    hasta: fechaRelativa(2, "17:00"),
    estado: "approved",
    pedidaPor: "Rubén Acosta",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b11",
    salonId: "r3",
    motivo: "Presentación de proyectos finales",
    desde: fechaRelativa(-5, "10:00"),
    hasta: fechaRelativa(-5, "12:00"),
    estado: "rejected",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b12",
    salonId: "r1",
    motivo: "Charla de orientación vocacional",
    desde: fechaRelativa(8, "10:00"),
    hasta: fechaRelativa(8, "11:00"),
    estado: "cancelled",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b13",
    salonId: "r14",
    motivo: "Acto de bienvenida a nuevos estudiantes",
    desde: fechaRelativa(9, "09:00"),
    hasta: fechaRelativa(9, "10:30"),
    estado: "pending",
    pedidaPor: "Lucía Fernández",
    esMia: false,
    relacionConPostulacionId: null,
  },

  /* ------------------------------------------------------------
     ACTIVIDADES REPARTIDAS A LO LARGO DEL AÑO
     Las de arriba caen todas en estas dos semanas (es lo que se
     ve en "Mis reservas" y en la agenda). Estas otras están más
     espaciadas para que el calendario anual muestre actividad en
     varios meses y no un único mes cargado.
     ------------------------------------------------------------ */
  {
    id: "b14",
    salonId: "r9",
    motivo: "Feria de clubes de ciencia",
    desde: fechaRelativa(24, "09:00"),
    hasta: fechaRelativa(24, "17:00"),
    estado: "approved",
    pedidaPor: "Lucía Fernández",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b15",
    salonId: "r2",
    motivo: "Capacitación docente en herramientas digitales",
    desde: fechaRelativa(38, "14:00"),
    hasta: fechaRelativa(38, "18:00"),
    estado: "approved",
    pedidaPor: "Diego Martínez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b16",
    salonId: "r11",
    motivo: "Torneo interliceal de futsal",
    desde: fechaRelativa(52, "08:00"),
    hasta: fechaRelativa(52, "13:00"),
    estado: "approved",
    pedidaPor: "Rubén Acosta",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b17",
    salonId: "r4",
    motivo: "Defensa de proyectos de Electromecánica",
    desde: fechaRelativa(67, "09:00"),
    hasta: fechaRelativa(67, "12:00"),
    estado: "approved",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b18",
    salonId: "r9",
    motivo: "Acto de fin de cursos",
    desde: fechaRelativa(95, "19:00"),
    hasta: fechaRelativa(95, "22:00"),
    estado: "approved",
    pedidaPor: "Valentina Silveira",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b19",
    salonId: "r6",
    motivo: "Mesa de exámenes - Ciencias",
    desde: fechaRelativa(-58, "08:00"),
    hasta: fechaRelativa(-58, "12:00"),
    estado: "approved",
    pedidaPor: "Lucía Fernández",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b20",
    salonId: "r1",
    motivo: "Jornada de inducción a primer año",
    desde: fechaRelativa(-92, "09:00"),
    hasta: fechaRelativa(-92, "12:00"),
    estado: "approved",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
];

/* ------------------------------------------------------------
   EMPRESAS PENDIENTES DE APROBAR
   Mismo dato que ya existía como concepto en companies.status
   ('pending_approval'), acá como mock para el panel de admin.
   Cada una con su rubro/sector, para mostrar el chip de tipo
   de empresa en la cola de aprobación.
   ------------------------------------------------------------ */
let empresasPendientes = [
  { id: "c1", razonSocial: "Industrias del Norte", sector: "industria" },
  { id: "c2", razonSocial: "Clínica Salud Tacuarembó", sector: "salud" },
];

// Empresas que YA están aprobadas (contraparte de empresasPendientes).
// Junto a ese array arman el "directorio" completo que ve el admin en
// dashboard-admin-pasantias.html: al aprobar una empresa pendiente,
// pasa de una lista a la otra (ver pintarColaDeEmpresas).
let empresasActivas = [
  { id: "c3", razonSocial: "TechCorp Tacuarembó", sector: "tecnologia" },
  { id: "c4", razonSocial: "AgroTacuá S.A.", sector: "agropecuaria" },
];

/* ------------------------------------------------------------
   ALUMNOS Y SUS POSTULACIONES (vista del admin)
   A diferencia de "Mis postulaciones" (estudiante) o "Postulantes"
   (empresa), acá se ven TODAS juntas, de cualquier alumno y
   cualquier empresa: es la foto completa del embudo de pasantías
   que necesita el admin para tener panorama, sin entrar cuenta
   por cuenta. Los 6 estados son los mismos que define
   applications.status en db/schema.sql.
   ------------------------------------------------------------ */
const postulacionesAdmin = [
  {
    id: "ap1",
    alumno: "María González",
    carrera: "Tecnólogo en Informática",
    pasantia: "Desarrollador Frontend Jr",
    empresa: "TechCorp Tacuarembó",
    estado: "selected",
  },
  {
    id: "ap2",
    alumno: "Facundo Pereira",
    carrera: "Tecnólogo en Mecánica",
    pasantia: "Soporte de Datos",
    empresa: "TechCorp Tacuarembó",
    estado: "under_review",
  },
  {
    id: "ap3",
    alumno: "Camila Sosa",
    carrera: "Tecnólogo en Gestión de Empresas",
    pasantia: "Asistente de Agroindustria",
    empresa: "AgroTacuá S.A.",
    estado: "submitted",
  },
  {
    id: "ap4",
    alumno: "Bruno Techera",
    carrera: "Tecnicatura en Análisis y Desarrollo de Software",
    pasantia: "Desarrollador Frontend Jr",
    empresa: "TechCorp Tacuarembó",
    estado: "shortlisted",
  },
  {
    id: "ap5",
    alumno: "Ivana Correa",
    carrera: "Tecnólogo en Electrónica",
    pasantia: "Soporte de Datos",
    empresa: "TechCorp Tacuarembó",
    estado: "rejected",
  },
  {
    id: "ap6",
    alumno: "Santiago Praderi",
    carrera: "Tecnólogo Químico",
    pasantia: "Asistente de Agroindustria",
    empresa: "AgroTacuá S.A.",
    estado: "withdrawn",
  },
];

// Los 6 estados de applications.status, bajados a las 4 variantes
// visuales que ya tiene .status-badge (pending/approved/rejected/
// cancelled), para no tener que inventar colores nuevos.
const ETIQUETA_POSTULACION_ADMIN = {
  submitted: "Enviada",
  under_review: "En revisión",
  shortlisted: "Preseleccionado",
  selected: "Seleccionado",
  rejected: "Rechazada",
  withdrawn: "Retirada",
};

const TONO_POSTULACION_ADMIN = {
  submitted: "pending",
  under_review: "pending",
  shortlisted: "pending",
  selected: "approved",
  rejected: "rejected",
  withdrawn: "cancelled",
};

/* ------------------------------------------------------------
   POSTULACIONES "SELECTED" QUE TODAVÍA NO TIENEN ENTREVISTA
   AGENDADA. Esta lista es el otro lado del puente: cuando una
   postulación llega a "selected" (ver applications.status en
   schema.sql), la empresa necesita coordinar una entrevista
   presencial, y acá el admin la puede reservar con un clic en
   vez de ir y venir por mail como se hace hoy.
   ------------------------------------------------------------ */
let entrevistasPorAgendar = [
  {
    id: "a1",
    nombreEstudiante: "María González",
    tituloPasantia: "Desarrollador Frontend Jr",
    nombreEmpresa: "TechCorp Tacuarembó",
    agendada: false,
  },
];

/* ============================================================
   FUNCIONES DE FORMATO
   (los toasts y el modal de confirmación ahora viven en
   js/ui.js, compartidos con estudiante y empresa)
   ============================================================ */
const ETIQUETA_ESTADO = {
  pending: "Pendiente",
  approved: "Aprobada",
  rejected: "Rechazada",
  cancelled: "Cancelada",
};

function nombreDelSalon(salonId) {
  const salon = salones.find((s) => s.id === salonId);
  return salon ? salon.nombre : "Salón";
}

// Convierte "2026-08-05T14:00:00" / "2026-08-05T16:00:00" en algo
// legible tipo "05/08 · 14:00 a 16:00", sin depender de librerías.
function formatearRango(desde, hasta) {
  const inicio = new Date(desde);
  const fin = new Date(hasta);

  const pad = (n) => String(n).padStart(2, "0");
  const etiquetaFecha = `${pad(inicio.getDate())}/${pad(inicio.getMonth() + 1)}`;
  const horaInicio = `${pad(inicio.getHours())}:${pad(inicio.getMinutes())}`;
  const horaFin = `${pad(fin.getHours())}:${pad(fin.getMinutes())}`;

  return `${etiquetaFecha} · ${horaInicio} a ${horaFin}`;
}

function chipDeEstado(estado) {
  return `<span class="status-badge ${estado}">${ETIQUETA_ESTADO[estado]}</span>`;
}

/* ============================================================
   VALIDACIÓN DE SOLAPAMIENTO (solo un aviso del lado del cliente)
   OJO: esto es nada más que una ayuda visual para que la persona
   no llene el formulario en vano. La verdad absoluta la tiene el
   EXCLUDE constraint de Postgres (ver schema.sql): si dos
   pedidos llegan al mismo tiempo, el backend es quien decide, no
   este chequeo hecho en el navegador.
   ============================================================ */
function haySolapamiento(salonId, desde, hasta, idAExcluir) {
  const nuevoInicio = new Date(desde).getTime();
  const nuevoFin = new Date(hasta).getTime();

  return reservas.some((reserva) => {
    if (reserva.id === idAExcluir) return false;
    if (reserva.salonId !== salonId) return false;
    if (reserva.estado !== "pending" && reserva.estado !== "approved") return false;

    const inicioExistente = new Date(reserva.desde).getTime();
    const finExistente = new Date(reserva.hasta).getTime();

    return nuevoInicio < finExistente && nuevoFin > inicioExistente;
  });
}

/* ============================================================
   AVISO DE DISPONIBILIDAD EN VIVO
   Mejora al formulario de reserva: en vez de que la persona se
   entere de un choque de horario recién al enviar, se lo mostramos
   apenas completa salón + fecha + horario. Sigue siendo solo un
   aviso del lado del cliente (misma lógica que haySolapamiento);
   la validación real sigue pasando en manejarNuevaReserva.
   ============================================================ */
function inicializarChequeoDisponibilidad() {
  const formulario = document.getElementById("form-nueva-reserva");
  if (!formulario) return;

  let hintEl = document.getElementById("disponibilidad-hint");
  if (!hintEl) {
    hintEl = document.createElement("p");
    hintEl.id = "disponibilidad-hint";
    hintEl.className = "availability-hint";
    const boton = formulario.querySelector("button[type=submit]");
    formulario.insertBefore(hintEl, boton);
  }

  const idsCampos = ["salon", "reserva-fecha", "reserva-desde", "reserva-hasta"];
  const campos = idsCampos.map((id) => document.getElementById(id));

  function actualizarAviso() {
    const [salonEl, fechaEl, desdeEl, hastaEl] = campos;
    const salonId = salonEl.value;
    const fecha = fechaEl.value;
    const horaDesde = desdeEl.value;
    const horaHasta = hastaEl.value;

    if (!salonId || !fecha || !horaDesde || !horaHasta) {
      hintEl.className = "availability-hint";
      hintEl.textContent = "";
      return;
    }

    const desde = `${fecha}T${horaDesde}:00`;
    const hasta = `${fecha}T${horaHasta}:00`;

    if (new Date(hasta) <= new Date(desde)) {
      hintEl.className = "availability-hint busy";
      hintEl.textContent = "⚠ La hora de fin tiene que ser posterior a la de inicio.";
      return;
    }

    if (haySolapamiento(salonId, desde, hasta, null)) {
      hintEl.className = "availability-hint busy";
      hintEl.textContent = `⚠ ${nombreDelSalon(salonId)} ya tiene otra reserva en ese horario.`;
    } else {
      hintEl.className = "availability-hint free";
      hintEl.textContent = `✓ ${nombreDelSalon(salonId)} está disponible en ese horario.`;
    }
  }

  campos.forEach((campo) => campo && campo.addEventListener("change", actualizarAviso));
  formulario.addEventListener("reset", () => {
    setTimeout(() => {
      hintEl.className = "availability-hint";
      hintEl.textContent = "";
    }, 0);
  });
}

/* ============================================================
   RENDER: SELECT DE SALONES (agrupado por tipo, con <optgroup>)
   Se usa en dashboard-profesor.html.
   ============================================================ */
function pintarOpcionesDeSalones(selectEl) {
  const grupos = {};
  salones.forEach((salon) => {
    if (!grupos[salon.tipo]) grupos[salon.tipo] = [];
    grupos[salon.tipo].push(salon);
  });

  const optgroupsHtml = Object.keys(grupos)
    .map((tipo) => {
      const opcionesHtml = grupos[tipo]
        .map((s) => `<option value="${s.id}">${s.nombre}</option>`)
        .join("");
      return `<optgroup label="${ETIQUETA_TIPO_SALON[tipo]}">${opcionesHtml}</optgroup>`;
    })
    .join("");

  selectEl.innerHTML =
    `<option value="" disabled selected>Elegí un salón</option>` + optgroupsHtml;
}

/* ============================================================
   PANTALLA: dashboard-profesor.html
   ============================================================ */

// Filtro activo de "Mis reservas" (pestañas). Vive fuera de la
// función de render para que sobreviva entre repintados.
let filtroMisReservas = "todas";

function pintarPestanasMisReservas() {
  const listaEl = document.getElementById("lista-mis-reservas");
  if (!listaEl) return;

  let tabsEl = document.getElementById("tabs-mis-reservas");
  if (!tabsEl) {
    tabsEl = document.createElement("div");
    tabsEl.id = "tabs-mis-reservas";
    tabsEl.className = "tabs";
    listaEl.parentElement.insertBefore(tabsEl, listaEl);
  }

  const opciones = [
    { valor: "todas", etiqueta: "Todas" },
    { valor: "pending", etiqueta: "Pendientes" },
    { valor: "approved", etiqueta: "Aprobadas" },
    { valor: "rejected", etiqueta: "Rechazadas" },
    { valor: "cancelled", etiqueta: "Canceladas" },
  ];

  tabsEl.innerHTML = opciones
    .map(
      (op) => `
      <button type="button" class="tab ${filtroMisReservas === op.valor ? "active" : ""}" data-filtro="${op.valor}">
        ${op.etiqueta}
      </button>
    `
    )
    .join("");

  tabsEl.querySelectorAll("button[data-filtro]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroMisReservas = boton.dataset.filtro;
      pintarMisReservas();
    });
  });
}

/* ============================================================
   TABLERO DEL PROFESOR
   Cuelga debajo de la portada del panel: cuántas reservas tiene en
   cada estado y cuál es la próxima aprobada. Se vuelve a pintar
   cada vez que se repinta "Mis reservas" (al pedir o cancelar),
   así nunca muestra números viejos.
   ============================================================ */
function pintarTableroProfesor() {
  const tableroEl = document.getElementById("tablero-profesor");
  if (!tableroEl) return;

  const mias = reservas.filter((r) => r.esMia);
  const ahora = new Date();
  const proxima = mias
    .filter((r) => r.estado === "approved" && new Date(r.desde) >= ahora)
    .sort((a, b) => new Date(a.desde) - new Date(b.desde))[0];
  const pad = (n) => String(n).padStart(2, "0");
  const cuando = proxima
    ? (() => {
        const d = new Date(proxima.desde);
        return `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
      })()
    : "--/--";

  const items = [
    { icono: icono("tilde"), tono: "success", etiqueta: "Aprobadas", valor: mias.filter((r) => r.estado === "approved").length },
    { icono: icono("reloj"), tono: "warning", etiqueta: "Esperando aprobación", valor: mias.filter((r) => r.estado === "pending").length },
    {
      icono: icono("calendario"),
      tono: "accent",
      etiqueta: proxima ? `Próxima: ${nombreDelSalon(proxima.salonId)}` : "Sin reservas próximas",
      valor: cuando,
      ancha: true,
    },
  ];

  tableroEl.innerHTML = items
    .map(
      (item) => `
      <div class="stat-card${item.ancha ? " stat-card-ancha" : ""}" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

function pintarMisReservas() {
  const listaEl = document.getElementById("lista-mis-reservas");
  if (!listaEl) return;

  pintarPestanasMisReservas();
  pintarTableroProfesor();

  let mias = reservas.filter((r) => r.esMia);
  if (filtroMisReservas !== "todas") {
    mias = mias.filter((r) => r.estado === filtroMisReservas);
  }
  mias = [...mias].sort((a, b) => new Date(a.desde) - new Date(b.desde));

  if (mias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay reservas para mostrar en "${
      { todas: "Todas", pending: "Pendientes", approved: "Aprobadas", rejected: "Rechazadas", cancelled: "Canceladas" }[filtroMisReservas]
    }".</p>`;
    return;
  }

  listaEl.innerHTML = mias
    .map(
      (reserva) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${reserva.motivo}</p>
          <p class="booking-card-meta">
            ${nombreDelSalon(reserva.salonId)} · ${formatearRango(reserva.desde, reserva.hasta)}
          </p>
        </div>
        <div class="booking-card-actions">
          ${chipDeEstado(reserva.estado)}
          ${
            reserva.estado === "pending"
              ? `<button class="btn-reject" data-cancelar-id="${reserva.id}">Cancelar</button>`
              : ""
          }
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-cancelar-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const reserva = reservas.find((r) => r.id === boton.dataset.cancelarId);
      pedirConfirmacion(
        "Cancelar reserva",
        `¿Cancelar el pedido de "${reserva.motivo}"? Esta acción no se puede deshacer.`,
        () => {
          // Versión real: PATCH /api/v1/bookings/:id/cancel
          reserva.estado = "cancelled";
          pintarMisReservas();
          pintarColaDeReservas();
          pintarAgendaPublica();
          pintarEstadisticasReservas();
          mostrarToast("Reserva cancelada.", "info");
        }
      );
    });
  });
}

function manejarNuevaReserva(evento) {
  evento.preventDefault();
  const formulario = evento.target;

  const salonId = formulario.querySelector("#salon").value;
  const motivo = formulario.querySelector("#reserva-motivo").value.trim();
  const fecha = formulario.querySelector("#reserva-fecha").value;
  const horaDesde = formulario.querySelector("#reserva-desde").value;
  const horaHasta = formulario.querySelector("#reserva-hasta").value;

  if (!salonId || !motivo || !fecha || !horaDesde || !horaHasta) {
    mostrarToast("Completá todos los campos para pedir la reserva.", "error");
    return;
  }

  const desde = `${fecha}T${horaDesde}:00`;
  const hasta = `${fecha}T${horaHasta}:00`;

  if (new Date(hasta) <= new Date(desde)) {
    mostrarToast("La hora de fin tiene que ser posterior a la hora de inicio.", "error");
    return;
  }

  if (haySolapamiento(salonId, desde, hasta, null)) {
    mostrarToast(
      `Ya hay otra reserva para ${nombreDelSalon(salonId)} que se solapa con ese horario.`,
      "error"
    );
    return;
  }

  // Versión real: POST /api/v1/bookings con este cuerpo.
  reservas.push({
    id: `b${reservas.length + 1}`,
    salonId,
    motivo,
    desde,
    hasta,
    estado: "pending",
    pedidaPor: `${profesorActual.nombre} ${profesorActual.apellido}`,
    esMia: true,
    relacionConPostulacionId: null,
  });

  formulario.reset();
  pintarMisReservas();
  mostrarToast("Reserva enviada. Queda pendiente de aprobación del admin.", "success");
}

/* ============================================================
   PANTALLA: dashboard-admin.html
   ============================================================ */

// Filtro activo de la cola de reservas (por tipo de salón), igual
// idea que filtroMisReservas del profesor.
let filtroTipoAdmin = "todos";

function pintarFiltrosColaReservas() {
  const listaEl = document.getElementById("lista-reservas-admin");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-tipo-admin");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-tipo-admin";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const opciones = [
    { valor: "todos", etiqueta: "Todos" },
    { valor: "espacio", etiqueta: `${icono(ICONO_TIPO_SALON.espacio, 14)}Espacios` },
    { valor: "laboratorio", etiqueta: `${icono(ICONO_TIPO_SALON.laboratorio, 14)}Laboratorios` },
    { valor: "equipo", etiqueta: `${icono(ICONO_TIPO_SALON.equipo, 14)}Equipos` },
  ];

  filtrosEl.innerHTML = opciones
    .map(
      (op) => `
      <button type="button" class="filter-chip ${filtroTipoAdmin === op.valor ? "active" : ""}" data-tipo="${op.valor}">
        ${op.etiqueta}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-tipo]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroTipoAdmin = boton.dataset.tipo;
      pintarColaDeReservas();
    });
  });
}

function pintarColaDeReservas() {
  const listaEl = document.getElementById("lista-reservas-admin");
  if (!listaEl) return;

  pintarFiltrosColaReservas();

  let pendientes = reservas.filter((r) => r.estado === "pending");
  if (filtroTipoAdmin !== "todos") {
    pendientes = pendientes.filter((r) => {
      const salon = salones.find((s) => s.id === r.salonId);
      return salon && salon.tipo === filtroTipoAdmin;
    });
  }
  pendientes = [...pendientes].sort((a, b) => new Date(a.desde) - new Date(b.desde));

  if (pendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay reservas pendientes de aprobar${
      filtroTipoAdmin === "todos" ? "" : " en esta categoría"
    }.</p>`;
    return;
  }

  listaEl.innerHTML = pendientes
    .map(
      (reserva) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${reserva.motivo}</p>
          <p class="booking-card-meta">
            ${nombreDelSalon(reserva.salonId)} · ${formatearRango(reserva.desde, reserva.hasta)}
            · Pedida por ${reserva.pedidaPor}
          </p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-approve" data-reserva-id="${reserva.id}" data-accion="approve">Aprobar</button>
          <button class="btn-reject" data-reserva-id="${reserva.id}" data-accion="reject">Rechazar</button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-reserva-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const reservaId = boton.dataset.reservaId;
      const accion = boton.dataset.accion;
      const reserva = reservas.find((r) => r.id === reservaId);

      const aplicarDecision = () => {
        // Versión real: PATCH /api/v1/bookings/:id/approve o /reject
        reserva.estado = accion === "approve" ? "approved" : "rejected";
        pintarColaDeReservas();
        pintarAgendaPublica();
        pintarEstadisticasReservas();
        pintarInventarioDeSalones();
        mostrarToast(
          accion === "approve" ? "Reserva aprobada." : "Reserva rechazada.",
          accion === "approve" ? "success" : "info"
        );
      };

      if (accion === "reject") {
        pedirConfirmacion(
          "Rechazar reserva",
          `¿Rechazar el pedido de "${reserva.motivo}" para ${nombreDelSalon(reserva.salonId)}?`,
          aplicarDecision
        );
      } else {
        aplicarDecision();
      }
    });
  });
}

function pintarColaDeEmpresas() {
  const listaEl = document.getElementById("lista-empresas-admin");
  if (!listaEl) return;

  if (empresasPendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay empresas pendientes de aprobar.</p>`;
    return;
  }

  listaEl.innerHTML = empresasPendientes
    .map(
      (empresa) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${empresa.razonSocial}</p>
          <p class="booking-card-meta">
            <span class="sector-tag">${empresa.sector}</span>
            · Cuenta nueva, esperando aprobación para poder publicar pasantías
          </p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-approve" data-empresa-id="${empresa.id}" data-accion="approve">Aprobar</button>
          <button class="btn-reject" data-empresa-id="${empresa.id}" data-accion="reject">Rechazar</button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-empresa-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const empresaId = boton.dataset.empresaId;
      const accion = boton.dataset.accion;
      const empresa = empresasPendientes.find((e) => e.id === empresaId);

      const aplicarDecision = () => {
        // Versión real: PATCH /api/v1/companies/:id/approve o /reject
        empresasPendientes = empresasPendientes.filter((e) => e.id !== empresaId);
        if (accion === "approve") {
          empresasActivas.push({ id: empresa.id, razonSocial: empresa.razonSocial, sector: empresa.sector });
        }
        pintarColaDeEmpresas();
        pintarResumenPasantias();
        pintarEmpresasRegistradas();
        mostrarToast(
          accion === "approve"
            ? `${empresa.razonSocial} aprobada. Ya puede publicar pasantías.`
            : `${empresa.razonSocial} rechazada.`,
          accion === "approve" ? "success" : "info"
        );
      };

      if (accion === "reject") {
        pedirConfirmacion(
          "Rechazar empresa",
          `¿Rechazar la cuenta de "${empresa.razonSocial}"? No va a poder publicar pasantías.`,
          aplicarDecision
        );
      } else {
        aplicarDecision();
      }
    });
  });
}

// Directorio completo de empresas (activas + pendientes), para que
// el admin tenga ejemplos concretos de con quién está trabajando el
// Polo, no solo la cola de aprobación. Las activas primero.
function pintarEmpresasRegistradas() {
  const listaEl = document.getElementById("lista-empresas-registradas");
  if (!listaEl) return;

  const directorio = [
    ...empresasActivas.map((e) => ({ ...e, estado: "approved", etiqueta: "Activa" })),
    ...empresasPendientes.map((e) => ({ ...e, estado: "pending", etiqueta: "Pendiente" })),
  ];

  if (directorio.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no hay empresas registradas.</p>`;
    return;
  }

  listaEl.innerHTML = directorio
    .map(
      (empresa) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${empresa.razonSocial}</p>
          <p class="booking-card-meta">
            <span class="sector-tag">${empresa.sector}</span>
          </p>
        </div>
        <span class="status-badge ${empresa.estado}">${empresa.etiqueta}</span>
      </div>
    `
    )
    .join("");
}

// Vista agregada de "alumnos y sus postulaciones", de cualquier
// empresa: le da al admin panorama del embudo completo de pasantías
// sin tener que entrar cuenta por cuenta.
function pintarPostulacionesAdmin() {
  const listaEl = document.getElementById("lista-postulaciones-admin");
  if (!listaEl) return;

  if (postulacionesAdmin.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no hay postulaciones.</p>`;
    return;
  }

  listaEl.innerHTML = postulacionesAdmin
    .map(
      (postulacion) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${postulacion.alumno}</p>
          <p class="booking-card-meta">
            ${postulacion.carrera} · ${postulacion.pasantia} en ${postulacion.empresa}
          </p>
        </div>
        <span class="status-badge ${TONO_POSTULACION_ADMIN[postulacion.estado]}">
          ${ETIQUETA_POSTULACION_ADMIN[postulacion.estado]}
        </span>
      </div>
    `
    )
    .join("");
}

// Esta es la parte "puente": el admin agenda la sala de
// entrevista para una postulación que ya llegó a "selected",
// usando el mismo motor de reservas que usan los profesores.
// Como quien la pide es el propio admin (quien aprueba), la
// reserva nace directamente en estado "approved".
function pintarEntrevistasPorAgendar() {
  const listaEl = document.getElementById("lista-entrevistas-agendar");
  if (!listaEl) return;

  const pendientes = entrevistasPorAgendar.filter((e) => !e.agendada);

  if (pendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay entrevistas pendientes de agendar.</p>`;
    return;
  }

  listaEl.innerHTML = pendientes
    .map(
      (entrevista) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${entrevista.nombreEstudiante} — ${entrevista.tituloPasantia}</p>
          <p class="booking-card-meta">${entrevista.nombreEmpresa} · postulación seleccionada</p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-secondary" data-postulacion-id="${entrevista.id}">
            Reservar sala de entrevista
          </button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-postulacion-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const postulacionId = boton.dataset.postulacionId;
      const entrevista = entrevistasPorAgendar.find((e) => e.id === postulacionId);
      agendarEntrevista(entrevista);
    });
  });
}

function agendarEntrevista(entrevista) {
  // Por simplicidad del mock, la entrevista queda fija para
  // dentro de 2 días de 15:00 a 15:45 en la Sala de Conferencias.
  // En la versión real, un formulario le dejaría elegir fecha y hora.
  const inicio = new Date();
  inicio.setDate(inicio.getDate() + 2);
  inicio.setHours(15, 0, 0, 0);
  const fin = new Date(inicio);
  fin.setMinutes(45);

  const desde = inicio.toISOString().slice(0, 19);
  const hasta = fin.toISOString().slice(0, 19);

  if (haySolapamiento("r3", desde, hasta, null)) {
    mostrarToast("La Sala de Conferencias ya tiene otra reserva en ese horario.", "error");
    return;
  }

  reservas.push({
    id: `b${reservas.length + 1}`,
    salonId: "r3",
    motivo: `Entrevista: ${entrevista.nombreEstudiante} (${entrevista.nombreEmpresa})`,
    desde,
    hasta,
    estado: "approved",
    pedidaPor: "Admin del Polo",
    esMia: false,
    relacionConPostulacionId: entrevista.id,
  });

  entrevista.agendada = true;

  pintarEntrevistasPorAgendar();
  pintarAgendaPublica();
  pintarEstadisticasReservas();
  pintarInventarioDeSalones();
  pintarResumenPasantias();
  mostrarToast(
    `Sala de Conferencias reservada para la entrevista de ${entrevista.nombreEstudiante}.`,
    "success"
  );
}

// Inventario de salones agrupado por tipo: cumple el pedido de la
// letra de que el admin pueda ver "el mantenimiento del inventario
// de salas y equipos" de un vistazo.
// Antes esta tarjeta solo decía "Disponible" siempre; ahora suma
// cuántas reservas aprobadas y a futuro tiene cada salón, para que
// el admin vea de un vistazo qué está más pedido sin entrar a la
// cola de reservas.
function pintarInventarioDeSalones() {
  const gridEl = document.getElementById("grilla-inventario");
  if (!gridEl) return;

  const ahora = new Date();

  gridEl.innerHTML = salones
    .map((salon) => {
      const proximas = reservas.filter(
        (r) => r.salonId === salon.id && r.estado === "approved" && new Date(r.desde) >= ahora
      ).length;

      const textoOcupacion = salon.cantidad
        ? `${salon.cantidad} unidades`
        : proximas > 0
        ? `${proximas} reserva${proximas === 1 ? "" : "s"} próxima${proximas === 1 ? "" : "s"}`
        : "Sin reservas próximas";

      return `
      <div class="inventory-card">
        <p class="inventory-card-type">${icono(ICONO_TIPO_SALON[salon.tipo], 15)}${ETIQUETA_TIPO_SALON[salon.tipo]}</p>
        <p class="inventory-card-name">${salon.nombre}</p>
        <p class="inventory-card-qty">${textoOcupacion}</p>
      </div>
    `;
    })
    .join("");
}

// Tarjetas de métricas del panel de admin — el foco es reservas:
// cuántos salones hay, cuántas reservas están pendientes/aprobadas
// y cuántos profesores las piden. "Empresas por aprobar" quedó
// afuera de esta grilla a propósito: es dato de pasantías, y ese
// módulo va después, con menos protagonismo (ver pintarResumenPasantias).
function pintarEstadisticasReservas() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const reservasPendientes = reservas.filter((r) => r.estado === "pending").length;
  const reservasAprobadas = reservas.filter((r) => r.estado === "approved").length;
  const hoyStr = new Date().toISOString().slice(0, 10);
  const reservasHoy = reservas.filter(
    (r) => r.estado === "approved" && r.desde.slice(0, 10) === hoyStr
  ).length;

  const estadisticas = [
    { icono: icono("edificio"), tono: "primary", etiqueta: "Salones y equipos", valor: salones.length },
    { icono: icono("reloj"), tono: "warning", etiqueta: "Reservas pendientes", valor: reservasPendientes },
    { icono: icono("tilde"), tono: "success", etiqueta: "Reservas aprobadas", valor: reservasAprobadas },
    { icono: icono("calendario"), tono: "accent", etiqueta: "Reservas de hoy", valor: reservasHoy },
    { icono: icono("persona"), tono: "info", etiqueta: "Profesores activos", valor: profesores.length },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

// Resumen chico (no una grilla de tarjetas grandes) para el módulo
// secundario de pasantías: cuántas empresas esperan aprobación y
// cuántas entrevistas quedan por agendar, en una sola línea.
function pintarResumenPasantias() {
  const resumenEl = document.getElementById("resumen-pasantias");
  if (!resumenEl) return;

  const entrevistasSinAgendar = entrevistasPorAgendar.filter((e) => !e.agendada).length;

  resumenEl.innerHTML = `
    <span class="mini-stat">${icono("edificio", 14)}${empresasPendientes.length} empresa${empresasPendientes.length === 1 ? "" : "s"} por aprobar</span>
    <span class="mini-stat">🗓️ ${entrevistasSinAgendar} entrevista${entrevistasSinAgendar === 1 ? "" : "s"} por agendar</span>
  `;
}

/* ============================================================
   PANTALLA: agenda-publica.html
   Solo muestra reservas ya aprobadas y a futuro: es justamente
   lo que la letra pide para el perfil Alumno/Público, sin login.

   Mejora: además de la tabla original, se puede ver la misma
   información agrupada "por día", más fácil de escanear cuando
   hay varias reservas seguidas. Un toggle alterna entre las dos
   vistas; ambas se arman con los mismos datos.
   ============================================================ */
// "tabla" | "dia". Arranca en lo que la persona haya elegido en
// Configuración (menú de perfil); si nunca tocó nada, en "tabla".
let vistaAgendaPublica =
  typeof obtenerPreferencias === "function" ? obtenerPreferencias().vistaAgenda : "tabla";

function asegurarToggleVistaAgenda() {
  const tablaEl = document.querySelector(".agenda-table");
  if (!tablaEl || document.getElementById("toggle-vista-agenda")) return;

  const toggleEl = document.createElement("div");
  toggleEl.id = "toggle-vista-agenda";
  toggleEl.className = "view-toggle";
  // Marcamos como activo el botón de la vista actual, que puede
  // venir de la preferencia guardada en Configuración, no siempre
  // "tabla".
  toggleEl.innerHTML = `
    <button type="button" class="view-toggle-btn ${vistaAgendaPublica === "tabla" ? "active" : ""}" data-vista="tabla">Tabla</button>
    <button type="button" class="view-toggle-btn ${vistaAgendaPublica === "dia" ? "active" : ""}" data-vista="dia">Por día</button>
  `;
  tablaEl.parentElement.insertBefore(toggleEl, tablaEl);

  const porDiaEl = document.createElement("div");
  porDiaEl.id = "agenda-por-dia";
  porDiaEl.className = "agenda-por-dia";
  tablaEl.parentElement.insertBefore(porDiaEl, tablaEl.nextSibling);

  toggleEl.querySelectorAll("button[data-vista]").forEach((boton) => {
    boton.addEventListener("click", () => {
      vistaAgendaPublica = boton.dataset.vista;
      toggleEl.querySelectorAll("button").forEach((b) => b.classList.toggle("active", b === boton));
      aplicarVistaAgenda();
    });
  });
}

function aplicarVistaAgenda() {
  const tablaEl = document.querySelector(".agenda-table");
  const porDiaEl = document.getElementById("agenda-por-dia");
  if (!tablaEl || !porDiaEl) return;
  tablaEl.style.display = vistaAgendaPublica === "tabla" ? "table" : "none";
  porDiaEl.style.display = vistaAgendaPublica === "dia" ? "block" : "none";
}

function pintarAgendaPublica() {
  const cuerpoEl = document.getElementById("cuerpo-tabla-agenda");
  const vaciaEl = document.getElementById("agenda-vacia");
  if (!cuerpoEl) return;

  asegurarToggleVistaAgenda();
  const porDiaEl = document.getElementById("agenda-por-dia");
  const tablaEl = document.querySelector(".agenda-table");

  const ahora = new Date();
  const proximas = reservas
    .filter((r) => r.estado === "approved" && new Date(r.desde) >= ahora)
    .sort((a, b) => new Date(a.desde) - new Date(b.desde));

  if (proximas.length === 0) {
    cuerpoEl.innerHTML = "";
    if (porDiaEl) porDiaEl.innerHTML = "";
    if (vaciaEl) vaciaEl.style.display = "block";
    if (tablaEl) tablaEl.style.display = "none";
    if (porDiaEl) porDiaEl.style.display = "none";
    return;
  }

  if (vaciaEl) vaciaEl.style.display = "none";

  // Vista tabla (la original).
  cuerpoEl.innerHTML = proximas
    .map(
      (reserva) => `
      <tr>
        <td>${formatearRango(reserva.desde, reserva.hasta)}</td>
        <td>${nombreDelSalon(reserva.salonId)}</td>
        <td>${reserva.motivo}</td>
        <td>${reserva.pedidaPor}</td>
      </tr>
    `
    )
    .join("");

  // Vista "por día": mismas reservas, agrupadas por fecha.
  if (porDiaEl) {
    const grupos = {};
    proximas.forEach((reserva) => {
      const fecha = reserva.desde.slice(0, 10);
      if (!grupos[fecha]) grupos[fecha] = [];
      grupos[fecha].push(reserva);
    });

    const etiquetasDia = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];

    porDiaEl.innerHTML = Object.keys(grupos)
      .map((fecha) => {
        const d = new Date(`${fecha}T00:00:00`);
        const pad = (n) => String(n).padStart(2, "0");
        const etiquetaFecha = `${etiquetasDia[d.getDay()]} ${pad(d.getDate())}/${pad(d.getMonth() + 1)}`;

        const tarjetas = grupos[fecha]
          .map(
            (reserva) => `
            <div class="booking-card">
              <div>
                <p class="booking-card-title">${nombreDelSalon(reserva.salonId)} · ${reserva.motivo}</p>
                <p class="booking-card-meta">${formatearRango(reserva.desde, reserva.hasta)} · ${reserva.pedidaPor}</p>
              </div>
            </div>
          `
          )
          .join("");

        return `
          <div class="agenda-day-group">
            <p class="agenda-day-heading">${etiquetaFecha}</p>
            <div class="booking-list">${tarjetas}</div>
          </div>
        `;
      })
      .join("");
  }

  aplicarVistaAgenda();
}

/* ============================================================
   SALUDO (compartido por dashboard-profesor.html y
   dashboard-admin.html: cada uno tiene su propio #saludo)
   ============================================================ */
function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;

  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;
  // El hub (dashboard-admin.html) tiene esta grilla de opciones; las
  // subpáginas (reservas / pasantías) no, así que con esto alcanza
  // para distinguir un saludo más corto del encabezado de cada módulo.
  const esHub = !!document.getElementById("hub-opciones");

  if (sesion && sesion.role === "professor") {
    saludoEl.textContent = `Hola, Prof. ${profesorActual.apellido}`;
  } else if (sesion && sesion.role === "admin") {
    saludoEl.textContent = esHub ? `Hola, ${sesion.name}` : `Panel del administrador — ${sesion.name}`;
  } else {
    // Mock, para cuando se abre el archivo directo sin login.
    saludoEl.textContent = esHub ? "Hola, Admin del Polo" : `Hola, Prof. ${profesorActual.apellido}`;
  }
}

// Números chicos que se muestran dentro de cada tarjeta del hub
// (dashboard-admin.html), para que la persona sepa qué la espera
// antes de entrar a Reservas o a Pasantías.
function pintarHubAdmin() {
  const hubEl = document.getElementById("hub-opciones");
  if (!hubEl) return;

  const reservasPendientes = reservas.filter((r) => r.estado === "pending").length;
  const empresasPorAprobar = empresasPendientes.length;
  const alumnosConPostulacion = new Set(postulacionesAdmin.map((p) => p.alumno)).size;

  const teaserReservas = document.getElementById("teaser-reservas");
  if (teaserReservas) {
    teaserReservas.innerHTML = `
      <span class="hub-option-teaser">${icono("salon", 14)}${salones.length} salones y equipos</span>
      <span class="hub-option-teaser">${icono("reloj", 14)}${reservasPendientes} pendientes</span>
    `;
  }

  const teaserPasantias = document.getElementById("teaser-pasantias");
  if (teaserPasantias) {
    teaserPasantias.innerHTML = `
      <span class="hub-option-teaser">${icono("edificio", 14)}${empresasPorAprobar} empresas por aprobar</span>
      <span class="hub-option-teaser">${icono("birrete", 14)}${alumnosConPostulacion} alumnos postulados</span>
    `;
  }
}

/* ============================================================
   PUNTO DE ENTRADA
   Cada página solo tiene los elementos que le corresponden, por
   eso cada función de render arranca revisando si su elemento
   existe (return temprano) antes de intentar tocar el DOM.
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  const selectSalon = document.getElementById("salon");
  if (selectSalon) pintarOpcionesDeSalones(selectSalon);

  pintarSaludo();
  pintarHubAdmin();
  pintarMisReservas();
  pintarEstadisticasReservas();
  pintarInventarioDeSalones();
  pintarColaDeReservas();
  pintarColaDeEmpresas();
  pintarEntrevistasPorAgendar();
  pintarResumenPasantias();
  pintarEmpresasRegistradas();
  pintarPostulacionesAdmin();
  pintarAgendaPublica();

  const formNuevaReserva = document.getElementById("form-nueva-reserva");
  if (formNuevaReserva) {
    formNuevaReserva.addEventListener("submit", manejarNuevaReserva);
    inicializarChequeoDisponibilidad();
  }
});
