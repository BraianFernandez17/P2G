# Polo 2 Gestión

Sistema de **reserva de salones, laboratorios y equipos** del Polo Tecnológico,
con un módulo adicional de **pasantías**.

Es un mockup funcional: todo el frontend anda de punta a punta (HTML + CSS +
JavaScript, sin frameworks ni librerías externas), pero todavía **no hay
backend**. Los datos que se ven en pantalla están escritos a mano en los
archivos de `js/`, y la sesión se guarda en el `localStorage` del navegador.
En paralelo, en `db/` está el modelo de datos real en PostgreSQL, que es lo que
ese backend usaría cuando exista.

---

## Cómo probarlo

### Solo el frontend (lo más rápido)

No hace falta instalar nada: alcanza con abrir **`index.html`** en el navegador.

Si tenés Python instalado, conviene levantarlo con un servidor local para que
todo se comporte igual que en producción:

```bash
python3 -m http.server 5500
```

Y entrar a <http://localhost:5500>.

### La base de datos (opcional)

Para ver el modelo de datos andando de verdad hace falta
[Docker](https://www.docker.com/products/docker-desktop/):

```bash
docker compose up -d
```

Eso levanta PostgreSQL y carga solo, en orden, `db/schema.sql` (crea las
tablas) y `db/seed.sql` (mete los datos de prueba). Después queda **Adminer**
en <http://localhost:8080> para mirar las tablas desde el navegador:

| Campo         | Valor        |
| ------------- | ------------ |
| Sistema       | PostgreSQL   |
| Servidor      | `db`         |
| Usuario       | `polotec`    |
| Contraseña    | `polotec`    |
| Base de datos | `polotec`    |

Para borrar todo y volver a arrancar de cero (si editás `schema.sql` o
`seed.sql`, hace falta, porque los scripts de inicio solo corren la primera vez):

```bash
docker compose down -v && docker compose up -d
```

---

## Cuentas de prueba

En `login.html` se entra **solo con el email** (todavía no se validan
contraseñas: eso lo hará el backend comparando hashes, nunca texto plano).
Las cuentas están definidas en `js/sesion.js`:

| Rol        | Email                             | Entra a                       |
| ---------- | --------------------------------- | ----------------------------- |
| Estudiante | `maria@estudiante.com`            | `dashboard-estudiante.html`   |
| Profesor   | `ana@polotec.edu.uy`              | `dashboard-profesor.html`     |
| Empresa    | `contacto@techcorp.com`           | `dashboard-empresa.html`      |
| Empresa    | `contacto@industriasnorte.com`    | igual, pero pendiente de aprobación |
| Admin      | `admin@polotec.edu.uy`            | `dashboard-admin.html`        |

> La cuenta de Industrias del Norte sirve para ver el aviso de "cuenta
> pendiente de aprobación", que es el estado `pending_approval` de la tabla
> `companies`.

La **agenda pública** (`agenda-publica.html`) se puede ver sin iniciar sesión:
es la pantalla para alumnos y público general.

---

## Qué hace cada pantalla

### Reservas (lo principal)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-profesor.html` | Profesor | Pide un salón, laboratorio o equipo. Avisa en vivo si el horario está libre u ocupado antes de enviar, y deja cancelar los pedidos propios que siguen pendientes. |
| `dashboard-admin-reservas.html` | Admin | Aprueba o rechaza los pedidos, con filtros por tipo de recurso, y ve el inventario con la ocupación próxima de cada salón. |
| `agenda-publica.html` | Cualquiera | Muestra solo las reservas ya aprobadas y a futuro, en tabla o agrupadas por día. |

### Pasantías (módulo adicional)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-estudiante.html` | Estudiante | Ve pasantías recomendadas (con filtro por modalidad), se postula y sigue el estado de cada postulación. |
| `dashboard-empresa.html` | Empresa | Publica pasantías y revisa los postulantes de cada una. |
| `dashboard-admin-pasantias.html` | Admin | Aprueba empresas nuevas y agenda las entrevistas. |

`dashboard-admin.html` es el hub: el panel de entrada del admin, que resume las
dos áreas y lleva a cada una.

### El puente entre los dos módulos

Es la parte más interesante del diseño: cuando una postulación llega al estado
`selected`, necesita una sala para la entrevista. En vez de coordinarla por
mail, el admin la reserva con un clic desde
`dashboard-admin-pasantias.html`, y eso genera una reserva normal de la Sala de
Conferencias — el mismo motor, la misma tabla `bookings` — enlazada a la
postulación por `related_application_id`.

---

## Estructura del proyecto

```
Polo 2 Gestión/
├── index.html                      Landing pública
├── login.html                      Ingreso (por email, mock)
├── registro-*.html                 Registro de estudiante / profesor / empresa
├── agenda-publica.html             Agenda sin login
├── dashboard-*.html                Un panel por rol
│
├── css/
│   └── styles.css                  Todo el diseño: tokens, tipografía y componentes
│
├── js/
│   ├── sesion.js                   Sesión, roles, buscador y menú (compartido)
│   ├── ui.js                       Avisos, modales y preferencias (compartido)
│   ├── perfil.js                   Menú de perfil: editar, configurar, salir (compartido)
│   ├── calendario.js               Calendario anual de reservas (compartido)
│   ├── asistente.js                Asistente de voz que guía por el sitio (compartido)
│   ├── iconos.js                   Íconos SVG (compartido)
│   ├── movimiento.js               Maqueta 3D, paletas, revelados e inclinación (compartido)
│   ├── autenticacion.js            Login y registros
│   ├── reservas.js                 Reservas + paneles del admin
│   ├── bolsa.js                    Perfiles, pasantías y postulaciones compartidos
│   ├── script.js                   Panel del estudiante (perfil profesional incluido)
│   └── empresa.js                  Panel de la empresa
│
├── db/
│   ├── schema.sql                  Tablas, restricciones e índices
│   ├── seed.sql                    Datos de prueba
│   └── consultas-ejemplo.sql       Los SELECT que haría el backend
│
├── fonts/
│   ├── archivo.woff2               Archivo variable (peso 100–900, ancho 62–125 %)
│   └── roboto-serif-italic.woff2   Roboto Serif cursiva variable (peso 100–900, tamaño óptico)
├── img/                            Isotipo y fotos del Polo
└── docker-compose.yml              PostgreSQL + Adminer
```

Cuatro archivos de `js/` se cargan en varias páginas y evitan repetir código:
**`sesion.js`** (control de acceso por rol, buscador del menú y navegación entre
secciones), **`ui.js`** (avisos, modales y preferencias, que reemplazan a los
`alert()` del navegador), **`perfil.js`** (el menú del avatar) y
**`calendario.js`** (el calendario anual).

### Menú de perfil

El avatar del navbar abre un menú con tres opciones:

- **Editar perfil** — cambia el nombre y el email de la cuenta; el saludo y el
  avatar se actualizan al instante, sin recargar.
- **Configuración** — preferencias que el resto de la app respeta de verdad:
  apagar los avisos emergentes, apagar las confirmaciones antes de acciones
  importantes, y elegir con qué vista abre la agenda pública.
- **Cerrar sesión** — ahora pide confirmación (antes el ícono cerraba la sesión
  de un clic, sin avisar).

### Calendario anual

Está en el panel del profesor (solo sus reservas), en el panel de reservas del
admin (todas) y en la agenda pública. Muestra los doce meses juntos, marca los
días con reservas —más intenso cuando hay tres o más—, señala el día de hoy, y
al tocar un día se despliega el detalle abajo. Se puede filtrar por estado y
cambiar de año.

### Asistente de voz

El botón chico del borde derecho abre un panel con un hexágono vivo y un chat.
El hexágono es un `<polygon>` SVG deformado por un filtro `feTurbulence` +
`feDisplacementMap`: en reposo apenas respira en azul, al escuchar se pone
amarillo 938 C y el borde ondula más, y al hablar late en un azul más claro. Guía por el sitio. Entiende
dos formas de pedir lo mismo:

- **"Llevame a reservar un salón"** → te lleva directo a esa sección.
- **"¿Dónde está la reserva de salones?"** → te explica dónde está y te ofrece
  llevarte; podés contestarle "sí" por voz o tocar el botón.

Está **adaptado al rol de la sesión**: un alumno no puede ser enviado al panel
del profesor ni al del admin. Si lo pide, el asistente le responde que esa
sección es de otro perfil. Los atajos que muestra también cambian según quién
esté usando el sitio.

Tres aclaraciones sobre cómo funciona, porque no es lo que suele asumirse:

1. **La voz la pone el navegador**, con la Web Speech API
   (`SpeechRecognition` para escuchar, `speechSynthesis` para hablar). No se
   manda audio a ningún servidor ni hace falta una clave de API.
2. **La interpretación es local**: no hay un modelo de lenguaje detrás, sino un
   puntaje por palabras clave contra el mapa de destinos de `js/asistente.js`.
   Alcanza para "llevame a X" y "dónde está X", y mantiene el proyecto sin
   backend como el resto del mockup.
3. **El micrófono necesita `https://` o `localhost`.** Si se abre el HTML con
   doble clic (`file://`) el navegador lo bloquea, por eso el asistente siempre
   ofrece además escribir el pedido en un campo de texto.

El hexágono solo se anima **mientras el panel está abierto** (y nunca con
"reducir movimiento" activado): al cerrarlo se corta el `requestAnimationFrame`, así no gasta CPU ni batería en el resto de las
pantallas.

Se puede apagar (y silenciar sus respuestas habladas) desde Configuración.

> Las fechas de las reservas de ejemplo se calculan **relativas al día de hoy**
> (`fechaRelativa()` en `js/reservas.js`), no escritas a mano. Así la demo nunca
> se vence: si tuvieran fechas fijas, pasado ese mes la agenda quedaría vacía.

---

## Del mockup al backend

El frontend está escrito pensando en que los datos hoy hardcodeados se van a
reemplazar por llamadas HTTP. Cada acción tiene comentado, en el código, qué
endpoint le correspondería:

| Acción en pantalla | Endpoint futuro |
| ------------------ | --------------- |
| Pedir una reserva | `POST /api/v1/bookings` |
| Aprobar / rechazar reserva | `PATCH /api/v1/bookings/:id/approve` · `/reject` |
| Cancelar reserva propia | `PATCH /api/v1/bookings/:id/cancel` |
| Aprobar / rechazar empresa | `PATCH /api/v1/companies/:id/approve` · `/reject` |
| Publicar pasantía | `POST /api/v1/internships` |
| Postularse | `POST /api/v1/internships/:id/applications` |
| Iniciar sesión | `POST /api/v1/auth/login` (devuelve un JWT) |

Y en `db/consultas-ejemplo.sql` están escritos los `SELECT` que alimentarían
cada pantalla, para poder probarlos a mano en Adminer mientras el backend no
exista.

### Una decisión de diseño que vale la pena mirar

El choque de horarios se valida **dos veces, a propósito**. En el navegador
(`js/reservas.js`) para avisar al instante, y en la base con un
`EXCLUDE constraint` de PostgreSQL sobre `bookings`, que impide físicamente
guardar dos reservas superpuestas del mismo recurso. La validación del
navegador es comodidad; la que garantiza que el dato sea correcto es la de la
base, porque es la única que no se puede saltear.


---

## Notas de diseño

**Color.** Dos tintas Pantone y nada más. El azul **P 105-8 C** (`#004789`) es
el edificio: estructura, botones y las superficies oscuras (derivadas de él,
como el azul noche `#00213F`). El amarillo **938 C** (`#FCEEA8`) es la luz:
marca lo reservado, lo que está pasando ahora y lo seleccionado. Nunca se usa de
fondo de página, porque sobre blanco no se ve y en superficies grandes se lee
como crema. Los neutros son fríos, para que la calidez la ponga solo el amarillo.

**Tipografía.** Dos familias, las dos viajan con el proyecto en `fonts/` (no
dependen de internet ni de Google Fonts):

- **Roboto Serif cursiva** para los titulares grandes (portada, secciones,
  ingreso, saludo de cada panel), en su peso más fino, 100. Tiene tamaño óptico
  automático: a 100 px el trazo es un hilo con contraste de cartel, y en los
  títulos medianos (tarjetas de rol, comprobante, modales, año del calendario)
  la misma letra va en 300 para seguir siendo firme.
- **Archivo** para todo lo demás: interfaz, formularios, títulos chicos y
  números (con cifras tabulares, para alinear en columna). Los títulos chicos
  bajaron a ancho normal y peso 650: el expandido pesado al lado del hilo de
  serif quedaba gritón.

**El letrero de la portada.** El titular "Tu salón, reservado en minutos" es un
letrero 3D (`tituloEn3D` en `js/movimiento.js`): cada letra es una pila de diez
capas hacia atrás, con la cara en blanco o en amarillo 938 C y el canto
hundiéndose en los azules del P 105-8 C. Las letras se paran una por una, el
volumen crece hacia atrás, y cada 7 s una ola recorre el letrero cambiando
blanco por amarillo. Con el mouse se mueve el punto de fuga y el canto se ve
desde otro lado. Para un lector de pantalla es una sola frase normal, y con
"reducir movimiento" el letrero queda quieto pero conserva el volumen.

**La maqueta.** El objeto de la portada es una maqueta 3D del Polo hecha con CSS:
cada salón es una caja con techo, frente y costado. Los salones con ventanas
encendidas en amarillo están reservados. Las cajas crecen desde el piso al
cargar, las ventanas se encienden después, y cada tanto un salón se enciende o
se apaga: el edificio está en uso. La misma maqueta aparece en el ingreso y en
los encabezados de cada panel, y en versión chica como objeto de cada rol (un
salón, una pila de postulaciones, una torre de oficinas).

**El tablero de llegadas.** Los números de las métricas y los horarios de la
agenda pública son paletas que giran sobre su bisagra hasta caer en su valor,
como los tableros de las estaciones. La agenda entera es ese tablero, colgado
sobre la foto del edificio.

**Del pedido a la agenda.** En la portada, un comprobante de reserva cambia de
estado según el paso que se está leyendo: pendiente, sellado "Aprobada", y al
final se da vuelta y muestra su línea en la agenda pública.

**Movimiento.** Curvas propias (nunca `ease-in`, que arranca lento justo cuando
la persona está mirando), respuesta al presionar en menos de 100 ms, y todo
hover detrás de `@media (hover: hover) and (pointer: fine)`. Los bloques entran
con una leve inclinación 3D al aparecer en pantalla, una sola vez; las listas
que se repintan al filtrar no se reaniman. Todo lo que se mueve vive en
`js/movimiento.js` y solo lee lo que ya pintaron los demás archivos: no toca
datos ni lógica.

**Paneles con sesión.** Cada panel (profesor, estudiante, empresa, admin)
abre con una portada a todo el ancho: el saludo como letrero 3D, la maqueta del
rol que gira con el mouse y la foto del Polo detrás. Los números cuelgan del
borde de la portada como el cartel de llegadas de una estación (el profesor
tiene su propio tablero: aprobadas, esperando aprobación y la próxima reserva).
Abajo, el trabajo va en dos columnas: pedir a la izquierda, seguir lo pedido a
la derecha.

**El mouse como linterna.** Cuatro efectos con la misma idea, todos en
`js/movimiento.js` (sección 9) y apagados en pantallas táctiles y con "reducir
movimiento":
- detrás de la página está la cuadrícula del plano del edificio, y solo se ve
  alrededor del mouse;
- el borde de cada panel se enciende en el punto más cercano al mouse;
- en las portadas, la foto se corre, la luz sigue al mouse y el punto de fuga
  del letrero 3D cambia;
- los botones principales se inclinan apenas hacia el mouse (efecto imán).

**Perfil profesional y bolsa de pasantías.** Cada estudiante arma su perfil
desde su panel ("Editar perfil profesional"): orientación, año, disponibilidad,
un texto sobre sí, capacidades e idiomas (se suman con Enter), títulos y
certificaciones, cursos y capacitaciones, experiencia y pasantías anteriores, y
links. La barra de "Perfil completo" se calcula con lo que está completo y dice
qué falta. Las empresas ven ese perfil en dos lugares: en "Postulantes" (quién se
postuló a cada pasantía, con Aceptar y Rechazar) y en "Perfiles de estudiantes"
(un directorio con buscador por capacidad, orientación o curso, desde donde
pueden seleccionar a alguien aunque no se haya postulado). Lo que decide la
empresa le aparece al estudiante en "Mis postulaciones".

Para que los dos paneles vean lo mismo, perfiles, pasantías y postulaciones
viven en una sola bolsa compartida (`js/bolsa.js`, guardada en el localStorage
del navegador, como la sesión). Todo lo que escribe un estudiante se escapa antes
de mostrarse: un `<script>` en "Sobre mí" aparece como texto. Cuentas de
estudiante para probar: maria@, facundo@, valentina@, camila@, joaquin@ y
sofia@estudiante.com.

**Agenda pública con sesión iniciada.** Si ya entraste, el menú de la agenda
muestra con qué cuenta estás y "Ir a mi panel" en lugar de "Iniciar sesión".

**Modo oscuro.** Se elige en Configuración (Automático, Claro u Oscuro);
"Automático" sigue al sistema. El tema se aplica con un script mínimo en el
`<head>` de cada página, antes de pintar, así no hay destello blanco al cargar.
Los colores salen de tokens con un solo uso cada uno: `--azul` es relleno
(botones, días ocupados) y `--azul-texto` es el azul para links e íconos, porque
en oscuro el relleno pide un azul más profundo y el texto uno más claro. Lo que
va sobre amarillo usa `--sobre-amarillo`, que no cambia nunca, y las paletas
del tablero (`--pala-arriba` / `--pala-abajo`) son siempre azul noche, en los
dos temas. Auditado igual que el claro: 0 problemas de contraste en las once
páginas y sus estados (menú de perfil, Configuración, asistente).

**Accesibilidad.** Auditado con axe-core: 0 violaciones WCAG 2 A/AA en las diez
páginas. Foco de teclado visible en todos los controles, texto real detrás de
cada paleta para lectores de pantalla, y con "reducir movimiento" se van las
caídas, giros y el 3D, pero se conservan los cambios de opacidad y color, que
son los que explican qué cambió.
