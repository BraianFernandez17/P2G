/* ============================================================
   DATOS DE EJEMPLO (mock data) — DASHBOARD DEL ESTUDIANTE
   En la versión real, estos objetos NO se escriben a mano:
   vienen de pedirle datos al backend, por ejemplo:

     fetch("/api/v1/students/me")
       .then((res) => res.json())
       .then((data) => pintarSaludo(data));

   Por ahora los dejamos fijos para poder ver la pantalla
   funcionando sin tener un backend corriendo todavía.
   ============================================================ */
const estudiante = {
  nombre: "María",
  porcentajePerfil: 70, // de 0 a 100
};

const estadisticasEstudiante = [
  { icono: "📄", tono: "accent", etiqueta: "Postulaciones", valor: 4 },
  { icono: "🔎", tono: "warning", etiqueta: "En revisión", valor: 2 },
  { icono: "🔔", tono: "info", etiqueta: "Avisos nuevos", valor: 3 },
];

const pasantiasRecomendadas = [
  {
    id: 1,
    titulo: "Desarrollador Frontend Jr",
    empresa: "TechCorp Tacuarembó",
    modalidad: "Remoto",
    duracionMeses: 6,
  },
  {
    id: 2,
    titulo: "Soporte de Datos",
    empresa: "Industrias del Norte",
    modalidad: "Presencial",
    duracionMeses: 4,
  },
  {
    id: 3,
    titulo: "Asistente de Agroindustria",
    empresa: "AgroTacuá S.A.",
    modalidad: "Híbrido",
    duracionMeses: 5,
  },
];

/* ============================================================
   FUNCIONES QUE "PINTAN" CADA PARTE DE LA PÁGINA
   Cada una agarra un dato y lo mete adentro del HTML que ya
   existe (los elementos con id="..." que dejamos vacíos en
   dashboard-estudiante.html).
   ============================================================ */

function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;
  // Si hay una sesión real (se creó al iniciar sesión o registrarse,
  // ver js/sesion.js), usamos ese nombre. Si alguien abre este
  // archivo directo sin pasar por el login, mostramos el mock de
  // "María" para que la pantalla siga siendo demostrable.
  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : estudiante.nombre;
  saludoEl.textContent = `Hola, ${nombre}`;
}

function pintarBarraDePerfil() {
  const fillEl = document.getElementById("barra-perfil-relleno");
  const porcentajeEl = document.getElementById("barra-perfil-porcentaje");
  if (!fillEl || !porcentajeEl) return;

  // Por las dudas, no dejamos que el valor se vaya de 0-100
  const porcentaje = Math.min(100, Math.max(0, estudiante.porcentajePerfil));

  fillEl.style.width = `${porcentaje}%`;
  porcentajeEl.textContent = `${porcentaje}%`;
}

function pintarEstadisticas() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  // Por cada estadística del array, armamos el HTML de su tarjeta
  // y lo vamos sumando a un solo string (más eficiente que
  // ir tocando el DOM una vez por cada tarjeta).
  grillaEl.innerHTML = estadisticasEstudiante
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

function pintarPasantiasRecomendadas() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  listaEl.innerHTML = pasantiasRecomendadas
    .map(
      (pasantia) => `
      <div class="internship-card">
        <div>
          <p class="internship-title">${pasantia.titulo}</p>
          <p class="internship-meta">
            ${pasantia.empresa} · ${pasantia.modalidad} · ${pasantia.duracionMeses} meses
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">
          Ver
        </button>
      </div>
    `
    )
    .join("");

  // Una vez que los botones "Ver" ya existen en el HTML,
  // les enganchamos el evento de click a todos de una.
  listaEl.querySelectorAll(".btn-view").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPasantia(boton.dataset.pasantiaId);
    });
  });
}

/* ============================================================
   MANEJADORES DE EVENTOS
   ============================================================ */
function verPasantia(pasantiaId) {
  // Acá, en la versión final, en vez de un alert,
  // redirigimos al detalle real de la pasantía:
  // window.location.href = `/pasantias/${pasantiaId}`;
  alert(`Ver detalle de la pasantía con id ${pasantiaId}`);
}

/* ============================================================
   PUNTO DE ENTRADA
   Esperamos a que todo el HTML esté cargado en el navegador
   antes de intentar tocarlo, para no buscar elementos que
   todavía no existen.
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  pintarSaludo();
  pintarBarraDePerfil();
  pintarEstadisticas();
  pintarPasantiasRecomendadas();
});
