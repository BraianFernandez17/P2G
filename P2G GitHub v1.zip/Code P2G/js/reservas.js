/* ============================================================
   MÓDULO DE RESERVAS DE SALONES (mock)
   Mismo espíritu que estudiante.js: datos de ejemplo escritos a
   mano, más funciones que "pintan" el HTML, para poder ver las
   pantallas del módulo (profesor, admin, agenda pública)
   funcionando sin backend todavía.

   En la versión real, esto se reemplaza por pedidos al backend:

     fetch("/api/v1/resources")
     fetch("/api/v1/bookings/me")
     fetch("/api/v1/bookings", { method: "POST", body: ... })
     fetch("/api/v1/bookings/:id/approve", { method: "PATCH" })

   y la regla de "no dos reservas en el mismo lugar al mismo
   tiempo" queda garantizada por Postgres (ver el EXCLUDE
   constraint en db/schema.sql), no por este JS.
   ============================================================ */

/* ------------------------------------------------------------
   INVENTARIO DE SALONES, LABORATORIOS Y EQUIPOS
   Calcado del inventario que pide la letra del proyecto, más el
   Auditorio y la Sala de Reuniones Docentes (ver db/seed.sql).
   ------------------------------------------------------------ */
const salones = [
  { id: "r1", nombre: "Biblioteca", tipo: "espacio" },
  { id: "r2", nombre: "Sala de Informática", tipo: "espacio" },
  { id: "r3", nombre: "Sala de Conferencias", tipo: "espacio" },
  { id: "r9", nombre: "Auditorio", tipo: "espacio" },
  { id: "r10", nombre: "Sala de Reuniones Docentes", tipo: "espacio" },
  { id: "r4", nombre: "Laboratorio de Física", tipo: "laboratorio" },
  { id: "r5", nombre: "Laboratorio de Química", tipo: "laboratorio" },
  { id: "r6", nombre: "Laboratorio de Ciencias", tipo: "laboratorio" },
  { id: "r7", nombre: "Proyector", tipo: "equipo", cantidad: 2 },
  { id: "r8", nombre: "Televisión", tipo: "equipo", cantidad: 1 },
];

const ETIQUETA_TIPO_SALON = {
  espacio: "Espacios diferenciales",
  laboratorio: "Laboratorios",
  equipo: "Equipamiento móvil",
};

const ICONO_TIPO_SALON = {
  espacio: "🏛️",
  laboratorio: "🧪",
  equipo: "📽️",
};

/* ------------------------------------------------------------
   PROFESORES DEL POLO
   Cinco docentes en vez de uno solo, para que el panel de admin
   y la agenda pública se vean con movimiento real de varias
   personas pidiendo salones (ver db/seed.sql: professors).
   ------------------------------------------------------------ */
const profesores = [
  { id: "p1", nombre: "Ana", apellido: "Rodríguez" },
  { id: "p2", nombre: "Diego", apellido: "Martínez" },
  { id: "p3", nombre: "Lucía", apellido: "Fernández" },
  { id: "p4", nombre: "Rubén", apellido: "Acosta" },
  { id: "p5", nombre: "Valentina", apellido: "Silveira" },
];

/* ------------------------------------------------------------
   PROFESOR ACTUAL
   Simula a quién le mostramos "Mis reservas" en
   dashboard-profesor.html. relacionConPostulacionId != null es
   el PUENTE con el módulo de pasantías: esa reserva es para la
   entrevista de una postulación puntual, no una clase normal.
   ------------------------------------------------------------ */
const profesorActual = (() => {
  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;
  if (sesion && sesion.role === "professor") {
    const [nombre, ...resto] = sesion.name.split(" ");
    return { nombre, apellido: resto.join(" ") };
  }
  // Si se abre este archivo directo, sin pasar por el login, usamos
  // este mock para que la pantalla siga siendo demostrable.
  return { nombre: "Ana", apellido: "Rodríguez" };
})();

let reservas = [
  {
    id: "b1",
    salonId: "r4",
    motivo: "Práctico de mecánica - 2do año",
    desde: "2026-08-05T14:00:00",
    hasta: "2026-08-05T16:00:00",
    estado: "approved",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b2",
    salonId: "r3",
    motivo: "Reunión de coordinación docente",
    desde: "2026-08-07T10:00:00",
    hasta: "2026-08-07T11:00:00",
    estado: "pending",
    pedidaPor: "Ana Rodríguez",
    esMia: true,
    relacionConPostulacionId: null,
  },
  {
    id: "b3",
    salonId: "r2",
    motivo: "Taller de programación",
    desde: "2026-08-06T09:00:00",
    hasta: "2026-08-06T12:00:00",
    estado: "pending",
    pedidaPor: "Diego Martínez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b4",
    salonId: "r5",
    motivo: "Práctico de titulación",
    desde: "2026-08-10T14:00:00",
    hasta: "2026-08-10T17:00:00",
    estado: "pending",
    pedidaPor: "Ana Rodríguez",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b5",
    salonId: "r6",
    motivo: "Práctico de biología - Bach. Agrario",
    desde: "2026-08-06T14:00:00",
    hasta: "2026-08-06T16:00:00",
    estado: "approved",
    pedidaPor: "Lucía Fernández",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b6",
    salonId: "r9",
    motivo: "Charla de egresados de Electromecánica",
    desde: "2026-08-08T18:00:00",
    hasta: "2026-08-08T20:00:00",
    estado: "approved",
    pedidaPor: "Rubén Acosta",
    esMia: false,
    relacionConPostulacionId: null,
  },
  {
    id: "b7",
    salonId: "r10",
    motivo: "Reunión de coordinación de Gestión de Empresas",
    desde: "2026-08-05T09:00:00",
    hasta: "2026-08-05T10:00:00",
    estado: "pending",
    pedidaPor: "Valentina Silveira",
    esMia: false,
    relacionConPostulacionId: null,
  },
];

/* ------------------------------------------------------------
   EMPRESAS PENDIENTES DE APROBAR
   Mismo dato que ya existía como concepto en companies.status
   ('pending_approval'), acá como mock para el panel de admin.
   Cada una con su rubro/sector, para mostrar el chip de tipo
   de empresa en la cola de aprobación.
   ------------------------------------------------------------ */
let empresasPendientes = [
  { id: "c1", razonSocial: "Industrias del Norte", sector: "industria" },
  { id: "c2", razonSocial: "Clínica Salud Tacuarembó", sector: "salud" },
];

/* ------------------------------------------------------------
   POSTULACIONES "SELECTED" QUE TODAVÍA NO TIENEN ENTREVISTA
   AGENDADA. Esta lista es el otro lado del puente: cuando una
   postulación llega a "selected" (ver applications.status en
   schema.sql), la empresa necesita coordinar una entrevista
   presencial, y acá el admin la puede reservar con un clic en
   vez de ir y venir por mail como se hace hoy.
   ------------------------------------------------------------ */
let entrevistasPorAgendar = [
  {
    id: "a1",
    nombreEstudiante: "María González",
    tituloPasantia: "Desarrollador Frontend Jr",
    nombreEmpresa: "TechCorp Tacuarembó",
    agendada: false,
  },
];

/* ============================================================
   FUNCIONES DE FORMATO
   ============================================================ */
const ETIQUETA_ESTADO = {
  pending: "Pendiente",
  approved: "Aprobada",
  rejected: "Rechazada",
  cancelled: "Cancelada",
};

function nombreDelSalon(salonId) {
  const salon = salones.find((s) => s.id === salonId);
  return salon ? salon.nombre : "Salón";
}

// Convierte "2026-08-05T14:00:00" / "2026-08-05T16:00:00" en algo
// legible tipo "05/08 · 14:00 a 16:00", sin depender de librerías.
function formatearRango(desde, hasta) {
  const inicio = new Date(desde);
  const fin = new Date(hasta);

  const pad = (n) => String(n).padStart(2, "0");
  const etiquetaFecha = `${pad(inicio.getDate())}/${pad(inicio.getMonth() + 1)}`;
  const horaInicio = `${pad(inicio.getHours())}:${pad(inicio.getMinutes())}`;
  const horaFin = `${pad(fin.getHours())}:${pad(fin.getMinutes())}`;

  return `${etiquetaFecha} · ${horaInicio} a ${horaFin}`;
}

function chipDeEstado(estado) {
  return `<span class="status-badge ${estado}">${ETIQUETA_ESTADO[estado]}</span>`;
}

/* ============================================================
   VALIDACIÓN DE SOLAPAMIENTO (solo un aviso del lado del cliente)
   OJO: esto es nada más que una ayuda visual para que la persona
   no llene el formulario en vano. La verdad absoluta la tiene el
   EXCLUDE constraint de Postgres (ver schema.sql): si dos
   pedidos llegan al mismo tiempo, el backend es quien decide, no
   este chequeo hecho en el navegador.
   ============================================================ */
function haySolapamiento(salonId, desde, hasta, idAExcluir) {
  const nuevoInicio = new Date(desde).getTime();
  const nuevoFin = new Date(hasta).getTime();

  return reservas.some((reserva) => {
    if (reserva.id === idAExcluir) return false;
    if (reserva.salonId !== salonId) return false;
    if (reserva.estado !== "pending" && reserva.estado !== "approved") return false;

    const inicioExistente = new Date(reserva.desde).getTime();
    const finExistente = new Date(reserva.hasta).getTime();

    return nuevoInicio < finExistente && nuevoFin > inicioExistente;
  });
}

/* ============================================================
   RENDER: SELECT DE SALONES (agrupado por tipo, con <optgroup>)
   Se usa en dashboard-profesor.html.
   ============================================================ */
function pintarOpcionesDeSalones(selectEl) {
  const grupos = {};
  salones.forEach((salon) => {
    if (!grupos[salon.tipo]) grupos[salon.tipo] = [];
    grupos[salon.tipo].push(salon);
  });

  const optgroupsHtml = Object.keys(grupos)
    .map((tipo) => {
      const opcionesHtml = grupos[tipo]
        .map((s) => `<option value="${s.id}">${s.nombre}</option>`)
        .join("");
      return `<optgroup label="${ETIQUETA_TIPO_SALON[tipo]}">${opcionesHtml}</optgroup>`;
    })
    .join("");

  selectEl.innerHTML =
    `<option value="" disabled selected>Elegí un salón</option>` + optgroupsHtml;
}

/* ============================================================
   PANTALLA: dashboard-profesor.html
   ============================================================ */
function pintarMisReservas() {
  const listaEl = document.getElementById("lista-mis-reservas");
  if (!listaEl) return;

  const mias = reservas.filter((r) => r.esMia);

  if (mias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no pediste ninguna reserva.</p>`;
    return;
  }

  listaEl.innerHTML = mias
    .map(
      (reserva) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${reserva.motivo}</p>
          <p class="booking-card-meta">
            ${nombreDelSalon(reserva.salonId)} · ${formatearRango(reserva.desde, reserva.hasta)}
          </p>
        </div>
        ${chipDeEstado(reserva.estado)}
      </div>
    `
    )
    .join("");
}

function manejarNuevaReserva(evento) {
  evento.preventDefault();
  const formulario = evento.target;

  const salonId = formulario.querySelector("#salon").value;
  const motivo = formulario.querySelector("#reserva-motivo").value.trim();
  const fecha = formulario.querySelector("#reserva-fecha").value;
  const horaDesde = formulario.querySelector("#reserva-desde").value;
  const horaHasta = formulario.querySelector("#reserva-hasta").value;

  if (!salonId || !motivo || !fecha || !horaDesde || !horaHasta) {
    alert("Completá todos los campos para pedir la reserva.");
    return;
  }

  const desde = `${fecha}T${horaDesde}:00`;
  const hasta = `${fecha}T${horaHasta}:00`;

  if (new Date(hasta) <= new Date(desde)) {
    alert("La hora de fin tiene que ser posterior a la hora de inicio.");
    return;
  }

  if (haySolapamiento(salonId, desde, hasta, null)) {
    alert(
      `Ya hay otra reserva (pendiente o aprobada) para ${nombreDelSalon(
        salonId
      )} que se solapa con ese horario. Elegí otro horario o salón.`
    );
    return;
  }

  // Versión real: POST /api/v1/bookings con este cuerpo.
  reservas.push({
    id: `b${reservas.length + 1}`,
    salonId,
    motivo,
    desde,
    hasta,
    estado: "pending",
    pedidaPor: `${profesorActual.nombre} ${profesorActual.apellido}`,
    esMia: true,
    relacionConPostulacionId: null,
  });

  formulario.reset();
  pintarMisReservas();
  alert("Reserva enviada. Queda pendiente de aprobación del admin (simulado).");
}

/* ============================================================
   PANTALLA: dashboard-admin.html
   ============================================================ */
function pintarColaDeReservas() {
  const listaEl = document.getElementById("lista-reservas-admin");
  if (!listaEl) return;

  const pendientes = reservas.filter((r) => r.estado === "pending");

  if (pendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay reservas pendientes de aprobar.</p>`;
    return;
  }

  listaEl.innerHTML = pendientes
    .map(
      (reserva) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${reserva.motivo}</p>
          <p class="booking-card-meta">
            ${nombreDelSalon(reserva.salonId)} · ${formatearRango(reserva.desde, reserva.hasta)}
            · Pedida por ${reserva.pedidaPor}
          </p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-approve" data-reserva-id="${reserva.id}" data-accion="approve">Aprobar</button>
          <button class="btn-reject" data-reserva-id="${reserva.id}" data-accion="reject">Rechazar</button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-reserva-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const reservaId = boton.dataset.reservaId;
      const accion = boton.dataset.accion;
      // Versión real: PATCH /api/v1/bookings/:id/approve o /reject
      const reserva = reservas.find((r) => r.id === reservaId);
      reserva.estado = accion === "approve" ? "approved" : "rejected";
      pintarColaDeReservas();
      pintarAgendaPublica();
      pintarEstadisticasAdmin();
    });
  });
}

function pintarColaDeEmpresas() {
  const listaEl = document.getElementById("lista-empresas-admin");
  if (!listaEl) return;

  if (empresasPendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay empresas pendientes de aprobar.</p>`;
    return;
  }

  listaEl.innerHTML = empresasPendientes
    .map(
      (empresa) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${empresa.razonSocial}</p>
          <p class="booking-card-meta">
            <span class="sector-tag">${empresa.sector}</span>
            · Cuenta nueva, esperando aprobación para poder publicar pasantías
          </p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-approve" data-empresa-id="${empresa.id}" data-accion="approve">Aprobar</button>
          <button class="btn-reject" data-empresa-id="${empresa.id}" data-accion="reject">Rechazar</button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-empresa-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const empresaId = boton.dataset.empresaId;
      // Versión real: PATCH /api/v1/companies/:id/approve o /reject
      empresasPendientes = empresasPendientes.filter((e) => e.id !== empresaId);
      pintarColaDeEmpresas();
      pintarEstadisticasAdmin();
    });
  });
}

// Esta es la parte "puente": el admin agenda la sala de
// entrevista para una postulación que ya llegó a "selected",
// usando el mismo motor de reservas que usan los profesores.
// Como quien la pide es el propio admin (quien aprueba), la
// reserva nace directamente en estado "approved".
function pintarEntrevistasPorAgendar() {
  const listaEl = document.getElementById("lista-entrevistas-agendar");
  if (!listaEl) return;

  const pendientes = entrevistasPorAgendar.filter((e) => !e.agendada);

  if (pendientes.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay entrevistas pendientes de agendar.</p>`;
    return;
  }

  listaEl.innerHTML = pendientes
    .map(
      (entrevista) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${entrevista.nombreEstudiante} — ${entrevista.tituloPasantia}</p>
          <p class="booking-card-meta">${entrevista.nombreEmpresa} · postulación seleccionada</p>
        </div>
        <div class="booking-card-actions">
          <button class="btn-secondary" data-postulacion-id="${entrevista.id}">
            Reservar sala de entrevista
          </button>
        </div>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-postulacion-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const postulacionId = boton.dataset.postulacionId;
      const entrevista = entrevistasPorAgendar.find((e) => e.id === postulacionId);
      agendarEntrevista(entrevista);
    });
  });
}

function agendarEntrevista(entrevista) {
  // Por simplicidad del mock, la entrevista queda fija para
  // dentro de 2 días de 15:00 a 15:45 en la Sala de Conferencias.
  // En la versión real, un formulario le dejaría elegir fecha y hora.
  const inicio = new Date();
  inicio.setDate(inicio.getDate() + 2);
  inicio.setHours(15, 0, 0, 0);
  const fin = new Date(inicio);
  fin.setMinutes(45);

  const desde = inicio.toISOString().slice(0, 19);
  const hasta = fin.toISOString().slice(0, 19);

  if (haySolapamiento("r3", desde, hasta, null)) {
    alert("La Sala de Conferencias ya tiene otra reserva en ese horario. Probá con otro horario.");
    return;
  }

  reservas.push({
    id: `b${reservas.length + 1}`,
    salonId: "r3",
    motivo: `Entrevista: ${entrevista.nombreEstudiante} (${entrevista.nombreEmpresa})`,
    desde,
    hasta,
    estado: "approved",
    pedidaPor: "Admin del Polo",
    esMia: false,
    relacionConPostulacionId: entrevista.id,
  });

  entrevista.agendada = true;

  pintarEntrevistasPorAgendar();
  pintarAgendaPublica();
  pintarEstadisticasAdmin();
  alert(
    `Sala de Conferencias reservada para la entrevista de ${entrevista.nombreEstudiante} (simulado).`
  );
}

// Inventario de salones agrupado por tipo: cumple el pedido de la
// letra de que el admin pueda ver "el mantenimiento del inventario
// de salas y equipos" de un vistazo.
function pintarInventarioDeSalones() {
  const gridEl = document.getElementById("grilla-inventario");
  if (!gridEl) return;

  gridEl.innerHTML = salones
    .map(
      (salon) => `
      <div class="inventory-card">
        <p class="inventory-card-type">${ICONO_TIPO_SALON[salon.tipo]} ${ETIQUETA_TIPO_SALON[salon.tipo]}</p>
        <p class="inventory-card-name">${salon.nombre}</p>
        <p class="inventory-card-qty">${salon.cantidad ? `${salon.cantidad} unidades` : "Disponible"}</p>
      </div>
    `
    )
    .join("");
}

// Tarjetas de métricas generales del panel de admin: cuántos
// salones hay, cuántas reservas están pendientes, cuántas empresas
// esperan aprobación y cuántos profesores usan el sistema.
function pintarEstadisticasAdmin() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const reservasPendientes = reservas.filter((r) => r.estado === "pending").length;
  const reservasAprobadas = reservas.filter((r) => r.estado === "approved").length;

  const estadisticas = [
    { icono: "🏛️", tono: "primary", etiqueta: "Salones y equipos", valor: salones.length },
    { icono: "⏳", tono: "warning", etiqueta: "Reservas pendientes", valor: reservasPendientes },
    { icono: "✅", tono: "success", etiqueta: "Reservas aprobadas", valor: reservasAprobadas },
    { icono: "🏢", tono: "danger", etiqueta: "Empresas por aprobar", valor: empresasPendientes.length },
    { icono: "👩‍🏫", tono: "info", etiqueta: "Profesores activos", valor: profesores.length },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PANTALLA: agenda-publica.html
   Solo muestra reservas ya aprobadas y a futuro: es justamente
   lo que la letra pide para el perfil Alumno/Público, sin login.
   ============================================================ */
function pintarAgendaPublica() {
  const cuerpoEl = document.getElementById("cuerpo-tabla-agenda");
  const vaciaEl = document.getElementById("agenda-vacia");
  if (!cuerpoEl) return;

  const ahora = new Date();
  const proximas = reservas
    .filter((r) => r.estado === "approved" && new Date(r.desde) >= ahora)
    .sort((a, b) => new Date(a.desde) - new Date(b.desde));

  if (proximas.length === 0) {
    cuerpoEl.innerHTML = "";
    if (vaciaEl) vaciaEl.style.display = "block";
    return;
  }

  if (vaciaEl) vaciaEl.style.display = "none";

  cuerpoEl.innerHTML = proximas
    .map(
      (reserva) => `
      <tr>
        <td>${formatearRango(reserva.desde, reserva.hasta)}</td>
        <td>${nombreDelSalon(reserva.salonId)}</td>
        <td>${reserva.motivo}</td>
        <td>${reserva.pedidaPor}</td>
      </tr>
    `
    )
    .join("");
}

/* ============================================================
   SALUDO (compartido por dashboard-profesor.html y
   dashboard-admin.html: cada uno tiene su propio #saludo)
   ============================================================ */
function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;

  const sesion = typeof obtenerSesion === "function" ? obtenerSesion() : null;

  if (sesion && sesion.role === "professor") {
    saludoEl.textContent = `Hola, Prof. ${profesorActual.apellido}`;
  } else if (sesion && sesion.role === "admin") {
    saludoEl.textContent = `Panel del administrador — ${sesion.name}`;
  } else {
    // Mock, para cuando se abre el archivo directo sin login.
    saludoEl.textContent = `Hola, Prof. ${profesorActual.apellido}`;
  }
}

/* ============================================================
   PUNTO DE ENTRADA
   Cada página solo tiene los elementos que le corresponden, por
   eso cada función de render arranca revisando si su elemento
   existe (return temprano) antes de intentar tocar el DOM.
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  const selectSalon = document.getElementById("salon");
  if (selectSalon) pintarOpcionesDeSalones(selectSalon);

  pintarSaludo();
  pintarMisReservas();
  pintarEstadisticasAdmin();
  pintarInventarioDeSalones();
  pintarColaDeReservas();
  pintarColaDeEmpresas();
  pintarEntrevistasPorAgendar();
  pintarAgendaPublica();

  const formNuevaReserva = document.getElementById("form-nueva-reserva");
  if (formNuevaReserva) {
    formNuevaReserva.addEventListener("submit", manejarNuevaReserva);
  }
});
