/* ============================================================
   DASHBOARD DE EMPRESA (mock)
   Mismo patrón que estudiante.js y reservas.js: datos de ejemplo
   a mano + funciones que pintan el HTML, para poder ver la
   pantalla funcionando sin backend todavía.
   ============================================================ */

// Rubros posibles de una empresa (mismo CHECK que companies.sector
// en db/schema.sql), con una etiqueta linda para mostrar en pantalla.
const ETIQUETA_SECTOR = {
  tecnologia: "Tecnología",
  industria: "Industria",
  agropecuaria: "Agropecuaria",
  comercio: "Comercio",
  servicios: "Servicios",
  educacion: "Educación",
  salud: "Salud",
  construccion: "Construcción",
  turismo: "Turismo",
  logistica: "Logística",
};

const estadisticasEmpresa = [
  { icono: "📢", tono: "accent", etiqueta: "Pasantías publicadas", valor: 2 },
  { icono: "🧑‍🎓", tono: "info", etiqueta: "Postulantes nuevos", valor: 5 },
  { icono: "🗓️", tono: "success", etiqueta: "Entrevistas agendadas", valor: 1 },
];

const misPasantias = [
  {
    id: 1,
    titulo: "Desarrollador Frontend Jr",
    modalidad: "Remoto",
    duracionMeses: 6,
    postulantes: 4,
  },
  {
    id: 2,
    titulo: "Soporte de Datos",
    modalidad: "Presencial",
    duracionMeses: 4,
    postulantes: 3,
  },
];

function pintarSaludoEmpresa() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;

  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : "TechCorp Tacuarembó";
  saludoEl.textContent = `Hola, ${nombre}`;
}

// Muestra el rubro de la empresa como chip, al lado del saludo.
function pintarSectorEmpresa() {
  const sectorEl = document.getElementById("sector-empresa");
  if (!sectorEl) return;

  const sesion = obtenerSesion();
  const sector = sesion && sesion.sector ? sesion.sector : "servicios";
  sectorEl.textContent = ETIQUETA_SECTOR[sector] || sector;
}

// Este banner es el mismo caso de "pending_approval" que ya
// describe schema.sql para companies: mientras el admin no
// apruebe la cuenta, se lo recordamos en vez de escondérselo.
function pintarAvisoPendiente() {
  const avisoEl = document.getElementById("aviso-pendiente");
  if (!avisoEl) return;

  const sesion = obtenerSesion();
  avisoEl.style.display =
    sesion && sesion.status === "pending_approval" ? "block" : "none";
}

function pintarEstadisticasEmpresa() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  grillaEl.innerHTML = estadisticasEmpresa
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

function pintarMisPasantias() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  listaEl.innerHTML = misPasantias
    .map(
      (pasantia) => `
      <div class="internship-card">
        <div>
          <p class="internship-title">${pasantia.titulo}</p>
          <p class="internship-meta">
            ${pasantia.modalidad} · ${pasantia.duracionMeses} meses · ${pasantia.postulantes} postulantes
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">Ver postulantes</button>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll("button[data-pasantia-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      // Versión real: GET /api/v1/internships/:id/applications
      alert(`Ver postulantes de la pasantía #${boton.dataset.pasantiaId} (simulado)`);
    });
  });
}

function publicarPasantia() {
  // Versión real: abre un formulario -> POST /api/v1/internships
  alert(
    "Publicar nueva pasantía (simulado): acá iría un formulario para cargar título, modalidad y duración."
  );
}

document.addEventListener("DOMContentLoaded", () => {
  pintarSaludoEmpresa();
  pintarSectorEmpresa();
  pintarAvisoPendiente();
  pintarEstadisticasEmpresa();
  pintarMisPasantias();

  const botonPublicar = document.getElementById("publicar-pasantia");
  if (botonPublicar) botonPublicar.addEventListener("click", publicarPasantia);
});
