/* ============================================================
   SESIÓN (mock, con localStorage)
   Como todavía no hay backend, "iniciar sesión" acá no genera un
   JWT de verdad (ver sección 9 del documento técnico): guardamos
   un objeto simple en localStorage del navegador, que simula
   "quién soy y qué rol tengo" (mi cuenta). Es SOLO para que el
   mockup se sienta como una app real de principio a fin.

   En la versión con backend, esto se reemplaza por:
     - Guardar el JWT que devuelve POST /api/v1/auth/login
     - Mandar ese JWT en cada pedido (header Authorization)
     - Pedirle al backend "quién sos" en vez de leerlo de acá
   ============================================================ */

const CLAVE_SESION = "poloTecSesion";

// A qué panel va cada rol de cuenta una vez que inició sesión.
const PANEL_POR_ROL = {
  student: "dashboard-estudiante.html",
  company: "dashboard-empresa.html",
  professor: "dashboard-profesor.html",
  admin: "dashboard-admin.html",
};

// Nombre "bonito" de cada rol, para mostrar en la interfaz
// (navbar, saludo, distintivo de cuenta) en vez del código interno.
const NOMBRE_DEL_ROL = {
  student: "Estudiante",
  company: "Empresa",
  professor: "Profesor",
  admin: "Admin",
};

/* ------------------------------------------------------------
   "BASE DE CUENTAS" DE DEMOSTRACIÓN
   Como no hay tabla "users" real todavía, login.html necesita
   algo contra qué validar el email. Estas son las cuentas de
   ejemplo, una por rol (más una empresa y un profesor extra),
   para poder probar el flujo completo. En la versión real esto
   lo resuelve el backend con un SELECT a la tabla users
   (comparando el hash de la contraseña, nunca la contraseña en
   texto plano).
   ------------------------------------------------------------ */
const CUENTAS_DEMO = [
  { email: "maria@estudiante.com", role: "student", name: "María González" },
  { email: "facundo@estudiante.com", role: "student", name: "Facundo Pereira" },
  { email: "contacto@techcorp.com", role: "company", name: "TechCorp Tacuarembó", sector: "tecnologia", status: "active" },
  { email: "rrhh@agrotacua.com.uy", role: "company", name: "AgroTacuá S.A.", sector: "agropecuaria", status: "active" },
  { email: "contacto@industriasnorte.com", role: "company", name: "Industrias del Norte", sector: "industria", status: "pending_approval" },
  { email: "ana@polotec.edu.uy", role: "professor", name: "Ana Rodríguez" },
  { email: "diego@polotec.edu.uy", role: "professor", name: "Diego Martínez" },
  { email: "lucia@polotec.edu.uy", role: "professor", name: "Lucía Fernández" },
  { email: "admin@polotec.edu.uy", role: "admin", name: "Admin del Polo" },
];

function guardarSesion(cuenta) {
  localStorage.setItem(CLAVE_SESION, JSON.stringify(cuenta));
}

function obtenerSesion() {
  const datos = localStorage.getItem(CLAVE_SESION);
  if (!datos) return null;
  try {
    return JSON.parse(datos);
  } catch {
    return null;
  }
}

function borrarSesion() {
  localStorage.removeItem(CLAVE_SESION);
}

// Se llama al principio de CADA dashboard (en un <script> chiquito
// en el <head>, antes de que se pinte el contenido). Si no hay
// sesión, o la sesión es de otro rol, manda derecho al login: así
// lo primero que ve alguien sin cuenta iniciada es siempre
// login/registro, nunca el contenido del panel.
function requerirRol(rolEsperado) {
  const sesion = obtenerSesion();
  if (!sesion || sesion.role !== rolEsperado) {
    window.location.href = "login.html";
    return null;
  }
  return sesion;
}

// Se llama en index.html: si ya hay sesión activa, en vez de
// mostrarle de nuevo la landing pública a alguien que ya se
// registró, lo manda directo a su panel.
function redirigirSiHaySesion() {
  const sesion = obtenerSesion();
  if (sesion && PANEL_POR_ROL[sesion.role]) {
    window.location.href = PANEL_POR_ROL[sesion.role];
  }
}

function cerrarSesion() {
  borrarSesion();
  window.location.href = "login.html";
}

/* ------------------------------------------------------------
   BOTÓN DE "CERRAR SESIÓN" Y DISTINTIVO DE ROL
   Todos los dashboards comparten el mismo botón (id="cerrar-sesion")
   y, si existe, un distintivo de rol (id="etiqueta-rol") en el
   navbar, así que los enganchamos acá una sola vez en vez de
   repetir el mismo código en cada página.
   ------------------------------------------------------------ */
document.addEventListener("DOMContentLoaded", () => {
  const botonCerrarSesion = document.getElementById("cerrar-sesion");
  if (botonCerrarSesion) {
    botonCerrarSesion.addEventListener("click", () => {
      cerrarSesion();
    });
  }

  const etiquetaRol = document.getElementById("etiqueta-rol");
  if (etiquetaRol) {
    const sesion = obtenerSesion();
    if (sesion && NOMBRE_DEL_ROL[sesion.role]) {
      etiquetaRol.textContent = NOMBRE_DEL_ROL[sesion.role];
    } else {
      etiquetaRol.style.display = "none";
    }
  }
});
