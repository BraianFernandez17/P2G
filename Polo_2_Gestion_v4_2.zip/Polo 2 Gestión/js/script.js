/* ============================================================
   DASHBOARD DEL ESTUDIANTE
   Las pasantías, las postulaciones y el perfil profesional ya no
   viven acá: salen de la bolsa compartida (js/bolsa.js), la misma
   que lee el panel de empresa. Así, cuando una empresa acepta a
   un estudiante, el estudiante lo ve en "Mis postulaciones".

   En la versión real, cada lectura sería un fetch al backend:
     fetch("/api/v1/students/me/profile").then((r) => r.json())
   ============================================================ */

// Para cuando se abre el archivo directo, sin pasar por el login.
const ESTUDIANTE_DEMO = { email: "maria@estudiante.com", name: "María González" };

function estudianteActual() {
  const sesion = obtenerSesion();
  return sesion && sesion.role === "student" ? sesion : ESTUDIANTE_DEMO;
}

function miPerfil() {
  const yo = estudianteActual();
  return perfilDe(yo.email, yo.name);
}

/* ============================================================
   SALUDO, BARRA DE PERFIL Y NÚMEROS
   ============================================================ */
function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;
  saludoEl.textContent = `Hola, ${estudianteActual().name}`;
}

// La barra ya no es un 70 % fijo: se calcula con lo que el
// estudiante completó de verdad en su perfil profesional.
function pintarBarraDePerfil() {
  const fillEl = document.getElementById("barra-perfil-relleno");
  const porcentajeEl = document.getElementById("barra-perfil-porcentaje");
  if (!fillEl || !porcentajeEl) return;

  const perfil = miPerfil();
  const porcentaje = completitudPerfil(perfil);
  fillEl.style.width = `${porcentaje}%`;
  porcentajeEl.textContent = `${porcentaje}%`;

  const faltaEl = document.getElementById("perfil-falta");
  if (faltaEl) {
    const faltan = faltantesDelPerfil(perfil);
    faltaEl.textContent = faltan.length
      ? `Te falta: ${faltan.slice(0, 3).join(", ").toLowerCase()}${faltan.length > 3 ? "…" : "."}`
      : "Tu perfil está completo: las empresas ven todo lo que sabés hacer.";
  }
}

function pintarEstadisticas() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const postulaciones = postulacionesDeEstudiante(estudianteActual().email);
  const enRevision = postulaciones.filter((p) => p.estado === "pending").length;
  const seleccionado = postulaciones.filter((p) => p.estado === "approved").length;

  const estadisticas = [
    { icono: icono("documento"), tono: "accent", etiqueta: "Postulaciones", valor: postulaciones.length },
    { icono: icono("lupa"), tono: "warning", etiqueta: "En revisión", valor: enRevision },
    { icono: icono("tilde"), tono: "success", etiqueta: "Te seleccionaron", valor: seleccionado },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PERFIL PROFESIONAL
   ============================================================ */
function pintarPerfilProfesional() {
  const tarjetaEl = document.getElementById("perfil-profesional");
  if (!tarjetaEl) return;
  tarjetaEl.innerHTML = htmlPerfil(miPerfil(), { propio: true });
  pintarBarraDePerfil();
}

// Una fila editable de una lista (título, curso o experiencia).
function filaEditable(tipo, campos, valores = {}) {
  return `
    <div class="editor-fila" data-tipo="${tipo}">
      ${campos
        .map(
          ([clave, etiqueta, ayuda]) => `
        <label class="editor-campo">
          <span class="form-label">${etiqueta}</span>
          <input type="text" class="form-input" data-clave="${clave}" data-sin-enter
                 value="${escaparHTML(valores[clave] || "")}" placeholder="${ayuda}" />
        </label>`
        )
        .join("")}
      <button type="button" class="editor-quitar" data-quitar aria-label="Quitar esta fila" title="Quitar">×</button>
    </div>`;
}

const CAMPOS_EDITOR = {
  titulos: [
    ["nombre", "Título o certificación", "Ej: Bachillerato Tecnológico"],
    ["institucion", "Institución", "Ej: UTU Tacuarembó"],
    ["anio", "Año", "2025"],
  ],
  cursos: [
    ["nombre", "Curso", "Ej: Introducción a Python"],
    ["institucion", "Dónde", "Ej: Ceibal"],
    ["detalle", "Duración o año", "40 horas"],
  ],
  experiencia: [
    ["puesto", "Puesto o tarea", "Ej: Ayudante de laboratorio"],
    ["lugar", "Dónde", "Ej: Cooperativa local"],
    ["periodo", "Cuándo", "2024 – 2025"],
  ],
};

// Las capacidades e idiomas se escriben y se suman con Enter (o
// coma); cada una queda como un chip con su botón para quitarla.
function campoDeChips(id, etiqueta, valores, ayuda) {
  return `
    <div class="form-group editor-chips" data-chips="${id}">
      <label class="form-label" for="chips-${id}">${etiqueta}</label>
      <div class="chips-caja">
        <ul class="perfil-chips perfil-chips-editables">
          ${valores.map((v) => chipEditable(v)).join("")}
        </ul>
        <input type="text" id="chips-${id}" class="chips-entrada" data-sin-enter placeholder="${ayuda}" />
      </div>
      <p class="form-hint">Escribí y apretá Enter para sumar.</p>
    </div>`;
}

function chipEditable(valor) {
  return `<li><span>${escaparHTML(valor)}</span><button type="button" data-quitar-chip aria-label="Quitar ${escaparHTML(valor)}">×</button></li>`;
}

function opciones(lista, actual, vacia) {
  return (
    `<option value="">${vacia}</option>` +
    lista.map((v) => `<option ${v === actual ? "selected" : ""}>${escaparHTML(v)}</option>`).join("")
  );
}

function abrirEditorPerfil() {
  const perfil = miPerfil();
  // Currículum: el archivo elegido (todavía sin guardar) y si pidió quitar el actual.
  let archivoCV = null;
  let quitarCV = false;
  const seccionLista = (tipo, titulo, boton) => `
    <fieldset class="editor-seccion" data-lista="${tipo}">
      <legend class="editor-legend">${titulo}</legend>
      <div class="editor-filas">
        ${perfil[tipo].map((item) => filaEditable(tipo, CAMPOS_EDITOR[tipo], item)).join("")}
      </div>
      <button type="button" class="btn-secondary editor-agregar" data-agregar="${tipo}">${boton}</button>
    </fieldset>`;

  abrirModal({
    titulo: "Tu perfil profesional",
    amplio: true,
    textoConfirmar: "Guardar perfil",
    cuerpoHTML: `
      <p class="form-hint editor-intro">Esto es lo que ven las empresas cuando te postulás o cuando buscan perfiles como el tuyo.</p>

      <div class="editor-grilla">
        <div class="form-group">
          <label class="form-label" for="perfil-orientacion">Orientación que cursás</label>
          <input type="text" id="perfil-orientacion" class="form-input" list="lista-orientaciones"
                 value="${escaparHTML(perfil.orientacion)}" placeholder="Elegí o escribí la tuya" />
          <datalist id="lista-orientaciones">${ORIENTACIONES.map((o) => `<option value="${o}"></option>`).join("")}</datalist>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-nivel">Año o nivel</label>
          <select id="perfil-nivel" class="form-select">${opciones(NIVELES, perfil.nivel, "Elegí")}</select>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-disponibilidad">Disponibilidad</label>
          <select id="perfil-disponibilidad" class="form-select">${opciones(DISPONIBILIDADES, perfil.disponibilidad, "Elegí")}</select>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-localidad">Localidad</label>
          <input type="text" id="perfil-localidad" class="form-input" value="${escaparHTML(perfil.localidad)}" placeholder="Ej: Tacuarembó" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="perfil-sobre">Sobre vos</label>
        <textarea id="perfil-sobre" class="form-input form-textarea" rows="3" maxlength="400"
                  placeholder="Qué te interesa, qué sabés hacer y qué buscás en una pasantía.">${escaparHTML(perfil.sobreMi)}</textarea>
      </div>

      <div class="editor-grilla editor-grilla-2">
        ${campoDeChips("capacidades", "Capacidades", perfil.capacidades, "Ej: Excel, Arduino, atención al público")}
        ${campoDeChips("idiomas", "Idiomas", perfil.idiomas, "Ej: Inglés B1")}
      </div>

      ${seccionLista("titulos", "Títulos y certificaciones", "Agregar título")}
      ${seccionLista("cursos", "Cursos y capacitaciones", "Agregar curso")}
      ${seccionLista("experiencia", "Experiencia y pasantías anteriores", "Agregar experiencia")}

      <div class="editor-grilla editor-grilla-2">
        <div class="form-group">
          <label class="form-label" for="perfil-linkedin">LinkedIn</label>
          <input type="text" id="perfil-linkedin" class="form-input" value="${escaparHTML(perfil.linkedin)}" placeholder="linkedin.com/in/…" />
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-portfolio">GitHub o portfolio</label>
          <input type="text" id="perfil-portfolio" class="form-input" value="${escaparHTML(perfil.portfolio)}" placeholder="github.com/…" />
        </div>
      </div>

      <div class="form-group editor-cv">
        <label class="form-label" for="perfil-cv">Currículum (PDF)</label>
        <p class="form-hint">Las empresas lo abren desde tu perfil. Solo PDF, hasta 5 MB.</p>
        ${
          perfil.cv
            ? `<p class="editor-cv-actual" id="cv-actual">Cargado: <strong>${escaparHTML(perfil.cv.nombre)}</strong> (${escaparHTML(formatoTamanoArchivo(perfil.cv.tamano))})
                <button type="button" class="btn-secondary" id="cv-quitar">Quitar</button></p>`
            : ""
        }
        <input type="file" id="perfil-cv" class="form-input" accept="application/pdf,.pdf" />
        <p id="cv-error" class="form-error" role="alert"></p>
      </div>
    `,
    alConfirmar: (cuerpo) => {
      const leerChips = (id) =>
        [...cuerpo.querySelectorAll(`[data-chips="${id}"] li span`)].map((s) => s.textContent.trim()).filter(Boolean);
      const leerLista = (tipo) =>
        [...cuerpo.querySelectorAll(`[data-lista="${tipo}"] .editor-fila`)]
          .map((fila) =>
            Object.fromEntries([...fila.querySelectorAll("input")].map((i) => [i.dataset.clave, i.value.trim()]))
          )
          .filter((item) => Object.values(item).some(Boolean));

      // Lo que quedó escrito en un campo de chips sin apretar Enter
      // también cuenta: si no, se perdería en silencio.
      cuerpo.querySelectorAll(".chips-entrada").forEach((entrada) => sumarChip(entrada));

      const nuevo = {
        ...perfil,
        nombre: estudianteActual().name,
        orientacion: cuerpo.querySelector("#perfil-orientacion").value.trim(),
        nivel: cuerpo.querySelector("#perfil-nivel").value,
        disponibilidad: cuerpo.querySelector("#perfil-disponibilidad").value,
        localidad: cuerpo.querySelector("#perfil-localidad").value.trim(),
        sobreMi: cuerpo.querySelector("#perfil-sobre").value.trim(),
        capacidades: leerChips("capacidades"),
        idiomas: leerChips("idiomas"),
        titulos: leerLista("titulos"),
        cursos: leerLista("cursos"),
        experiencia: leerLista("experiencia"),
        linkedin: cuerpo.querySelector("#perfil-linkedin").value.trim(),
        portfolio: cuerpo.querySelector("#perfil-portfolio").value.trim(),
      };

      // Versión real: PUT /api/v1/students/me/profile (+ POST/DELETE del CV)
      const email = estudianteActual().email;
      const terminar = (cv) => {
        nuevo.cv = cv;
        guardarPerfil(email, nuevo);
        pintarPerfilProfesional();
        mostrarToast("Perfil guardado. Las empresas ya ven la versión nueva.", "success");
      };

      if (archivoCV) {
        guardarArchivoCV(email, archivoCV)
          .then(() => terminar({ nombre: archivoCV.name.slice(0, 80), tamano: archivoCV.size, fecha: new Date().toISOString() }))
          .catch(() => {
            terminar(quitarCV ? null : perfil.cv || null);
            mostrarToast("El perfil se guardó, pero no se pudo guardar el currículum en este navegador.", "error");
          });
      } else if (quitarCV) {
        borrarArchivoCV(email)
          .catch(() => {})
          .then(() => terminar(null));
      } else {
        terminar(perfil.cv || null);
      }
    },
  });

  const cuerpoEditor = document.getElementById("modal-cuerpo");
  engancharEditor(cuerpoEditor);

  // Currículum: se valida apenas se elige, así el error aparece ahí mismo.
  const entradaCV = cuerpoEditor.querySelector("#perfil-cv");
  const errorCV = cuerpoEditor.querySelector("#cv-error");
  const mostrarErrorCV = (texto) => {
    errorCV.textContent = texto || "";
    errorCV.classList.toggle("visible", !!texto);
  };
  entradaCV.addEventListener("change", async () => {
    const elegido = entradaCV.files[0];
    mostrarErrorCV("");
    archivoCV = null;
    if (!elegido) return;
    const problema = await validarCV(elegido);
    if (problema) {
      entradaCV.value = "";
      mostrarErrorCV(problema);
      return;
    }
    archivoCV = elegido;
    quitarCV = false;
  });
  const botonQuitar = cuerpoEditor.querySelector("#cv-quitar");
  if (botonQuitar) {
    botonQuitar.addEventListener("click", () => {
      quitarCV = true;
      archivoCV = null;
      entradaCV.value = "";
      cuerpoEditor.querySelector("#cv-actual").hidden = true;
    });
  }
}

function sumarChip(entrada) {
  const caja = entrada.closest(".editor-chips");
  const lista = caja.querySelector("ul");
  entrada.value
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean)
    .forEach((valor) => {
      const repetido = [...lista.querySelectorAll("li span")].some((s) => s.textContent.toLowerCase() === valor.toLowerCase());
      if (!repetido) lista.insertAdjacentHTML("beforeend", chipEditable(valor.slice(0, 40)));
    });
  entrada.value = "";
}

function engancharEditor(cuerpo) {
  cuerpo.querySelectorAll(".chips-entrada").forEach((entrada) => {
    entrada.addEventListener("keydown", (evento) => {
      if (evento.key === "Enter" || evento.key === ",") {
        evento.preventDefault();
        sumarChip(entrada);
      } else if (evento.key === "Backspace" && !entrada.value) {
        // Borrar con el campo vacío quita el último chip, como en
        // cualquier campo de etiquetas.
        entrada.closest(".editor-chips").querySelector("li:last-child")?.remove();
      }
    });
  });

  // Un solo manejador para quitar chips y filas y para agregar filas
  // (también sirve para las filas que se agregan después).
  cuerpo.addEventListener("click", (evento) => {
    const quitarChip = evento.target.closest("[data-quitar-chip]");
    if (quitarChip) {
      quitarChip.closest("li").remove();
      return;
    }
    const quitarFila = evento.target.closest("[data-quitar]");
    if (quitarFila) {
      quitarFila.closest(".editor-fila").remove();
      return;
    }
    const agregar = evento.target.closest("[data-agregar]");
    if (agregar) {
      const tipo = agregar.dataset.agregar;
      const filas = cuerpo.querySelector(`[data-lista="${tipo}"] .editor-filas`);
      filas.insertAdjacentHTML("beforeend", filaEditable(tipo, CAMPOS_EDITOR[tipo]));
      filas.lastElementChild.querySelector("input").focus();
    }
  });
}

/* ============================================================
   MIS POSTULACIONES
   ============================================================ */
function pintarMisPostulaciones() {
  const listaEl = document.getElementById("lista-postulaciones");
  if (!listaEl) return;

  const postulaciones = postulacionesDeEstudiante(estudianteActual().email);

  if (postulaciones.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no te postulaste a ninguna pasantía. Elegí una de las recomendadas.</p>`;
    return;
  }

  listaEl.innerHTML = postulaciones
    .map(
      (postulacion) => `
      <div class="booking-card${postulacion.estado === "approved" ? " booking-card-destacada" : ""}">
        <div>
          <p class="booking-card-title">${escaparHTML(postulacion.pasantia.titulo)}</p>
          <p class="booking-card-meta">
            ${escaparHTML(postulacion.pasantia.empresa)}${
              postulacion.estado === "approved" ? " · La empresa te eligió para esta pasantía" : ""
            }
          </p>
        </div>
        <span class="status-badge ${postulacion.estado}">${ESTADO_POSTULACION[postulacion.estado]}</span>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PASANTÍAS RECOMENDADAS (con filtro por modalidad)
   ============================================================ */
let filtroModalidad = "todas";

function pintarFiltrosModalidad() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-modalidad");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-modalidad";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const modalidades = ["todas", ...new Set(pasantiasVisibles().map((p) => p.modalidad))];
  filtrosEl.innerHTML = modalidades
    .map(
      (modalidad) => `
      <button type="button" class="filter-chip ${filtroModalidad === modalidad ? "active" : ""}" data-modalidad="${modalidad}">
        ${modalidad === "todas" ? "Todas" : escaparHTML(modalidad)}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-modalidad]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroModalidad = boton.dataset.modalidad;
      pintarPasantiasRecomendadas();
    });
  });
}

function pintarPasantiasRecomendadas() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  pintarFiltrosModalidad();

  const todas = pasantiasVisibles();
  const pasantias = filtroModalidad === "todas" ? todas : todas.filter((p) => p.modalidad === filtroModalidad);

  if (pasantias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay pasantías ${filtroModalidad.toLowerCase()} por ahora.</p>`;
    return;
  }

  listaEl.innerHTML = pasantias
    .map(
      (pasantia) => `
      <div class="internship-card">
        <div>
          <p class="internship-title">${escaparHTML(pasantia.titulo)}</p>
          <p class="internship-meta">
            ${escaparHTML(pasantia.empresa)} · ${escaparHTML(pasantia.modalidad)} · ${pasantia.duracionMeses} meses
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">
          Ver
        </button>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll(".btn-view").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPasantia(boton.dataset.pasantiaId);
    });
  });
}

/* ============================================================
   VER UNA PASANTÍA Y POSTULARSE
   ============================================================ */
function verPasantia(pasantiaId) {
  const pasantia = pasantiaPorId(pasantiaId);
  if (!pasantia) return;

  const yo = estudianteActual();
  const postulacion = postulacionDe(yo.email, pasantia.id);
  const completitud = completitudPerfil(miPerfil());

  let texto = `${pasantia.empresa} · ${pasantia.modalidad} · ${pasantia.duracionMeses} meses.`;
  if (postulacion) {
    texto += ` Ya estás postulado: ${ESTADO_POSTULACION[postulacion.estado].toLowerCase()}.`;
  } else {
    texto += " La empresa va a ver tu perfil profesional.";
    if (completitud < 60) texto += ` Tu perfil está al ${completitud} %: completalo para tener más chances.`;
    texto += " ¿Querés postularte?";
  }

  pedirConfirmacion(
    pasantia.titulo,
    texto,
    postulacion ? null : () => postularme(pasantia),
    postulacion ? "Entendido" : "Postularme",
    postulacion ? null : "Cerrar"
  );
}

function postularme(pasantia) {
  // Versión real: POST /api/v1/internships/:id/applications
  postular(estudianteActual().email, pasantia.id);
  pintarMisPostulaciones();
  pintarEstadisticas();
  mostrarToast(`Te postulaste a "${pasantia.titulo}". Queda en revisión.`, "success");
}

/* ============================================================
   PUNTO DE ENTRADA
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  pintarSaludo();
  pintarPerfilProfesional();
  pintarEstadisticas();
  pintarMisPostulaciones();
  pintarPasantiasRecomendadas();

  const botonEditar = document.getElementById("editar-perfil-profesional");
  if (botonEditar) botonEditar.addEventListener("click", abrirEditorPerfil);

  // Si la empresa cambió algo desde otra pestaña (aceptó la
  // postulación, por ejemplo), se refleja sin recargar.
  window.addEventListener("storage", (evento) => {
    if (evento.key !== CLAVE_BOLSA) return;
    pintarPerfilProfesional();
    pintarEstadisticas();
    pintarMisPostulaciones();
    pintarPasantiasRecomendadas();
  });
});
