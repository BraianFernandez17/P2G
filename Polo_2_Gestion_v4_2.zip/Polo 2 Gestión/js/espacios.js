/* ============================================================
   ESPACIO DE CADA SALÓN (salon.html?id=r4)
   Cada salón y laboratorio tiene su propia página, y dentro de ella:

     1. Un banner de Biblioteca Ceibal (Biblioteca País), en los salones
        de estudio.
     2. Libros: enlaces a los textos de ese espacio (en el Laboratorio
        de Física, dos de 4.º a 6.º año y uno universitario).
     3. Herramientas de la materia (js/herramientas.js y
        js/calculadora.js): la calculadora solo en los salones
        relacionados con números; constantes físicas y conversor en
        Física, masa molar en Química, ley de Ohm y resistencias en
        Robótica, bases numéricas en Informática. Ver RECURSOS_POR_SALON.
     4. PETS: un enlace.
     5. Protocolos: un espacio donde el admin y los profesores publican
        los protocolos del salón, y los alumnos los leen.
     6. Los materiales que suelen usarse en ese salón.
     7. Las próximas reservas aprobadas de ese salón.

   Los materiales (proyector, notebooks, TV...) NO tienen espacio:
   son equipamiento móvil, no un lugar.

   Todo lo que se muestra pasa por escaparEspacio(): lo que escribe
   una persona en un protocolo nunca se interpreta como HTML.

   Versión real: los libros y protocolos salen de la base
   (GET /api/v1/resources/:id/materials y /protocols) y se publican
   con POST /api/v1/resources/:id/protocols (solo admin y profesor).
   ============================================================ */

/* ------------------------------------------------------------
   ENLACES EXTERNOS
   Se cambian acá y se actualizan en todos los salones a la vez.
   ------------------------------------------------------------ */
const ENLACES_EXTERNOS = {
  // Portal de Biblioteca País de Ceibal (préstamo digital con cédula
  // o usuario Ceibal; incluye los libros de texto de Secundaria).
  bibliotecaCeibal: "https://bibliotecapais.ceibal.edu.uy",

  // PETS: COMPLETAR con la dirección. Mientras esté vacío, la tarjeta
  // muestra "Enlace por definir" en lugar de un botón que no lleva a nada.
  pets: "",
};

/* ------------------------------------------------------------
   LIBROS POR SALÓN
   Física tiene tres: dos de bachillerato (4.º a 6.º año) y uno
   universitario. Los dos de bachillerato apuntan a Biblioteca País,
   donde Secundaria publica los textos sugeridos por la inspección:
   conviene reemplazar `titulo` y `url` por el texto exacto que use
   el docente de cada año.
   ------------------------------------------------------------ */
const LIBROS_POR_SALON = {
  r4: [
    {
      nivel: "4.º año",
      titulo: "Texto de Física de 4.º año",
      autor: "Texto sugerido por la inspección de Física (ANEP)",
      nota: "Pedilo en préstamo en Biblioteca País con tu usuario Ceibal.",
      url: ENLACES_EXTERNOS.bibliotecaCeibal,
    },
    {
      nivel: "5.º y 6.º año",
      titulo: "Texto de Física de 5.º y 6.º año",
      autor: "Texto sugerido por la inspección de Física (ANEP)",
      nota: "Pedilo en préstamo en Biblioteca País con tu usuario Ceibal.",
      url: ENLACES_EXTERNOS.bibliotecaCeibal,
    },
    {
      nivel: "Universitario",
      titulo: "Física universitaria, volumen 1",
      autor: "OpenStax · en español · licencia CC BY 4.0",
      nota: "Mecánica, sonido, oscilaciones y ondas. Gratis, para leer en línea o descargar.",
      url: "https://openstax.org/books/f%C3%ADsica-universitaria-volumen-1",
    },
  ],
};

/* ------------------------------------------------------------
   RECURSOS POR SALÓN
   Cada salón muestra solo lo que le sirve a su materia: una calculadora
   no tiene sentido en la Cancha Techada, pero sí en Física, Química o
   Robótica. Para cambiar un salón se edita acá, sin tocar nada más.

     banner        → banner de Biblioteca Ceibal
     herramientas  → claves de HERRAMIENTAS (js/herramientas.js):
                     calculadora, constantes, conversor, masamolar,
                     ohm, colores, bases
     materiales    → ids de los materiales que suelen usarse en ese
                     salón (los de `salones`, en js/reservas.js)
   Los libros se cargan aparte en LIBROS_POR_SALON.
   PETS, protocolos y próximas reservas están en todos los salones.
   ------------------------------------------------------------ */
const RECURSOS_POR_SALON = {
  r1: { banner: true, herramientas: [], materiales: ["r13", "r19"] }, // Biblioteca
  r2: { banner: true, herramientas: ["calculadora", "bases"], materiales: ["r13", "r19", "r22"] }, // Informática
  r3: { banner: false, herramientas: [], materiales: ["r7", "r15", "r16", "r22"] }, // Conferencias
  r4: { banner: true, herramientas: ["calculadora", "constantes", "conversor"], materiales: ["r21", "r17", "r18", "r13"] }, // Física
  r5: { banner: true, herramientas: ["calculadora", "masamolar", "conversor"], materiales: ["r17", "r13"] }, // Química
  r6: { banner: true, herramientas: ["calculadora", "conversor"], materiales: ["r17", "r18", "r19"] }, // Ciencias
  r9: { banner: false, herramientas: [], materiales: ["r7", "r14", "r15", "r16", "r17", "r18", "r22"] }, // Auditorio
  r10: { banner: false, herramientas: [], materiales: ["r7", "r8", "r13"] }, // Reuniones docentes
  r11: { banner: false, herramientas: [], materiales: ["r14", "r15", "r16"] }, // Cancha techada
  r12: { banner: true, herramientas: ["calculadora", "ohm", "colores", "bases"], materiales: ["r20", "r21", "r13"] }, // Robótica
};

// Un salón nuevo que todavía no está en la tabla de arriba: los laboratorios
// reciben la calculadora y los demás espacios, lo básico.
function recursosDe(salon) {
  return (
    RECURSOS_POR_SALON[salon.id] || {
      banner: salon.tipo === "laboratorio",
      herramientas: salon.tipo === "laboratorio" ? ["calculadora"] : [],
      materiales: [],
    }
  );
}

/* ------------------------------------------------------------
   PROTOCOLOS BASE (por tipo de salón)
   Son EJEMPLOS generales para que el espacio no arranque vacío; se
   muestran con la etiqueta "Ejemplo". Los protocolos oficiales de
   cada salón los publica el admin o un profesor desde la misma página.
   ------------------------------------------------------------ */
const PROTOCOLOS_BASE = {
  laboratorio: [
    {
      id: "base-lab-1",
      titulo: "Antes de entrar",
      texto: "Dejá las mochilas fuera del área de trabajo, recogete el pelo y usá calzado cerrado. No se entra sin el docente a cargo.",
    },
    {
      id: "base-lab-2",
      titulo: "Durante la práctica",
      texto: "No se come ni se bebe. Seguí las indicaciones del docente y avisá enseguida ante cualquier accidente, derrame o rotura.",
    },
    {
      id: "base-lab-3",
      titulo: "Al terminar",
      texto: "Apagá y guardá los equipos, limpiá la mesada y reportá lo que falte o se haya dañado antes de irte.",
    },
  ],
  espacio: [
    {
      id: "base-esp-1",
      titulo: "Uso del espacio",
      texto: "Respetá el horario reservado, dejá el salón ordenado y avisá a la dirección si encontrás algo roto.",
    },
    {
      id: "base-esp-2",
      titulo: "Cuidado del equipamiento",
      texto: "Apagá computadoras, proyectores y luces al salir, y no muevas el equipamiento fijo sin autorización.",
    },
  ],
};

/* ------------------------------------------------------------
   PROTOCOLOS PUBLICADOS (localStorage, como la sesión y la bolsa)
   Forma: { r4: [ { id, titulo, texto, autor, fecha }, ... ], ... }
   ------------------------------------------------------------ */
const CLAVE_PROTOCOLOS = "poloTecProtocolos";

function leerProtocolosPublicados() {
  try {
    const datos = JSON.parse(localStorage.getItem(CLAVE_PROTOCOLOS));
    return datos && typeof datos === "object" ? datos : {};
  } catch {
    return {};
  }
}

function guardarProtocolosPublicados(datos) {
  try {
    localStorage.setItem(CLAVE_PROTOCOLOS, JSON.stringify(datos));
    return true;
  } catch {
    return false; // navegador sin almacenamiento (modo privado, cuota llena)
  }
}

function escaparEspacio(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/* ------------------------------------------------------------
   PERMISOS
   Ven el espacio: alumno, profesor y admin. Publican y borran
   protocolos: profesor y admin.
   ------------------------------------------------------------ */
const ROLES_CON_ESPACIO = ["student", "professor", "admin"];

function puedePublicarProtocolos() {
  return ["professor", "admin"].includes(rolDeSesion());
}

// A dónde vuelve cada rol con el botón "Volver".
const VOLVER_POR_ROL = {
  student: { href: "dashboard-estudiante-reservas.html", texto: "Volver a Reservas" },
  professor: { href: "dashboard-profesor.html#seccion-espacios", texto: "Volver a mi panel" },
  admin: { href: "dashboard-admin-reservas.html", texto: "Volver a Reservas" },
};

/* ------------------------------------------------------------
   RENDER
   ------------------------------------------------------------ */
function idDelSalonEnLaURL() {
  return new URLSearchParams(window.location.search).get("id");
}

function htmlBannerCeibal() {
  const url = escaparEspacio(ENLACES_EXTERNOS.bibliotecaCeibal);
  return `
    <section class="espacio-banner" aria-labelledby="banner-ceibal-titulo">
      <div class="espacio-banner-icono" aria-hidden="true">${icono("libro", 30)}</div>
      <div class="espacio-banner-texto">
        <p class="espacio-banner-etiqueta">Biblioteca Ceibal</p>
        <h2 id="banner-ceibal-titulo" class="espacio-banner-titulo">Miles de libros, gratis y con tu usuario Ceibal</h2>
        <p class="espacio-banner-desc">Pedí en préstamo los textos de estudio de Física, Química, Matemática y más, y leelos en línea o sin conexión.</p>
      </div>
      <a class="espacio-banner-cta" href="${url}" target="_blank" rel="noopener noreferrer">
        Entrar a Biblioteca País ${icono("flecha", 16)}
        <span class="sr-only">(se abre en una pestaña nueva)</span>
      </a>
    </section>`;
}

function htmlLibros(salonId) {
  const libros = LIBROS_POR_SALON[salonId];
  if (!libros || libros.length === 0) return "";

  const items = libros
    .map(
      (libro) => `
      <li>
        <a class="espacio-libro" href="${escaparEspacio(libro.url)}" target="_blank" rel="noopener noreferrer">
          <span class="espacio-libro-nivel">${escaparEspacio(libro.nivel)}</span>
          <span class="espacio-libro-titulo">${escaparEspacio(libro.titulo)}</span>
          <span class="espacio-libro-autor">${escaparEspacio(libro.autor)}</span>
          <span class="espacio-libro-nota">${escaparEspacio(libro.nota)}</span>
          <span class="espacio-libro-abrir">Abrir libro ${icono("enlace", 14)}<span class="sr-only">(se abre en una pestaña nueva)</span></span>
        </a>
      </li>`
    )
    .join("");

  return `
    <section class="espacio-bloque" aria-labelledby="espacio-libros-titulo">
      <h2 id="espacio-libros-titulo" class="espacio-bloque-titulo">${icono("libro", 18)}Libros</h2>
      <p class="section-hint">Textos para estudiar y consultar en este espacio.</p>
      <ul class="espacio-libros">${items}</ul>
    </section>`;
}

// Un bloque por herramienta (js/herramientas.js). Se dibuja vacío y
// después pintarEspacio() monta la herramienta adentro.
function htmlHerramienta(clave) {
  const h = HERRAMIENTAS[clave];
  if (!h) return "";
  return `
    <section class="espacio-bloque" aria-labelledby="herr-titulo-${clave}">
      <h2 id="herr-titulo-${clave}" class="espacio-bloque-titulo">${icono(h.icono, 18)}${escaparEspacio(h.titulo)}</h2>
      <p class="section-hint">${escaparEspacio(h.ayuda)}</p>
      <div id="herr-${clave}"></div>
    </section>`;
}

// Materiales que suelen usarse en este salón, con el camino a pedirlos.
const RESERVAR_POR_ROL = {
  student: "dashboard-estudiante-reservas.html#seccion-materiales",
  professor: "dashboard-profesor.html#seccion-materiales",
  admin: "dashboard-admin-reservas.html#grilla-inventario",
};

function htmlMateriales(salon) {
  const ids = recursosDe(salon).materiales;
  const lista = ids.map((id) => salones.find((s) => s.id === id)).filter(esMaterial);
  if (lista.length === 0) return "";
  const destino = RESERVAR_POR_ROL[rolDeSesion()] || RESERVAR_POR_ROL.student;

  return `
    <section class="espacio-bloque espacio-bloque-ancho" aria-labelledby="espacio-materiales-titulo">
      <h2 id="espacio-materiales-titulo" class="espacio-bloque-titulo">${icono("equipo", 18)}Materiales que se usan acá</h2>
      <p class="section-hint">Lo que suele pedirse para trabajar en este espacio.</p>
      <ul class="perfil-chips espacio-materiales">${lista
        .map((m) => `<li>${escaparEspacio(m.nombre)} <span class="espacio-material-cant">×${m.cantidad}</span></li>`)
        .join("")}</ul>
      <p class="section-hint"><a href="${destino}" class="espacio-link">Pedir un material</a></p>
    </section>`;
}

function htmlPets() {
  const url = ENLACES_EXTERNOS.pets;
  const cuerpo = url
    ? `<a class="btn-primary espacio-pets-boton" href="${escaparEspacio(url)}" target="_blank" rel="noopener noreferrer">Abrir PETS ${icono("enlace", 16)}<span class="sr-only">(se abre en una pestaña nueva)</span></a>`
    : `<p class="espacio-pets-pendiente">Enlace por definir.</p>`;

  return `
    <section class="espacio-bloque" aria-labelledby="espacio-pets-titulo">
      <h2 id="espacio-pets-titulo" class="espacio-bloque-titulo">${icono("escudo", 18)}PETS</h2>
      <p class="section-hint">Acceso directo a PETS desde este espacio.</p>
      ${cuerpo}
    </section>`;
}

function protocolosDelSalon(salon) {
  const base = (PROTOCOLOS_BASE[salon.tipo] || []).map((p) => ({ ...p, ejemplo: true }));
  const publicados = leerProtocolosPublicados()[salon.id] || [];
  return [...publicados, ...base];
}

function htmlProtocolos(salon) {
  const puedePublicar = puedePublicarProtocolos();
  const lista = protocolosDelSalon(salon);

  const items = lista
    .map(
      (p) => `
      <details class="espacio-protocolo">
        <summary>
          <span class="espacio-protocolo-titulo">${escaparEspacio(p.titulo)}</span>
          ${p.ejemplo ? `<span class="espacio-protocolo-chip">Ejemplo</span>` : ""}
        </summary>
        <p class="espacio-protocolo-texto">${escaparEspacio(p.texto)}</p>
        ${p.autor ? `<p class="espacio-protocolo-meta">Publicado por ${escaparEspacio(p.autor)} · ${escaparEspacio(p.fecha)}</p>` : ""}
        ${
          puedePublicar && !p.ejemplo
            ? `<button type="button" class="btn-reject espacio-protocolo-borrar" data-borrar-protocolo="${escaparEspacio(p.id)}">Eliminar</button>`
            : ""
        }
      </details>`
    )
    .join("");

  const formulario = puedePublicar
    ? `
      <form id="form-protocolo" class="booking-form espacio-protocolo-form" novalidate>
        <div class="form-group">
          <label class="form-label" for="protocolo-titulo">Título del protocolo</label>
          <input id="protocolo-titulo" class="form-input" type="text" maxlength="80" placeholder="Ej: Manejo de la fuente de poder" required />
        </div>
        <div class="form-group">
          <label class="form-label" for="protocolo-texto">Qué hay que hacer</label>
          <textarea id="protocolo-texto" class="form-input espacio-protocolo-area" rows="4" maxlength="1200" placeholder="Pasos, advertencias, qué hacer ante un problema..." required></textarea>
        </div>
        <button type="submit" class="btn-primary">Publicar protocolo</button>
      </form>`
    : "";

  return `
    <section class="espacio-bloque espacio-bloque-ancho" aria-labelledby="espacio-protocolos-titulo">
      <h2 id="espacio-protocolos-titulo" class="espacio-bloque-titulo">${icono("documento", 18)}Protocolos</h2>
      <p class="section-hint">${
        puedePublicar
          ? "Los protocolos de este salón. Lo que publiques lo ven los alumnos y los demás docentes."
          : "Normas y pasos a seguir en este salón. Leelos antes de usarlo."
      }</p>
      <div id="lista-protocolos" class="espacio-protocolos">${items}</div>
      ${formulario}
    </section>`;
}

function htmlProximasReservas(salon) {
  const ahora = new Date();
  const proximas = reservas
    .filter((r) => r.salonId === salon.id && r.estado === "approved" && new Date(r.desde) >= ahora)
    .sort((a, b) => new Date(a.desde) - new Date(b.desde))
    .slice(0, 4);

  const cuerpo = proximas.length
    ? `<ul class="espacio-agenda">${proximas
        .map(
          (r) => `
        <li><span class="espacio-agenda-cuando">${escaparEspacio(formatearRango(r.desde, r.hasta))}</span>
            <span class="espacio-agenda-que">${escaparEspacio(r.motivo)}</span></li>`
        )
        .join("")}</ul>`
    : `<p class="empty-state">Sin reservas próximas: el salón está libre.</p>`;

  return `
    <section class="espacio-bloque espacio-bloque-ancho" aria-labelledby="espacio-agenda-titulo">
      <h2 id="espacio-agenda-titulo" class="espacio-bloque-titulo">${icono("calendario", 18)}Próximas reservas</h2>
      ${cuerpo}
      <p class="section-hint"><a href="agenda-publica.html" class="espacio-link">Ver la agenda completa</a></p>
    </section>`;
}

function pintarEspacio() {
  const contenidoEl = document.getElementById("salon-contenido");
  if (!contenidoEl) return;

  const rol = rolDeSesion();
  const volver = VOLVER_POR_ROL[rol] || VOLVER_POR_ROL.student;
  const volverEl = document.getElementById("salon-volver");
  if (volverEl) {
    volverEl.href = volver.href;
    volverEl.querySelector("span").textContent = volver.texto;
  }
  const enlacePanel = document.getElementById("enlace-panel");
  if (enlacePanel && PANEL_POR_ROL[rol]) enlacePanel.href = PANEL_POR_ROL[rol];

  const salon = salones.find((s) => s.id === idDelSalonEnLaURL());
  const tituloEl = document.getElementById("salon-titulo");
  const subtituloEl = document.getElementById("salon-subtitulo");

  // Sin id, con un id inventado o con un material (que no tiene espacio).
  if (!esSalon(salon)) {
    tituloEl.textContent = "Espacio no encontrado";
    subtituloEl.textContent = "Ese salón no existe o no tiene un espacio propio.";
    contenidoEl.innerHTML = `<p class="empty-state">Volvé a <a class="espacio-link" href="${volver.href}">${volver.texto.replace("Volver a ", "")}</a> y elegí un salón o laboratorio.</p>`;
    return;
  }

  document.title = `${salon.nombre} · Polo 2 Gestión`;
  tituloEl.textContent = salon.nombre;
  subtituloEl.textContent = `${ETIQUETA_TIPO_SALON[salon.tipo]} · recursos, PETS y protocolos de este espacio.`;

  const recursos = recursosDe(salon);
  contenidoEl.innerHTML = `
    ${recursos.banner ? htmlBannerCeibal() : ""}
    <div class="espacio-grilla">
      ${htmlLibros(salon.id)}
      ${recursos.herramientas.map(htmlHerramienta).join("")}
      ${htmlPets()}
      ${htmlProtocolos(salon)}
      ${htmlMateriales(salon)}
      ${htmlProximasReservas(salon)}
    </div>`;

  recursos.herramientas.forEach((clave) => {
    if (HERRAMIENTAS[clave]) HERRAMIENTAS[clave].montar(document.getElementById(`herr-${clave}`));
  });
  enganchar(salon);
}

// Al publicar o borrar solo se vuelve a dibujar el bloque de protocolos:
// así la calculadora no pierde lo que la persona tenía escrito.
function repintarProtocolos(salon) {
  const titulo = document.getElementById("espacio-protocolos-titulo");
  const bloque = titulo && titulo.closest("section");
  if (!bloque) return;
  bloque.outerHTML = htmlProtocolos(salon);
  enganchar(salon);
}

function enganchar(salon) {
  const form = document.getElementById("form-protocolo");
  if (form && puedePublicarProtocolos()) {
    form.addEventListener("submit", (evento) => {
      evento.preventDefault();
      const titulo = form.querySelector("#protocolo-titulo").value.trim();
      const texto = form.querySelector("#protocolo-texto").value.trim();
      if (!titulo || !texto) {
        mostrarToast("Completá el título y el texto del protocolo.", "error");
        return;
      }

      const sesion = obtenerSesion();
      const todos = leerProtocolosPublicados();
      const hoy = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      todos[salon.id] = [
        {
          id: `p${Date.now()}`,
          titulo,
          texto,
          autor: sesion ? sesion.name : "Polo",
          fecha: `${pad(hoy.getDate())}/${pad(hoy.getMonth() + 1)}/${hoy.getFullYear()}`,
        },
        ...(todos[salon.id] || []),
      ];
      // Versión real: POST /api/v1/resources/:id/protocols
      if (!guardarProtocolosPublicados(todos)) {
        mostrarToast("No se pudo guardar: el navegador bloqueó el almacenamiento.", "error");
        return;
      }
      repintarProtocolos(salon);
      mostrarToast("Protocolo publicado.", "success");
    });
  }

  document.querySelectorAll("button[data-borrar-protocolo]").forEach((boton) => {
    boton.addEventListener("click", () => {
      pedirConfirmacion("Eliminar protocolo", "¿Eliminar este protocolo? Los alumnos dejarán de verlo.", () => {
        const todos = leerProtocolosPublicados();
        todos[salon.id] = (todos[salon.id] || []).filter((p) => p.id !== boton.dataset.borrarProtocolo);
        // Versión real: DELETE /api/v1/resources/:id/protocols/:protocolId
        guardarProtocolosPublicados(todos);
        repintarProtocolos(salon);
        mostrarToast("Protocolo eliminado.", "info");
      }, "Eliminar");
    });
  });
}

document.addEventListener("DOMContentLoaded", pintarEspacio);
