/* ============================================================
   BOLSA DE PASANTÍAS (compartida entre estudiantes y empresas)
   Antes cada panel tenía su propia copia de las pasantías y de
   las postulaciones, en memoria: si una empresa aceptaba a alguien,
   el estudiante nunca se enteraba. Ahora hay una sola "bolsa",
   guardada en el localStorage del navegador (igual que la sesión),
   que leen y escriben los dos paneles:

     · perfiles      → el perfil profesional de cada estudiante
     · pasantias     → las publicadas por cada empresa
     · postulaciones → quién se postuló a qué, y en qué estado está

   En la versión con backend, cada función de acá es un endpoint:
     perfilDe(email)               → GET   /api/v1/students/:id/profile
     guardarPerfil(email, perfil)  → PUT   /api/v1/students/me/profile
     postular(email, pasantiaId)   → POST  /api/v1/internships/:id/applications
     cambiarEstadoPostulacion(...) → PATCH /api/v1/applications/:id
   ============================================================ */

const CLAVE_BOLSA = "poloTecBolsa";
// Si cambia la forma de los datos de ejemplo, se sube este número y
// la bolsa vieja se reemplaza por la nueva en vez de romperse.
const VERSION_BOLSA = 1;

// Sugerencias para el campo de orientación (se puede escribir otra).
const ORIENTACIONES = [
  "Bachillerato Tecnológico en Informática",
  "Bachillerato Tecnológico en Electromecánica",
  "Bachillerato Tecnológico en Química",
  "Bachillerato Tecnológico Agrario",
  "Bachillerato Tecnológico en Electrónica",
  "Tecnólogo en Informática",
  "Tecnicatura en Robótica",
  "Tecnicatura en Energías Renovables",
];

const NIVELES = ["1er año", "2do año", "3er año", "Egresado/a"];
const DISPONIBILIDADES = ["Medio tiempo", "Tiempo completo", "Solo fines de semana", "A coordinar"];

const ESTADO_POSTULACION = {
  pending: "En revisión",
  approved: "Seleccionado/a",
  rejected: "No seleccionado/a",
};

/* ------------------------------------------------------------
   DATOS DE EJEMPLO (se cargan la primera vez)
   ------------------------------------------------------------ */
function perfilVacio(email, nombre) {
  return {
    email,
    nombre: nombre || "",
    orientacion: "",
    nivel: "",
    localidad: "",
    disponibilidad: "",
    sobreMi: "",
    capacidades: [],
    idiomas: [],
    titulos: [],      // { nombre, institucion, anio }
    cursos: [],       // { nombre, institucion, detalle }
    experiencia: [],  // { puesto, lugar, periodo }
    linkedin: "",
    portfolio: "",
    cv: null,         // { nombre, tamano, fecha } del PDF; el archivo está en IndexedDB
  };
}

function semillaBolsa() {
  const perfil = (email, nombre, datos) => ({ ...perfilVacio(email, nombre), ...datos });

  return {
    version: VERSION_BOLSA,
    perfiles: {
      "maria@estudiante.com": perfil("maria@estudiante.com", "María González", {
        orientacion: "Bachillerato Tecnológico en Informática",
        nivel: "3er año",
        localidad: "Tacuarembó",
        disponibilidad: "Medio tiempo",
        sobreMi:
          "Me gusta armar páginas web y entender cómo funcionan los datos detrás. Busco mi primera pasantía para aprender a trabajar en equipo en un proyecto real.",
        capacidades: ["HTML y CSS", "JavaScript", "Python", "Trabajo en equipo"],
        idiomas: ["Español nativo", "Inglés B1"],
        titulos: [{ nombre: "Ciclo Básico Tecnológico", institucion: "UTU Tacuarembó", anio: "2023" }],
        cursos: [{ nombre: "Introducción a Python", institucion: "Ceibal", detalle: "40 horas" }],
        experiencia: [],
        linkedin: "",
        portfolio: "github.com/mariagonzalez",
      }),
      "facundo@estudiante.com": perfil("facundo@estudiante.com", "Facundo Pereira", {
        orientacion: "Tecnólogo en Informática",
        nivel: "2do año",
        localidad: "Tacuarembó",
        disponibilidad: "Tiempo completo",
        sobreMi:
          "Programo en JavaScript y estoy aprendiendo React. Hice la web del club de fútbol del barrio y la mantengo desde hace un año.",
        capacidades: ["JavaScript", "React", "Git", "Diseño responsive", "Bases de datos SQL"],
        idiomas: ["Español nativo", "Inglés B2"],
        titulos: [{ nombre: "Bachillerato Tecnológico en Informática", institucion: "UTU Tacuarembó", anio: "2024" }],
        cursos: [
          { nombre: "Desarrollo web full stack", institucion: "Jóvenes a Programar", detalle: "2025" },
          { nombre: "Git y GitHub", institucion: "Plataforma Ceibal", detalle: "20 horas" },
        ],
        experiencia: [{ puesto: "Desarrollador web voluntario", lugar: "Club Atlético Barrio Centro", periodo: "2025 – hoy" }],
        portfolio: "facundopereira.dev",
      }),
      "valentina@estudiante.com": perfil("valentina@estudiante.com", "Valentina Silveira", {
        orientacion: "Bachillerato Tecnológico en Informática",
        nivel: "Egresado/a",
        localidad: "Paso de los Toros",
        disponibilidad: "Medio tiempo",
        sobreMi: "Me interesa el diseño de interfaces y la accesibilidad. Armo prototipos en Figma antes de programar.",
        capacidades: ["Figma", "HTML y CSS", "Accesibilidad web", "Comunicación"],
        idiomas: ["Español nativo", "Portugués B2", "Inglés A2"],
        titulos: [{ nombre: "Bachillerato Tecnológico en Informática", institucion: "UTU Paso de los Toros", anio: "2025" }],
        cursos: [{ nombre: "Diseño UX", institucion: "Google (Coursera)", detalle: "6 meses" }],
        experiencia: [{ puesto: "Pasante de diseño", lugar: "Intendencia de Tacuarembó", periodo: "Verano 2025" }],
        linkedin: "linkedin.com/in/valentinasilveira",
      }),
      "camila@estudiante.com": perfil("camila@estudiante.com", "Camila Núñez", {
        orientacion: "Bachillerato Tecnológico en Química",
        nivel: "3er año",
        localidad: "Tacuarembó",
        disponibilidad: "A coordinar",
        sobreMi: "Trabajo ordenada en el laboratorio y llevo bien los registros. Quiero aplicar lo que sé en una planta o en control de calidad.",
        capacidades: ["Análisis de laboratorio", "Excel", "Control de calidad", "Normas de seguridad"],
        idiomas: ["Español nativo", "Inglés A2"],
        cursos: [{ nombre: "Buenas prácticas de laboratorio", institucion: "LATU", detalle: "16 horas" }],
      }),
      "joaquin@estudiante.com": perfil("joaquin@estudiante.com", "Joaquín Olivera", {
        orientacion: "Bachillerato Tecnológico Agrario",
        nivel: "Egresado/a",
        localidad: "Ansina",
        disponibilidad: "Tiempo completo",
        sobreMi: "Crecí en el campo y me especialicé en producción ganadera. Manejo registros de rodeo y maquinaria básica.",
        capacidades: ["Manejo de ganado", "Registros productivos", "Maquinaria agrícola", "Excel"],
        idiomas: ["Español nativo"],
        titulos: [{ nombre: "Bachillerato Tecnológico Agrario", institucion: "Escuela Agraria de Tacuarembó", anio: "2025" }],
        cursos: [{ nombre: "Inseminación artificial", institucion: "INIA", detalle: "2025" }],
        experiencia: [{ puesto: "Ayudante de campo", lugar: "Establecimiento La Aurora", periodo: "2024 – 2025" }],
      }),
      "sofia@estudiante.com": perfil("sofia@estudiante.com", "Sofía Pintos", {
        orientacion: "Bachillerato Tecnológico en Electromecánica",
        nivel: "3er año",
        localidad: "Tacuarembó",
        disponibilidad: "Medio tiempo",
        sobreMi: "Me gusta el mantenimiento de equipos y la automatización. Armé un brazo robótico con Arduino para la feria de clubes.",
        capacidades: ["Arduino", "Electricidad industrial", "AutoCAD", "Mantenimiento preventivo"],
        idiomas: ["Español nativo", "Inglés A2"],
        cursos: [{ nombre: "Automatización con PLC", institucion: "UTU", detalle: "60 horas" }],
      }),
    },
    pasantias: [
      {
        id: 1,
        titulo: "Desarrollador Frontend Jr",
        empresa: "TechCorp Tacuarembó",
        empresaEmail: "contacto@techcorp.com",
        modalidad: "Remoto",
        duracionMeses: 6,
      },
      {
        id: 2,
        titulo: "Soporte de Datos",
        empresa: "TechCorp Tacuarembó",
        empresaEmail: "contacto@techcorp.com",
        modalidad: "Presencial",
        duracionMeses: 4,
      },
      {
        id: 3,
        titulo: "Asistente de Agroindustria",
        empresa: "AgroTacuá S.A.",
        empresaEmail: "rrhh@agrotacua.com.uy",
        modalidad: "Híbrido",
        duracionMeses: 5,
      },
    ],
    postulaciones: [
      { id: "po1", pasantiaId: 2, estudianteEmail: "maria@estudiante.com", estado: "pending" },
      { id: "po2", pasantiaId: 1, estudianteEmail: "facundo@estudiante.com", estado: "pending" },
      { id: "po3", pasantiaId: 1, estudianteEmail: "valentina@estudiante.com", estado: "approved" },
      { id: "po4", pasantiaId: 1, estudianteEmail: "sofia@estudiante.com", estado: "rejected" },
      { id: "po5", pasantiaId: 2, estudianteEmail: "camila@estudiante.com", estado: "pending" },
      { id: "po6", pasantiaId: 3, estudianteEmail: "joaquin@estudiante.com", estado: "pending" },
    ],
  };
}

/* ------------------------------------------------------------
   LEER Y GUARDAR
   ------------------------------------------------------------ */
function leerBolsa() {
  try {
    const guardada = JSON.parse(localStorage.getItem(CLAVE_BOLSA));
    if (guardada && guardada.version === VERSION_BOLSA) return guardada;
  } catch {
    // datos corruptos: se vuelve a la semilla
  }
  const nueva = semillaBolsa();
  guardarBolsa(nueva);
  return nueva;
}

function guardarBolsa(bolsa) {
  localStorage.setItem(CLAVE_BOLSA, JSON.stringify(bolsa));
}

/* ------------------------------------------------------------
   PERFILES
   ------------------------------------------------------------ */
function perfilDe(email, nombre) {
  const bolsa = leerBolsa();
  const perfil = bolsa.perfiles[email];
  if (perfil) return { ...perfilVacio(email, nombre), ...perfil };
  return perfilVacio(email, nombre);
}

function guardarPerfil(email, perfil) {
  const bolsa = leerBolsa();
  bolsa.perfiles[email] = { ...perfil, email };
  guardarBolsa(bolsa);
}

function todosLosPerfiles() {
  return Object.values(leerBolsa().perfiles).map((p) => ({ ...perfilVacio(p.email, p.nombre), ...p }));
}

// Qué tan completo está un perfil, de 0 a 100. Cada bloque vale lo
// mismo: así la barra le dice al estudiante qué le falta, sin
// premiar escribir mucho en un solo campo.
const BLOQUES_DEL_PERFIL = [
  ["Orientación", (p) => p.orientacion],
  ["Año o nivel", (p) => p.nivel],
  ["Disponibilidad", (p) => p.disponibilidad],
  ["Sobre vos", (p) => p.sobreMi && p.sobreMi.length >= 30],
  ["Capacidades", (p) => p.capacidades.length >= 3],
  ["Idiomas", (p) => p.idiomas.length],
  ["Títulos", (p) => p.titulos.length],
  ["Cursos", (p) => p.cursos.length],
  ["Experiencia", (p) => p.experiencia.length],
  ["Link a tu trabajo", (p) => p.linkedin || p.portfolio],
  ["Currículum (PDF)", (p) => p.cv],
];

function completitudPerfil(perfil) {
  const hechos = BLOQUES_DEL_PERFIL.filter(([, cumple]) => cumple(perfil)).length;
  return Math.round((hechos / BLOQUES_DEL_PERFIL.length) * 100);
}

function faltantesDelPerfil(perfil) {
  return BLOQUES_DEL_PERFIL.filter(([, cumple]) => !cumple(perfil)).map(([nombre]) => nombre);
}

/* ------------------------------------------------------------
   CURRÍCULUM EN PDF
   El perfil guarda solo los datos del archivo (nombre, tamaño,
   fecha); el PDF en sí va a IndexedDB, que aguanta archivos de
   varios MB (el localStorage no: tiene un tope de ~5 MB en total).

   Esto es un mock del navegador: el archivo queda en la computadora
   donde se subió. En la versión con backend:
     guardarArchivoCV(email, archivo) → POST /api/v1/students/me/cv   (multipart)
     leerArchivoCV(email)             → GET  /api/v1/students/:id/cv
     borrarArchivoCV(email)           → DELETE /api/v1/students/me/cv
   y el servidor tiene que repetir las validaciones de validarCV():
   las del navegador son comodidad, no seguridad.
   ------------------------------------------------------------ */
const CV_MAX_BYTES = 5 * 1024 * 1024; // el tope previsto en el documento técnico
const BD_ARCHIVOS = "poloTecArchivos";

function abrirBdArchivos() {
  return new Promise((resolver, rechazar) => {
    if (typeof indexedDB === "undefined") {
      rechazar(new Error("Este navegador no permite guardar archivos."));
      return;
    }
    const pedido = indexedDB.open(BD_ARCHIVOS, 1);
    pedido.onupgradeneeded = () => pedido.result.createObjectStore("cv");
    pedido.onsuccess = () => resolver(pedido.result);
    pedido.onerror = () => rechazar(pedido.error);
  });
}

function operarArchivoCV(modo, accion) {
  return abrirBdArchivos().then(
    (bd) =>
      new Promise((resolver, rechazar) => {
        const tx = bd.transaction("cv", modo);
        const pedido = accion(tx.objectStore("cv"));
        tx.oncomplete = () => {
          bd.close();
          resolver(pedido.result);
        };
        tx.onerror = tx.onabort = () => {
          bd.close();
          rechazar(tx.error);
        };
      })
  );
}

function guardarArchivoCV(email, archivo) {
  return operarArchivoCV("readwrite", (almacen) => almacen.put({ blob: archivo, nombre: archivo.name }, email));
}
function leerArchivoCV(email) {
  return operarArchivoCV("readonly", (almacen) => almacen.get(email));
}
function borrarArchivoCV(email) {
  return operarArchivoCV("readwrite", (almacen) => almacen.delete(email));
}

// Devuelve el texto del problema, o null si el archivo sirve. No se
// confía en la extensión ni en el tipo que informa el navegador: se
// mira que el archivo empiece de verdad con la firma de un PDF.
async function validarCV(archivo) {
  if (!archivo) return "Elegí un archivo.";
  if (!/\.pdf$/i.test(archivo.name)) return "Solo se aceptan archivos PDF.";
  if (archivo.size === 0) return "El archivo está vacío.";
  if (archivo.size > CV_MAX_BYTES) return `El archivo pesa ${formatoTamanoArchivo(archivo.size)} y el máximo es 5 MB.`;
  const cabecera = await archivo.slice(0, 5).text();
  if (cabecera !== "%PDF-") return "El archivo no parece un PDF válido.";
  return null;
}

function formatoTamanoArchivo(bytes) {
  if (!Number.isFinite(bytes)) return "";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1).replace(".", ",")} MB`;
}

// Abre el CV en una pestaña nueva (lo usan el estudiante y las empresas).
// La pestaña se abre ANTES de leer el archivo para que el navegador no
// la bloquee como ventana emergente.
async function abrirCV(email) {
  const ventana = window.open("about:blank", "_blank");
  try {
    const registro = await leerArchivoCV(email);
    if (!registro) throw new Error("falta");
    const url = URL.createObjectURL(new Blob([registro.blob], { type: "application/pdf" }));
    if (ventana) {
      ventana.opener = null;
      ventana.location.href = url;
    } else {
      const enlace = document.createElement("a");
      enlace.href = url;
      enlace.download = registro.nombre || "curriculum.pdf";
      enlace.click();
    }
    setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
  } catch {
    if (ventana) ventana.close();
    if (typeof mostrarToast === "function") {
      mostrarToast("No se encontró el archivo del currículum en este navegador. Pedile a la persona que lo vuelva a subir.", "error");
    }
  }
}

document.addEventListener("click", (evento) => {
  const boton = evento.target.closest("[data-cv-ver]");
  if (boton) abrirCV(boton.dataset.cvVer);
});

/* ------------------------------------------------------------
   PASANTÍAS
   ------------------------------------------------------------ */
// Las que ven los estudiantes: solo de empresas ya aprobadas por el
// Polo (una empresa "pendiente de aprobación" todavía no publica).
function pasantiasVisibles() {
  const pendientes = new Set(
    (typeof CUENTAS_DEMO !== "undefined" ? CUENTAS_DEMO : [])
      .filter((c) => c.role === "company" && c.status === "pending_approval")
      .map((c) => c.email)
  );
  return leerBolsa().pasantias.filter((p) => !pendientes.has(p.empresaEmail));
}

function pasantiasDeEmpresa(email) {
  return leerBolsa().pasantias.filter((p) => p.empresaEmail === email);
}

function publicarPasantia(datos) {
  const bolsa = leerBolsa();
  const id = bolsa.pasantias.length ? Math.max(...bolsa.pasantias.map((p) => p.id)) + 1 : 1;
  const pasantia = { id, ...datos };
  bolsa.pasantias.push(pasantia);
  guardarBolsa(bolsa);
  return pasantia;
}

function pasantiaPorId(id) {
  return leerBolsa().pasantias.find((p) => p.id === Number(id));
}

/* ------------------------------------------------------------
   POSTULACIONES
   ------------------------------------------------------------ */
function postulacionesDeEstudiante(email) {
  const bolsa = leerBolsa();
  return bolsa.postulaciones
    .filter((p) => p.estudianteEmail === email)
    .map((p) => ({ ...p, pasantia: bolsa.pasantias.find((x) => x.id === p.pasantiaId) }))
    .filter((p) => p.pasantia);
}

function postulacionesDePasantia(pasantiaId) {
  return leerBolsa().postulaciones.filter((p) => p.pasantiaId === Number(pasantiaId));
}

function postulacionDe(email, pasantiaId) {
  return leerBolsa().postulaciones.find(
    (p) => p.estudianteEmail === email && p.pasantiaId === Number(pasantiaId)
  );
}

function postular(email, pasantiaId) {
  const bolsa = leerBolsa();
  if (bolsa.postulaciones.some((p) => p.estudianteEmail === email && p.pasantiaId === Number(pasantiaId))) return null;
  const nueva = {
    id: `po${Date.now().toString(36)}`,
    pasantiaId: Number(pasantiaId),
    estudianteEmail: email,
    estado: "pending",
  };
  bolsa.postulaciones.push(nueva);
  guardarBolsa(bolsa);
  return nueva;
}

// La empresa acepta o rechaza. Si el estudiante no se había
// postulado (la empresa lo encontró en el directorio de perfiles),
// se crea la postulación ya aceptada: le llega igual a su panel.
function decidirPostulacion(email, pasantiaId, estado) {
  const bolsa = leerBolsa();
  let postulacion = bolsa.postulaciones.find(
    (p) => p.estudianteEmail === email && p.pasantiaId === Number(pasantiaId)
  );
  if (!postulacion) {
    postulacion = { id: `po${Date.now().toString(36)}`, pasantiaId: Number(pasantiaId), estudianteEmail: email, estado };
    bolsa.postulaciones.push(postulacion);
  } else {
    postulacion.estado = estado;
  }
  guardarBolsa(bolsa);
  return postulacion;
}

/* ------------------------------------------------------------
   PINTAR UN PERFIL (lo usan los dos paneles)
   Todo lo que escribió el estudiante pasa por escaparHTML: un
   "<script>" en "Sobre mí" se muestra como texto, no se ejecuta.
   ------------------------------------------------------------ */
function escaparHTML(texto) {
  return String(texto ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

function inicialesPerfil(nombre) {
  return (nombre || "?")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
}

function enlaceExterno(url) {
  if (!url) return "";
  const limpio = url.trim();
  const href = /^https?:\/\//i.test(limpio) ? limpio : `https://${limpio}`;
  return `<a href="${escaparHTML(href)}" target="_blank" rel="noopener noreferrer">${escaparHTML(limpio)}</a>`;
}

// `vacio` es lo que se muestra cuando un bloque está sin completar:
// al estudiante le sirve de invitación; a la empresa, de dato.
function htmlPerfil(perfil, { propio = false } = {}) {
  const e = escaparHTML;
  const vacio = (texto) => `<p class="perfil-vacio">${propio ? texto : "Sin completar."}</p>`;
  const chips = (lista) =>
    lista.length ? `<ul class="perfil-chips">${lista.map((c) => `<li>${e(c)}</li>`).join("")}</ul>` : "";
  const filas = (lista, armar) =>
    lista.length ? `<ul class="perfil-lista">${lista.map((item) => `<li>${armar(item)}</li>`).join("")}</ul>` : "";

  const datos = [perfil.nivel, perfil.localidad, perfil.disponibilidad].filter(Boolean).map(e);
  const links = [enlaceExterno(perfil.linkedin), enlaceExterno(perfil.portfolio)].filter(Boolean);

  return `
    <div class="perfil-cabecera">
      <span class="avatar perfil-avatar" aria-hidden="true">${e(inicialesPerfil(perfil.nombre))}</span>
      <div class="perfil-identidad">
        <p class="perfil-nombre">${e(perfil.nombre)}</p>
        <p class="perfil-orientacion">${perfil.orientacion ? e(perfil.orientacion) : propio ? "Agregá tu orientación" : "Orientación sin completar"}</p>
        ${datos.length ? `<p class="perfil-datos">${datos.join('<span aria-hidden="true"> · </span>')}</p>` : ""}
      </div>
    </div>

    <div class="perfil-bloque perfil-sobre">
      <h3 class="perfil-subtitulo">Sobre ${propio ? "vos" : "mí"}</h3>
      ${perfil.sobreMi ? `<p>${e(perfil.sobreMi)}</p>` : vacio("Contale a las empresas qué te interesa y qué sabés hacer.")}
    </div>

    <div class="perfil-columnas">
      <div class="perfil-bloque">
        <h3 class="perfil-subtitulo">Capacidades</h3>
        ${chips(perfil.capacidades) || vacio("Sumá al menos tres: herramientas, lenguajes, oficios.")}
      </div>
      <div class="perfil-bloque">
        <h3 class="perfil-subtitulo">Idiomas</h3>
        ${chips(perfil.idiomas) || vacio("Por ejemplo: Inglés B1.")}
      </div>
      <div class="perfil-bloque">
        <h3 class="perfil-subtitulo">Títulos y certificaciones</h3>
        ${
          filas(
            perfil.titulos,
            (t) => `<strong>${e(t.nombre)}</strong><span>${[t.institucion, t.anio].filter(Boolean).map(e).join(", ")}</span>`
          ) || vacio("Tu bachillerato, tecnicatura o certificados.")
        }
      </div>
      <div class="perfil-bloque">
        <h3 class="perfil-subtitulo">Cursos y capacitaciones</h3>
        ${
          filas(
            perfil.cursos,
            (c) => `<strong>${e(c.nombre)}</strong><span>${[c.institucion, c.detalle].filter(Boolean).map(e).join(", ")}</span>`
          ) || vacio("Cursos de Ceibal, UTU, Jóvenes a Programar, online…")
        }
      </div>
      <div class="perfil-bloque perfil-bloque-ancho">
        <h3 class="perfil-subtitulo">Experiencia y pasantías anteriores</h3>
        ${
          filas(
            perfil.experiencia,
            (x) => `<strong>${e(x.puesto)}</strong><span>${[x.lugar, x.periodo].filter(Boolean).map(e).join(", ")}</span>`
          ) || vacio("Trabajos, voluntariados o pasantías que ya hiciste. Si es tu primera, dejalo vacío.")
        }
      </div>
      <div class="perfil-bloque perfil-bloque-ancho perfil-cv">
        <h3 class="perfil-subtitulo">Currículum</h3>
        ${
          perfil.cv
            ? `<button type="button" class="perfil-cv-boton" data-cv-ver="${e(perfil.email)}">
                ${typeof icono === "function" ? icono("documento", 18) : ""}
                <span class="perfil-cv-nombre">${e(perfil.cv.nombre)}</span>
                <span class="perfil-cv-meta">PDF · ${e(formatoTamanoArchivo(perfil.cv.tamano))}</span>
              </button>`
            : vacio("Subí tu currículum en PDF (hasta 5 MB) desde \"Editar perfil\".")
        }
      </div>
      ${
        links.length
          ? `<div class="perfil-bloque perfil-bloque-ancho"><h3 class="perfil-subtitulo">Links</h3><p class="perfil-links">${links.join("")}</p></div>`
          : propio
          ? `<div class="perfil-bloque perfil-bloque-ancho"><h3 class="perfil-subtitulo">Links</h3>${vacio("LinkedIn, GitHub o un portfolio con lo que hiciste.")}</div>`
          : ""
      }
    </div>
  `;
}
