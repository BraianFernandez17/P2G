/* ============================================================
   HERRAMIENTAS POR MATERIA (para el espacio de cada salón)
   Cada salón muestra solo las que le sirven a su materia (ver
   RECURSOS_POR_SALON en js/espacios.js):

     constantes  → tabla de constantes físicas       (Física)
     conversor   → conversor de unidades             (Física, Ciencias)
     masamolar   → masa molar de una fórmula química (Química)
     ohm         → ley de Ohm y potencia             (Robótica)
     colores     → código de colores de resistencias (Robótica)
     bases       → binario, octal, decimal y hex     (Informática, Robótica)

   Cada herramienta tiene dos partes, igual que la calculadora:
   una función pura que hace la cuenta (se prueba en Node) y una
   función montar…() que dibuja la pantalla.

   Todo lo que escribe la persona se muestra con textContent o
   pasa por escaparHerr(): nunca se interpreta como HTML.
   ============================================================ */

function escaparHerr(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

class ErrorHerramienta extends Error {}

// Números con coma decimal, como se escriben en Uruguay.
function formatoNumero(n, cifras = 6) {
  if (n === 0) return "0";
  const abs = Math.abs(n);
  if (abs >= 1e9 || abs < 1e-4) {
    const [m, e] = n.toExponential(cifras - 1).split("e");
    return `${parseFloat(m).toString().replace(".", ",")} × 10${superindice(parseInt(e, 10))}`;
  }
  return parseFloat(n.toPrecision(cifras)).toString().replace(".", ",");
}

function superindice(n) {
  const mapa = { "-": "⁻", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
  return String(n)
    .split("")
    .map((c) => mapa[c])
    .join("");
}

// Lee un número escrito por una persona: acepta coma decimal y 1E-3.
function leerNumero(texto) {
  const limpio = String(texto ?? "").trim().replace(",", ".");
  if (limpio === "" || !/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(limpio)) return NaN;
  return Number(limpio);
}

/* ============================================================
   1) CONSTANTES FÍSICAS  (valores CODATA 2018)
   ============================================================ */
const CONSTANTES_FISICAS = [
  { simbolo: "c", nombre: "Velocidad de la luz en el vacío", mantisa: "2.99792458", exp: 8, unidad: "m/s" },
  { simbolo: "g", nombre: "Aceleración de la gravedad (estándar)", mantisa: "9.80665", exp: 0, unidad: "m/s²" },
  { simbolo: "G", nombre: "Constante de gravitación universal", mantisa: "6.67430", exp: -11, unidad: "N·m²/kg²" },
  { simbolo: "h", nombre: "Constante de Planck", mantisa: "6.62607015", exp: -34, unidad: "J·s" },
  { simbolo: "e", nombre: "Carga elemental", mantisa: "1.602176634", exp: -19, unidad: "C" },
  { simbolo: "kB", nombre: "Constante de Boltzmann", mantisa: "1.380649", exp: -23, unidad: "J/K" },
  { simbolo: "NA", nombre: "Número de Avogadro", mantisa: "6.02214076", exp: 23, unidad: "1/mol" },
  { simbolo: "R", nombre: "Constante de los gases", mantisa: "8.314462618", exp: 0, unidad: "J/(mol·K)" },
  { simbolo: "ε₀", nombre: "Permitividad del vacío", mantisa: "8.8541878128", exp: -12, unidad: "F/m" },
  { simbolo: "μ₀", nombre: "Permeabilidad del vacío", mantisa: "1.25663706212", exp: -6, unidad: "N/A²" },
  { simbolo: "mₑ", nombre: "Masa del electrón", mantisa: "9.1093837015", exp: -31, unidad: "kg" },
  { simbolo: "mₚ", nombre: "Masa del protón", mantisa: "1.67262192369", exp: -27, unidad: "kg" },
  { simbolo: "σ", nombre: "Constante de Stefan-Boltzmann", mantisa: "5.670374419", exp: -8, unidad: "W/(m²·K⁴)" },
  { simbolo: "atm", nombre: "Presión atmosférica estándar", mantisa: "1.01325", exp: 5, unidad: "Pa" },
];

// "6.62607015E-34": lo que se inserta en la calculadora.
function entradaConstante(c) {
  return c.exp === 0 ? c.mantisa : `${c.mantisa}E${c.exp}`;
}
function textoConstante(c) {
  const m = c.mantisa.replace(".", ",");
  return c.exp === 0 ? m : `${m} × 10${superindice(c.exp)}`;
}

function montarConstantes(contenedor) {
  contenedor.innerHTML = `
    <div class="herr-tabla-caja">
      <table class="herr-tabla">
        <thead><tr><th scope="col">Símbolo</th><th scope="col">Constante</th><th scope="col">Valor</th><th scope="col"><span class="sr-only">Usar en la calculadora</span></th></tr></thead>
        <tbody>${CONSTANTES_FISICAS.map(
          (c, i) => `<tr>
            <th scope="row" class="herr-simbolo">${escaparHerr(c.simbolo)}</th>
            <td>${escaparHerr(c.nombre)}</td>
            <td class="herr-valor">${escaparHerr(textoConstante(c))} <span class="herr-unidad">${escaparHerr(c.unidad)}</span></td>
            <td><button type="button" class="btn-secondary herr-usar" data-i="${i}" aria-label="Usar ${escaparHerr(c.nombre)} en la calculadora">Usar</button></td>
          </tr>`
        ).join("")}</tbody>
      </table>
    </div>
    <p class="section-hint herr-nota">Valores CODATA 2018. "Usar" lo escribe en la calculadora.</p>`;

  contenedor.addEventListener("click", (evento) => {
    const boton = evento.target.closest("button[data-i]");
    if (!boton) return;
    const c = CONSTANTES_FISICAS[Number(boton.dataset.i)];
    if (typeof window.insertarEnCalculadora === "function") {
      window.insertarEnCalculadora(entradaConstante(c));
      if (typeof mostrarToast === "function") mostrarToast(`${c.simbolo} agregado a la calculadora.`, "info");
    }
  });
}

/* ============================================================
   2) CONVERSOR DE UNIDADES
   ============================================================ */
// Cada categoría: factor para llevar la unidad a la unidad base.
const UNIDADES = {
  Longitud: { m: 1, km: 1000, cm: 0.01, mm: 0.001, in: 0.0254, ft: 0.3048, mi: 1609.344 },
  Masa: { kg: 1, g: 0.001, mg: 0.000001, t: 1000, lb: 0.45359237, oz: 0.028349523125 },
  Tiempo: { s: 1, min: 60, h: 3600, día: 86400 },
  Velocidad: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704 },
  Fuerza: { N: 1, kN: 1000, kgf: 9.80665, lbf: 4.4482216152605 },
  Presión: { Pa: 1, kPa: 1000, atm: 101325, bar: 100000, mmHg: 133.322387415 },
  Energía: { J: 1, kJ: 1000, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3600000, eV: 1.602176634e-19 },
  Temperatura: { "°C": null, K: null, "°F": null },
};

function convertirUnidad(categoria, valor, de, a) {
  const tabla = UNIDADES[categoria];
  if (!tabla || !(de in tabla) || !(a in tabla)) throw new ErrorHerramienta("Unidad no válida.");
  if (!Number.isFinite(valor)) throw new ErrorHerramienta("Escribí un número.");

  if (categoria === "Temperatura") {
    const aKelvin = { "°C": (v) => v + 273.15, K: (v) => v, "°F": (v) => ((v - 32) * 5) / 9 + 273.15 };
    const desdeKelvin = { "°C": (k) => k - 273.15, K: (k) => k, "°F": (k) => ((k - 273.15) * 9) / 5 + 32 };
    const k = aKelvin[de](valor);
    if (k < 0) throw new ErrorHerramienta("Eso está por debajo del cero absoluto.");
    return desdeKelvin[a](k);
  }
  return (valor * tabla[de]) / tabla[a];
}

function montarConversor(contenedor) {
  const categorias = Object.keys(UNIDADES);
  contenedor.innerHTML = `
    <div class="herr-fila">
      <div class="form-group">
        <label class="form-label" for="conv-categoria">Magnitud</label>
        <select id="conv-categoria" class="form-select">${categorias.map((c) => `<option>${escaparHerr(c)}</option>`).join("")}</select>
      </div>
      <div class="form-group">
        <label class="form-label" for="conv-valor">Valor</label>
        <input id="conv-valor" class="form-input" type="text" inputmode="decimal" autocomplete="off" value="1" />
      </div>
    </div>
    <div class="herr-fila">
      <div class="form-group">
        <label class="form-label" for="conv-de">De</label>
        <select id="conv-de" class="form-select"></select>
      </div>
      <div class="form-group">
        <label class="form-label" for="conv-a">A</label>
        <select id="conv-a" class="form-select"></select>
      </div>
    </div>
    <p id="conv-resultado" class="herr-resultado" role="status" aria-live="polite"></p>
    <p id="conv-error" class="calc-error" hidden></p>`;

  const $ = (id) => contenedor.querySelector(id);
  const llenarUnidades = () => {
    const unidades = Object.keys(UNIDADES[$("#conv-categoria").value]);
    const opciones = unidades.map((u) => `<option>${escaparHerr(u)}</option>`).join("");
    $("#conv-de").innerHTML = opciones;
    $("#conv-a").innerHTML = opciones;
    $("#conv-a").selectedIndex = Math.min(1, unidades.length - 1);
  };
  const calcular = () => {
    const errorEl = $("#conv-error");
    try {
      const valor = leerNumero($("#conv-valor").value);
      const r = convertirUnidad($("#conv-categoria").value, valor, $("#conv-de").value, $("#conv-a").value);
      $("#conv-resultado").textContent = `${formatoNumero(valor)} ${$("#conv-de").value} = ${formatoNumero(r)} ${$("#conv-a").value}`;
      errorEl.hidden = true;
    } catch (error) {
      if (!(error instanceof ErrorHerramienta)) throw error;
      $("#conv-resultado").textContent = "";
      errorEl.textContent = error.message;
      errorEl.hidden = false;
    }
  };

  $("#conv-categoria").addEventListener("change", () => {
    llenarUnidades();
    calcular();
  });
  ["#conv-valor", "#conv-de", "#conv-a"].forEach((id) => $(id).addEventListener("input", calcular));
  llenarUnidades();
  calcular();
}

/* ============================================================
   3) MASA MOLAR
   ============================================================ */
// Masas atómicas estándar (g/mol) de los elementos más usados en clase.
const MASAS_ATOMICAS = {
  H: 1.008, He: 4.0026, Li: 6.94, Be: 9.0122, B: 10.81, C: 12.011, N: 14.007, O: 15.999, F: 18.998,
  Ne: 20.18, Na: 22.99, Mg: 24.305, Al: 26.982, Si: 28.085, P: 30.974, S: 32.06, Cl: 35.45, Ar: 39.948,
  K: 39.098, Ca: 40.078, Cr: 51.996, Mn: 54.938, Fe: 55.845, Co: 58.933, Ni: 58.693, Cu: 63.546,
  Zn: 65.38, Br: 79.904, Ag: 107.87, Sn: 118.71, I: 126.9, Ba: 137.33, Au: 196.97, Hg: 200.59, Pb: 207.2,
};

// "Ca(OH)2" → { Ca: 1, O: 2, H: 2 }. Acepta paréntesis, corchetes y
// sales hidratadas con punto o "·" (CuSO4·5H2O).
function contarAtomos(formula) {
  const texto = String(formula ?? "").replace(/\s+/g, "");
  if (!texto) throw new ErrorHerramienta("Escribí una fórmula, por ejemplo H2SO4.");
  if (!/^[A-Za-z0-9()[\]·.]+$/.test(texto)) throw new ErrorHerramienta("La fórmula tiene un símbolo que no entiendo.");

  const total = {};
  for (const parte of texto.split(/[·.]/)) {
    if (!parte) throw new ErrorHerramienta("La fórmula está incompleta.");
    const coef = parte.match(/^(\d+)/);
    const cuerpo = coef ? parte.slice(coef[1].length) : parte;
    const conteo = contarGrupo(cuerpo);
    const k = coef ? parseInt(coef[1], 10) : 1;
    for (const [el, n] of Object.entries(conteo)) total[el] = (total[el] || 0) + n * k;
  }
  return total;
}

function contarGrupo(texto) {
  if (!texto) throw new ErrorHerramienta("La fórmula está incompleta.");
  let i = 0;

  function leerEntero() {
    const m = texto.slice(i).match(/^\d+/);
    if (!m) return 1;
    i += m[0].length;
    const n = parseInt(m[0], 10);
    if (n > 1000) throw new ErrorHerramienta("Ese subíndice es demasiado grande.");
    return n;
  }

  function grupo(cierre) {
    const conteo = {};
    const sumar = (otro, k) => Object.entries(otro).forEach(([el, n]) => (conteo[el] = (conteo[el] || 0) + n * k));

    while (i < texto.length) {
      const c = texto[i];
      if (c === "(" || c === "[") {
        i++;
        const interno = grupo(c === "(" ? ")" : "]");
        sumar(interno, leerEntero());
      } else if (c === ")" || c === "]") {
        if (c !== cierre) throw new ErrorHerramienta("Los paréntesis no coinciden.");
        i++;
        return conteo;
      } else if (/[A-Z]/.test(c)) {
        const m = texto.slice(i).match(/^[A-Z][a-z]?/)[0];
        // "Co" es cobalto, "CO" es carbono + oxígeno: se prueba primero con 2 letras.
        const simbolo = m.length === 2 && m in MASAS_ATOMICAS ? m : m[0];
        if (!(simbolo in MASAS_ATOMICAS)) throw new ErrorHerramienta(`No tengo el elemento "${simbolo}" en la tabla.`);
        i += simbolo.length;
        sumar({ [simbolo]: 1 }, leerEntero());
      } else {
        throw new ErrorHerramienta(`No esperaba "${c}" en la fórmula.`);
      }
    }
    if (cierre) throw new ErrorHerramienta("Falta cerrar un paréntesis.");
    return conteo;
  }
  return grupo(null);
}

function masaMolar(formula) {
  const atomos = contarAtomos(formula);
  let masa = 0;
  for (const [el, n] of Object.entries(atomos)) masa += MASAS_ATOMICAS[el] * n;
  return { masa, atomos };
}

function montarMasaMolar(contenedor) {
  contenedor.innerHTML = `
    <div class="form-group">
      <label class="form-label" for="mm-formula">Fórmula</label>
      <input id="mm-formula" class="form-input" type="text" autocomplete="off" spellcheck="false" value="H2SO4" placeholder="Ej: Ca(OH)2, CuSO4·5H2O" />
    </div>
    <div class="form-group">
      <label class="form-label" for="mm-gramos">Cantidad en gramos (opcional)</label>
      <input id="mm-gramos" class="form-input" type="text" inputmode="decimal" autocomplete="off" placeholder="Ej: 49" />
    </div>
    <p id="mm-resultado" class="herr-resultado" role="status" aria-live="polite"></p>
    <p id="mm-detalle" class="section-hint herr-nota"></p>
    <p id="mm-error" class="calc-error" hidden></p>`;

  const $ = (id) => contenedor.querySelector(id);
  const calcular = () => {
    try {
      const { masa, atomos } = masaMolar($("#mm-formula").value);
      $("#mm-resultado").textContent = `Masa molar: ${formatoNumero(masa, 5)} g/mol`;
      const gramos = leerNumero($("#mm-gramos").value);
      const partes = [Object.entries(atomos).map(([el, n]) => `${el}: ${n}`).join(" · ")];
      if (Number.isFinite(gramos) && gramos >= 0) partes.push(`${formatoNumero(gramos)} g = ${formatoNumero(gramos / masa, 5)} mol`);
      $("#mm-detalle").textContent = partes.join(" — ");
      $("#mm-error").hidden = true;
    } catch (error) {
      if (!(error instanceof ErrorHerramienta)) throw error;
      $("#mm-resultado").textContent = "";
      $("#mm-detalle").textContent = "";
      $("#mm-error").textContent = error.message;
      $("#mm-error").hidden = false;
    }
  };
  ["#mm-formula", "#mm-gramos"].forEach((id) => $(id).addEventListener("input", calcular));
  calcular();
}

/* ============================================================
   4) LEY DE OHM Y POTENCIA
   ============================================================ */
// Se completan dos de los cuatro valores y se calculan los otros.
function resolverOhm({ V, I, R, P }) {
  const datos = { V, I, R, P };
  const dados = Object.entries(datos).filter(([, v]) => v !== null && v !== undefined);
  if (dados.length !== 2) throw new ErrorHerramienta("Completá exactamente dos valores.");
  for (const [k, v] of dados) {
    if (!Number.isFinite(v) || v <= 0) throw new ErrorHerramienta(`${k} tiene que ser un número mayor que 0.`);
  }
  const tiene = (...ks) => ks.every((k) => datos[k] !== null && datos[k] !== undefined);

  if (tiene("V", "I")) return { V, I, R: V / I, P: V * I };
  if (tiene("V", "R")) return { V, I: V / R, R, P: (V * V) / R };
  if (tiene("I", "R")) return { V: I * R, I, R, P: I * I * R };
  if (tiene("V", "P")) return { V, I: P / V, R: (V * V) / P, P };
  if (tiene("I", "P")) return { V: P / I, I, R: P / (I * I), P };
  return { V: Math.sqrt(P * R), I: Math.sqrt(P / R), R, P }; // R y P
}

function montarOhm(contenedor) {
  const campos = [
    ["V", "Tensión V (volt)"],
    ["I", "Corriente I (ampere)"],
    ["R", "Resistencia R (ohm)"],
    ["P", "Potencia P (watt)"],
  ];
  contenedor.innerHTML = `
    <p class="section-hint herr-nota">Completá dos valores y se calculan los otros dos.</p>
    <div class="herr-fila herr-fila-2">
      ${campos
        .map(
          ([k, etiqueta]) => `<div class="form-group">
        <label class="form-label" for="ohm-${k}">${etiqueta}</label>
        <input id="ohm-${k}" class="form-input" type="text" inputmode="decimal" autocomplete="off" data-k="${k}" />
      </div>`
        )
        .join("")}
    </div>
    <div class="herr-botones">
      <button type="button" class="btn-primary" id="ohm-calcular">Calcular</button>
      <button type="button" class="btn-secondary" id="ohm-limpiar">Limpiar</button>
    </div>
    <p id="ohm-resultado" class="herr-resultado" role="status" aria-live="polite"></p>
    <p id="ohm-error" class="calc-error" hidden></p>`;

  const $ = (id) => contenedor.querySelector(id);
  const leer = () =>
    Object.fromEntries(
      campos.map(([k]) => {
        const texto = $(`#ohm-${k}`).value.trim();
        return [k, texto === "" ? null : leerNumero(texto)];
      })
    );

  $("#ohm-calcular").addEventListener("click", () => {
    try {
      const r = resolverOhm(leer());
      // Los valores vuelven a los campos en una forma que se puede reescribir y recalcular.
      campos.forEach(([k]) => ($(`#ohm-${k}`).value = String(parseFloat(r[k].toPrecision(6))).replace(".", ",")));
      $("#ohm-resultado").textContent = `V = ${formatoNumero(r.V)} V · I = ${formatoNumero(r.I)} A · R = ${formatoNumero(r.R)} Ω · P = ${formatoNumero(r.P)} W`;
      $("#ohm-error").hidden = true;
    } catch (error) {
      if (!(error instanceof ErrorHerramienta)) throw error;
      $("#ohm-resultado").textContent = "";
      $("#ohm-error").textContent = error.message;
      $("#ohm-error").hidden = false;
    }
  });
  $("#ohm-limpiar").addEventListener("click", () => {
    campos.forEach(([k]) => ($(`#ohm-${k}`).value = ""));
    $("#ohm-resultado").textContent = "";
    $("#ohm-error").hidden = true;
  });
}

/* ============================================================
   5) CÓDIGO DE COLORES DE RESISTENCIAS (4 bandas)
   ============================================================ */
const COLORES_RESISTENCIA = [
  { nombre: "Negro", hex: "#111111", digito: 0 },
  { nombre: "Marrón", hex: "#7B4A1E", digito: 1 },
  { nombre: "Rojo", hex: "#D62828", digito: 2 },
  { nombre: "Naranja", hex: "#F77F00", digito: 3 },
  { nombre: "Amarillo", hex: "#F2C500", digito: 4 },
  { nombre: "Verde", hex: "#2E9E44", digito: 5 },
  { nombre: "Azul", hex: "#1D4ED8", digito: 6 },
  { nombre: "Violeta", hex: "#7E3FBF", digito: 7 },
  { nombre: "Gris", hex: "#8A8F98", digito: 8 },
  { nombre: "Blanco", hex: "#F5F5F5", digito: 9 },
];
const MULTIPLICADORES_EXTRA = [
  { nombre: "Dorado", hex: "#C9A227", exp: -1 },
  { nombre: "Plateado", hex: "#B8BEC6", exp: -2 },
];
const TOLERANCIAS = [
  { nombre: "Marrón", hex: "#7B4A1E", valor: 1 },
  { nombre: "Rojo", hex: "#D62828", valor: 2 },
  { nombre: "Dorado", hex: "#C9A227", valor: 5 },
  { nombre: "Plateado", hex: "#B8BEC6", valor: 10 },
];

// b1 y b2: índices de COLORES (0-9). mult: 0-9 (potencia de 10), -1 (dorado) o -2 (plateado).
function valorResistencia(b1, b2, mult, tolerancia) {
  if (![b1, b2].every((d) => Number.isInteger(d) && d >= 0 && d <= 9)) throw new ErrorHerramienta("Banda no válida.");
  if (!Number.isInteger(mult) || mult < -2 || mult > 9) throw new ErrorHerramienta("Multiplicador no válido.");
  // Se redondea para evitar 4.7 × 0.1 = 0.47000000000000003
  const ohms = parseFloat(((b1 * 10 + b2) * Math.pow(10, mult)).toPrecision(12));
  return { ohms, tolerancia };
}

function textoResistencia(ohms) {
  if (ohms >= 1e6) return `${formatoNumero(ohms / 1e6, 4)} MΩ`;
  if (ohms >= 1e3) return `${formatoNumero(ohms / 1e3, 4)} kΩ`;
  return `${formatoNumero(ohms, 4)} Ω`;
}

function montarColores(contenedor) {
  const opcionesDigito = COLORES_RESISTENCIA.map((c, i) => `<option value="${i}">${c.nombre} (${c.digito})</option>`).join("");
  const opcionesMult =
    COLORES_RESISTENCIA.map((c, i) => `<option value="${i}">${c.nombre} (×10${superindice(i)})</option>`).join("") +
    MULTIPLICADORES_EXTRA.map((c) => `<option value="${c.exp}">${c.nombre} (×10${superindice(c.exp)})</option>`).join("");
  const opcionesTol = TOLERANCIAS.map((c, i) => `<option value="${i}">${c.nombre} (±${c.valor} %)</option>`).join("");

  contenedor.innerHTML = `
    <div class="herr-resistencia" aria-hidden="true">
      <span class="herr-cable"></span>
      <span class="herr-cuerpo">
        <i data-banda="1"></i><i data-banda="2"></i><i data-banda="3"></i><i class="herr-banda-sep"></i><i data-banda="4"></i>
      </span>
      <span class="herr-cable"></span>
    </div>
    <div class="herr-fila herr-fila-2">
      <div class="form-group"><label class="form-label" for="col-1">1.ª banda</label><select id="col-1" class="form-select">${opcionesDigito}</select></div>
      <div class="form-group"><label class="form-label" for="col-2">2.ª banda</label><select id="col-2" class="form-select">${opcionesDigito}</select></div>
      <div class="form-group"><label class="form-label" for="col-3">3.ª banda (multiplicador)</label><select id="col-3" class="form-select">${opcionesMult}</select></div>
      <div class="form-group"><label class="form-label" for="col-4">4.ª banda (tolerancia)</label><select id="col-4" class="form-select">${opcionesTol}</select></div>
    </div>
    <p id="col-resultado" class="herr-resultado" role="status" aria-live="polite"></p>`;

  const $ = (id) => contenedor.querySelector(id);
  const calcular = () => {
    const b1 = Number($("#col-1").value);
    const b2 = Number($("#col-2").value);
    const mult = Number($("#col-3").value);
    const tol = TOLERANCIAS[Number($("#col-4").value)];
    const { ohms } = valorResistencia(b1, b2, mult, tol.valor);
    $("#col-resultado").textContent = `${textoResistencia(ohms)} ±${tol.valor} %`;

    const multColor = mult >= 0 ? COLORES_RESISTENCIA[mult] : MULTIPLICADORES_EXTRA.find((c) => c.exp === mult);
    const colores = [COLORES_RESISTENCIA[b1], COLORES_RESISTENCIA[b2], multColor, tol];
    colores.forEach((c, i) => {
      contenedor.querySelector(`[data-banda="${i + 1}"]`).style.background = c.hex;
    });
  };
  ["#col-1", "#col-2", "#col-3", "#col-4"].forEach((id) => $(id).addEventListener("change", calcular));
  $("#col-1").value = "4"; // amarillo
  $("#col-2").value = "7"; // violeta
  $("#col-3").value = "2"; // rojo  → 4,7 kΩ
  $("#col-4").value = "2"; // dorado → ±5 %
  calcular();
}

/* ============================================================
   6) CONVERSOR DE BASES NUMÉRICAS
   ============================================================ */
const DIGITOS_BASE = "0123456789ABCDEF";

// Texto en una base (2, 8, 10 o 16) → BigInt. Solo enteros no negativos.
function leerEnBase(texto, base) {
  const limpio = String(texto ?? "").trim().replace(/[\s_]/g, "").toUpperCase();
  if (!limpio) throw new ErrorHerramienta("Escribí un número.");
  if (limpio.length > 64) throw new ErrorHerramienta("Ese número es demasiado largo.");
  let valor = 0n;
  const b = BigInt(base);
  for (const c of limpio) {
    const d = DIGITOS_BASE.indexOf(c);
    if (d < 0 || d >= base) throw new ErrorHerramienta(`"${c}" no es un dígito válido en base ${base}.`);
    valor = valor * b + BigInt(d);
  }
  return valor;
}

function agruparBinario(bin) {
  return bin.replace(/\B(?=(\d{4})+(?!\d))/g, " ");
}

function convertirBases(texto, base) {
  const n = leerEnBase(texto, base);
  return { binario: agruparBinario(n.toString(2)), octal: n.toString(8), decimal: n.toString(10), hexadecimal: n.toString(16).toUpperCase() };
}

function montarBases(contenedor) {
  contenedor.innerHTML = `
    <div class="herr-fila">
      <div class="form-group">
        <label class="form-label" for="base-valor">Número</label>
        <input id="base-valor" class="form-input" type="text" autocomplete="off" spellcheck="false" value="255" />
      </div>
      <div class="form-group">
        <label class="form-label" for="base-origen">Está en base</label>
        <select id="base-origen" class="form-select">
          <option value="10">Decimal (10)</option><option value="2">Binario (2)</option>
          <option value="8">Octal (8)</option><option value="16">Hexadecimal (16)</option>
        </select>
      </div>
    </div>
    <dl class="herr-resultados" id="base-resultados"></dl>
    <p id="base-error" class="calc-error" hidden></p>`;

  const $ = (id) => contenedor.querySelector(id);
  const calcular = () => {
    try {
      const r = convertirBases($("#base-valor").value, Number($("#base-origen").value));
      $("#base-resultados").innerHTML = [
        ["Binario", r.binario],
        ["Octal", r.octal],
        ["Decimal", r.decimal],
        ["Hexadecimal", r.hexadecimal],
      ]
        .map(([nombre, valor]) => `<div><dt>${nombre}</dt><dd>${escaparHerr(valor)}</dd></div>`)
        .join("");
      $("#base-error").hidden = true;
    } catch (error) {
      if (!(error instanceof ErrorHerramienta)) throw error;
      $("#base-resultados").innerHTML = "";
      $("#base-error").textContent = error.message;
      $("#base-error").hidden = false;
    }
  };
  ["#base-valor", "#base-origen"].forEach((id) => $(id).addEventListener("input", calcular));
  calcular();
}

/* ------------------------------------------------------------
   CATÁLOGO: lo que usa espacios.js para dibujar cada herramienta
   ------------------------------------------------------------ */
const HERRAMIENTAS = {
  calculadora: {
    titulo: "Calculadora científica",
    ayuda: "Trigonometría, logaritmos, potencias y notación científica. Escribí con el teclado o tocá los botones.",
    icono: "calculadora",
    montar: (el) => montarCalculadora(el),
  },
  constantes: {
    titulo: "Constantes físicas",
    ayuda: "Las que más se usan en Física, listas para pasar a la calculadora.",
    icono: "libro",
    montar: montarConstantes,
  },
  conversor: {
    titulo: "Conversor de unidades",
    ayuda: "Longitud, masa, tiempo, velocidad, fuerza, presión, energía y temperatura.",
    icono: "calculadora",
    montar: montarConversor,
  },
  masamolar: {
    titulo: "Masa molar",
    ayuda: "Escribí una fórmula y obtenés su masa molar. Si ponés los gramos, también los moles.",
    icono: "calculadora",
    montar: montarMasaMolar,
  },
  ohm: {
    titulo: "Ley de Ohm y potencia",
    ayuda: "V = I · R y P = V · I.",
    icono: "calculadora",
    montar: montarOhm,
  },
  colores: {
    titulo: "Código de colores de resistencias",
    ayuda: "Elegí los colores de las bandas y mirá el valor.",
    icono: "calculadora",
    montar: montarColores,
  },
  bases: {
    titulo: "Binario, octal y hexadecimal",
    ayuda: "Pasá un número entero entre bases.",
    icono: "calculadora",
    montar: montarBases,
  },
};

// Para probar las funciones puras desde Node; en el navegador no hace nada.
if (typeof module !== "undefined") {
  module.exports = {
    convertirUnidad, masaMolar, contarAtomos, resolverOhm, valorResistencia, textoResistencia,
    convertirBases, leerEnBase, leerNumero, formatoNumero, ErrorHerramienta, CONSTANTES_FISICAS,
    entradaConstante, textoConstante,
  };
}
