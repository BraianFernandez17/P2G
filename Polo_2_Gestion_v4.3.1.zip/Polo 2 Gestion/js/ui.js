/* ============================================================
   UI COMPARTIDA: TOASTS Y MODAL DE CONFIRMACIÓN
   Reemplazan a alert()/confirm() nativos por algo con la misma
   identidad visual del resto de la app. Vive en su propio archivo
   (en vez de repetirse en reservas.js, script.js y empresa.js)
   porque lo usan los tres: dashboard de estudiante, empresa,
   profesor y admin, más la agenda pública.

   Se inyectan una sola vez en el <body> la primera vez que hacen
   falta, así no hay que tocar cada HTML para tenerlos disponibles;
   con cargar este script alcanza.
   ============================================================ */
function asegurarContenedoresUI() {
  if (!document.getElementById("toast-container")) {
    const cont = document.createElement("div");
    cont.id = "toast-container";
    cont.className = "toast-container";
    document.body.appendChild(cont);
  }

  if (!document.getElementById("modal-overlay")) {
    const overlay = document.createElement("div");
    overlay.id = "modal-overlay";
    overlay.className = "modal-overlay";
    overlay.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <p id="modal-titulo" class="modal-title"></p>
        <p id="modal-texto" class="modal-text"></p>
        <!-- Ranura para contenido propio (formularios de "Editar perfil"
             y "Configuración"). Queda vacía en las confirmaciones
             normales, que solo usan #modal-texto. -->
        <div id="modal-cuerpo" class="modal-body"></div>
        <div class="modal-actions">
          <button id="modal-cancelar" type="button" class="btn-secondary">Cancelar</button>
          <button id="modal-confirmar" type="button" class="btn-primary">Confirmar</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (evento) => {
      if (evento.target === overlay) cerrarModal();
    });
  }
}

/* ============================================================
   PREFERENCIAS DE LA PERSONA
   Lo que se elige en "Configuración" (menú de perfil) se guarda
   acá, en localStorage, y lo respetan de verdad el resto de las
   funciones: si alguien apaga los avisos emergentes, mostrarToast
   no muestra nada; si apaga las confirmaciones, pedirConfirmacion
   ejecuta la acción derecho.

   En la versión con backend esto viviría en la tabla users (o en
   una tabla user_preferences), no en el navegador.
   ============================================================ */
const CLAVE_PREFERENCIAS = "poloTecPreferencias";

const PREFERENCIAS_POR_DEFECTO = {
  avisos: true, // mostrar los avisos emergentes (toasts)
  confirmaciones: true, // pedir confirmación antes de acciones importantes
  vistaAgenda: "tabla", // vista inicial de la agenda pública: "tabla" o "dia"
  asistente: true, // mostrar el asistente de voz en el borde derecho
  vozAsistente: true, // que el asistente además de escribir, hable
  aplausos: false, // abrir el asistente en grande con dos aplausos (pide el micrófono)
  tema: "auto", // modo oscuro, claro, o automático del sistema
  sonidos: true, // click al tocar botones y sonido de los avisos (js/sonidos.js)
  estiloSonido: "calido", // "calido" (como el reel), "suave", "burbuja", "mecanico" o "retro"
  volumenSonido: 60, // de 0 a 100
};

function aplicarTemaVisual(tema) {
  if (tema === "oscuro") {
    document.documentElement.setAttribute("data-tema", "oscuro");
  } else if (tema === "claro") {
    document.documentElement.setAttribute("data-tema", "claro");
  } else {
    document.documentElement.removeAttribute("data-tema");
  }
}

// Aplica el tema apenas se carga el script
aplicarTemaVisual(obtenerPreferencias().tema);

function obtenerPreferencias() {
  try {
    const guardadas = JSON.parse(localStorage.getItem(CLAVE_PREFERENCIAS));
    // Mezclamos con las de por defecto: si mañana se agrega una
    // preferencia nueva, las que ya estaban guardadas no rompen.
    return { ...PREFERENCIAS_POR_DEFECTO, ...(guardadas || {}) };
  } catch {
    return { ...PREFERENCIAS_POR_DEFECTO };
  }
}

function guardarPreferencias(preferencias) {
  localStorage.setItem(CLAVE_PREFERENCIAS, JSON.stringify(preferencias));
}

function mostrarToast(mensaje, tipo = "success") {
  // Si la persona apagó los avisos en Configuración, no molestamos.
  if (!obtenerPreferencias().avisos) return;

  asegurarContenedoresUI();
  const contenedor = document.getElementById("toast-container");

  const toast = document.createElement("div");
  toast.className = `toast toast-${tipo}`;
  const icono = { success: "✓", error: "✕", info: "i" }[tipo] || "✓";
  toast.innerHTML = `<span class="toast-icon">${icono}</span><span>${mensaje}</span>`;
  contenedor.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("toast-saliendo");
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

function cerrarModal() {
  const overlay = document.getElementById("modal-overlay");
  if (overlay) overlay.classList.remove("visible");
}

/* ------------------------------------------------------------
   MODAL GENÉRICO
   Es la base de todo lo demás: las confirmaciones de siempre y
   también los formularios de "Editar perfil" y "Configuración",
   que en vez de un texto le pasan HTML propio en cuerpoHTML.

   alConfirmar recibe el elemento del cuerpo, así quien abrió el
   modal puede leer los valores de sus propios campos. Si devuelve
   false, el modal NO se cierra (sirve para avisar de un campo mal
   completado sin perder lo que la persona venía escribiendo).
   ------------------------------------------------------------ */
function abrirModal({
  titulo,
  texto = "",
  cuerpoHTML = "",
  alConfirmar = null,
  textoConfirmar = "Confirmar",
  textoCancelar = "Cancelar",
  amplio = false, // perfiles y editores: el modal se ensancha
}) {
  asegurarContenedoresUI();
  const overlay = document.getElementById("modal-overlay");
  overlay.querySelector(".modal").classList.toggle("modal-amplio", amplio);
  document.getElementById("modal-titulo").textContent = titulo;

  const textoEl = document.getElementById("modal-texto");
  textoEl.textContent = texto;
  textoEl.style.display = texto ? "" : "none";

  const cuerpoEl = document.getElementById("modal-cuerpo");
  cuerpoEl.innerHTML = cuerpoHTML;
  cuerpoEl.style.display = cuerpoHTML ? "" : "none";

  overlay.classList.add("visible");

  // Clonamos los botones antes de engancharlos para no ir
  // acumulando listeners de aperturas anteriores.
  const btnConfirmar = document.getElementById("modal-confirmar");
  const btnCancelar = document.getElementById("modal-cancelar");
  const nuevoConfirmar = btnConfirmar.cloneNode(true);
  btnConfirmar.replaceWith(nuevoConfirmar);
  const nuevoCancelar = btnCancelar.cloneNode(true);
  btnCancelar.replaceWith(nuevoCancelar);

  // textoConfirmar = null: modal de solo lectura (las acciones van
  // adentro del cuerpo, como en la ficha de un postulante).
  nuevoConfirmar.style.display = textoConfirmar === null ? "none" : "";
  nuevoConfirmar.textContent = textoConfirmar || "";
  if (textoCancelar === null) {
    nuevoCancelar.style.display = "none";
  } else {
    nuevoCancelar.style.display = "";
    nuevoCancelar.textContent = textoCancelar;
  }

  nuevoConfirmar.addEventListener("click", () => {
    if (alConfirmar && alConfirmar(cuerpoEl) === false) return;
    cerrarModal();
  });
  nuevoCancelar.addEventListener("click", cerrarModal);

  // Enter confirma y Escape cancela, como en cualquier diálogo.
  // (Los campos con data-sin-enter usan Enter para otra cosa, como
  // sumar una capacidad en el editor de perfil.)
  cuerpoEl.querySelectorAll("input:not([data-sin-enter])").forEach((campo) => {
    campo.addEventListener("keydown", (evento) => {
      if (evento.key === "Enter") {
        evento.preventDefault();
        nuevoConfirmar.click();
      }
    });
  });
}

// alConfirmar corre solo si la persona toca el botón de confirmar.
// textoConfirmar/textoCancelar dejan reusar el mismo modal tanto
// para confirmaciones destructivas ("Rechazar" / "Cancelar") como
// para diálogos informativos con una acción ("Postularme", "Ver
// postulantes"...), sin tener que escribir un modal por pantalla.
// Si se pasa textoCancelar = null, el botón de cancelar se oculta
// (para diálogos de solo información con un único botón de cierre).
function pedirConfirmacion(titulo, texto, alConfirmar, textoConfirmar = "Confirmar", textoCancelar = "Cancelar") {
  // Si la persona apagó las confirmaciones en Configuración, la
  // acción se ejecuta derecho. Ojo: solo vale para los diálogos
  // que SÍ tienen una acción detrás; los informativos (sin
  // alConfirmar) se muestran igual, porque son la respuesta misma.
  if (alConfirmar && !obtenerPreferencias().confirmaciones) {
    alConfirmar();
    return;
  }

  abrirModal({ titulo, texto, alConfirmar, textoConfirmar, textoCancelar });
}

// Escape cierra el modal desde cualquier parte de la página.
document.addEventListener("keydown", (evento) => {
  if (evento.key === "Escape") cerrarModal();
});
