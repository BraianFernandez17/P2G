/* ============================================================
   SONIDOS AL TOCAR
   Cada botón suena al apretarlo, como en las interfaces "que se
   sienten": un click corto y suave, distinto según lo que hace.

     clic       botones y links
     seleccion  pestañas, filtros y chips (más liviano)
     tecla      teclas de la calculadora (cambia un poco cada una)
     peligro    rechazar, cancelar, quitar (un tono más grave)
     encender / apagar   interruptores y casillas
     exito / error       cuando algo se guarda o falla (los avisos)
     abrir / cerrar      ventanas (modales)

   No hay archivos de audio: todo se sintetiza en el momento con
   Web Audio (osciladores + ruido filtrado). Así pesa 0 KB, suena
   al instante y anda sin internet.

   Estilos (Configuración → Estilo de sonido):
     calido (el de por defecto) · suave · burbuja · mecanico · retro

   "Cálido" está calcado del reel que pasó el equipo (el de la
   portada de seguros marítimos): cada click son DOS notas muy cortas
   y sin brillo, una grave (~550 Hz, 4 ms) y 28 ms después una más
   aguda y más fuerte (~790 Hz, 15 ms) con un poco de cuerpo abajo
   (~210 Hz). Casi nada arriba de 3 kHz: por eso suena "tu-tík",
   redondo, y no como un chasquido. Al cambiar el tema, en el video
   el par va al revés (agudo y después grave): de ahí "apagar".
   Se puede apagar y bajar el volumen en Configuración.

   Ojo con los aplausos: el oído de js/aplausos.js escucha el
   micrófono, y un click por los parlantes es un golpe corto, como
   un aplauso. Cada vez que suena algo, el oído se tapa un instante.
   ============================================================ */

const ESTILOS_DE_SONIDO = {
  calido: "Cálido",
  suave: "Suave",
  burbuja: "Burbuja",
  mecanico: "Mecánico",
  retro: "Retro",
};

const sonido = {
  ctx: null,
  salida: null, // volumen general
  ruido: null, // un buffer de ruido blanco reutilizable
  ultimoPorElemento: new WeakMap(),
};

/* ------------------------------------------------------------
   PREFERENCIAS (las guarda js/ui.js con el resto)
   ------------------------------------------------------------ */
function preferenciasDeSonido() {
  const p = typeof obtenerPreferencias === "function" ? obtenerPreferencias() : {};
  return {
    activo: p.sonidos !== false,
    estilo: ESTILOS_DE_SONIDO[p.estiloSonido] ? p.estiloSonido : "calido",
    volumen: Number.isFinite(Number(p.volumenSonido)) ? Math.min(100, Math.max(0, Number(p.volumenSonido))) : 60,
  };
}

/* ------------------------------------------------------------
   MOTOR DE AUDIO
   El AudioContext se crea con el primer toque de la persona: los
   navegadores no dejan sonar nada antes de una interacción.
   ------------------------------------------------------------ */
function motorDeSonido() {
  if (sonido.ctx) {
    if (sonido.ctx.state === "suspended") sonido.ctx.resume().catch(() => {});
    return sonido.ctx;
  }
  const Contexto = window.AudioContext || window.webkitAudioContext;
  if (!Contexto) return null;
  try {
    const ctx = new Contexto({ latencyHint: "interactive" });
    const compresor = ctx.createDynamicsCompressor();
    compresor.threshold.value = -14;
    compresor.ratio.value = 4;
    compresor.attack.value = 0.001;
    compresor.release.value = 0.08;
    const salida = ctx.createGain();
    salida.connect(compresor).connect(ctx.destination);

    const largo = Math.floor(ctx.sampleRate * 0.5);
    const ruido = ctx.createBuffer(1, largo, ctx.sampleRate);
    const datos = ruido.getChannelData(0);
    for (let i = 0; i < largo; i++) datos[i] = Math.random() * 2 - 1;

    Object.assign(sonido, { ctx, salida, ruido });
    return ctx;
  } catch {
    return null;
  }
}

// Un tono con envolvente: sube en "ataque" y se apaga en "decae".
// frecFin hace un barrido (el "pop" de la burbuja, el "tock" suave).
function tono(t, { tipo = "sine", frec, frecFin = null, barrido = 0.04, ataque = 0.002, decae = 0.06, gan = 0.4, filtro = null }) {
  const { ctx, salida } = sonido;
  const osc = ctx.createOscillator();
  osc.type = tipo;
  osc.frequency.setValueAtTime(frec, t);
  if (frecFin) osc.frequency.exponentialRampToValueAtTime(frecFin, t + barrido);

  const env = ctx.createGain();
  env.gain.setValueAtTime(0.0001, t);
  env.gain.linearRampToValueAtTime(gan, t + ataque);
  env.gain.exponentialRampToValueAtTime(0.0001, t + ataque + decae);

  let ultimo = osc;
  if (filtro) {
    const f = ctx.createBiquadFilter();
    f.type = filtro.tipo;
    f.frequency.value = filtro.frec;
    if (filtro.q) f.Q.value = filtro.q;
    ultimo.connect(f);
    ultimo = f;
  }
  ultimo.connect(env).connect(salida);
  osc.start(t);
  osc.stop(t + ataque + decae + 0.03);
}

// Ruido filtrado: el "tic" del borde de un botón, el aire de un whoosh.
function chasquido(t, { dur = 0.012, tipo = "bandpass", frec = 3000, frecFin = null, q = 1, gan = 0.2, ataque = 0.001 }) {
  const { ctx, salida, ruido } = sonido;
  const fuente = ctx.createBufferSource();
  fuente.buffer = ruido;
  const f = ctx.createBiquadFilter();
  f.type = tipo;
  f.frequency.setValueAtTime(frec, t);
  if (frecFin) f.frequency.exponentialRampToValueAtTime(frecFin, t + dur);
  f.Q.value = q;
  const env = ctx.createGain();
  env.gain.setValueAtTime(0.0001, t);
  env.gain.linearRampToValueAtTime(gan, t + ataque);
  env.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(dur, ataque + 0.004));
  fuente.connect(f).connect(env).connect(salida);
  // Arranca en un punto al azar del buffer: cada click es apenas distinto.
  fuente.start(t, Math.random() * 0.4, dur + 0.03);
}

/* ------------------------------------------------------------
   LOS SONIDOS DE CADA ESTILO
   v: variación chica de afinación (±4 %) para que diez clicks
   seguidos no suenen a máquina.
   ------------------------------------------------------------ */
const NOTAS_TECLA = [523.25, 587.33, 659.25, 783.99, 880, 1046.5]; // pentatónica de do

// Una nota "de madera": sube casi de golpe y se apaga en milisegundos.
function nota(t, frec, { decae = 0.012, gan = 0.4, ataque = 0.0008 } = {}) {
  tono(t, { frec, ataque, decae, gan });
  // un armónico chiquito le da color sin agregar brillo
  tono(t, { frec: frec * 2.01, ataque, decae: decae * 0.5, gan: gan * 0.12 });
  // y el roce del arranque: apenas audible, como en el video (-30 dB arriba de 3 kHz)
  chasquido(t, { dur: 0.005, frec: 4200, q: 0.7, gan: gan * 0.16 });
}

const SONIDOS = {
  calido: {
    clic: (t, v) => {
      nota(t, 550 * v, { decae: 0.04, gan: 0.75 });
      nota(t + 0.028, 790 * v, { decae: 0.06, gan: 0.55 });
      tono(t + 0.028, { frec: 190 * v, ataque: 0.001, decae: 0.05, gan: 0.2 });
    },
    seleccion: (t, v) => {
      nota(t, 790 * v, { decae: 0.03, gan: 0.36 });
      tono(t, { frec: 230 * v, ataque: 0.001, decae: 0.02, gan: 0.06 });
    },
    tecla: (t, v) => {
      const nota1 = NOTAS_TECLA[Math.floor(Math.random() * NOTAS_TECLA.length)] * 0.85;
      nota(t, nota1 * 0.75 * v, { decae: 0.016, gan: 0.26 });
      nota(t + 0.02, nota1 * v, { decae: 0.03, gan: 0.42 });
    },
    peligro: (t, v) => {
      nota(t, 790 * v, { decae: 0.03, gan: 0.45 });
      nota(t + 0.05, 530 * v, { decae: 0.045, gan: 0.42 });
      tono(t + 0.05, { frec: 180 * v, ataque: 0.001, decae: 0.03, gan: 0.1 });
    },
    encender: (t, v) => {
      nota(t, 550 * v, { decae: 0.026, gan: 0.36 });
      nota(t + 0.05, 1030 * v, { decae: 0.045, gan: 0.46 });
    },
    apagar: (t, v) => {
      nota(t, 1030 * v, { decae: 0.035, gan: 0.42 });
      nota(t + 0.08, 530 * v, { decae: 0.05, gan: 0.42 });
    },
  },
  suave: {
    clic: (t, v) => {
      tono(t, { frec: 700 * v, frecFin: 320 * v, barrido: 0.045, decae: 0.06, gan: 0.5 });
      chasquido(t, { dur: 0.012, frec: 3400, q: 1.2, gan: 0.16 });
    },
    seleccion: (t, v) => {
      tono(t, { frec: 1050 * v, frecFin: 760 * v, barrido: 0.03, decae: 0.04, gan: 0.3 });
      chasquido(t, { dur: 0.008, frec: 4800, q: 1.5, gan: 0.1 });
    },
    tecla: (t, v) => {
      tono(t, { tipo: "triangle", frec: 560 * v, frecFin: 430 * v, barrido: 0.03, decae: 0.05, gan: 0.34 });
      chasquido(t, { dur: 0.006, tipo: "highpass", frec: 2600, gan: 0.12 });
    },
    peligro: (t, v) => {
      tono(t, { frec: 420 * v, frecFin: 210 * v, barrido: 0.06, decae: 0.08, gan: 0.5 });
      chasquido(t, { dur: 0.012, frec: 2200, q: 1, gan: 0.14 });
    },
  },
  burbuja: {
    clic: (t, v) => tono(t, { frec: 260 * v, frecFin: 860 * v, barrido: 0.05, ataque: 0.003, decae: 0.07, gan: 0.55 }),
    seleccion: (t, v) => tono(t, { frec: 420 * v, frecFin: 1180 * v, barrido: 0.035, ataque: 0.002, decae: 0.05, gan: 0.42 }),
    tecla: (t, v) => {
      const nota = NOTAS_TECLA[Math.floor(Math.random() * NOTAS_TECLA.length)];
      tono(t, { frec: nota * 0.5, frecFin: nota, barrido: 0.04, ataque: 0.002, decae: 0.06, gan: 0.45 });
    },
    peligro: (t, v) => tono(t, { frec: 640 * v, frecFin: 220 * v, barrido: 0.07, ataque: 0.003, decae: 0.08, gan: 0.5 }),
  },
  mecanico: {
    // Apretar y soltar una tecla de teclado mecánico: "tic-tac".
    clic: (t, v) => {
      chasquido(t, { dur: 0.004, tipo: "highpass", frec: 5200, gan: 0.28 });
      chasquido(t, { dur: 0.03, tipo: "lowpass", frec: 1900 * v, q: 0.8, gan: 0.53 });
      tono(t, { frec: 150 * v, frecFin: 90, barrido: 0.04, decae: 0.05, gan: 0.38 });
      chasquido(t + 0.06, { dur: 0.02, tipo: "lowpass", frec: 2600 * v, q: 0.8, gan: 0.25 });
    },
    seleccion: (t, v) => {
      chasquido(t, { dur: 0.003, tipo: "highpass", frec: 6000, gan: 0.22 });
      chasquido(t, { dur: 0.018, tipo: "lowpass", frec: 2600 * v, q: 0.8, gan: 0.38 });
    },
    tecla: (t, v) => {
      chasquido(t, { dur: 0.004, tipo: "highpass", frec: 5000, gan: 0.25 });
      chasquido(t, { dur: 0.026, tipo: "lowpass", frec: 1700 * v, q: 0.9, gan: 0.5 });
      tono(t, { frec: 170 * v, frecFin: 100, barrido: 0.03, decae: 0.04, gan: 0.33 });
    },
    peligro: (t, v) => {
      chasquido(t, { dur: 0.04, tipo: "lowpass", frec: 1200 * v, q: 0.8, gan: 0.56 });
      tono(t, { frec: 110 * v, frecFin: 70, barrido: 0.05, decae: 0.07, gan: 0.43 });
    },
  },
  retro: {
    clic: (t, v) => {
      const filtro = { tipo: "lowpass", frec: 4200 };
      tono(t, { tipo: "square", frec: 880 * v, decae: 0.03, gan: 0.36, filtro });
      tono(t + 0.03, { tipo: "square", frec: 1320 * v, decae: 0.04, gan: 0.31, filtro });
    },
    seleccion: (t, v) => tono(t, { tipo: "square", frec: 1320 * v, decae: 0.035, gan: 0.29, filtro: { tipo: "lowpass", frec: 4200 } }),
    tecla: (t) => {
      const nota = NOTAS_TECLA[Math.floor(Math.random() * NOTAS_TECLA.length)];
      tono(t, { tipo: "square", frec: nota, decae: 0.05, gan: 0.31, filtro: { tipo: "lowpass", frec: 4000 } });
    },
    peligro: (t, v) => {
      const filtro = { tipo: "lowpass", frec: 3000 };
      tono(t, { tipo: "square", frec: 440 * v, decae: 0.04, gan: 0.34, filtro });
      tono(t + 0.045, { tipo: "square", frec: 294 * v, decae: 0.06, gan: 0.34, filtro });
    },
  },
};

// Los que son iguales en todos los estilos (avisos y ventanas),
// apenas teñidos según el estilo elegido.
const SONIDOS_COMUNES = {
  encender: (t, v, estilo) => {
    const tipo = estilo === "retro" ? "square" : "sine";
    const g = estilo === "retro" ? 0.26 : 0.3;
    tono(t, { tipo, frec: 660, decae: 0.06, gan: g });
    tono(t + 0.06, { tipo, frec: 990, decae: 0.08, gan: g });
  },
  apagar: (t, v, estilo) => {
    const tipo = estilo === "retro" ? "square" : "sine";
    const g = estilo === "retro" ? 0.26 : 0.28;
    tono(t, { tipo, frec: 990, decae: 0.06, gan: g });
    tono(t + 0.06, { tipo, frec: 620, decae: 0.08, gan: g });
  },
  exito: (t, v, estilo) => {
    const tipo = estilo === "retro" ? "square" : "sine";
    const g = estilo === "retro" ? 0.22 : 0.26;
    tono(t, { tipo, frec: 659.25, ataque: 0.005, decae: 0.22, gan: g }); // mi
    tono(t + 0.09, { tipo, frec: 987.77, ataque: 0.005, decae: 0.32, gan: g }); // si
    if (estilo !== "retro") tono(t + 0.09, { tipo: "triangle", frec: 493.88, ataque: 0.01, decae: 0.3, gan: 0.07 });
  },
  error: (t, v, estilo) => {
    const tipo = estilo === "retro" ? "square" : "triangle";
    const g = estilo === "retro" ? 0.26 : 0.3;
    const filtro = { tipo: "lowpass", frec: 1400 };
    tono(t, { tipo, frec: 330, ataque: 0.004, decae: 0.13, gan: g, filtro });
    tono(t + 0.11, { tipo, frec: 233, ataque: 0.004, decae: 0.2, gan: g, filtro });
  },
  abrir: (t) => chasquido(t, { dur: 0.16, frec: 700, frecFin: 2600, q: 1.4, gan: 0.07, ataque: 0.05 }),
  cerrar: (t) => chasquido(t, { dur: 0.13, frec: 2400, frecFin: 700, q: 1.4, gan: 0.055, ataque: 0.03 }),
};

/* ------------------------------------------------------------
   REPRODUCIR
   ------------------------------------------------------------ */
function reproducirSonido(nombre, { estilo = null, volumen = null, forzar = false } = {}) {
  const prefs = preferenciasDeSonido();
  if (!prefs.activo && !forzar) return;
  const vol = volumen ?? prefs.volumen;
  if (vol <= 0) return;
  const ctx = motorDeSonido();
  if (!ctx || !sonido.salida) return;

  const est = estilo || prefs.estilo;
  const generar = (SONIDOS[est] && SONIDOS[est][nombre]) || SONIDOS_COMUNES[nombre] || SONIDOS[est].clic;
  // Curva de volumen "de oído": el 50 % se escucha a la mitad.
  sonido.salida.gain.setValueAtTime(Math.pow(vol / 100, 2) * 0.9, ctx.currentTime);
  const variacion = 1 + (Math.random() * 0.08 - 0.04);
  try {
    generar(ctx.currentTime + 0.005, variacion, est);
  } catch {
    // un navegador sin algún nodo de audio: mejor callados que con error
  }
  taparOidoDeAplausos();
}

function taparOidoDeAplausos() {
  // El click sale por los parlantes y el micrófono lo escucha: que no
  // cuente como aplauso, ni como la primera mitad de un par.
  if (typeof oido !== "undefined" && oido) {
    oido.enfriarHasta = Math.max(oido.enfriarHasta || 0, performance.now() + 450);
    oido.ultimoAplauso = 0;
  }
}

/* ------------------------------------------------------------
   QUÉ SONIDO VA CON CADA ELEMENTO
   ------------------------------------------------------------ */
const SELECTOR_SONORO = [
  "button", "a[href]", "[role='button']", "[role='tab']", "summary", "select",
  "label.cv-subir", ".hub-option",
].join(",");

function sonidoPara(el) {
  if (el.matches(".calc-tecla")) return el.classList.contains("calc-tecla-accion") ? "seleccion" : "tecla";
  if (el.matches("[role='tab'], .tab, .filter-chip, .view-toggle-btn, .cal-day, .chips-ejemplo button")) return "seleccion";
  if (el.matches(".btn-reject, .editor-quitar, [data-quitar], [data-quitar-chip], .btn-peligro")) return "peligro";
  return "clic";
}

function elementoSonoro(objetivo) {
  const el = objetivo && objetivo.closest ? objetivo.closest(SELECTOR_SONORO) : null;
  if (!el) return null;
  if (el.disabled || el.getAttribute("aria-disabled") === "true" || el.closest("[inert]")) return null;
  // Las casillas y los interruptores suenan al cambiar (ver "change").
  if (el.matches("label") && el.querySelector("input[type=checkbox], input[type=radio]") && !el.matches(".cv-subir")) return null;
  return el;
}

function sonarElemento(el) {
  const ahora = performance.now();
  // pointerdown y click llegan los dos: que suene una sola vez.
  if (ahora - (sonido.ultimoPorElemento.get(el) || 0) < 450) return;
  sonido.ultimoPorElemento.set(el, ahora);
  reproducirSonido(sonidoPara(el));
}

// Mouse y lápiz: suena al APRETAR (se siente inmediato).
document.addEventListener(
  "pointerdown",
  (evento) => {
    if (evento.pointerType === "touch" || evento.button > 0) return;
    const el = elementoSonoro(evento.target);
    if (el) sonarElemento(el);
  },
  { capture: true, passive: true }
);

// Dedo: al soltar (si suena al apoyar, también sonaría al hacer
// scroll). Teclado (Enter / Espacio): el click llega con detail 0.
document.addEventListener(
  "click",
  (evento) => {
    const el = elementoSonoro(evento.target);
    if (el) sonarElemento(el);
  },
  { capture: true }
);

// Casillas e interruptores: "encender" o "apagar" según quedó.
document.addEventListener(
  "change",
  (evento) => {
    const el = evento.target;
    if (!el.matches || !el.matches("input[type=checkbox], input[type=radio]")) return;
    // La casilla de "Sonidos al tocar" se prueba a sí misma (abajo).
    if (el.id === "pref-sonidos") return;
    reproducirSonido(el.checked ? "encender" : "apagar");
  },
  true
);

/* ------------------------------------------------------------
   AVISOS Y VENTANAS
   mostrarToast, abrirModal y cerrarModal son de js/ui.js; acá se
   envuelven para que suenen, sin tocar las que ya existen.
   ------------------------------------------------------------ */
function envolverFuncionesDeUI() {
  if (typeof window.mostrarToast === "function" && !window.mostrarToast.conSonido) {
    const original = window.mostrarToast;
    window.mostrarToast = function (mensaje, tipo = "success") {
      if (tipo === "success") reproducirSonido("exito");
      else if (tipo === "error") reproducirSonido("error");
      return original.apply(this, arguments);
    };
    window.mostrarToast.conSonido = true;
  }
  if (typeof window.abrirModal === "function" && !window.abrirModal.conSonido) {
    const original = window.abrirModal;
    window.abrirModal = function () {
      const yaAbierto = document.querySelector("#modal-overlay.visible");
      const resultado = original.apply(this, arguments);
      if (!yaAbierto) setTimeout(() => reproducirSonido("abrir"), 25);
      return resultado;
    };
    window.abrirModal.conSonido = true;
  }
  if (typeof window.cerrarModal === "function" && !window.cerrarModal.conSonido) {
    const original = window.cerrarModal;
    window.cerrarModal = function () {
      const estabaAbierto = document.querySelector("#modal-overlay.visible");
      const resultado = original.apply(this, arguments);
      if (estabaAbierto) reproducirSonido("cerrar");
      return resultado;
    };
    window.cerrarModal.conSonido = true;
  }
}
envolverFuncionesDeUI();

/* ------------------------------------------------------------
   PARA CONFIGURACIÓN (js/perfil.js): probar un estilo y volumen
   antes de guardarlos.
   ------------------------------------------------------------ */
window.sonidosPolo = {
  estilos: ESTILOS_DE_SONIDO,
  reproducir: reproducirSonido,
  probar(estilo, volumen) {
    reproducirSonido("clic", { estilo, volumen, forzar: true });
    setTimeout(() => reproducirSonido("seleccion", { estilo, volumen, forzar: true }), 180);
    setTimeout(() => reproducirSonido("exito", { estilo, volumen, forzar: true }), 400);
  },
};
