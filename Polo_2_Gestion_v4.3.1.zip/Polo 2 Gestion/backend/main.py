"""
Polo 2 Gestión · API
====================

Backend en FastAPI sobre la base de db/schema.sql. Casi toda la lógica
vive en la base (funciones fn_*, triggers y vistas v_*): acá solo se
autentica, se valida la forma de lo que llega y se traducen los errores
de PostgreSQL a respuestas HTTP con el mismo mensaje en castellano que
escribió la base.

Cómo correrlo (con la base ya levantada, ver README):

    cd backend
    pip install -r requirements.txt
    python main.py

Queda en http://localhost:8000 · la documentación interactiva, con un
botón "Try it out" en cada endpoint, en http://localhost:8000/docs
De yapa sirve también el sitio: http://localhost:8000/index.html

Variables de entorno (todas opcionales):
    POLO_DB_URL    postgresql://polotec:polotec@localhost:5432/polotec
    POLO_SECRETO   clave para firmar las sesiones. Si no está, se inventa
                   una al arrancar (las sesiones se pierden al reiniciar).
    POLO_PUERTO    8000
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal, Optional
from uuid import UUID

import asyncpg
from urllib.parse import quote, unquote

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB_URL = os.environ.get("POLO_DB_URL", "postgresql://polotec:polotec@localhost:5432/polotec")
SECRETO = os.environ.get("POLO_SECRETO") or secrets.token_hex(32)
DURACION_SESION = 8 * 3600  # una jornada
URUGUAY = timezone(timedelta(hours=-3))  # Uruguay no tiene horario de verano desde 2015
RAIZ_DEL_SITIO = Path(__file__).resolve().parent.parent
TAMANO_MAXIMO_CV = 5 * 1024 * 1024  # 5 MB, igual que js/curriculum.js y la tabla student_cv


# ----------------------------------------------------------------
# Conexión
# ----------------------------------------------------------------
async def _preparar_conexion(conn: asyncpg.Connection) -> None:
    # Las vistas devuelven json (títulos, cursos, experiencia): que lleguen como listas.
    for tipo in ("json", "jsonb"):
        await conn.set_type_codec(tipo, encoder=json.dumps, decoder=json.loads, schema="pg_catalog")


@asynccontextmanager
async def ciclo_de_vida(app: FastAPI):
    try:
        app.state.pool = await asyncpg.create_pool(
            DB_URL, min_size=1, max_size=10, init=_preparar_conexion,
            server_settings={"timezone": "America/Montevideo", "application_name": "polo2gestion-api"},
        )
        print(f"Conectado a la base: {DB_URL.rsplit('@', 1)[-1]}")
    except Exception as e:  # la API arranca igual y /api/v1/salud avisa
        print(f"No me pude conectar a la base ({e}). ¿Está levantada? Ver README, sección Base de datos.")
        app.state.pool = None
    if "POLO_SECRETO" not in os.environ:
        print("Aviso: sin POLO_SECRETO, las sesiones se invalidan cada vez que se reinicia la API.")
    yield
    if app.state.pool:
        await app.state.pool.close()


app = FastAPI(
    title="Polo 2 Gestión · API",
    description="Reservas de salones, laboratorios y equipos del Polo Tecnológico de Tacuarembó, y pasantías.",
    version="4.3",
    lifespan=ciclo_de_vida,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def sin_cache_para_el_sitio(request: Request, call_next):
    """Que el navegador no siga usando .js/.css de una versión anterior del sitio."""
    respuesta = await call_next(request)
    if not request.url.path.startswith("/api/"):
        respuesta.headers.setdefault("Cache-Control", "no-cache")
    return respuesta


async def db(request: Request):
    pool = request.app.state.pool
    if pool is None:
        raise HTTPException(503, "La base de datos no está disponible. ¿Está levantada?")
    async with pool.acquire() as conn:
        yield conn


# ----------------------------------------------------------------
# Errores de la base → HTTP, con el mensaje que escribió la base
# ----------------------------------------------------------------
CODIGOS = {
    "23P01": 409,  # exclusion_violation: horario tomado / sin unidades
    "23505": 409,  # unique_violation: email repetido, ya postulado
    "23514": 422,  # check_violation: reglas de negocio
    "23503": 422,  # foreign_key_violation: id que no existe
    "23502": 422,  # not_null_violation
    "22P02": 422,  # invalid_text_representation
    "22001": 422,  # string_data_right_truncation: texto demasiado largo
    "42501": 403,  # insufficient_privilege
    "P0002": 404,  # no_data_found
}


@app.exception_handler(asyncpg.PostgresError)
async def error_de_la_base(_: Request, e: asyncpg.PostgresError):
    estado = CODIGOS.get(e.sqlstate, 500)
    mensaje = e.message if estado != 500 else "Error inesperado en la base de datos."
    if e.sqlstate == "23505" and "users_email_key" in (e.constraint_name or ""):
        mensaje = "Ya hay una cuenta con ese email."
    if estado == 500:
        print(f"[base] {e.sqlstate}: {e}")
    return JSONResponse({"detail": mensaje}, status_code=estado)


# ----------------------------------------------------------------
# Sesión: token firmado con HMAC (sin dependencias extra)
# ----------------------------------------------------------------
def _b64(datos: bytes) -> str:
    return base64.urlsafe_b64encode(datos).decode().rstrip("=")


def crear_token(user_id: UUID, rol: str) -> str:
    carga = _b64(json.dumps({"id": str(user_id), "rol": rol, "vence": int(time.time()) + DURACION_SESION}).encode())
    firma = _b64(hmac.new(SECRETO.encode(), carga.encode(), hashlib.sha256).digest())
    return f"{carga}.{firma}"


class Usuario(BaseModel):
    id: UUID
    rol: str


def usuario_actual(authorization: Optional[str] = Header(None)) -> Usuario:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Iniciá sesión para seguir.")
    token = authorization[7:].strip()
    try:
        carga, firma = token.split(".")
        esperada = _b64(hmac.new(SECRETO.encode(), carga.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(firma, esperada):
            raise ValueError
        datos = json.loads(base64.urlsafe_b64decode(carga + "=" * (-len(carga) % 4)))
    except Exception:
        raise HTTPException(401, "La sesión no es válida. Volvé a iniciar sesión.")
    if datos["vence"] < time.time():
        raise HTTPException(401, "La sesión venció. Volvé a iniciar sesión.")
    return Usuario(id=datos["id"], rol=datos["rol"])


def con_rol(*roles: str):
    def verificar(u: Usuario = Depends(usuario_actual)) -> Usuario:
        if u.rol not in roles:
            raise HTTPException(403, "Tu cuenta no tiene permiso para esto.")
        return u
    return verificar


def filas(registros) -> list[dict]:
    return [dict(r) for r in registros]


def hora_local(momento: datetime) -> datetime:
    """Un horario sin zona ("2026-10-20T14:00") se entiende en hora de Uruguay."""
    return momento if momento.tzinfo else momento.replace(tzinfo=URUGUAY)


# ----------------------------------------------------------------
# Modelos de entrada
# ----------------------------------------------------------------
class LoginEntrada(BaseModel):
    email: str
    password: str


class RegistroEntrada(BaseModel):
    rol: Literal["student", "professor", "company"]
    email: str
    password: str = Field(min_length=8)
    nombre: str = Field(min_length=1, max_length=150)
    apellido: Optional[str] = None
    sector: str = "servicios"


class PreferenciasEntrada(BaseModel):
    tema: Optional[Literal["auto", "claro", "oscuro"]] = None
    avisos: Optional[bool] = None
    confirmaciones: Optional[bool] = None
    asistente: Optional[bool] = None
    voz_asistente: Optional[bool] = None
    aplausos: Optional[bool] = None
    vista_agenda: Optional[Literal["tabla", "dia"]] = None
    sonidos: Optional[bool] = None
    estilo_sonido: Optional[Literal["calido", "suave", "burbuja", "mecanico", "retro"]] = None
    volumen_sonido: Optional[int] = Field(None, ge=0, le=100)


class ReservaEntrada(BaseModel):
    recurso: str = Field(description="Código del recurso (r1…r14) o su id")
    motivo: str = Field(min_length=3, max_length=200)
    desde: datetime
    hasta: datetime
    unidades: int = Field(1, ge=1, le=100)
    postulacion_id: Optional[UUID] = Field(None, description="Si la sala es para la entrevista de una pasantía")


class DecisionEntrada(BaseModel):
    estado: Literal["approved", "rejected"]


class PasantiaEntrada(BaseModel):
    titulo: str = Field(min_length=3, max_length=200)
    descripcion: Optional[str] = None
    modalidad: Literal["remoto", "presencial", "hibrido"]
    meses: int = Field(ge=1, le=12)


class DecisionPostulanteEntrada(BaseModel):
    estudiante_id: UUID
    pasantia_id: UUID
    estado: Literal["approved", "rejected"]


class Titulo(BaseModel):
    nombre: str = Field(min_length=1, max_length=200)
    institucion: Optional[str] = None
    anio: Optional[int] = Field(None, ge=1950, le=2100)


class Curso(BaseModel):
    nombre: str = Field(min_length=1, max_length=200)
    institucion: Optional[str] = None
    detalle: Optional[str] = Field(None, max_length=60)


class Experiencia(BaseModel):
    puesto: str = Field(min_length=1, max_length=200)
    lugar: Optional[str] = None
    periodo: Optional[str] = Field(None, max_length=60)


class PerfilEntrada(BaseModel):
    orientacion: Optional[str] = None
    nivel: Optional[Literal["primero", "segundo", "tercero", "egresado"]] = None
    localidad: Optional[str] = None
    disponibilidad: Optional[Literal["medio_tiempo", "tiempo_completo", "fines_de_semana", "a_coordinar"]] = None
    sobre_mi: Optional[str] = Field(None, max_length=400)
    linkedin_url: Optional[str] = None
    portfolio_url: Optional[str] = None
    capacidades: list[str] = Field(default_factory=list, max_length=20)
    idiomas: list[str] = Field(default_factory=list, max_length=10)
    titulos: list[Titulo] = Field(default_factory=list, max_length=10)
    cursos: list[Curso] = Field(default_factory=list, max_length=20)
    experiencia: list[Experiencia] = Field(default_factory=list, max_length=10)


class RevisionEmpresaEntrada(BaseModel):
    estado: Literal["active", "rejected", "suspended"]


# ================================================================
# Endpoints
# ================================================================
api = "/api/v1"


@app.get(f"{api}/salud", tags=["general"])
async def salud(request: Request):
    """¿Está viva la API y llega a la base?"""
    if request.app.state.pool is None:
        return {"api": "ok", "base": "sin conexión"}
    async with request.app.state.pool.acquire() as conn:
        version = await conn.fetchval("SHOW server_version")
    return {"api": "ok", "base": "ok", "postgres": version}


# --- Sesión y cuenta ------------------------------------------------
@app.post(f"{api}/auth/login", tags=["cuenta"])
async def login(datos: LoginEntrada, conn=Depends(db)):
    fila = await conn.fetchrow("SELECT * FROM fn_login($1, $2)", datos.email.strip(), datos.password)
    if not fila:
        raise HTTPException(401, "El email o la contraseña no coinciden.")
    return {
        "token": crear_token(fila["user_id"], fila["role"]),
        "usuario": {"id": fila["user_id"], "rol": fila["role"], "nombre": fila["display_name"], "email": datos.email.strip().lower()},
    }


@app.post(f"{api}/auth/registro", status_code=201, tags=["cuenta"])
async def registro(datos: RegistroEntrada, conn=Depends(db)):
    nuevo = await conn.fetchval(
        "SELECT fn_registrar($1, $2, $3, $4, $5, $6)",
        datos.rol, datos.email.strip(), datos.password, datos.nombre.strip(), datos.apellido, datos.sector,
    )
    aviso = "Tu cuenta queda pendiente hasta que el Polo la apruebe." if datos.rol == "company" else None
    return {"id": nuevo, "aviso": aviso}


@app.get(f"{api}/yo", tags=["cuenta"])
async def yo(u: Usuario = Depends(usuario_actual), conn=Depends(db)):
    cuenta = await conn.fetchrow(
        "SELECT id, email::text, role AS rol, display_name AS nombre, last_login_at FROM users WHERE id = $1", u.id)
    if not cuenta:
        raise HTTPException(404, "La cuenta ya no existe.")
    prefs = await conn.fetchrow("SELECT * FROM user_preferences WHERE user_id = $1", u.id)
    extra = {}
    if u.rol == "company":
        extra["empresa"] = dict(await conn.fetchrow(
            "SELECT legal_name AS razon_social, sector, status AS estado FROM companies WHERE user_id = $1", u.id))
    return {**dict(cuenta), "preferencias": _prefs_a_front(prefs), **extra}


def _prefs_a_front(p) -> dict:
    """Mismos nombres que js/ui.js guarda en localStorage (poloTecPreferencias)."""
    return {
        "tema": p["theme"], "avisos": p["show_toasts"], "confirmaciones": p["ask_confirmation"],
        "asistente": p["assistant"], "vozAsistente": p["assistant_voice"], "aplausos": p["clap_to_open"],
        "vistaAgenda": p["agenda_view"],
        "sonidos": p["click_sounds"], "estiloSonido": p["sound_style"], "volumenSonido": p["sound_volume"],
    }


@app.put(f"{api}/yo/preferencias", tags=["cuenta"])
async def guardar_preferencias(datos: PreferenciasEntrada, u: Usuario = Depends(usuario_actual), conn=Depends(db)):
    columnas = {
        "tema": "theme", "avisos": "show_toasts", "confirmaciones": "ask_confirmation", "asistente": "assistant",
        "voz_asistente": "assistant_voice", "aplausos": "clap_to_open", "vista_agenda": "agenda_view",
        "sonidos": "click_sounds", "estilo_sonido": "sound_style", "volumen_sonido": "sound_volume",
    }
    cambios = {columnas[k]: v for k, v in datos.model_dump(exclude_none=True).items()}
    if cambios:
        sets = ", ".join(f"{col} = ${i + 2}" for i, col in enumerate(cambios))
        await conn.execute(f"UPDATE user_preferences SET {sets} WHERE user_id = $1", u.id, *cambios.values())
    prefs = await conn.fetchrow("SELECT * FROM user_preferences WHERE user_id = $1", u.id)
    return _prefs_a_front(prefs)


@app.get(f"{api}/avisos", tags=["cuenta"])
async def avisos(solo_sin_leer: bool = False, u: Usuario = Depends(usuario_actual), conn=Depends(db)):
    return filas(await conn.fetch(
        """SELECT id, kind AS tipo, title AS titulo, body AS detalle, link, created_at AS fecha, read_at AS leido
             FROM notifications WHERE user_id = $1 AND ($2 = false OR read_at IS NULL)
            ORDER BY created_at DESC LIMIT 50""", u.id, solo_sin_leer))


@app.post(f"{api}/avisos/leidos", tags=["cuenta"])
async def marcar_avisos_leidos(u: Usuario = Depends(usuario_actual), conn=Depends(db)):
    resultado = await conn.execute(
        "UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL", u.id)
    return {"marcados": int(resultado.split()[-1])}


# --- Reservas (lo principal) ---------------------------------------
@app.get(f"{api}/recursos", tags=["reservas"])
async def recursos(tipo: Optional[Literal["espacio", "laboratorio", "equipo"]] = None, conn=Depends(db)):
    """Inventario, con los recursos según la materia de cada salón (herramientas,
    materiales que se usan ahí y si muestra la Biblioteca Ceibal)."""
    return filas(await conn.fetch("SELECT * FROM v_recursos WHERE $1::text IS NULL OR tipo = $1", tipo))


@app.get(f"{api}/recursos/{{codigo}}", tags=["reservas"])
async def ficha_del_recurso(codigo: str, conn=Depends(db)):
    """La ficha de un salón: lo que muestra "Ver recursos"."""
    fila = await conn.fetchrow("SELECT * FROM v_recursos WHERE codigo = $1", codigo)
    if not fila:
        raise HTTPException(404, f'No existe el salón o material "{codigo}".')
    ficha = dict(fila)
    ficha["materiales"] = filas(await conn.fetch(
        """SELECT codigo, nombre, unidades FROM v_recursos
            WHERE codigo = ANY($1::text[]) ORDER BY array_position($1::text[], codigo)""", fila["materiales_sugeridos"]))
    return ficha


@app.get(f"{api}/agenda", tags=["reservas"])
async def agenda_publica(conn=Depends(db)):
    """La agenda pública: no hace falta iniciar sesión."""
    return filas(await conn.fetch("SELECT * FROM v_agenda_publica"))


@app.get(f"{api}/disponibilidad", tags=["reservas"])
async def disponibilidad(recurso: str, desde: datetime, hasta: datetime, conn=Depends(db)):
    """Lo que avisa el formulario antes de enviar: ¿cuántas unidades quedan libres en ese horario?"""
    r = await _buscar_recurso(conn, recurso)
    ocupadas = await conn.fetchval(
        """SELECT COALESCE(SUM(quantity), 0) FROM bookings
            WHERE resource_id = $1 AND status IN ('pending', 'approved')
              AND tstzrange(starts_at, ends_at, '[)') && tstzrange($2, $3, '[)')""",
        r["id"], hora_local(desde), hora_local(hasta))
    libres = r["total_quantity"] - ocupadas
    return {"recurso": r["name"], "unidades": r["total_quantity"], "libres": max(libres, 0), "esta_libre": libres > 0}


async def _buscar_recurso(conn, recurso: str):
    try:
        fila = await conn.fetchrow("SELECT * FROM resources WHERE id = $1", UUID(recurso))
    except ValueError:
        fila = await conn.fetchrow("SELECT * FROM resources WHERE code = $1", recurso)
    if not fila:
        raise HTTPException(404, f'No existe el salón o equipo "{recurso}".')
    return fila


@app.get(f"{api}/reservas/mias", tags=["reservas"])
async def mis_reservas(u: Usuario = Depends(con_rol("professor", "admin", "student")), conn=Depends(db)):
    """Solo las que pidió quien está logueado."""
    return filas(await conn.fetch(
        """SELECT b.id, r.code AS recurso_codigo, r.name AS recurso, b.title AS motivo, b.starts_at AS desde,
                  b.ends_at AS hasta, b.quantity AS unidades, b.status AS estado, b.decided_at AS decidida
             FROM bookings b JOIN resources r ON r.id = b.resource_id
            WHERE b.requested_by = $1 ORDER BY b.starts_at""", u.id))


@app.post(f"{api}/reservas", status_code=201, tags=["reservas"])
async def pedir_reserva(datos: ReservaEntrada, u: Usuario = Depends(con_rol("professor", "admin", "student")), conn=Depends(db)):
    """Profesores y admin: cualquier recurso. Estudiantes: solo materiales (si piden
    un salón o laboratorio, la base responde 403 con el motivo)."""
    if datos.postulacion_id and u.rol != "admin":
        raise HTTPException(403, "Solo la administración agenda salas de entrevista.")
    r = await _buscar_recurso(conn, datos.recurso)
    async with conn.transaction():
        nueva = await conn.fetchval(
            "SELECT fn_solicitar_reserva($1, $2, $3, $4, $5, $6::smallint)",
            u.id, r["id"], datos.motivo.strip(), hora_local(datos.desde), hora_local(datos.hasta), datos.unidades)
        if datos.postulacion_id:
            await conn.execute("UPDATE bookings SET related_application_id = $2 WHERE id = $1", nueva, datos.postulacion_id)
    return {"id": nueva, "estado": "pending"}


@app.post(f"{api}/reservas/{{reserva_id}}/cancelar", tags=["reservas"])
async def cancelar_reserva(reserva_id: UUID, u: Usuario = Depends(con_rol("professor", "admin", "student")), conn=Depends(db)):
    resultado = await conn.execute(
        """UPDATE bookings SET status = 'cancelled'
            WHERE id = $1 AND status IN ('pending', 'approved') AND (requested_by = $2 OR $3 = 'admin')""",
        reserva_id, u.id, u.rol)
    if resultado.endswith(" 0"):
        raise HTTPException(404, "Esa reserva no existe, no es tuya o ya no se puede cancelar.")
    return {"id": reserva_id, "estado": "cancelled"}


@app.get(f"{api}/reservas/pendientes", tags=["admin de reservas"])
async def reservas_pendientes(_: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    return filas(await conn.fetch("SELECT * FROM v_reservas_pendientes"))


@app.post(f"{api}/reservas/{{reserva_id}}/decision", tags=["admin de reservas"])
async def decidir_reserva(reserva_id: UUID, datos: DecisionEntrada, u: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    await conn.execute("SELECT fn_decidir_reserva($1, $2, $3)", u.id, reserva_id, datos.estado)
    return {"id": reserva_id, "estado": datos.estado}


@app.get(f"{api}/estadisticas", tags=["admin de reservas"])
async def estadisticas(_: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    return dict(await conn.fetchrow("SELECT * FROM v_estadisticas_reservas"))


@app.get(f"{api}/calendario/{{anio}}", tags=["admin de reservas"])
async def calendario_anual(anio: int, _: Usuario = Depends(con_rol("admin", "professor")), conn=Depends(db)):
    """Cuántas reservas aprobadas hay cada día del año (el calendario anual)."""
    registros = await conn.fetch(
        """SELECT starts_at::date AS dia, count(*) AS reservas FROM bookings
            WHERE status = 'approved' AND date_part('year', starts_at) = $1 GROUP BY 1 ORDER BY 1""", anio)
    return {str(r["dia"]): r["reservas"] for r in registros}


# --- Pasantías -------------------------------------------------------
@app.get(f"{api}/pasantias", tags=["pasantías"])
async def pasantias(modalidad: Optional[Literal["remoto", "presencial", "hibrido"]] = None, conn=Depends(db)):
    return filas(await conn.fetch(
        "SELECT * FROM v_pasantias_visibles WHERE $1::text IS NULL OR modalidad = $1", modalidad))


@app.post(f"{api}/pasantias", status_code=201, tags=["pasantías"])
async def publicar_pasantia(datos: PasantiaEntrada, u: Usuario = Depends(con_rol("company")), conn=Depends(db)):
    nueva = await conn.fetchval(
        """INSERT INTO internships (company_id, title, description, modality, duration_months)
           VALUES ($1, $2, $3, $4, $5) RETURNING id""",
        u.id, datos.titulo.strip(), datos.descripcion, datos.modalidad, datos.meses)
    return {"id": nueva, "estado": "published"}


@app.post(f"{api}/pasantias/{{pasantia_id}}/cerrar", tags=["pasantías"])
async def cerrar_pasantia(pasantia_id: UUID, u: Usuario = Depends(con_rol("company")), conn=Depends(db)):
    resultado = await conn.execute(
        "UPDATE internships SET status = 'closed' WHERE id = $1 AND company_id = $2", pasantia_id, u.id)
    if resultado.endswith(" 0"):
        raise HTTPException(404, "Esa pasantía no existe o no es de tu empresa.")
    return {"id": pasantia_id, "estado": "closed"}


@app.post(f"{api}/pasantias/{{pasantia_id}}/postulaciones", status_code=201, tags=["pasantías"])
async def postularme(pasantia_id: UUID, u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    nueva = await conn.fetchval("SELECT fn_postular($1, $2)", u.id, pasantia_id)
    return {"id": nueva, "estado": "pending"}


@app.get(f"{api}/postulaciones/mias", tags=["pasantías"])
async def mis_postulaciones(u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    return filas(await conn.fetch(
        "SELECT * FROM v_mis_postulaciones WHERE student_id = $1 ORDER BY fecha DESC", u.id))


@app.post(f"{api}/postulaciones/{{postulacion_id}}/retirar", tags=["pasantías"])
async def retirar_postulacion(postulacion_id: UUID, u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    resultado = await conn.execute(
        "UPDATE applications SET status = 'withdrawn' WHERE id = $1 AND student_id = $2 AND status = 'pending'",
        postulacion_id, u.id)
    if resultado.endswith(" 0"):
        raise HTTPException(404, "Esa postulación no existe o ya tiene respuesta.")
    return {"id": postulacion_id, "estado": "withdrawn"}


# --- Perfil profesional del estudiante ------------------------------
@app.get(f"{api}/orientaciones", tags=["perfil"])
async def orientaciones(conn=Depends(db)):
    return [r["name"] for r in await conn.fetch("SELECT name FROM orientations ORDER BY name")]


@app.get(f"{api}/perfil", tags=["perfil"])
async def mi_perfil(u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    fila = await conn.fetchrow("SELECT * FROM v_perfiles WHERE student_id = $1", u.id)
    if not fila:
        raise HTTPException(404, "No encontré tu perfil.")
    return dict(fila)


@app.put(f"{api}/perfil", tags=["perfil"])
async def guardar_perfil(datos: PerfilEntrada, u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    """Lo que hace "Guardar perfil" en el editor: reemplaza todo el perfil de una vez."""
    async with conn.transaction():
        orientacion_id, orientacion_otra = None, None
        if datos.orientacion and datos.orientacion.strip():
            orientacion_id = await conn.fetchval(
                "SELECT id FROM orientations WHERE lower(name) = lower($1)", datos.orientacion.strip())
            if orientacion_id is None:
                orientacion_otra = datos.orientacion.strip()[:150]
        await conn.execute(
            """UPDATE students SET orientation_id = $2, orientation_other = $3, level = $4, locality = $5,
                      availability = $6, about = $7, linkedin_url = $8, portfolio_url = $9
                WHERE user_id = $1""",
            u.id, orientacion_id, orientacion_otra, datos.nivel, _vacio(datos.localidad), datos.disponibilidad,
            _vacio(datos.sobre_mi), _vacio(datos.linkedin_url), _vacio(datos.portfolio_url))

        await conn.execute("SELECT fn_guardar_capacidades($1, $2)", u.id, datos.capacidades)

        for tabla in ("student_languages", "student_titles", "student_courses", "student_experiences"):
            await conn.execute(f"DELETE FROM {tabla} WHERE student_id = $1", u.id)
        idiomas = list(dict.fromkeys(i.strip() for i in datos.idiomas if i.strip()))
        await conn.executemany(
            "INSERT INTO student_languages (student_id, label, position) VALUES ($1, $2, $3)",
            [(u.id, idioma, i) for i, idioma in enumerate(idiomas)])
        await conn.executemany(
            "INSERT INTO student_titles (student_id, name, institution, year, position) VALUES ($1, $2, $3, $4, $5)",
            [(u.id, t.nombre, t.institucion, t.anio, i) for i, t in enumerate(datos.titulos)])
        await conn.executemany(
            "INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ($1, $2, $3, $4, $5)",
            [(u.id, c.nombre, c.institucion, c.detalle, i) for i, c in enumerate(datos.cursos)])
        await conn.executemany(
            "INSERT INTO student_experiences (student_id, role, place, period, position) VALUES ($1, $2, $3, $4, $5)",
            [(u.id, e.puesto, e.lugar, e.periodo, i) for i, e in enumerate(datos.experiencia)])
    return dict(await conn.fetchrow("SELECT * FROM v_perfiles WHERE student_id = $1", u.id))


# --- Currículum en PDF ------------------------------------------------
# El cuerpo del pedido ES el PDF (Content-Type: application/pdf), y el
# nombre va en el encabezado X-Nombre-Archivo (codificado con
# encodeURIComponent). Así no hace falta instalar nada para formularios
# multipart. Se repiten las validaciones del navegador: tipo, 5 MB y
# que empiece con %PDF- (la base las vuelve a exigir con sus CHECK).
@app.put(f"{api}/perfil/cv", tags=["perfil"])
async def subir_cv(
    request: Request,
    content_type: Optional[str] = Header(None),
    content_length: Optional[int] = Header(None),
    x_nombre_archivo: Optional[str] = Header(None, description="Nombre del archivo (encodeURIComponent)"),
    u: Usuario = Depends(con_rol("student")),
    conn=Depends(db),
):
    """Subir o reemplazar el currículum. Cuerpo: el PDF, con Content-Type: application/pdf."""
    if (content_type or "").split(";")[0].strip().lower() != "application/pdf":
        raise HTTPException(415, "Mandá el currículum como PDF (Content-Type: application/pdf).")
    if content_length is not None and content_length > TAMANO_MAXIMO_CV:
        raise HTTPException(413, "El currículum pasa de 5 MB.")
    contenido = bytearray()
    async for parte in request.stream():
        contenido.extend(parte)
        if len(contenido) > TAMANO_MAXIMO_CV:
            raise HTTPException(413, "El currículum pasa de 5 MB.")
    if not contenido:
        raise HTTPException(422, "El archivo está vacío.")
    if not contenido.startswith(b"%PDF-"):
        raise HTTPException(422, "Ese archivo no es un PDF (aunque se llame .pdf).")
    nombre = unquote(x_nombre_archivo or "curriculum.pdf").replace("/", "_").replace("\\", "_").strip() or "curriculum.pdf"
    await conn.execute("SELECT fn_guardar_cv($1, $2, $3)", u.id, nombre[:200], bytes(contenido))
    fila = await conn.fetchrow("SELECT curriculum, completitud FROM v_perfiles WHERE student_id = $1", u.id)
    return {"curriculum": fila["curriculum"], "completitud": fila["completitud"]}


@app.delete(f"{api}/perfil/cv", tags=["perfil"])
async def quitar_cv(u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    resultado = await conn.execute("DELETE FROM student_cv WHERE student_id = $1", u.id)
    if resultado.endswith(" 0"):
        raise HTTPException(404, "No tenías currículum cargado.")
    return {"completitud": await conn.fetchval("SELECT fn_completitud($1)", u.id)}


async def _respuesta_cv(conn, estudiante_id: UUID) -> Response:
    fila = await conn.fetchrow("SELECT file_name, content FROM student_cv WHERE student_id = $1", estudiante_id)
    if not fila:
        raise HTTPException(404, "No se encontró el archivo: ese estudiante no subió currículum.")
    nombre = fila["file_name"]
    return Response(
        content=bytes(fila["content"]),
        media_type="application/pdf",
        headers={
            # inline: el navegador lo muestra; filename*: respeta los acentos
            "Content-Disposition": f"inline; filename=\"curriculum.pdf\"; filename*=UTF-8''{quote(nombre)}",
            "X-Content-Type-Options": "nosniff",
        },
    )


@app.get(f"{api}/perfil/cv", tags=["perfil"])
async def mi_cv(u: Usuario = Depends(con_rol("student")), conn=Depends(db)):
    return await _respuesta_cv(conn, u.id)


def _vacio(texto: Optional[str]) -> Optional[str]:
    return texto.strip() if texto and texto.strip() else None


# --- Panel de empresa -------------------------------------------------
@app.get(f"{api}/empresa/postulantes", tags=["empresa"])
async def postulantes(u: Usuario = Depends(con_rol("company")), conn=Depends(db)):
    return filas(await conn.fetch("SELECT * FROM v_postulantes WHERE company_id = $1", u.id))


@app.get(f"{api}/empresa/pasantias", tags=["empresa"])
async def pasantias_de_mi_empresa(u: Usuario = Depends(con_rol("company")), conn=Depends(db)):
    return filas(await conn.fetch(
        """SELECT i.id, i.title AS titulo, i.modality AS modalidad, i.duration_months AS meses, i.status AS estado,
                  i.published_at AS publicada,
                  count(a.id) FILTER (WHERE a.status = 'pending')  AS esperando,
                  count(a.id) FILTER (WHERE a.status = 'approved') AS aceptados
             FROM internships i LEFT JOIN applications a ON a.internship_id = i.id
            WHERE i.company_id = $1 GROUP BY i.id ORDER BY i.created_at DESC""", u.id))


@app.get(f"{api}/perfiles", tags=["empresa"])
async def directorio_de_perfiles(
    q: Optional[str] = Query(None, description="Busca en nombre, orientación, capacidades, cursos y títulos"),
    _: Usuario = Depends(con_rol("company", "admin")), conn=Depends(db),
):
    return filas(await conn.fetch(
        """SELECT * FROM v_perfiles p
            WHERE $1::text IS NULL
               OR p.nombre ILIKE '%' || $1 || '%'
               OR p.orientacion ILIKE '%' || $1 || '%'
               OR EXISTS (SELECT 1 FROM unnest(p.capacidades) c WHERE c ILIKE '%' || $1 || '%')
               OR p.cursos::text ILIKE '%' || $1 || '%'
               OR p.titulos::text ILIKE '%' || $1 || '%'
            ORDER BY p.completitud DESC, p.nombre""", _vacio(q)))


@app.get(f"{api}/perfiles/{{estudiante_id}}", tags=["empresa"])
async def ver_perfil(estudiante_id: UUID, _: Usuario = Depends(con_rol("company", "admin")), conn=Depends(db)):
    fila = await conn.fetchrow("SELECT * FROM v_perfiles WHERE student_id = $1", estudiante_id)
    if not fila:
        raise HTTPException(404, "Ese perfil no existe.")
    return dict(fila)


@app.get(f"{api}/perfiles/{{estudiante_id}}/cv", tags=["empresa"])
async def ver_cv(estudiante_id: UUID, _: Usuario = Depends(con_rol("company", "admin")), conn=Depends(db)):
    """"Ver currículum" desde la ficha del estudiante."""
    return await _respuesta_cv(conn, estudiante_id)


@app.post(f"{api}/empresa/decisiones", tags=["empresa"])
async def decidir_postulante(datos: DecisionPostulanteEntrada, u: Usuario = Depends(con_rol("company")), conn=Depends(db)):
    """Aceptar o rechazar a un postulante, o seleccionar a alguien del directorio aunque no se haya postulado."""
    postulacion = await conn.fetchval(
        "SELECT fn_decidir_postulacion($1, $2, $3, $4)", u.id, datos.estudiante_id, datos.pasantia_id, datos.estado)
    return {"postulacion_id": postulacion, "estado": datos.estado}


# --- Admin de pasantías ----------------------------------------------
@app.get(f"{api}/empresas", tags=["admin de pasantías"])
async def empresas(estado: Optional[str] = None, _: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    return filas(await conn.fetch(
        """SELECT c.user_id AS id, c.legal_name AS razon_social, c.sector, c.status AS estado, u.email::text,
                  c.created_at AS registrada, c.reviewed_at AS revisada
             FROM companies c JOIN users u ON u.id = c.user_id
            WHERE $1::text IS NULL OR c.status = $1 ORDER BY c.created_at""", estado))


@app.post(f"{api}/empresas/{{empresa_id}}/revision", tags=["admin de pasantías"])
async def revisar_empresa(empresa_id: UUID, datos: RevisionEmpresaEntrada, u: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    resultado = await conn.execute(
        "UPDATE companies SET status = $2, reviewed_by = $3 WHERE user_id = $1", empresa_id, datos.estado, u.id)
    if resultado.endswith(" 0"):
        raise HTTPException(404, "Esa empresa no existe.")
    return {"id": empresa_id, "estado": datos.estado}


@app.get(f"{api}/entrevistas-por-agendar", tags=["admin de pasantías"])
async def entrevistas_por_agendar(_: Usuario = Depends(con_rol("admin")), conn=Depends(db)):
    return filas(await conn.fetch("SELECT * FROM v_entrevistas_por_agendar ORDER BY decided_at"))


# ----------------------------------------------------------------
# El sitio, servido por la misma API (va al final para no tapar /api)
# ----------------------------------------------------------------
app.mount("/", StaticFiles(directory=RAIZ_DEL_SITIO, html=True), name="sitio")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host=os.environ.get("POLO_HOST", "127.0.0.1"), port=int(os.environ.get("POLO_PUERTO", 8000)))
