"""
Prueba de humo de la API: recorre todos los endpoints con las cuentas
de prueba (profesor, admin, estudiante, empresa) y avisa si algo no
responde como debe.

    python prueba_api.py                      (API en http://localhost:8000)
    set POLO_API=http://localhost:9000/api/v1 (si la levantaste en otro puerto)

OJO: crea reservas, postulaciones y cuentas de verdad. Correla sobre
la base de prueba y después reseteala ("Base de datos.bat" > Resetear).
"""
import os
from urllib.parse import quote
import datetime as dt
import sys
import httpx

B = os.environ.get("POLO_API", "http://localhost:8000/api/v1")
c = httpx.Client(timeout=10)
fallas = 0


def ok(nombre, cond, extra=""):
    global fallas
    print(("OK   " if cond else "FALLA") + " " + nombre + ("  " + str(extra) if extra else ""))
    if not cond:
        fallas += 1


def entrar(email, pw="demo1234"):
    r = c.post(f"{B}/auth/login", json={"email": email, "password": pw})
    return r, ({"Authorization": "Bearer " + r.json()["token"]} if r.status_code == 200 else {})


r, _ = entrar("ana@polotec.edu.uy", "mala")
ok("login con contraseña mala → 401", r.status_code == 401, r.json())
r, PROF = entrar("ANA@polotec.edu.uy")
ok("login profesor (email sin importar mayúsculas)", r.status_code == 200, r.json()["usuario"])
_, ADMIN = entrar("admin@polotec.edu.uy")
_, EST = entrar("maria@estudiante.com")
_, EMP = entrar("contacto@techcorp.com")
_, EMP_PEND = entrar("contacto@industriasnorte.com")

ok("sin token → 401", c.get(f"{B}/reservas/mias").status_code == 401)
ok("token trucho → 401", c.get(f"{B}/yo", headers={"Authorization": "Bearer abc.def"}).status_code == 401)
r = c.get(f"{B}/yo", headers=PROF)
ok("/yo trae preferencias", r.status_code == 200 and "aplausos" in r.json()["preferencias"], r.json()["preferencias"])
r = c.put(f"{B}/yo/preferencias", headers=PROF, json={"aplausos": True, "tema": "claro"})
ok("guardar preferencias", r.json()["aplausos"] is True and r.json()["tema"] == "claro")
r = c.put(f"{B}/yo/preferencias", headers=PROF, json={"sonidos": False, "estilo_sonido": "mecanico", "volumen_sonido": 35})
ok("guardar preferencias de sonido", r.json()["sonidos"] is False and r.json()["estiloSonido"] == "mecanico" and r.json()["volumenSonido"] == 35, r.json())
ok("estilo de sonido inválido → 422", c.put(f"{B}/yo/preferencias", headers=PROF, json={"estilo_sonido": "sirena"}).status_code == 422)
ok("volumen fuera de rango → 422", c.put(f"{B}/yo/preferencias", headers=PROF, json={"volumen_sonido": 150}).status_code == 422)
r = c.put(f"{B}/yo/preferencias", headers=PROF, json={"tema": "violeta"})
ok("tema inválido → 422", r.status_code == 422)

# Reservas
ok("agenda pública sin sesión", c.get(f"{B}/agenda").status_code == 200 and len(c.get(f"{B}/agenda").json()) > 0)
ok("17 recursos (salones, laboratorios y materiales)", len(c.get(f"{B}/recursos").json()) == 17)
ficha = c.get(f"{B}/recursos/r5").json()
ok("ficha de Química: herramientas y materiales", ficha["herramientas"] == ["calculadora", "masaMolar", "conversor"] and [m["codigo"] for m in ficha["materiales"]] == ["r7", "r8"], ficha.get("herramientas"))
ok("solo materiales con ?tipo=equipo", all(x["tipo"] == "equipo" for x in c.get(f"{B}/recursos", params={"tipo": "equipo"}).json()))
dia = (dt.date.today() + dt.timedelta(days=5)).isoformat()
r = c.get(f"{B}/disponibilidad", params={"recurso": "r1", "desde": f"{dia}T15:00", "hasta": f"{dia}T16:00"})
ok("disponibilidad", r.status_code == 200, r.json())
r = c.post(f"{B}/reservas", headers=PROF, json={"recurso": "r1", "motivo": "Prueba de la API", "desde": f"{dia}T15:00", "hasta": f"{dia}T16:00"})
ok("profesor pide reserva → 201", r.status_code == 201, r.json())
nueva = r.json().get("id")
r = c.post(f"{B}/reservas", headers=PROF, json={"recurso": "r1", "motivo": "Choca", "desde": f"{dia}T15:30", "hasta": f"{dia}T17:00"})
ok("superpuesta → 409 con mensaje claro", r.status_code == 409, r.json())
r = c.post(f"{B}/reservas", headers=PROF, json={"recurso": "r1", "motivo": "Al ras", "desde": f"{dia}T16:00", "hasta": f"{dia}T17:00"})
ok("pegada justo al final → 201", r.status_code == 201)
r = c.post(f"{B}/reservas", headers=PROF, json={"recurso": "r1", "motivo": "Pasado", "desde": "2020-01-01T10:00", "hasta": "2020-01-01T11:00"})
ok("en el pasado → 422", r.status_code == 422, r.json())
r = c.post(f"{B}/reservas", headers=EST, json={"recurso": "r1", "motivo": "Estudiante", "desde": f"{dia}T18:00", "hasta": f"{dia}T19:00"})
ok("estudiante no reserva un salón → 403 con el motivo", r.status_code == 403 and "materiales" in r.json()["detail"], r.json())
r = c.post(f"{B}/reservas", headers=EST, json={"recurso": "r13", "motivo": "Trabajo en grupo", "desde": f"{dia}T18:00", "hasta": f"{dia}T19:00", "unidades": 5})
ok("estudiante reserva un material (5 notebooks) → 201", r.status_code == 201, r.json())
res_alumno = r.json().get("id")
ok("el alumno ve solo las suyas en /reservas/mias", [x["id"] for x in c.get(f"{B}/reservas/mias", headers=EST).json()] == ["60000000-0000-0000-0000-000000000015", res_alumno] or res_alumno in [x["id"] for x in c.get(f"{B}/reservas/mias", headers=EST).json()])
ok("…y no ve las de Ana", all(x["id"] != nueva for x in c.get(f"{B}/reservas/mias", headers=EST).json()))
pend_alumno = [p for p in c.get(f"{B}/reservas/pendientes", headers=ADMIN).json() if p["id"] == res_alumno]
ok("en la cola del admin lleva (alumno)", pend_alumno and pend_alumno[0]["pedida_por"].endswith("(alumno)"), pend_alumno)
r = c.post(f"{B}/reservas", headers=EST, json={"recurso": "r2", "motivo": "Entrevista", "desde": f"{dia}T20:00", "hasta": f"{dia}T20:30", "postulacion_id": "40000000-0000-0000-0000-000000000001"})
ok("un alumno no agenda salas de entrevista → 403", r.status_code == 403)
r = c.post(f"{B}/reservas", headers=PROF, json={"recurso": "r99", "motivo": "No existe", "desde": f"{dia}T18:00", "hasta": f"{dia}T19:00"})
ok("recurso inexistente → 404", r.status_code == 404)
# Proyectores: 2 unidades
proy = [x for x in c.get(f"{B}/recursos").json() if x["unidades"] == 2][0]["codigo"]
codigos = [c.post(f"{B}/reservas", headers=PROF, json={"recurso": proy, "motivo": f"Proyector {i}", "desde": f"{dia}T08:00", "hasta": f"{dia}T09:00"}).status_code for i in range(3)]
ok("proyectores: 2 entran, el 3º → 409", codigos == [201, 201, 409], codigos)

ok("profesor no ve pendientes → 403", c.get(f"{B}/reservas/pendientes", headers=PROF).status_code == 403)
pend = c.get(f"{B}/reservas/pendientes", headers=ADMIN).json()
ok("admin ve la nueva en pendientes", any(p["id"] == nueva for p in pend))
r = c.post(f"{B}/reservas/{nueva}/decision", headers=ADMIN, json={"estado": "approved"})
ok("admin aprueba", r.status_code == 200)
r = c.post(f"{B}/reservas/{nueva}/decision", headers=ADMIN, json={"estado": "rejected"})
ok("decidir dos veces → 404", r.status_code == 404, r.json())
avisos = c.get(f"{B}/avisos", headers=PROF, params={"solo_sin_leer": True}).json()
ok("el profesor recibió el aviso", any("Aprobaron" in a["titulo"] for a in avisos), avisos[:1])
ok("marcar leídos", c.post(f"{B}/avisos/leidos", headers=PROF).json()["marcados"] >= 1)
r = c.post(f"{B}/reservas/{nueva}/cancelar", headers=PROF)
ok("cancelar propia", r.status_code == 200)
ok("cancelar otra vez → 404", c.post(f"{B}/reservas/{nueva}/cancelar", headers=PROF).status_code == 404)
est = c.get(f"{B}/estadisticas", headers=ADMIN).json()
ok("estadísticas", est["salones_y_equipos"] == 17, est)
cal = c.get(f"{B}/calendario/{dt.date.today().year}", headers=ADMIN).json()
ok("calendario anual", len(cal) > 0, list(cal.items())[:3])
ok("mis reservas", len(c.get(f"{B}/reservas/mias", headers=PROF).json()) >= 8)

# Pasantías
pas = c.get(f"{B}/pasantias").json()
ok("pasantías visibles (3)", len(pas) == 3, [p["titulo"] for p in pas])
ok("filtro por modalidad", all(p["modalidad"] == "remoto" for p in c.get(f"{B}/pasantias", params={"modalidad": "remoto"}).json()))
r = c.post(f"{B}/pasantias", headers=EMP_PEND, json={"titulo": "No puede", "modalidad": "remoto", "meses": 3})
ok("empresa pendiente no publica → 422", r.status_code == 422, r.json())
r = c.post(f"{B}/pasantias", headers=EMP, json={"titulo": "Pasantía de prueba API", "descripcion": "x", "modalidad": "hibrido", "meses": 4})
ok("empresa activa publica", r.status_code == 201)
p_nueva = r.json()["id"]
r = c.post(f"{B}/pasantias/{p_nueva}/postulaciones", headers=EST)
ok("estudiante se postula", r.status_code == 201)
post_id = r.json()["id"]
r = c.post(f"{B}/pasantias/{p_nueva}/postulaciones", headers=EST)
ok("postularse dos veces → 409", r.status_code == 409, r.json())
ok("mis postulaciones", any(x["application_id"] == post_id for x in c.get(f"{B}/postulaciones/mias", headers=EST).json()))
avisos_emp = c.get(f"{B}/avisos", headers=EMP).json()
ok("la empresa recibió aviso de postulación", any(a["tipo"] == "postulacion_nueva" for a in avisos_emp))
ok("empresa ve postulantes", any(x["application_id"] == post_id for x in c.get(f"{B}/empresa/postulantes", headers=EMP).json()))
ok("pasantías de mi empresa", any(x["id"] == p_nueva and x["esperando"] == 1 for x in c.get(f"{B}/empresa/pasantias", headers=EMP).json()))
yo_est = c.get(f"{B}/yo", headers=EST).json()
r = c.post(f"{B}/empresa/decisiones", headers=EMP, json={"estudiante_id": yo_est["id"], "pasantia_id": p_nueva, "estado": "approved"})
ok("empresa acepta", r.status_code == 200 and r.json()["postulacion_id"] == post_id)
ok("retirar ya decidida → 404", c.post(f"{B}/postulaciones/{post_id}/retirar", headers=EST).status_code == 404)

# Directorio y selección directa
dirr = c.get(f"{B}/perfiles", headers=EMP, params={"q": "python"}).json()
ok("directorio busca por capacidad", len(dirr) >= 1, [d["nombre"] for d in dirr])
ok("estudiante no ve el directorio → 403", c.get(f"{B}/perfiles", headers=EST).status_code == 403)
otro = [d for d in c.get(f"{B}/perfiles", headers=EMP).json() if d["email"] != "maria@estudiante.com"][0]
ok("ver un perfil", c.get(f"{B}/perfiles/{otro['student_id']}", headers=EMP).json()["nombre"] == otro["nombre"])
r = c.post(f"{B}/empresa/decisiones", headers=EMP, json={"estudiante_id": otro["student_id"], "pasantia_id": p_nueva, "estado": "approved"})
ok("selección directa sin postulación", r.status_code == 200)
origen = [x for x in c.get(f"{B}/empresa/postulantes", headers=EMP).json() if x["student_id"] == otro["student_id"] and x["internship_id"] == p_nueva]
ok("queda con origen seleccion_directa", origen and origen[0]["origen"] == "seleccion_directa", origen and origen[0]["origen"])
ajena = [p for p in pas if p["empresa"] != "TechCorp"][0]["id"]
r = c.post(f"{B}/empresa/decisiones", headers=EMP, json={"estudiante_id": otro["student_id"], "pasantia_id": ajena, "estado": "approved"})
ok("decidir en pasantía ajena → 403", r.status_code == 403, r.json())

# Perfil del estudiante
perfil = c.get(f"{B}/perfil", headers=EST).json()
ok("mi perfil (82 %, como en el sitio)", perfil["completitud"] == 82, perfil["completitud"])
ok("orientaciones", len(c.get(f"{B}/orientaciones").json()) == 8)
r = c.put(f"{B}/perfil", headers=EST, json={
    "orientacion": "Robótica marina", "nivel": "tercero", "disponibilidad": "a_coordinar",
    "sobre_mi": "Corto", "capacidades": ["Python", "python", "SQL"], "idiomas": ["Inglés B2"],
    "titulos": [{"nombre": "Bachillerato", "anio": 2025}], "cursos": [], "experiencia": [],
})
ok("guardar perfil", r.status_code == 200, r.text[:200])
p2 = r.json()
ok("orientación libre", p2["orientacion"] == "Robótica marina")
ok("capacidades sin repetir", p2["capacidades"] == ["Python", "SQL"], p2["capacidades"])
ok("completitud recalculada (11 bloques)", p2["completitud"] == 45 and "Sobre vos" in p2["faltan"] and "Currículum" in p2["faltan"], (p2["completitud"], p2["faltan"]))

# Currículum en PDF
PDF = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
def subir(cuerpo, tipo="application/pdf", nombre="Mi currículum.pdf", headers=EST):
    return c.put(f"{B}/perfil/cv", headers={**headers, "Content-Type": tipo, "X-Nombre-Archivo": quote(nombre)}, content=cuerpo)
r = subir(b"MZ no soy un pdf")
ok("CV: un archivo que no empieza con %PDF- → 422", r.status_code == 422 and "no es un PDF" in r.json()["detail"], r.json())
r = subir(PDF, tipo="image/png")
ok("CV: otro Content-Type → 415", r.status_code == 415)
r = subir(PDF + b"0" * (5 * 1024 * 1024))
ok("CV: más de 5 MB → 413", r.status_code == 413, r.status_code)
r = subir(PDF, headers=EMP)
ok("CV: una empresa no sube currículum → 403", r.status_code == 403)
r = subir(PDF)
ok("CV: PDF válido → 200 y suma a la completitud", r.status_code == 200 and r.json()["completitud"] == 55 and r.json()["curriculum"]["nombre"] == "Mi currículum.pdf", r.json())
r = c.get(f"{B}/perfiles/{yo_est['id']}/cv", headers=EMP)
ok("CV: la empresa lo abre (application/pdf, mismo contenido)", r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content == PDF, r.headers.get("content-type"))
ok("CV: el nombre con acentos viaja en filename*", "Mi%20curr%C3%ADculum.pdf" in r.headers["content-disposition"], r.headers["content-disposition"])
ok("CV: el estudiante ve el suyo", c.get(f"{B}/perfil/cv", headers=EST).content == PDF)
ok("CV: un estudiante no abre el de otro → 403", c.get(f"{B}/perfiles/{yo_est['id']}/cv", headers=EST).status_code == 403)
sin_cv = [d for d in c.get(f"{B}/perfiles", headers=EMP).json() if not d["curriculum"]][0]
r = c.get(f"{B}/perfiles/{sin_cv['student_id']}/cv", headers=EMP)
ok("CV: si no subió → 404 'No se encontró el archivo'", r.status_code == 404 and "No se encontró" in r.json()["detail"])
r = subir(PDF.replace(b"1.4", b"1.7"), nombre="CV nuevo")
ok("CV: reemplazar (y se le agrega .pdf al nombre)", r.status_code == 200 and r.json()["curriculum"]["nombre"] == "CV nuevo.pdf", r.json())
r = c.delete(f"{B}/perfil/cv", headers=EST)
ok("CV: quitar baja la completitud", r.status_code == 200 and r.json()["completitud"] == 45, r.json())
ok("CV: quitar dos veces → 404", c.delete(f"{B}/perfil/cv", headers=EST).status_code == 404)
r = c.put(f"{B}/perfil", headers=EST, json={"sobre_mi": "x" * 401})
ok("sobre mí > 400 → 422", r.status_code == 422)

# Admin de pasantías
pend_emp = c.get(f"{B}/empresas", headers=ADMIN, params={"estado": "pending_approval"}).json()
ok("empresas pendientes (2)", len(pend_emp) == 2, [e["razon_social"] for e in pend_emp])
r = c.post(f"{B}/empresas/{pend_emp[0]['id']}/revision", headers=ADMIN, json={"estado": "active"})
ok("aprobar empresa", r.status_code == 200)
ok("entrevistas por agendar", len(c.get(f"{B}/entrevistas-por-agendar", headers=ADMIN).json()) >= 2)
ent = c.get(f"{B}/entrevistas-por-agendar", headers=ADMIN).json()[0]
r = c.post(f"{B}/reservas", headers=ADMIN, json={"recurso": "r2", "motivo": "Entrevista de pasantía", "desde": f"{dia}T11:00", "hasta": f"{dia}T11:45", "postulacion_id": ent["application_id"]})
ok("admin reserva sala para entrevista", r.status_code == 201, r.json())
ok("sale de entrevistas por agendar", all(e["application_id"] != ent["application_id"] for e in c.get(f"{B}/entrevistas-por-agendar", headers=ADMIN).json()))

# Registro
r = c.post(f"{B}/auth/registro", json={"rol": "student", "email": "nuevo@estudiante.com", "password": "clave1234", "nombre": "Nuevo", "apellido": "Alumno"})
ok("registro estudiante", r.status_code == 201)
r = c.post(f"{B}/auth/registro", json={"rol": "student", "email": "NUEVO@estudiante.com", "password": "clave1234", "nombre": "Otro"})
ok("email repetido → 409", r.status_code == 409, r.json())
r = c.post(f"{B}/auth/registro", json={"rol": "admin", "email": "x@x.com", "password": "clave1234", "nombre": "X"})
ok("registrarse como admin → 422", r.status_code == 422)
r = c.post(f"{B}/auth/registro", json={"rol": "company", "email": "rrhh@nueva.com", "password": "clave1234", "nombre": "Nueva SA", "sector": "comercio"})
ok("registro empresa avisa pendiente", r.status_code == 201 and r.json()["aviso"])
ok("el nuevo puede entrar", entrar("nuevo@estudiante.com", "clave1234")[0].status_code == 200)
r = c.get(f"{B}/perfil", headers=entrar("nuevo@estudiante.com", "clave1234")[1])
ok("perfil nuevo vacío = 0 %", r.json()["completitud"] == 0, r.json()["completitud"])

print(f"\n{fallas} fallas")
sys.exit(1 if fallas else 0)
