# Polo 2 Gestión

Sistema de **reserva de salones, laboratorios y materiales** del Polo
Tecnológico de Tacuarembó, con un módulo adicional de **pasantías**.

## Qué hay de nuevo en la v4.3

- **Sonidos al tocar.** Cada botón suena al apretarlo, con un sonido distinto
  según lo que hace: click en botones y links, un tic más liviano en pestañas y
  filtros, un tono más grave en *Rechazar* / *Cancelar* / *Quitar*, dos notas
  que suben o bajan en los interruptores, un acorde corto cuando algo se guarda,
  un aviso grave cuando algo falla, y un soplido suave al abrir o cerrar una
  ventana. Las teclas de la calculadora suenan como teclas.
- **Cinco estilos**: **Cálido** (el de por defecto), Suave, Burbuja, Mecánico
  y Retro, con volumen y apagado en *Configuración* y un botón **Probar** para
  escucharlos antes de guardar.
- **Cálido está calcado del reel de referencia**: se le sacó el audio al video y
  se midió cada click. Son dos notas muy cortas y sin brillo, una grave
  (~550 Hz) y 28 ms después una más aguda y más fuerte (~790 Hz) con un poco de
  cuerpo abajo; en total suena unos 37 ms. El de Polo 2 Gestión tiene la misma
  separación, la misma duración y el mismo reparto de graves y agudos (con
  diferencias de pocos dB). Al cambiar el tema, en el video el par va al revés
  (agudo y después grave): así suenan acá los interruptores al apagarse.
- No hay archivos de audio: todo se genera en el momento con Web Audio
  (`js/sonidos.js`). Pesa nada, suena al instante y anda sin internet.
- Suena al **apretar** con el mouse (se siente inmediato), al soltar con el dedo
  (para no sonar al hacer scroll) y también con Enter o Espacio desde el teclado.
- **No dispara los aplausos:** cada sonido tapa el oído del asistente medio
  segundo, para que un click por los parlantes no cuente como aplauso.
- La base guarda las tres preferencias nuevas (`user_preferences.click_sounds`,
  `sound_style`, `sound_volume`) y la API las lee y escribe en
  `GET` / `PUT /api/v1/yo/preferencias`.

## Qué hay de nuevo en la v4.2

- **Los estudiantes reservan materiales** (proyector, televisión, notebooks,
  equipo de sonido, micrófono, parlante, kits de Arduino), pero no salones ni
  laboratorios. La regla se aplica tres veces: el selector del alumno solo
  lista materiales, `solicitarReserva()` rechaza cualquier otro recurso aunque
  lo fuercen desde la consola, y en la base lo frena un trigger (no se puede
  saltear). Siguen pasando por la aprobación del admin, el choque de horarios
  se valida igual, y en la cola del admin los pedidos de alumnos llevan
  **"(alumno)"**. Cada persona ve como suyas solo las reservas que pidió.
- **El panel del estudiante es un hub** igual al del admin, con dos tarjetas:
  Reservas (`dashboard-estudiante-reservas.html`) y Pasantías
  (`dashboard-estudiante-pasantias.html`, el panel de antes, intacto).
- **Mismo orden en Reservas para alumno y profesor:** 1) salones y
  laboratorios, 2) materiales con el formulario, 3) las reservas ya hechas. El
  formulario del profesor sigue ofreciendo todo; el botón **Pedir** de cada
  material (o salón) lo deja elegido en el formulario.
- **Currículum en PDF:** el alumno lo sube en *Editar perfil profesional* y las
  empresas lo abren con **Ver currículum** desde su ficha. Solo PDF de hasta
  5 MB, y se mira que el archivo realmente empiece como un PDF (no alcanza con
  la extensión). Suma a la barra de completitud, y se puede reemplazar o quitar.
- **Recursos según la materia:** cada salón muestra solo las herramientas que
  le sirven (ver la tabla en [Recursos según la materia](#recursos-según-la-materia)),
  los "Materiales que se usan acá", el banner de **Biblioteca Ceibal** en los
  salones de estudio y el enlace a **PETS** en todos.
- **La reserva se comparte entre paneles:** antes cada página tenía su copia en
  memoria; ahora quedan en `localStorage` (como la bolsa de pasantías), así lo
  que pide un alumno le aparece al admin, aun en otra pestaña.
- La base de datos, la API y las pruebas están al día con todo esto.

Tiene tres partes:

- **El sitio** (HTML + CSS + JavaScript, sin frameworks ni librerías externas).
  Anda de punta a punta por sí solo: los datos de la demo viven en `js/` y lo
  que se cambia se guarda en el `localStorage` del navegador.
- **La base de datos** (`db/`, PostgreSQL 16). Es la versión real de todo lo
  que hace el sitio: cuentas con contraseña cifrada, reservas que no se pueden
  superponer, materiales para alumnos, perfiles profesionales con currículum
  en PDF, recursos según la materia, postulaciones, selección directa,
  preferencias y avisos. Las reglas las hace cumplir la propia base.
- **La API** (`backend/`, FastAPI). Expone la base por HTTP, con sesión y
  permisos por rol.

> El sitio todavía **no está conectado** a la API: sigue funcionando con
> `localStorage`. La base y la API ya tienen los mismos datos y las mismas
> reglas, así que el próximo paso es cambiar cada llamada de `js/` por un
> `fetch()` al endpoint que corresponde (están en la tabla de
> [Del mockup al backend](#del-mockup-al-backend)).

---

## Cómo abrir la página

**Doble clic en `Abrir Polo 2 Gestion.bat`** (Windows). Levanta un servidor local
y abre el navegador en `http://localhost:8080/index.html`. Para apagarlo, se
cierra la ventana negra.

- Si la computadora tiene Python 3, usa su servidor. Si no, usa uno que trae
  Windows (`herramientas/servidor.ps1`): no hay que instalar nada.
- Si el 8080 está ocupado, prueba el 8081, 8082… y avisa cuál usó.
- Solo se puede entrar desde la misma computadora (escucha en 127.0.0.1).

> **Al pasar a una versión nueva** no hace falta borrar nada del navegador.
> Cada página pide sus archivos con el número de versión
> (`js/reservas.js?v=4.3.1`), y el servidor del `.bat` manda
> `Cache-Control: no-cache`. Así el navegador nunca mezcla páginas nuevas con
> código viejo: eso era lo que en la v4.2 hacía que un estudiante viera el
> saludo del admin y las reservas de un profesor. **Si cambiás un `.js` o el
> `.css`, subí ese número en todos los `.html`.**

¿Por qué no alcanza con abrir `index.html` con doble clic? Porque así la página
se abre como `file://`, y los navegadores solo dejan usar el micrófono (dictado
por voz y aplausos) en `https://` o en `localhost`. El resto del sitio funciona
igual de las dos formas.

## Cómo probarlo

### Solo el frontend (lo más rápido)

No hace falta instalar nada: alcanza con abrir **`index.html`** en el navegador.

Si tenés Python instalado, conviene levantarlo con un servidor local para que
todo se comporte igual que en producción:

```bash
python3 -m http.server 5500
```

Y entrar a <http://localhost:5500>.

### La base de datos

**Doble clic en `Base de datos.bat`** (Windows). Abre un menú:

| Opción | Qué hace |
| ------ | -------- |
| 1 | Levanta PostgreSQL y Adminer con Docker. La primera vez crea las tablas y carga la demo |
| 2 | Lo mismo, más la API en <http://localhost:8000/docs> |
| 3 | Corre las 93 pruebas de `db/pruebas.sql` (no modifican nada) |
| 4 | Abre una consola SQL (`psql`) |
| 5 | Resetear: borra todo y vuelve a cargar la demo |
| 6 | Apagar (los datos quedan para la próxima) |
| 7 | **Sin Docker:** carga todo en un PostgreSQL instalado en la compu (14 o más nuevo) |
| 8 | **Sin Docker:** levanta la API con Python (crea su propio entorno en `backend/.venv`) |

> **Si ya usaste la base de la v4.1 con Docker**, usá una vez la opción 5
> (Resetear): Postgres carga `schema.sql` y `seed.sql` solo la primera vez, y la
> v4.2 agrega tablas y columnas nuevas. Lo mismo con un PostgreSQL instalado:
> volvé a correr la opción 7.

Las opciones 1 a 6 necesitan [Docker Desktop](https://www.docker.com/products/docker-desktop/)
abierto. Si ya tenés PostgreSQL instalado, la 7 y la 8 hacen lo mismo sin Docker.

**Adminer** (para mirar las tablas desde el navegador) queda en
<http://localhost:8081> — el 8080 lo usa el sitio:

| Campo         | Valor        |
| ------------- | ------------ |
| Sistema       | PostgreSQL   |
| Servidor      | `db`         |
| Usuario       | `polotec`    |
| Contraseña    | `polotec`    |
| Base de datos | `polotec`    |

Para conectarse desde DBeaver, pgAdmin o VS Code: `localhost:5432`, mismo
usuario y contraseña.

En Mac o Linux, lo mismo a mano:

```bash
docker compose up -d                  # base + Adminer
docker compose --profile api up -d    # base + Adminer + API
docker compose exec -T db psql -U polotec -d polotec -f /polotec-db/pruebas.sql
docker compose down -v                # borrar todo (al levantar, recarga la demo)
```

> Las claves `polotec`/`polotec` y `POLO_SECRETO` del `docker-compose.yml` son
> para desarrollo local. Los puertos escuchan solo en `127.0.0.1`.

### La API

Con la base levantada, la opción 2 u 8 de `Base de datos.bat`, o a mano:

```bash
cd backend
pip install -r requirements.txt
python main.py
```

En <http://localhost:8000/docs> está la documentación interactiva: cada
endpoint tiene un botón **Try it out**. Para probar los que piden sesión,
primero `POST /api/v1/auth/login` con una cuenta de prueba, copiar el `token`
y pegarlo en **Authorize**. La API también sirve el sitio, en
<http://localhost:8000/index.html>.

`python prueba_api.py` recorre todos los endpoints con cada rol (87
comprobaciones, incluidas las de materiales para alumnos, currículum en PDF y
sonidos). Crea datos de verdad, así que después conviene resetear.

---

## Cuentas de prueba

En el sitio (`login.html`) se entra **solo con el email**, porque todavía no
usa la API. En la base y en la API, **todas las cuentas tienen la contraseña
`demo1234`**, guardada con bcrypt (nunca en texto plano). Son las mismas
cuentas de `js/sesion.js`:

| Rol        | Email                             | Entra a                       |
| ---------- | --------------------------------- | ----------------------------- |
| Estudiante | `maria@estudiante.com`            | `dashboard-estudiante.html` (hub) |
| Estudiante | `facundo@estudiante.com`          | igual, con currículum de ejemplo |
| Profesor   | `ana@polotec.edu.uy`              | `dashboard-profesor.html`     |
| Empresa    | `contacto@techcorp.com`           | `dashboard-empresa.html`      |
| Empresa    | `contacto@industriasnorte.com`    | igual, pero pendiente de aprobación |
| Admin      | `admin@polotec.edu.uy`            | `dashboard-admin.html`        |

> La cuenta de Industrias del Norte sirve para ver el aviso de "cuenta
> pendiente de aprobación", que es el estado `pending_approval` de la tabla
> `companies`.

La **agenda pública** (`agenda-publica.html`) se puede ver sin iniciar sesión:
es la pantalla para alumnos y público general.

---

## Qué hace cada pantalla

### Reservas (lo principal)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-profesor.html` | Profesor | En este orden: salones y laboratorios (con sus herramientas), materiales con el formulario, y sus reservas. Pide salones, laboratorios o materiales; avisa en vivo si el horario está libre y deja cancelar los pedidos pendientes. |
| `dashboard-estudiante-reservas.html` | Estudiante | El mismo orden. Abre las herramientas de cada salón y pide **solo materiales**; ve y cancela sus propios pedidos. |
| `dashboard-admin-reservas.html` | Admin | Aprueba o rechaza los pedidos (los de alumnos dicen "(alumno)"), con filtros por tipo, y ve el inventario; cada salón abre su ficha. |
| `agenda-publica.html` | Cualquiera | Muestra solo las reservas ya aprobadas y a futuro, en tabla o agrupadas por día. |

### Pasantías (módulo adicional)

| Pantalla | Quién | Qué hace |
| -------- | ----- | -------- |
| `dashboard-estudiante-pasantias.html` | Estudiante | Su perfil profesional (con currículum en PDF), pasantías recomendadas con filtro por modalidad, postularse y el estado de cada postulación. |
| `dashboard-empresa.html` | Empresa | Publica pasantías, revisa postulantes, busca en el directorio de perfiles y abre el currículum de cada estudiante. |
| `dashboard-admin-pasantias.html` | Admin | Aprueba empresas nuevas y agenda las entrevistas. |

### Recursos según la materia

La calculadora ya no está en todos los salones: cada uno muestra solo lo que le
sirve. Se abre con **Ver recursos** en la tarjeta del salón.

| Salón | Herramientas |
| ----- | ------------ |
| Laboratorio de Física | calculadora, constantes físicas, conversor de unidades |
| Laboratorio de Química | calculadora, masa molar de una fórmula, conversor |
| Laboratorio de Ciencias | calculadora, conversor |
| Laboratorio de Robótica | calculadora, ley de Ohm, colores de resistencias, bases numéricas |
| Sala de Informática | calculadora, bases numéricas |
| Biblioteca, Conferencias, Auditorio, Reuniones docentes, Cancha | ninguna |

Cada salón muestra también los **materiales que se usan ahí** (la Cancha:
equipo de sonido, micrófono y parlante), cada uno con su botón **Pedir**.

- **Biblioteca Ceibal** (Biblioteca País, `bibliotecapais.ceibal.edu.uy`): solo
  en los salones de estudio, no en el Auditorio ni en la Cancha.
- **PETS**: en todos los salones. **Falta la dirección**: mientras
  `ENLACES_DEL_POLO.pets` esté vacío, el botón dice "Enlace pendiente".
- **Todo se edita en un solo lugar:** `RECURSOS_POR_SALON` y `ENLACES_DEL_POLO`
  en `js/espacios.js`. La base tiene lo mismo (`resources.tools`,
  `resources.study_room` y `resource_materials`): si se cambia algo, hay que
  cambiarlo también en `db/seed.sql`.

Las herramientas no usan `eval()`: la calculadora tiene su propio intérprete
(potencias, raíces, trigonometría en grados o radianes, logaritmos, factorial,
`Ans`), la masa molar entiende paréntesis, corchetes e hidratos (`CuSO4·5H2O`),
y la ley de Ohm y las resistencias aceptan prefijos (`4.7k`, `20m`).

### Currículum en PDF: el límite del prototipo

El archivo queda guardado **solo en el navegador donde se subió** (en
IndexedDB, porque `localStorage` no aguanta 5 MB). Una empresa que entre desde
otra computadora ve el aviso **"No se encontró el archivo"**. Los dos perfiles
de ejemplo con CV (Facundo y Valentina) arman el PDF al vuelo con sus datos, así
la demo anda en cualquier lado. Con el backend real, el archivo va al servidor
(`PUT /api/v1/perfil/cv`, tabla `student_cv`) y ahí se repiten las validaciones.

`dashboard-admin.html` y `dashboard-estudiante.html` son hubs: el panel de
entrada, que resume las dos áreas y lleva a cada una.

### El puente entre los dos módulos

Es la parte más interesante del diseño: cuando una postulación llega al estado
`selected`, necesita una sala para la entrevista. En vez de coordinarla por
mail, el admin la reserva con un clic desde
`dashboard-admin-pasantias.html`, y eso genera una reserva normal de la Sala de
Conferencias — el mismo motor, la misma tabla `bookings` — enlazada a la
postulación por `related_application_id`.

---

## Estructura del proyecto

```
Polo 2 Gestión/
├── index.html                      Landing pública
├── login.html                      Ingreso (por email, mock)
├── registro-*.html                 Registro de estudiante / profesor / empresa
├── agenda-publica.html             Agenda sin login
├── dashboard-*.html                Un panel por rol (admin y estudiante: hub + Reservas + Pasantías)
│
├── css/
│   └── styles.css                  Todo el diseño: tokens, tipografía y componentes
│
├── js/
│   ├── sesion.js                   Sesión, roles, buscador y menú (compartido)
│   ├── ui.js                       Avisos, modales y preferencias (compartido)
│   ├── perfil.js                   Menú de perfil: editar, configurar, salir (compartido)
│   ├── calendario.js               Calendario anual de reservas (compartido)
│   ├── asistente.js                Asistente de voz que guía por el sitio (compartido)
│   ├── iconos.js                   Íconos SVG (compartido)
│   ├── movimiento.js               Maqueta 3D, paletas, revelados e inclinación (compartido)
│   ├── autenticacion.js            Login y registros
│   ├── reservas.js                 Reservas (compartidas entre paneles) + paneles del admin
│   ├── espacios.js                 Recursos según la materia: herramientas, materiales, enlaces
│   ├── curriculum.js               Currículum en PDF: validar, guardar, ver
│   ├── sonidos.js                  Sonidos al tocar (Web Audio, sin archivos)
│   ├── aplausos.js                 Dos aplausos: el asistente en grande, en el centro
│   ├── bolsa.js                    Perfiles, pasantías y postulaciones compartidos
│   ├── script.js                   Panel del estudiante (perfil profesional incluido)
│   └── empresa.js                  Panel de la empresa
│
├── db/
│   ├── schema.sql                  Tablas, reglas (triggers), funciones y vistas
│   ├── seed.sql                    Los mismos datos que muestra la demo
│   ├── pruebas.sql                 93 pruebas de las reglas (no modifican nada)
│   └── consultas-ejemplo.sql       Lo que pide cada pantalla, en SQL
│
├── backend/
│   ├── main.py                     API (FastAPI): sesión, permisos y endpoints
│   ├── prueba_api.py               Recorre todos los endpoints con cada rol
│   └── requirements.txt
│
├── fonts/
│   ├── archivo.woff2               Archivo variable (peso 100–900, ancho 62–125 %)
│   └── roboto-serif-italic.woff2   Roboto Serif cursiva variable (peso 100–900, tamaño óptico)
├── img/                            Isotipo y fotos del Polo
├── herramientas/servidor.ps1       Servidor local (lo usa el .bat)
├── herramientas/servidor.py        El mismo, con Python y sin caché (si hay Python)
├── Abrir Polo 2 Gestion.bat        Doble clic: abre la página en localhost
├── Base de datos.bat               Doble clic: menú de la base y la API
└── docker-compose.yml              PostgreSQL + Adminer (+ API)
```

Cuatro archivos de `js/` se cargan en varias páginas y evitan repetir código:
**`sesion.js`** (control de acceso por rol, buscador del menú y navegación entre
secciones), **`ui.js`** (avisos, modales y preferencias, que reemplazan a los
`alert()` del navegador), **`perfil.js`** (el menú del avatar) y
**`calendario.js`** (el calendario anual).

### Menú de perfil

El avatar del navbar abre un menú con tres opciones:

- **Editar perfil** — cambia el nombre y el email de la cuenta; el saludo y el
  avatar se actualizan al instante, sin recargar.
- **Configuración** — preferencias que el resto de la app respeta de verdad:
  apagar los avisos emergentes, apagar las confirmaciones antes de acciones
  importantes, y elegir con qué vista abre la agenda pública.
- **Cerrar sesión** — ahora pide confirmación (antes el ícono cerraba la sesión
  de un clic, sin avisar).

### Calendario anual

Está en el panel del profesor (solo sus reservas), en el panel de reservas del
admin (todas) y en la agenda pública. Muestra los doce meses juntos, marca los
días con reservas —más intenso cuando hay tres o más—, señala el día de hoy, y
al tocar un día se despliega el detalle abajo. Se puede filtrar por estado y
cambiar de año.

### Asistente de voz

El botón chico del borde derecho abre un panel con un hexágono vivo y un chat.
El hexágono es un `<polygon>` SVG deformado por un filtro `feTurbulence` +
`feDisplacementMap`: en reposo apenas respira en azul, al escuchar se pone
amarillo 938 C y el borde ondula más, y al hablar late en un azul más claro. Guía por el sitio. Entiende
dos formas de pedir lo mismo:

- **"Llevame a reservar un salón"** → te lleva directo a esa sección.
- **"¿Dónde está la reserva de salones?"** → te explica dónde está y te ofrece
  llevarte; podés contestarle "sí" por voz o tocar el botón.

Está **adaptado al rol de la sesión**: un alumno no puede ser enviado al panel
del profesor ni al del admin. Si lo pide, el asistente le responde que esa
sección es de otro perfil. Los atajos que muestra también cambian según quién
esté usando el sitio.

Tres aclaraciones sobre cómo funciona, porque no es lo que suele asumirse:

1. **La voz la pone el navegador**, con la Web Speech API
   (`SpeechRecognition` para escuchar, `speechSynthesis` para hablar). No se
   manda audio a ningún servidor ni hace falta una clave de API.
2. **La interpretación es local**: no hay un modelo de lenguaje detrás, sino un
   puntaje por palabras clave contra el mapa de destinos de `js/asistente.js`.
   Alcanza para "llevame a X" y "dónde está X", y mantiene el proyecto sin
   backend como el resto del mockup.
3. **El micrófono necesita `https://` o `localhost`.** Si se abre el HTML con
   doble clic (`file://`) el navegador lo bloquea, por eso el asistente siempre
   ofrece además escribir el pedido en un campo de texto.

El hexágono solo se anima **mientras el panel está abierto** (y nunca con
"reducir movimiento" activado): al cerrarlo se corta el `requestAnimationFrame`, así no gasta CPU ni batería en el resto de las
pantallas.

Se puede apagar (y silenciar sus respuestas habladas) desde Configuración.

> Las fechas de las reservas de ejemplo se calculan **relativas al día de hoy**
> (`fechaRelativa()` en `js/reservas.js`), no escritas a mano. Así la demo nunca
> se vence: si tuvieran fechas fijas, pasado ese mes la agenda quedaría vacía.

---

## Del mockup al backend

Cada acción del sitio ya tiene su endpoint en la API. Para conectar una
pantalla, se cambia la función de `js/` que hoy lee o escribe `localStorage`
por un `fetch()` a la ruta de esta tabla (todas empiezan con `/api/v1`):

| Acción en pantalla | Endpoint | En la base |
| ------------------ | -------- | ---------- |
| Iniciar sesión | `POST /auth/login` → token | `fn_login` (bcrypt) |
| Registrarse | `POST /auth/registro` | `fn_registrar` |
| Mi cuenta y preferencias | `GET /yo` · `PUT /yo/preferencias` | `user_preferences` |
| Campanita de avisos | `GET /avisos` · `POST /avisos/leidos` | `notifications` (las crean triggers) |
| Agenda pública | `GET /agenda` | `v_agenda_publica` |
| Salones y materiales | `GET /recursos?tipo=` · `GET /disponibilidad` | `v_recursos` |
| Ficha del salón ("Ver recursos") | `GET /recursos/:codigo` | `resources.tools`, `resource_materials` |
| Pedir una reserva (alumno: solo materiales) | `POST /reservas` | `fn_solicitar_reserva` + trigger `validar_reserva` |
| Mis reservas · cancelar | `GET /reservas/mias` · `POST /reservas/:id/cancelar` | `bookings` |
| Aprobar / rechazar reserva | `GET /reservas/pendientes` · `POST /reservas/:id/decision` | `fn_decidir_reserva` |
| Tablero y calendario anual | `GET /estadisticas` · `GET /calendario/:año` | `v_estadisticas_reservas` |
| Pasantías recomendadas | `GET /pasantias?modalidad=` | `v_pasantias_visibles` |
| Postularse · mis postulaciones | `POST /pasantias/:id/postulaciones` · `GET /postulaciones/mias` | `fn_postular` |
| Perfil profesional | `GET /perfil` · `PUT /perfil` | `v_perfiles`, `fn_completitud` |
| Currículum en PDF | `PUT /perfil/cv` (el cuerpo es el PDF) · `DELETE /perfil/cv` · `GET /perfil/cv` | `fn_guardar_cv`, `student_cv` |
| Ver currículum (empresa) | `GET /perfiles/:id/cv` | `student_cv` |
| Publicar / cerrar pasantía | `POST /pasantias` · `POST /pasantias/:id/cerrar` | `internships` |
| Postulantes de mi empresa | `GET /empresa/postulantes` · `GET /empresa/pasantias` | `v_postulantes` |
| Directorio de perfiles | `GET /perfiles?q=` · `GET /perfiles/:id` | `v_perfiles` |
| Aceptar o seleccionar estudiante | `POST /empresa/decisiones` | `fn_decidir_postulacion` |
| Aprobar empresas | `GET /empresas?estado=` · `POST /empresas/:id/revision` | `companies` |
| Entrevistas por agendar | `GET /entrevistas-por-agendar` | `v_entrevistas_por_agendar` |

Los errores vuelven con el mensaje en castellano que escribe la base, listo
para mostrar en un aviso: *"Ese horario ya está tomado para ese salón o
equipo. Elegí otro horario."* (409), *"Ya estás postulado a esta pasantía."*
(409), *"La empresa todavía no fue aprobada por el Polo…"* (422).

En `db/consultas-ejemplo.sql` está lo que pide cada pantalla escrito en SQL,
para probarlo a mano en Adminer.

## La base de datos por dentro

```
users ─┬─ user_preferences       (tema, avisos, asistente, voz, aplausos, vista de agenda)
       ├─ professors
       ├─ companies ── internships ── applications ──┐
       ├─ students ─┬─ student_skills ── skills       │  (postulación o selección directa)
       │            ├─ student_languages / titles / courses / experiences
       │            ├─ student_cv                     │  (el PDF, hasta 5 MB)
       │            └─ orientations                   │
       ├─ bookings ── resources ── resource_materials  │  (materiales que se usan en cada salón)
       │     └── related_application_id ─────────────┘  (sala para la entrevista)
       └─ notifications
```

Lo que la base hace cumplir sola, aunque alguien se saltee el sitio o la API:

- **No hay dos reservas superpuestas del mismo salón.** Un `EXCLUDE
  constraint` sobre el rango horario; dos pedidos al mismo tiempo, entra uno.
- **Los equipos con varias unidades se cuentan.** Dos proyectores a la misma
  hora, sí; un tercero, no. Un bloqueo por recurso evita que dos pedidos
  simultáneos se pasen del total (probado con pedidos en paralelo).
- **Los estudiantes reservan solo materiales**: si piden un salón o un
  laboratorio, la base lo rechaza aunque el pedido venga directo a la tabla.
- **El currículum tiene que ser un PDF de verdad**: hasta 5 MB y con la firma
  `%PDF-` al principio (CHECK en `student_cv`), y suma a la completitud.
- **Cada rol hace lo suyo**: reservan profesores, alumnos (materiales) y admin; solo el admin
  aprueba, una empresa pendiente no publica, una empresa solo decide sobre sus
  pasantías, nadie se registra como admin.
- **Los avisos se crean solos** (triggers): postulación nueva → a la empresa;
  aceptado o rechazado → al estudiante; reserva decidida → al profesor; cuenta
  revisada → a la empresa.
- **La completitud del perfil** se calcula con los mismos 11 bloques que
  `js/bolsa.js`, así el porcentaje coincide con el del sitio.
- **Las fechas de la demo son relativas a hoy** y la zona horaria es
  `America/Montevideo`: la agenda nunca queda vacía.

> Una diferencia con el sitio: en `js/reservas.js` cada equipo se reserva
> entero; la base ya admite pedir *unidades* (por ejemplo, 5 de las 15
> notebooks). Cuando se conecte la API, el formulario puede sumar ese campo.

### Una decisión de diseño que vale la pena mirar

El choque de horarios se valida **dos veces, a propósito**. En el navegador
(`js/reservas.js`) para avisar al instante, y en la base con un
`EXCLUDE constraint` de PostgreSQL sobre `bookings`, que impide físicamente
guardar dos reservas superpuestas del mismo recurso. La validación del
navegador es comodidad; la que garantiza que el dato sea correcto es la de la
base, porque es la única que no se puede saltear.


---

## Notas de diseño

**Color.** Dos tintas Pantone y nada más. El azul **P 105-8 C** (`#004789`) es
el edificio: estructura, botones y las superficies oscuras (derivadas de él,
como el azul noche `#00213F`). El amarillo **938 C** (`#FCEEA8`) es la luz:
marca lo reservado, lo que está pasando ahora y lo seleccionado. Nunca se usa de
fondo de página, porque sobre blanco no se ve y en superficies grandes se lee
como crema. Los neutros son fríos, para que la calidez la ponga solo el amarillo.

**Tipografía.** Dos familias, las dos viajan con el proyecto en `fonts/` (no
dependen de internet ni de Google Fonts):

- **Roboto Serif cursiva** para los titulares grandes (portada, secciones,
  ingreso, saludo de cada panel), en su peso más fino, 100. Tiene tamaño óptico
  automático: a 100 px el trazo es un hilo con contraste de cartel, y en los
  títulos medianos (tarjetas de rol, comprobante, modales, año del calendario)
  la misma letra va en 300 para seguir siendo firme.
- **Archivo** para todo lo demás: interfaz, formularios, títulos chicos y
  números (con cifras tabulares, para alinear en columna). Los títulos chicos
  bajaron a ancho normal y peso 650: el expandido pesado al lado del hilo de
  serif quedaba gritón.

**El letrero de la portada.** El titular "Tu salón, reservado en minutos" es un
letrero 3D (`tituloEn3D` en `js/movimiento.js`): cada letra es una pila de diez
capas hacia atrás, con la cara en blanco o en amarillo 938 C y el canto
hundiéndose en los azules del P 105-8 C. Las letras se paran una por una, el
volumen crece hacia atrás, y cada 7 s una ola recorre el letrero cambiando
blanco por amarillo. Con el mouse se mueve el punto de fuga y el canto se ve
desde otro lado. Para un lector de pantalla es una sola frase normal, y con
"reducir movimiento" el letrero queda quieto pero conserva el volumen.

**La maqueta.** El objeto de la portada es una maqueta 3D del Polo hecha con CSS:
cada salón es una caja con techo, frente y costado. Los salones con ventanas
encendidas en amarillo están reservados. Las cajas crecen desde el piso al
cargar, las ventanas se encienden después, y cada tanto un salón se enciende o
se apaga: el edificio está en uso. La misma maqueta aparece en el ingreso y en
los encabezados de cada panel, y en versión chica como objeto de cada rol (un
salón, una pila de postulaciones, una torre de oficinas).

**El tablero de llegadas.** Los números de las métricas y los horarios de la
agenda pública son paletas que giran sobre su bisagra hasta caer en su valor,
como los tableros de las estaciones. La agenda entera es ese tablero, colgado
sobre la foto del edificio.

**Del pedido a la agenda.** En la portada, un comprobante de reserva cambia de
estado según el paso que se está leyendo: pendiente, sellado "Aprobada", y al
final se da vuelta y muestra su línea en la agenda pública.

**Movimiento.** Curvas propias (nunca `ease-in`, que arranca lento justo cuando
la persona está mirando), respuesta al presionar en menos de 100 ms, y todo
hover detrás de `@media (hover: hover) and (pointer: fine)`. Los bloques entran
con una leve inclinación 3D al aparecer en pantalla, una sola vez; las listas
que se repintan al filtrar no se reaniman. Todo lo que se mueve vive en
`js/movimiento.js` y solo lee lo que ya pintaron los demás archivos: no toca
datos ni lógica.

**Paneles con sesión.** Cada panel (profesor, estudiante, empresa, admin)
abre con una portada a todo el ancho: el saludo como letrero 3D, la maqueta del
rol que gira con el mouse y la foto del Polo detrás. Los números cuelgan del
borde de la portada como el cartel de llegadas de una estación (el profesor
tiene su propio tablero: aprobadas, esperando aprobación y la próxima reserva).
Abajo, el trabajo va en dos columnas: pedir a la izquierda, seguir lo pedido a
la derecha.

**El mouse como linterna.** Cuatro efectos con la misma idea, todos en
`js/movimiento.js` (sección 9) y apagados en pantallas táctiles y con "reducir
movimiento":
- detrás de la página está la cuadrícula del plano del edificio, y solo se ve
  alrededor del mouse;
- el borde de cada panel se enciende en el punto más cercano al mouse;
- en las portadas, la foto se corre, la luz sigue al mouse y el punto de fuga
  del letrero 3D cambia;
- los botones principales se inclinan apenas hacia el mouse (efecto imán).

**Perfil profesional y bolsa de pasantías.** Cada estudiante arma su perfil
desde su panel ("Editar perfil profesional"): orientación, año, disponibilidad,
un texto sobre sí, capacidades e idiomas (se suman con Enter), títulos y
certificaciones, cursos y capacitaciones, experiencia y pasantías anteriores, y
links. La barra de "Perfil completo" se calcula con lo que está completo y dice
qué falta. Las empresas ven ese perfil en dos lugares: en "Postulantes" (quién se
postuló a cada pasantía, con Aceptar y Rechazar) y en "Perfiles de estudiantes"
(un directorio con buscador por capacidad, orientación o curso, desde donde
pueden seleccionar a alguien aunque no se haya postulado). Lo que decide la
empresa le aparece al estudiante en "Mis postulaciones".

Para que los dos paneles vean lo mismo, perfiles, pasantías y postulaciones
viven en una sola bolsa compartida (`js/bolsa.js`, guardada en el localStorage
del navegador, como la sesión). Todo lo que escribe un estudiante se escapa antes
de mostrarse: un `<script>` en "Sobre mí" aparece como texto. Cuentas de
estudiante para probar: maria@, facundo@, valentina@, camila@, joaquin@ y
sofia@estudiante.com.

**Agenda pública con sesión iniciada.** Si ya entraste, el menú de la agenda
muestra con qué cuenta estás y "Ir a mi panel" en lugar de "Iniciar sesión".

**Asistente a pedido: dos aplausos.** Con "Abrir con aplausos" encendido (en el
panel del asistente o en Configuración), el sitio escucha el micrófono y, al oír
dos aplausos seguidos, abre el asistente en grande en el centro de la pantalla
con una entrada animada: dos ondas hexagonales (una por aplauso) y el hexágono
que se arma con seis piezas que llegan volando. Dice "A sus órdenes" y se queda
escuchando: contesta en voz alta y vuelve a escuchar solo, hasta que le digas
"gracias" o lo cierres (Esc). También se puede abrir sin aplaudir con el botón ⤢
del panel, y escribir el pedido si no hay micrófono.

Cómo distingue un aplauso (`js/aplausos.js`): el sonido se analiza en el hilo de
audio del navegador (AudioWorklet), sin grabar ni mandar nada a ningún lado. Un
aplauso sube de golpe, cae en menos de 45 ms y después queda en silencio; la voz
vuelve a subir enseguida con la sílaba siguiente. Hacen falta dos golpes con
0,18 a 0,75 s entre sí y que no venga un tercero (así no lo dispara una ronda de
aplausos ni el teclado). Probado con grabaciones sintéticas de aplausos, voz,
eco de sala y con la página cargada.

Requisitos: Chrome o Edge (el dictado por voz de Firefox no existe todavía; ahí
se puede escribir), abrir la página con el `.bat` (localhost) y, en cada visita,
un primer clic en la página: los navegadores no dejan que una página empiece a
escuchar o hablar sola. Para no tener que hacer ni ese clic, en Chrome:
candado de la barra de direcciones → Configuración del sitio → Sonido:
Permitir. En salas con mucho eco, conviene aplaudir más cerca de la computadora.

**Modo oscuro.** Se elige en Configuración (Automático, Claro u Oscuro);
"Automático" sigue al sistema. El tema se aplica con un script mínimo en el
`<head>` de cada página, antes de pintar, así no hay destello blanco al cargar.
Los colores salen de tokens con un solo uso cada uno: `--azul` es relleno
(botones, días ocupados) y `--azul-texto` es el azul para links e íconos, porque
en oscuro el relleno pide un azul más profundo y el texto uno más claro. Lo que
va sobre amarillo usa `--sobre-amarillo`, que no cambia nunca, y las paletas
del tablero (`--pala-arriba` / `--pala-abajo`) son siempre azul noche, en los
dos temas. Auditado igual que el claro: 0 problemas de contraste en las once
páginas y sus estados (menú de perfil, Configuración, asistente).

**Accesibilidad.** Auditado con axe-core: 0 violaciones WCAG 2 A/AA en las diez
páginas. Foco de teclado visible en todos los controles, texto real detrás de
cada paleta para lectores de pantalla, y con "reducir movimiento" se van las
caídas, giros y el 3D, pero se conservan los cambios de opacidad y color, que
son los que explican qué cambió.
