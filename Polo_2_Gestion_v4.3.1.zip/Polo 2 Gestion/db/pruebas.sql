-- ================================================================
-- POLO 2 GESTIÓN · PRUEBAS DE LA BASE DE DATOS
-- ----------------------------------------------------------------
-- Comprueba, contra la base real, que cada regla de negocio se
-- cumpla: login con bcrypt, roles, la regla de no superponer
-- reservas, las unidades de los equipos, postulaciones, selección
-- directa, avisos automáticos, completitud del perfil, vistas...
--
-- Corre todo dentro de una transacción que al final se DESHACE
-- (ROLLBACK): se puede ejecutar las veces que se quiera sin tocar
-- los datos de prueba.
--
--   psql -U polotec -d polotec -f db/pruebas.sql
--
-- Al final muestra una tabla con cada prueba y su resultado. Si
-- alguna falla, termina con error.
-- Requiere haber cargado schema.sql y seed.sql.
-- ================================================================
SET client_encoding TO 'UTF8';   -- los acentos se leen bien aunque psql corra en una consola de Windows
\set ON_ERROR_STOP on
\pset footer off
SET client_min_messages TO warning;
SET timezone TO 'America/Montevideo';
BEGIN;

CREATE TEMP TABLE resultado (n SERIAL, prueba TEXT, ok BOOLEAN, detalle TEXT);

CREATE FUNCTION pg_temp.probar(p_prueba TEXT, p_ok BOOLEAN, p_detalle TEXT DEFAULT NULL) RETURNS VOID LANGUAGE sql AS $$
  INSERT INTO resultado (prueba, ok, detalle) VALUES (p_prueba, COALESCE(p_ok, false), p_detalle);
$$;

-- Ejecuta un SQL que TIENE que fallar; anota si falló y con qué mensaje.
CREATE FUNCTION pg_temp.debe_fallar(p_prueba TEXT, p_sql TEXT, p_debe_decir TEXT DEFAULT NULL) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    EXECUTE p_sql;
    PERFORM pg_temp.probar(p_prueba, false, 'no falló y tenía que fallar');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.probar(p_prueba, p_debe_decir IS NULL OR SQLERRM ILIKE '%' || p_debe_decir || '%', SQLERRM);
  END;
END $$;

-- Atajos para las cuentas de prueba
CREATE FUNCTION pg_temp.u(p_email TEXT) RETURNS UUID LANGUAGE sql AS $$ SELECT id FROM users WHERE email = p_email::citext $$;
CREATE FUNCTION pg_temp.r(p_code TEXT) RETURNS UUID LANGUAGE sql AS $$ SELECT id FROM resources WHERE code = p_code $$;
CREATE FUNCTION pg_temp.p(p_titulo TEXT) RETURNS UUID LANGUAGE sql AS $$ SELECT id FROM internships WHERE title = p_titulo $$;

-- ---------------------------------------------------------------
-- CUENTAS Y LOGIN
-- ---------------------------------------------------------------
DO $$ BEGIN
  PERFORM pg_temp.probar('Login con la contraseña correcta',
    (SELECT count(*) = 1 FROM fn_login('admin@polotec.edu.uy', 'demo1234')));
  PERFORM pg_temp.probar('Login sin distinguir mayúsculas en el email',
    (SELECT count(*) = 1 FROM fn_login('ANA@PoloTec.edu.uy', 'demo1234')));
  PERFORM pg_temp.probar('Login con contraseña incorrecta no entra',
    (SELECT count(*) = 0 FROM fn_login('admin@polotec.edu.uy', 'otra-cosa')));
  PERFORM pg_temp.probar('La contraseña no se guarda en texto plano',
    (SELECT password_hash LIKE '$2a$%' AND password_hash <> 'demo1234' FROM users WHERE email = 'admin@polotec.edu.uy'));
  UPDATE users SET active = false WHERE email = 'diego@polotec.edu.uy';
  PERFORM pg_temp.probar('Una cuenta dada de baja no puede entrar',
    (SELECT count(*) = 0 FROM fn_login('diego@polotec.edu.uy', 'demo1234')));
  UPDATE users SET active = true WHERE email = 'diego@polotec.edu.uy';
  PERFORM pg_temp.probar('El login registra la fecha del último acceso',
    (SELECT last_login_at IS NOT NULL FROM users WHERE email = 'admin@polotec.edu.uy'));
END $$;

DO $$
DECLARE nuevo UUID;
BEGIN
  nuevo := fn_registrar('student', 'nuevo@estudiante.com', 'clave-segura-1', 'Lucas', 'Méndez');
  PERFORM pg_temp.probar('Registrar estudiante crea cuenta, perfil y preferencias',
    EXISTS (SELECT 1 FROM students WHERE user_id = nuevo) AND EXISTS (SELECT 1 FROM user_preferences WHERE user_id = nuevo));
  PERFORM pg_temp.probar('Las preferencias arrancan con los valores del sitio',
    (SELECT theme = 'auto' AND assistant AND assistant_voice AND NOT clap_to_open AND agenda_view = 'tabla'
       FROM user_preferences WHERE user_id = nuevo));
  PERFORM pg_temp.probar('Un perfil recién creado está al 0 %', fn_completitud(nuevo) = 0);
END $$;

SELECT pg_temp.debe_fallar('No se repite un email (aunque cambien las mayúsculas)',
  $q$ SELECT fn_registrar('student', 'MARIA@estudiante.com', 'clave-segura-1', 'Otra', 'María') $q$);
SELECT pg_temp.debe_fallar('Contraseña de menos de 8 caracteres',
  $q$ SELECT fn_registrar('student', 'corta@estudiante.com', '123', 'X', 'Y') $q$, '8 caracteres');
SELECT pg_temp.debe_fallar('No se puede registrar un admin desde el sitio',
  $q$ SELECT fn_registrar('admin', 'otro-admin@polotec.edu.uy', 'clave-segura-1', 'X') $q$, 'rol');
SELECT pg_temp.debe_fallar('Email con formato inválido',
  $q$ INSERT INTO users (email, password_hash, role, display_name) VALUES ('sin-arroba', 'x', 'student', 'X') $q$);
SELECT pg_temp.debe_fallar('Una cuenta de empresa no puede tener perfil de estudiante',
  $q$ INSERT INTO students (user_id, first_name, last_name) VALUES (pg_temp.u('contacto@techcorp.com'), 'X', 'Y') $q$, 'rol');
SELECT pg_temp.debe_fallar('Tema inválido en las preferencias',
  $q$ UPDATE user_preferences SET theme = 'violeta' WHERE user_id = pg_temp.u('ana@polotec.edu.uy') $q$);
DO $$
DECLARE
  ana UUID := pg_temp.u('ana@polotec.edu.uy');
BEGIN
  PERFORM pg_temp.probar('Los sonidos al tocar arrancan prendidos, estilo cálido, volumen 60 (como el sitio)',
    (SELECT click_sounds AND sound_style = 'calido' AND sound_volume = 60 FROM user_preferences WHERE user_id = ana));
END $$;
SELECT pg_temp.debe_fallar('El estilo de sonido tiene que ser uno de los cinco',
  $q$ UPDATE user_preferences SET sound_style = 'sirena' WHERE user_id = pg_temp.u('ana@polotec.edu.uy') $q$);
SELECT pg_temp.debe_fallar('El volumen de los sonidos va de 0 a 100',
  $q$ UPDATE user_preferences SET sound_volume = 150 WHERE user_id = pg_temp.u('ana@polotec.edu.uy') $q$);

-- ---------------------------------------------------------------
-- RESERVAS: la regla principal de la consigna
-- ---------------------------------------------------------------
DO $$
DECLARE
  ana UUID := pg_temp.u('ana@polotec.edu.uy');
  diego UUID := pg_temp.u('diego@polotec.edu.uy');
  sala UUID := pg_temp.r('r3');       -- Sala de Conferencias
  manana TIMESTAMPTZ := (current_date + 10) + time '10:00';
  b1 UUID;
BEGIN
  b1 := fn_solicitar_reserva(ana, sala, 'Clase de prueba', manana, manana + interval '2 hours');
  PERFORM pg_temp.probar('Un profesor pide una reserva y queda pendiente',
    (SELECT status = 'pending' FROM bookings WHERE id = b1));

  BEGIN
    PERFORM fn_solicitar_reserva(diego, sala, 'Se superpone', manana + interval '1 hour', manana + interval '3 hours');
    PERFORM pg_temp.probar('NO se puede reservar el mismo salón en un horario superpuesto', false, 'se aceptó la superposición');
  EXCEPTION WHEN exclusion_violation THEN
    PERFORM pg_temp.probar('NO se puede reservar el mismo salón en un horario superpuesto', SQLERRM ILIKE '%ya está tomado%', SQLERRM);
  END;

  BEGIN
    PERFORM fn_solicitar_reserva(diego, sala, 'Pegada a la anterior', manana + interval '2 hours', manana + interval '3 hours');
    PERFORM pg_temp.probar('Se puede reservar justo cuando termina la anterior (10–12 y 12–13)', true);
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.probar('Se puede reservar justo cuando termina la anterior (10–12 y 12–13)', false, SQLERRM);
  END;

  PERFORM fn_solicitar_reserva(diego, pg_temp.r('r2'), 'Otro salón, misma hora', manana, manana + interval '2 hours');
  PERFORM pg_temp.probar('La misma hora en OTRO salón sí se puede', true);

  UPDATE bookings SET status = 'cancelled' WHERE id = b1;
  BEGIN
    PERFORM fn_solicitar_reserva(diego, sala, 'Ahora sí', manana, manana + interval '1 hour');
    PERFORM pg_temp.probar('Una reserva cancelada libera el horario', true);
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.probar('Una reserva cancelada libera el horario', false, SQLERRM);
  END;
END $$;

-- ---------------------------------------------------------------
-- ESTUDIANTES: SOLO MATERIALES (v4.2)
-- ---------------------------------------------------------------
SELECT pg_temp.debe_fallar('Un estudiante no puede reservar un salón',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('maria@estudiante.com'), pg_temp.r('r1'), 'X', (current_date + 12) + time '09:00', (current_date + 12) + time '10:00') $q$,
  'solo pueden reservar materiales');
SELECT pg_temp.debe_fallar('Un estudiante no puede reservar un laboratorio aunque inserte directo en la tabla',
  $q$ INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at) VALUES (pg_temp.r('r4'), pg_temp.u('maria@estudiante.com'), 'X', (current_date + 12) + time '09:00', (current_date + 12) + time '10:00') $q$,
  'lo tiene que pedir un profesor');
SELECT pg_temp.debe_fallar('Una empresa no puede pedir reservas',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('contacto@techcorp.com'), pg_temp.r('r7'), 'X', (current_date + 12) + time '09:00', (current_date + 12) + time '10:00') $q$,
  'Solo profesores, estudiantes');
DO $$
DECLARE
  maria   UUID := pg_temp.u('maria@estudiante.com');
  pedido  UUID;
BEGIN
  pedido := fn_solicitar_reserva(maria, pg_temp.r('r13'), 'Trabajo en grupo', (current_date + 12) + time '14:00', (current_date + 12) + time '16:00', 5::smallint);
  PERFORM pg_temp.probar('Un estudiante sí puede reservar un material (5 de las 15 notebooks)',
    (SELECT status = 'pending' AND quantity = 5 FROM bookings WHERE id = pedido));
  PERFORM pg_temp.probar('En la cola del admin, el pedido de un alumno lleva "(alumno)"',
    (SELECT pedida_por = 'María González (alumno)' AND rol_solicitante = 'student' FROM v_reservas_pendientes WHERE id = pedido));
  PERFORM fn_decidir_reserva(pg_temp.u('admin@polotec.edu.uy'), pedido, 'approved');
  PERFORM pg_temp.probar('Al aprobarla, el aviso del alumno lleva a SU página de reservas',
    EXISTS (SELECT 1 FROM notifications WHERE user_id = maria AND kind = 'reserva_decidida'
             AND link = 'dashboard-estudiante-reservas.html#seccion-mis-reservas'));
  PERFORM pg_temp.probar('La agenda pública también aclara "(alumno)"',
    (SELECT a_cargo_de = 'María González (alumno)' FROM v_agenda_publica WHERE id = pedido));
END $$;
SELECT pg_temp.debe_fallar('A un alumno también se le aplica el choque de horarios (la TV está tomada)',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('maria@estudiante.com'), pg_temp.r('r8'), 'X', (current_date + 4) + time '16:30', (current_date + 4) + time '17:30') $q$,
  'ya está tomado');

-- ---------------------------------------------------------------
-- RECURSOS SEGÚN LA MATERIA (v4.2)
-- ---------------------------------------------------------------
DO $$ BEGIN
  PERFORM pg_temp.probar('Química tiene calculadora, masa molar y conversor',
    (SELECT herramientas = ARRAY['calculadora', 'masaMolar', 'conversor'] FROM v_recursos WHERE codigo = 'r5'));
  PERFORM pg_temp.probar('La Cancha no tiene herramientas ni banner de Ceibal, y sugiere sonido, micrófono y parlante',
    (SELECT herramientas = '{}' AND NOT biblioteca_ceibal AND materiales_sugeridos = ARRAY['r14', 'r15', 'r16'] FROM v_recursos WHERE codigo = 'r11'));
  PERFORM pg_temp.probar('El Auditorio no muestra el banner de Biblioteca Ceibal',
    (SELECT NOT biblioteca_ceibal FROM v_recursos WHERE codigo = 'r9'));
END $$;
SELECT pg_temp.debe_fallar('Una herramienta que no existe no se puede asignar',
  $q$ UPDATE resources SET tools = ARRAY['calculadora', 'tabla periodica'] WHERE code = 'r5' $q$);
SELECT pg_temp.debe_fallar('Un material no tiene herramientas de materia',
  $q$ UPDATE resources SET tools = ARRAY['calculadora'] WHERE code = 'r7' $q$);
SELECT pg_temp.debe_fallar('"Materiales que se usan acá" solo admite materiales',
  $q$ INSERT INTO resource_materials (space_id, material_id) VALUES (pg_temp.r('r11'), pg_temp.r('r4')) $q$,
  'Solo se pueden sugerir materiales');
SELECT pg_temp.debe_fallar('No se puede reservar en el pasado',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('ana@polotec.edu.uy'), pg_temp.r('r1'), 'X', now() - interval '2 days', now() - interval '2 days' + interval '1 hour') $q$,
  'pasado');
SELECT pg_temp.debe_fallar('La hora de fin tiene que ser después del inicio',
  $q$ INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at) VALUES (pg_temp.r('r1'), pg_temp.u('ana@polotec.edu.uy'), 'X', (current_date + 12) + time '11:00', (current_date + 12) + time '10:00') $q$);
SELECT pg_temp.debe_fallar('Una reserva no puede durar días',
  $q$ INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at) VALUES (pg_temp.r('r1'), pg_temp.u('ana@polotec.edu.uy'), 'X', (current_date + 12) + time '08:00', (current_date + 14) + time '08:00') $q$);

DO $$ BEGIN
  UPDATE resources SET active = false WHERE code = 'r8';
END $$;
SELECT pg_temp.debe_fallar('Un recurso dado de baja no se puede reservar',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('ana@polotec.edu.uy'), pg_temp.r('r8'), 'X', (current_date + 12) + time '09:00', (current_date + 12) + time '10:00') $q$,
  'dado de baja');
UPDATE resources SET active = true WHERE code = 'r8';

-- Equipos con varias unidades: hay 2 proyectores.
DO $$
DECLARE
  hora TIMESTAMPTZ := (current_date + 15) + time '14:00';
BEGIN
  PERFORM fn_solicitar_reserva(pg_temp.u('ana@polotec.edu.uy'), pg_temp.r('r7'), 'Proyector 1', hora, hora + interval '2 hours');
  PERFORM fn_solicitar_reserva(pg_temp.u('diego@polotec.edu.uy'), pg_temp.r('r7'), 'Proyector 2', hora, hora + interval '2 hours');
  PERFORM pg_temp.probar('Los 2 proyectores se pueden reservar a la misma hora', true);
  BEGIN
    PERFORM fn_solicitar_reserva(pg_temp.u('lucia@polotec.edu.uy'), pg_temp.r('r7'), 'Proyector 3', hora + interval '1 hour', hora + interval '3 hours');
    PERFORM pg_temp.probar('Un tercer proyector a esa hora NO (solo hay 2)', false, 'se aceptó');
  EXCEPTION WHEN exclusion_violation THEN
    PERFORM pg_temp.probar('Un tercer proyector a esa hora NO (solo hay 2)', true, SQLERRM);
  END;
  PERFORM fn_solicitar_reserva(pg_temp.u('ana@polotec.edu.uy'), pg_temp.r('r13'), 'Media clase', hora, hora + interval '1 hour', 10::smallint);
  BEGIN
    PERFORM fn_solicitar_reserva(pg_temp.u('diego@polotec.edu.uy'), pg_temp.r('r13'), 'La otra mitad', hora, hora + interval '1 hour', 6::smallint);
    PERFORM pg_temp.probar('Notebooks: 10 + 6 no entran en 15', false, 'se aceptó');
  EXCEPTION WHEN exclusion_violation THEN
    PERFORM pg_temp.probar('Notebooks: 10 + 6 no entran en 15', true, SQLERRM);
  END;
  PERFORM fn_solicitar_reserva(pg_temp.u('diego@polotec.edu.uy'), pg_temp.r('r13'), 'La otra mitad', hora, hora + interval '1 hour', 5::smallint);
  PERFORM pg_temp.probar('Notebooks: 10 + 5 sí entran en 15', true);
END $$;
SELECT pg_temp.debe_fallar('No se pueden pedir más unidades de las que hay',
  $q$ SELECT fn_solicitar_reserva(pg_temp.u('ana@polotec.edu.uy'), pg_temp.r('r7'), 'X', (current_date + 20) + time '09:00', (current_date + 20) + time '10:00', 3::smallint) $q$,
  'tiene 2');

-- Aprobar y rechazar
DO $$
DECLARE
  admin UUID := pg_temp.u('admin@polotec.edu.uy');
  pendiente UUID;
  avisos_antes INT;
BEGIN
  SELECT id INTO pendiente FROM bookings WHERE title = 'Reunión de coordinación docente';
  SELECT count(*) INTO avisos_antes FROM notifications WHERE user_id = pg_temp.u('ana@polotec.edu.uy');
  PERFORM fn_decidir_reserva(admin, pendiente, 'approved');
  PERFORM pg_temp.probar('El admin aprueba una reserva pendiente',
    (SELECT status = 'approved' AND decided_at IS NOT NULL AND decided_by = admin FROM bookings WHERE id = pendiente));
  PERFORM pg_temp.probar('Al profesor le llega el aviso de la aprobación',
    (SELECT count(*) = avisos_antes + 1 FROM notifications WHERE user_id = pg_temp.u('ana@polotec.edu.uy')));
  PERFORM pg_temp.probar('La reserva aprobada aparece en la agenda pública',
    EXISTS (SELECT 1 FROM v_agenda_publica WHERE id = pendiente));
END $$;
SELECT pg_temp.debe_fallar('Una reserva ya decidida no se vuelve a decidir',
  $q$ SELECT fn_decidir_reserva(pg_temp.u('admin@polotec.edu.uy'), (SELECT id FROM bookings WHERE title = 'Reunión de coordinación docente'), 'rejected') $q$,
  'ya fue decidida');
SELECT pg_temp.debe_fallar('Un profesor no puede aprobar reservas',
  $q$ SELECT fn_decidir_reserva(pg_temp.u('ana@polotec.edu.uy'), (SELECT id FROM bookings WHERE title = 'Taller de programación'), 'approved') $q$,
  'administración');

DO $$ BEGIN
  PERFORM pg_temp.probar('La agenda pública solo muestra aprobadas de hoy en adelante',
    NOT EXISTS (SELECT 1 FROM v_agenda_publica a JOIN bookings b ON b.id = a.id WHERE b.status <> 'approved' OR b.ends_at < now()));
  PERFORM pg_temp.probar('Los datos de la demo no tienen reservas superpuestas',
    NOT EXISTS (SELECT 1 FROM bookings x JOIN bookings y ON x.resource_id = y.resource_id AND x.id < y.id
                 WHERE x.exclusive AND x.status IN ('pending', 'approved') AND y.status IN ('pending', 'approved')
                   AND tstzrange(x.starts_at, x.ends_at) && tstzrange(y.starts_at, y.ends_at)));
END $$;

-- ---------------------------------------------------------------
-- PERFIL PROFESIONAL
-- ---------------------------------------------------------------
DO $$
DECLARE
  maria UUID := pg_temp.u('maria@estudiante.com');
BEGIN
  PERFORM pg_temp.probar('El perfil de María está al 82 % (le faltan Experiencia y Currículum), igual que en el sitio',
    fn_completitud(maria) = 82 AND fn_bloques_faltantes(maria) = ARRAY['Experiencia', 'Currículum']);
  INSERT INTO student_experiences (student_id, role, place, period) VALUES (maria, 'Ayudante de informática', 'Liceo 1', '2025');
  PERFORM pg_temp.probar('Al sumar experiencia, el perfil pasa al 91 %', fn_completitud(maria) = 91);
  PERFORM fn_guardar_cv(maria, 'Mi CV', convert_to('%PDF-1.4 curriculum de prueba', 'UTF8'));
  PERFORM pg_temp.probar('Al subir el currículum, llega al 100 % (11 de 11 bloques)', fn_completitud(maria) = 100);
  PERFORM pg_temp.probar('fn_guardar_cv le agrega ".pdf" al nombre si no lo tiene',
    (SELECT file_name = 'Mi CV.pdf' AND size_bytes = 29 FROM student_cv WHERE student_id = maria));
  PERFORM fn_guardar_cv(maria, 'CV nuevo.pdf', convert_to('%PDF-1.7 otro', 'UTF8'));
  PERFORM pg_temp.probar('Reemplazar el currículum deja uno solo, el nuevo',
    (SELECT count(*) = 1 AND min(file_name) = 'CV nuevo.pdf' FROM student_cv WHERE student_id = maria));
  PERFORM pg_temp.probar('El perfil (v_perfiles) muestra nombre y tamaño del currículum, no el archivo',
    (SELECT curriculum->>'nombre' = 'CV nuevo.pdf' AND (curriculum->>'tamano')::int = 13 FROM v_perfiles WHERE student_id = maria));
  DELETE FROM student_cv WHERE student_id = maria;
  PERFORM pg_temp.probar('Al quitar el currículum vuelve a faltar ese bloque',
    fn_completitud(maria) = 91 AND 'Currículum' = ANY (fn_bloques_faltantes(maria)));

  PERFORM fn_guardar_capacidades(maria, ARRAY['JavaScript', 'javascript', 'Excel', '  ', 'Python']);
  PERFORM pg_temp.probar('Capacidades: "JavaScript" y "javascript" son la misma, y se ignoran las vacías',
    (SELECT capacidades = ARRAY['JavaScript', 'Excel', 'Python'] FROM v_perfiles WHERE student_id = maria));
  PERFORM pg_temp.probar('Una capacidad nueva queda en el catálogo para buscar', EXISTS (SELECT 1 FROM skills WHERE name = 'excel'));
  PERFORM pg_temp.probar('El perfil arma títulos, cursos y experiencia como listas',
    (SELECT json_array_length(titulos) = 1 AND json_array_length(cursos) = 1 AND json_array_length(experiencia) = 1
       FROM v_perfiles WHERE student_id = maria));
END $$;
SELECT pg_temp.debe_fallar('No se cargan una orientación del catálogo y una escrita a la vez',
  $q$ UPDATE students SET orientation_id = 1, orientation_other = 'Otra' WHERE user_id = pg_temp.u('maria@estudiante.com') $q$);
SELECT pg_temp.debe_fallar('"Sobre vos" tiene un máximo de 400 caracteres',
  $q$ UPDATE students SET about = repeat('a', 401) WHERE user_id = pg_temp.u('maria@estudiante.com') $q$);
SELECT pg_temp.debe_fallar('El año de un título tiene que ser razonable',
  $q$ INSERT INTO student_titles (student_id, name, year) VALUES (pg_temp.u('maria@estudiante.com'), 'X', 3025) $q$);
SELECT pg_temp.debe_fallar('Currículum: un archivo que no empieza como PDF se rechaza aunque se llame .pdf',
  $q$ SELECT fn_guardar_cv(pg_temp.u('maria@estudiante.com'), 'cv.pdf', convert_to('MZ esto es un ejecutable', 'UTF8')) $q$,
  'no es un PDF');
SELECT pg_temp.debe_fallar('Currículum: más de 5 MB se rechaza',
  $q$ SELECT fn_guardar_cv(pg_temp.u('maria@estudiante.com'), 'cv.pdf', convert_to('%PDF-', 'UTF8') || decode(repeat('00', 5242880), 'hex')) $q$,
  'máximo es 5 MB');
SELECT pg_temp.debe_fallar('Currículum: aunque se inserte directo en la tabla, la firma %PDF- se exige',
  $q$ INSERT INTO student_cv (student_id, file_name, content) VALUES (pg_temp.u('camila@estudiante.com'), 'cv.pdf', convert_to('hola mundo', 'UTF8')) $q$);
SELECT pg_temp.debe_fallar('Currículum: el nombre guardado tiene que terminar en .pdf',
  $q$ INSERT INTO student_cv (student_id, file_name, content) VALUES (pg_temp.u('camila@estudiante.com'), 'cv.exe', convert_to('%PDF-1.4', 'UTF8')) $q$);

-- ---------------------------------------------------------------
-- PASANTÍAS Y POSTULACIONES
-- ---------------------------------------------------------------
SELECT pg_temp.debe_fallar('Una empresa sin aprobar no puede publicar pasantías',
  $q$ INSERT INTO internships (company_id, title, modality, duration_months) VALUES (pg_temp.u('contacto@industriasnorte.com'), 'X', 'presencial', 3) $q$,
  'no fue aprobada');
SELECT pg_temp.debe_fallar('Una pasantía dura de 1 a 12 meses',
  $q$ INSERT INTO internships (company_id, title, modality, duration_months) VALUES (pg_temp.u('contacto@techcorp.com'), 'X', 'remoto', 18) $q$);

DO $$
DECLARE
  maria UUID := pg_temp.u('maria@estudiante.com');
  techcorp UUID := pg_temp.u('contacto@techcorp.com');
  avisos_empresa INT;
  avisos_maria INT;
BEGIN
  SELECT count(*) INTO avisos_empresa FROM notifications WHERE user_id = techcorp;
  PERFORM fn_postular(maria, pg_temp.p('Desarrollador Frontend Jr'));
  PERFORM pg_temp.probar('Un estudiante se postula y queda en revisión',
    (SELECT estado = 'pending' AND origen = 'postulacion' FROM v_mis_postulaciones WHERE student_id = maria AND pasantia = 'Desarrollador Frontend Jr'));
  PERFORM pg_temp.probar('A la empresa le llega el aviso de la postulación',
    (SELECT count(*) = avisos_empresa + 1 FROM notifications WHERE user_id = techcorp AND kind = 'postulacion_nueva'));

  SELECT count(*) INTO avisos_maria FROM notifications
   WHERE user_id = maria AND kind = 'postulacion_decidida' AND title LIKE '%te eligió%';
  PERFORM fn_decidir_postulacion(techcorp, maria, pg_temp.p('Soporte de Datos'), 'approved');
  PERFORM pg_temp.probar('La empresa acepta a María para "Soporte de Datos"',
    (SELECT status = 'approved' AND decided_at IS NOT NULL FROM applications
      WHERE student_id = maria AND internship_id = pg_temp.p('Soporte de Datos')));
  PERFORM pg_temp.probar('María recibe el aviso de que la eligieron',
    (SELECT count(*) = avisos_maria + 1 FROM notifications WHERE user_id = maria AND kind = 'postulacion_decidida' AND title LIKE '%te eligió%'));
  PERFORM pg_temp.probar('Lo ve como seleccionada en "Mis postulaciones"',
    (SELECT estado = 'approved' FROM v_mis_postulaciones WHERE student_id = maria AND pasantia = 'Soporte de Datos'));
END $$;

DO $$
DECLARE
  camila UUID := pg_temp.u('camila@estudiante.com');
  techcorp UUID := pg_temp.u('contacto@techcorp.com');
BEGIN
  PERFORM fn_decidir_postulacion(techcorp, camila, pg_temp.p('Desarrollador Frontend Jr'), 'approved');
  PERFORM pg_temp.probar('Selección directa desde el directorio (sin postulación previa)',
    (SELECT status = 'approved' AND origin = 'seleccion_directa' FROM applications
      WHERE student_id = camila AND internship_id = pg_temp.p('Desarrollador Frontend Jr')));
  PERFORM pg_temp.probar('La seleccionada aparece en los postulantes de la empresa',
    EXISTS (SELECT 1 FROM v_postulantes WHERE company_id = techcorp AND nombre = 'Camila Núñez' AND origen = 'seleccion_directa'));
  PERFORM pg_temp.probar('Los postulantes por revisar aparecen primero',
    (SELECT estado = 'pending' FROM v_postulantes WHERE company_id = techcorp LIMIT 1));
  PERFORM pg_temp.probar('Los postulantes traen hasta 3 capacidades principales',
    (SELECT bool_and(cardinality(capacidades_principales) <= 3) FROM v_postulantes));
END $$;

SELECT pg_temp.debe_fallar('No se puede postular dos veces a la misma pasantía',
  $q$ SELECT fn_postular(pg_temp.u('maria@estudiante.com'), pg_temp.p('Desarrollador Frontend Jr')) $q$, 'Ya estás postulado');
SELECT pg_temp.debe_fallar('Una empresa no decide sobre pasantías de otra',
  $q$ SELECT fn_decidir_postulacion(pg_temp.u('rrhh@agrotacua.com.uy'), pg_temp.u('facundo@estudiante.com'), pg_temp.p('Desarrollador Frontend Jr'), 'approved') $q$,
  'no es de tu empresa');
SELECT pg_temp.debe_fallar('Estado de decisión inválido',
  $q$ SELECT fn_decidir_postulacion(pg_temp.u('contacto@techcorp.com'), pg_temp.u('facundo@estudiante.com'), pg_temp.p('Desarrollador Frontend Jr'), 'quizas') $q$,
  'inválido');

DO $$
DECLARE
  techcorp UUID := pg_temp.u('contacto@techcorp.com');
  borrador UUID;
BEGIN
  INSERT INTO internships (company_id, title, modality, duration_months, status)
  VALUES (techcorp, 'Borrador sin publicar', 'remoto', 3, 'draft') RETURNING id INTO borrador;
  PERFORM pg_temp.probar('Una pasantía en borrador no la ven los estudiantes',
    NOT EXISTS (SELECT 1 FROM v_pasantias_visibles WHERE id = borrador));
  BEGIN
    PERFORM fn_postular(pg_temp.u('facundo@estudiante.com'), borrador);
    PERFORM pg_temp.probar('No se puede postular a un borrador', false, 'se aceptó');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.probar('No se puede postular a un borrador', SQLERRM ILIKE '%no está abierta%', SQLERRM);
  END;
  UPDATE internships SET status = 'published' WHERE id = borrador;
  PERFORM pg_temp.probar('Al publicarla, aparece y queda con fecha de publicación',
    EXISTS (SELECT 1 FROM v_pasantias_visibles WHERE id = borrador AND publicada IS NOT NULL));
END $$;

DO $$
DECLARE
  industrias UUID := pg_temp.u('contacto@industriasnorte.com');
BEGIN
  UPDATE companies SET status = 'active', reviewed_by = pg_temp.u('admin@polotec.edu.uy') WHERE user_id = industrias;
  PERFORM pg_temp.probar('Al aprobar una empresa, le llega el aviso',
    EXISTS (SELECT 1 FROM notifications WHERE user_id = industrias AND kind = 'empresa_revisada'));
  INSERT INTO internships (company_id, title, modality, duration_months) VALUES (industrias, 'Mantenimiento de planta', 'presencial', 4);
  PERFORM pg_temp.probar('Ya aprobada, puede publicar pasantías',
    EXISTS (SELECT 1 FROM v_pasantias_visibles WHERE titulo = 'Mantenimiento de planta'));
END $$;

-- El puente entre módulos: entrevista en una sala del Polo
DO $$
DECLARE
  valentina_app UUID;
BEGIN
  SELECT application_id INTO valentina_app FROM v_entrevistas_por_agendar WHERE estudiante = 'Valentina Silveira';
  PERFORM pg_temp.probar('Una postulación aceptada queda como "entrevista por agendar"', valentina_app IS NOT NULL);
  INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at, related_application_id)
  VALUES (pg_temp.r('r3'), pg_temp.u('admin@polotec.edu.uy'), 'Entrevista de pasantía',
          (current_date + 30) + time '10:00', (current_date + 30) + time '10:45', valentina_app);
  PERFORM pg_temp.probar('Al reservarle la sala, deja de estar por agendar',
    NOT EXISTS (SELECT 1 FROM v_entrevistas_por_agendar WHERE application_id = valentina_app));
END $$;

-- ---------------------------------------------------------------
-- INTEGRIDAD
-- ---------------------------------------------------------------
DO $$
DECLARE
  sofia UUID := pg_temp.u('sofia@estudiante.com');
BEGIN
  DELETE FROM users WHERE id = sofia;
  PERFORM pg_temp.probar('Al borrar una cuenta se borran su perfil, capacidades y postulaciones',
    NOT EXISTS (SELECT 1 FROM students WHERE user_id = sofia)
    AND NOT EXISTS (SELECT 1 FROM student_skills WHERE student_id = sofia)
    AND NOT EXISTS (SELECT 1 FROM applications WHERE student_id = sofia)
    AND NOT EXISTS (SELECT 1 FROM user_preferences WHERE user_id = sofia));
  DELETE FROM users WHERE email = 'valentina@estudiante.com';
  PERFORM pg_temp.probar('Al borrar una cuenta se borra también su currículum',
    (SELECT count(*) = 1 FROM student_cv));
END $$;

-- ---------------------------------------------------------------
-- RESULTADO
-- ---------------------------------------------------------------
SELECT n AS "#", CASE WHEN ok THEN 'OK' ELSE 'FALLA' END AS resultado, prueba,
       CASE WHEN NOT ok THEN detalle END AS detalle
  FROM resultado ORDER BY n;

SELECT count(*) FILTER (WHERE ok) || ' de ' || count(*) || ' pruebas pasan' AS resumen FROM resultado;

DO $$
DECLARE fallas INT;
BEGIN
  SELECT count(*) INTO fallas FROM resultado WHERE NOT ok;
  IF fallas > 0 THEN
    RAISE EXCEPTION '% prueba(s) fallaron: mirá la tabla de arriba.', fallas;
  END IF;
END $$;

-- Nada de lo que hicieron las pruebas queda guardado.
ROLLBACK;
