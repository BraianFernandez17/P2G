-- ================================================================
-- POLO 2 GESTIÓN · ESQUEMA DE BASE DE DATOS (PostgreSQL 16) · v4.3
-- ----------------------------------------------------------------
-- Refleja todo lo que hace la versión actual del sitio:
--
--   · Cuentas y roles (estudiante, profesor, empresa, admin) con
--     contraseña hasheada de verdad (bcrypt, vía pgcrypto).
--   · Preferencias de cada cuenta (tema, avisos, asistente de voz,
--     abrir con aplausos, vista de la agenda, sonidos al tocar).
--   · MÓDULO PRINCIPAL: inventario de salones, laboratorios y
--     materiales, y reservas con la regla "no puede haber dos reservas
--     en el mismo lugar al mismo tiempo" garantizada por la base.
--     Profesores y admin reservan cualquier cosa; los estudiantes,
--     solo materiales (proyector, tele, notebooks, sonido…).
--   · Recursos según la materia: qué herramientas tiene cada salón
--     (calculadora, conversor, masa molar…) y qué materiales se
--     suelen usar ahí (lo mismo que RECURSOS_POR_SALON en js/espacios.js).
--   · MÓDULO ADICIONAL: perfil profesional del estudiante
--     (orientación, capacidades, idiomas, títulos, cursos,
--     experiencia, links, currículum en PDF), pasantías,
--     postulaciones y la selección directa de una empresa desde el
--     directorio de perfiles.
--   · Avisos (notificaciones) que se generan solos con triggers.
--
-- Las reglas de negocio viven en la base (restricciones, triggers
-- y funciones), no solo en el JavaScript: así se cumplen aunque
-- mañana se conecte otra aplicación.
--
-- Se corre de punta a punta sin errores sobre una base vacía:
--   psql -U polotec -d polotec -f db/schema.sql
-- Después: db/seed.sql (datos de prueba) y db/pruebas.sql (pruebas).
-- ================================================================

-- ---------------------------------------------------------------
-- 0. EXTENSIONES Y ZONA HORARIA
-- ---------------------------------------------------------------
SET client_encoding TO 'UTF8';   -- los acentos se leen bien aunque psql corra en una consola de Windows
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid(), crypt(), gen_salt('bf')
CREATE EXTENSION IF NOT EXISTS citext;     -- emails y etiquetas sin distinguir mayúsculas
CREATE EXTENSION IF NOT EXISTS btree_gist; -- para la restricción de exclusión de reservas

-- Las reservas se ven y se piden en hora de Uruguay.
DO $$
BEGIN
  EXECUTE format('ALTER DATABASE %I SET timezone TO %L', current_database(), 'America/Montevideo');
END $$;
SET timezone TO 'America/Montevideo';

-- ---------------------------------------------------------------
-- 1. CUENTAS
-- ---------------------------------------------------------------
-- Tabla raíz del login: todos tienen una fila acá, sin importar el
-- rol. El perfil de cada rol cuelga de esta tabla (1 a 1).
CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          CITEXT NOT NULL UNIQUE
                 CHECK (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  password_hash  TEXT NOT NULL,              -- bcrypt; nunca la contraseña en texto plano
  role           TEXT NOT NULL
                 CHECK (role IN ('student', 'professor', 'company', 'admin')),
  display_name   VARCHAR(150) NOT NULL,      -- lo que se ve en el saludo y en el avatar
  active         BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at  TIMESTAMPTZ
);

-- Las mismas opciones de "Configuración" del menú de perfil
-- (js/ui.js, PREFERENCIAS_POR_DEFECTO). Se crea sola al crear la
-- cuenta (trigger más abajo), con los mismos valores por defecto.
CREATE TABLE user_preferences (
  user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  theme            TEXT NOT NULL DEFAULT 'auto' CHECK (theme IN ('auto', 'claro', 'oscuro')),
  show_toasts      BOOLEAN NOT NULL DEFAULT true,   -- avisos emergentes
  ask_confirmation BOOLEAN NOT NULL DEFAULT true,   -- preguntar antes de cancelar/rechazar/salir
  assistant        BOOLEAN NOT NULL DEFAULT true,   -- mostrar el asistente de voz
  assistant_voice  BOOLEAN NOT NULL DEFAULT true,   -- que conteste en voz alta
  clap_to_open     BOOLEAN NOT NULL DEFAULT false,  -- dos aplausos abren el asistente (usa el micrófono)
  agenda_view      TEXT NOT NULL DEFAULT 'tabla' CHECK (agenda_view IN ('tabla', 'dia')),
  click_sounds     BOOLEAN NOT NULL DEFAULT true,   -- sonido al tocar botones (js/sonidos.js)
  sound_style      TEXT NOT NULL DEFAULT 'calido'
                   CHECK (sound_style IN ('calido', 'suave', 'burbuja', 'mecanico', 'retro')),
  sound_volume     SMALLINT NOT NULL DEFAULT 60 CHECK (sound_volume BETWEEN 0 AND 100),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE professors (
  user_id     UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  first_name  VARCHAR(100) NOT NULL,
  last_name   VARCHAR(100) NOT NULL,
  department  VARCHAR(120)
);

-- Una empresa nace "pendiente de aprobación": hasta que el admin la
-- aprueba no puede publicar pasantías (ver trigger de internships).
CREATE TABLE companies (
  user_id      UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  legal_name   VARCHAR(200) NOT NULL,
  sector       TEXT NOT NULL DEFAULT 'servicios'
               CHECK (sector IN ('tecnologia', 'industria', 'agropecuaria', 'comercio', 'servicios',
                                 'educacion', 'salud', 'construccion', 'turismo', 'logistica')),
  status       TEXT NOT NULL DEFAULT 'pending_approval'
               CHECK (status IN ('pending_approval', 'active', 'suspended', 'rejected')),
  phone        VARCHAR(40),
  website      VARCHAR(300),
  reviewed_by  UUID REFERENCES users(id),
  reviewed_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------
-- 2. PERFIL PROFESIONAL DEL ESTUDIANTE
-- ---------------------------------------------------------------
-- Las orientaciones que sugiere el editor (js/bolsa.js, ORIENTACIONES).
-- Si la del estudiante no está, la escribe: va en orientation_other.
CREATE TABLE orientations (
  id    SMALLSERIAL PRIMARY KEY,
  name  VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE students (
  user_id            UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  first_name         VARCHAR(100) NOT NULL,
  last_name          VARCHAR(100) NOT NULL,
  orientation_id     SMALLINT REFERENCES orientations(id),
  orientation_other  VARCHAR(150),
  level              TEXT CHECK (level IN ('primero', 'segundo', 'tercero', 'egresado')),
  locality           VARCHAR(100),
  availability       TEXT CHECK (availability IN ('medio_tiempo', 'tiempo_completo', 'fines_de_semana', 'a_coordinar')),
  about              VARCHAR(400),                    -- "Sobre vos" (400 caracteres, como el editor)
  linkedin_url       VARCHAR(300),
  portfolio_url      VARCHAR(300),                    -- GitHub o portfolio
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- O una orientación del catálogo, o una escrita a mano; no las dos.
  CHECK (orientation_id IS NULL OR orientation_other IS NULL)
);

-- Capacidades como etiquetas normalizadas: "JavaScript" y
-- "javascript" son la misma, y una empresa puede buscar por ellas.
CREATE TABLE skills (
  id    SERIAL PRIMARY KEY,
  name  CITEXT NOT NULL UNIQUE CHECK (length(name) BETWEEN 1 AND 40)
);

CREATE TABLE student_skills (
  student_id  UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  skill_id    INT NOT NULL REFERENCES skills(id),
  position    SMALLINT NOT NULL DEFAULT 0,            -- el orden en que las cargó
  PRIMARY KEY (student_id, skill_id)
);

CREATE TABLE student_languages (
  id          BIGSERIAL PRIMARY KEY,
  student_id  UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  label       CITEXT NOT NULL CHECK (length(label) BETWEEN 1 AND 40),   -- ej: "Inglés B1"
  position    SMALLINT NOT NULL DEFAULT 0,
  UNIQUE (student_id, label)
);

CREATE TABLE student_titles (
  id           BIGSERIAL PRIMARY KEY,
  student_id   UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  name         VARCHAR(200) NOT NULL,                  -- título o certificación
  institution  VARCHAR(200),
  year         SMALLINT CHECK (year BETWEEN 1950 AND 2100),
  position     SMALLINT NOT NULL DEFAULT 0
);

CREATE TABLE student_courses (
  id           BIGSERIAL PRIMARY KEY,
  student_id   UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  name         VARCHAR(200) NOT NULL,                  -- curso o capacitación
  institution  VARCHAR(200),
  detail       VARCHAR(60),                            -- duración o año: "40 horas", "2025"
  position     SMALLINT NOT NULL DEFAULT 0
);

-- Currículum en PDF: uno por estudiante. Las mismas validaciones que
-- el navegador (js/curriculum.js) y la API: hasta 5 MB y que el
-- archivo EMPIECE como un PDF ("%PDF-"), no solo que se llame .pdf.
CREATE TABLE student_cv (
  student_id   UUID PRIMARY KEY REFERENCES students(user_id) ON DELETE CASCADE,
  file_name    VARCHAR(200) NOT NULL CHECK (file_name ~* '\.pdf$'),
  content      BYTEA NOT NULL
               CHECK (octet_length(content) BETWEEN 5 AND 5242880)
               CHECK (substring(content FROM 1 FOR 5) = '\x255044462d'::bytea),  -- "%PDF-"
  size_bytes   INT GENERATED ALWAYS AS (octet_length(content)) STORED,
  uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE student_experiences (
  id          BIGSERIAL PRIMARY KEY,
  student_id  UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  role        VARCHAR(200) NOT NULL,                   -- puesto o tarea
  place       VARCHAR(200),
  period      VARCHAR(60),                             -- "2024 – 2025", "Verano 2025"
  position    SMALLINT NOT NULL DEFAULT 0
);

CREATE INDEX ON student_skills (skill_id);
CREATE INDEX ON student_languages (student_id);
CREATE INDEX ON student_titles (student_id);
CREATE INDEX ON student_courses (student_id);
CREATE INDEX ON student_experiences (student_id);

-- ---------------------------------------------------------------
-- 3. PASANTÍAS Y POSTULACIONES
-- ---------------------------------------------------------------
CREATE TABLE internships (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id       UUID NOT NULL REFERENCES companies(user_id) ON DELETE CASCADE,
  title            VARCHAR(200) NOT NULL,
  description      TEXT,
  modality         TEXT NOT NULL CHECK (modality IN ('remoto', 'presencial', 'hibrido')),
  duration_months  SMALLINT NOT NULL CHECK (duration_months BETWEEN 1 AND 12),
  status           TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'closed')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at     TIMESTAMPTZ
);

CREATE INDEX ON internships (company_id);
CREATE INDEX ON internships (status);

-- Una postulación nace de dos formas (origin):
--   · 'postulacion'       → el estudiante se postuló;
--   · 'seleccion_directa' → la empresa lo encontró en el directorio
--                           de perfiles y lo eligió sin que se postulara.
-- En los dos casos el estudiante lo ve en "Mis postulaciones".
CREATE TABLE applications (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id     UUID NOT NULL REFERENCES students(user_id) ON DELETE CASCADE,
  internship_id  UUID NOT NULL REFERENCES internships(id) ON DELETE CASCADE,
  status         TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn')),
  origin         TEXT NOT NULL DEFAULT 'postulacion'
                 CHECK (origin IN ('postulacion', 'seleccion_directa')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at     TIMESTAMPTZ,
  decided_by     UUID REFERENCES users(id),
  UNIQUE (student_id, internship_id)                  -- no dos veces a la misma pasantía
);

CREATE INDEX ON applications (internship_id, status);

-- ---------------------------------------------------------------
-- 4. RESERVAS DE SALONES, LABORATORIOS Y EQUIPOS (módulo principal)
-- ---------------------------------------------------------------
-- code es el mismo id que usa el frontend (r1, r2, ...), para poder
-- cruzar los datos de la demo con los de la base sin traducir.
CREATE TABLE resources (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code            VARCHAR(10) NOT NULL UNIQUE,
  name            VARCHAR(150) NOT NULL UNIQUE,
  type            TEXT NOT NULL CHECK (type IN ('espacio', 'laboratorio', 'equipo')),
  total_quantity  SMALLINT NOT NULL DEFAULT 1 CHECK (total_quantity > 0),  -- 2 proyectores, 15 notebooks...
  capacity        SMALLINT CHECK (capacity > 0),                           -- personas (salones)
  active          BOOLEAN NOT NULL DEFAULT true,                           -- de baja sin borrar el historial
  -- Recursos según la materia (js/espacios.js, RECURSOS_POR_SALON):
  subject         VARCHAR(80),                                             -- "Física", "Química"…
  tools           TEXT[] NOT NULL DEFAULT '{}'
                  CHECK (tools <@ ARRAY['calculadora', 'constantes', 'conversor', 'masaMolar',
                                        'ohm', 'resistencias', 'bases']),
  study_room      BOOLEAN NOT NULL DEFAULT false,                          -- muestra el banner de Biblioteca Ceibal
  CHECK (type <> 'equipo' OR (tools = '{}' AND NOT study_room))            -- un material no tiene herramientas
);

-- "Materiales que se usan acá": qué materiales se sugieren en cada
-- salón (la Cancha: equipo de sonido, micrófono y parlante).
CREATE TABLE resource_materials (
  space_id     UUID NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  material_id  UUID NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  position     SMALLINT NOT NULL DEFAULT 0,
  PRIMARY KEY (space_id, material_id),
  CHECK (space_id <> material_id)
);

CREATE TABLE bookings (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_id             UUID NOT NULL REFERENCES resources(id),
  requested_by            UUID NOT NULL REFERENCES users(id),
  title                   VARCHAR(200) NOT NULL,       -- motivo: "Práctico de Física - 2do año"
  starts_at               TIMESTAMPTZ NOT NULL,
  ends_at                 TIMESTAMPTZ NOT NULL,
  quantity                SMALLINT NOT NULL DEFAULT 1 CHECK (quantity > 0),  -- cuántas unidades (equipos)
  status                  TEXT NOT NULL DEFAULT 'pending'
                          CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
  -- PUENTE ENTRE LOS DOS MÓDULOS: si la reserva es para la entrevista
  -- de una postulación, queda enlazada acá ("Reservar sala de
  -- entrevista" en el panel del admin). Si es NULL, es una reserva
  -- normal de un profesor.
  related_application_id  UUID REFERENCES applications(id) ON DELETE SET NULL,
  -- Lo completa un trigger según el recurso: true si hay una sola
  -- unidad (salones, laboratorios, la TV). Lo usa la restricción
  -- de exclusión de abajo.
  exclusive               BOOLEAN NOT NULL DEFAULT true,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_by              UUID REFERENCES users(id),
  decided_at              TIMESTAMPTZ,
  CHECK (ends_at > starts_at),
  CHECK (ends_at - starts_at <= interval '16 hours')   -- una reserva es de un día, no de una semana
);

CREATE INDEX ON bookings (requested_by);
CREATE INDEX ON bookings (status, starts_at);

-- EL criterio de aceptación más importante de la consigna:
-- "no puede haber dos reservas en el mismo lugar al mismo tiempo".
-- No lo calcula la aplicación (fácil de hacer mal y con carreras):
-- Postgres rechaza el INSERT/UPDATE si el horario [inicio, fin) de
-- un recurso de una sola unidad se toca con otra reserva pendiente
-- o aprobada. Dos pedidos simultáneos no pueden colarse los dos.
ALTER TABLE bookings ADD CONSTRAINT no_solapamiento_de_horarios
  EXCLUDE USING gist (
    resource_id WITH =,
    tstzrange(starts_at, ends_at, '[)') WITH &&
  )
  WHERE (status IN ('pending', 'approved') AND exclusive);

-- ---------------------------------------------------------------
-- 5. AVISOS (notificaciones)
-- ---------------------------------------------------------------
-- Se generan solos (triggers): a la empresa cuando alguien se
-- postula, al estudiante cuando lo aceptan o rechazan, al profesor
-- cuando le deciden una reserva, a la empresa cuando la aprueban.
CREATE TABLE notifications (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK (kind IN ('postulacion_nueva', 'postulacion_decidida',
                                            'reserva_decidida', 'empresa_revisada')),
  title       VARCHAR(200) NOT NULL,
  body        TEXT,
  link        VARCHAR(300),                            -- a qué parte del sitio lleva
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  read_at     TIMESTAMPTZ
);

CREATE INDEX ON notifications (user_id) WHERE read_at IS NULL;

-- ================================================================
-- 6. TRIGGERS: reglas que la base hace cumplir sola
-- ================================================================

-- Toda cuenta nueva arranca con las preferencias por defecto.
CREATE FUNCTION trg_crear_preferencias() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO user_preferences (user_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER crear_preferencias AFTER INSERT ON users
  FOR EACH ROW EXECUTE FUNCTION trg_crear_preferencias();

-- updated_at al día en cada cambio.
CREATE FUNCTION trg_tocar_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER tocar_updated_at BEFORE UPDATE ON user_preferences
  FOR EACH ROW EXECUTE FUNCTION trg_tocar_updated_at();
CREATE TRIGGER tocar_updated_at BEFORE UPDATE ON students
  FOR EACH ROW EXECUTE FUNCTION trg_tocar_updated_at();

-- Cada perfil tiene que corresponder al rol de la cuenta: una cuenta
-- de empresa no puede tener perfil de estudiante, etc.
CREATE FUNCTION trg_rol_del_perfil() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  esperado TEXT := TG_ARGV[0];
  real     TEXT;
BEGIN
  SELECT role INTO real FROM users WHERE id = NEW.user_id;
  IF real IS DISTINCT FROM esperado THEN
    RAISE EXCEPTION 'La cuenta % es de rol "%", no puede tener perfil de "%".', NEW.user_id, real, esperado
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER rol_del_perfil BEFORE INSERT OR UPDATE OF user_id ON students
  FOR EACH ROW EXECUTE FUNCTION trg_rol_del_perfil('student');
CREATE TRIGGER rol_del_perfil BEFORE INSERT OR UPDATE OF user_id ON professors
  FOR EACH ROW EXECUTE FUNCTION trg_rol_del_perfil('professor');
CREATE TRIGGER rol_del_perfil BEFORE INSERT OR UPDATE OF user_id ON companies
  FOR EACH ROW EXECUTE FUNCTION trg_rol_del_perfil('company');

-- Una empresa que todavía no aprobó el Polo no publica pasantías.
CREATE FUNCTION trg_publicar_pasantia() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  estado_empresa TEXT;
BEGIN
  IF NEW.status = 'published' THEN
    SELECT status INTO estado_empresa FROM companies WHERE user_id = NEW.company_id;
    IF estado_empresa <> 'active' THEN
      RAISE EXCEPTION 'La empresa todavía no fue aprobada por el Polo: no puede publicar pasantías.'
        USING ERRCODE = 'check_violation';
    END IF;
    NEW.published_at := COALESCE(NEW.published_at, now());
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER publicar_pasantia BEFORE INSERT OR UPDATE OF status ON internships
  FOR EACH ROW EXECUTE FUNCTION trg_publicar_pasantia();

-- Postulaciones: no a pasantías cerradas, y la fecha de decisión se
-- completa sola.
CREATE FUNCTION trg_validar_postulacion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  estado_pasantia TEXT;
BEGIN
  IF TG_OP = 'INSERT' AND NEW.origin = 'postulacion' THEN
    SELECT status INTO estado_pasantia FROM internships WHERE id = NEW.internship_id;
    IF estado_pasantia <> 'published' THEN
      RAISE EXCEPTION 'Esa pasantía no está abierta a postulaciones.' USING ERRCODE = 'check_violation';
    END IF;
  END IF;
  IF NEW.status IN ('approved', 'rejected')
     AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN
    NEW.decided_at := COALESCE(NEW.decided_at, now());
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER validar_postulacion BEFORE INSERT OR UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION trg_validar_postulacion();

-- Avisos automáticos de postulaciones.
CREATE FUNCTION trg_avisar_postulacion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  p   RECORD;
  est TEXT;
BEGIN
  SELECT i.title, i.company_id, c.legal_name INTO p
    FROM internships i JOIN companies c ON c.user_id = i.company_id
   WHERE i.id = NEW.internship_id;
  SELECT first_name || ' ' || last_name INTO est FROM students WHERE user_id = NEW.student_id;

  IF TG_OP = 'INSERT' AND NEW.origin = 'postulacion' THEN
    INSERT INTO notifications (user_id, kind, title, body, link)
    VALUES (p.company_id, 'postulacion_nueva', est || ' se postuló a "' || p.title || '"',
            'Abrí su perfil en Postulantes para aceptarlo o rechazarlo.', 'dashboard-empresa.html#seccion-postulantes');
  END IF;

  IF NEW.status IN ('approved', 'rejected')
     AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN
    INSERT INTO notifications (user_id, kind, title, body, link)
    VALUES (NEW.student_id, 'postulacion_decidida',
            CASE NEW.status WHEN 'approved'
                 THEN p.legal_name || ' te eligió para "' || p.title || '"'
                 ELSE p.legal_name || ' no siguió adelante con tu postulación a "' || p.title || '"' END,
            CASE NEW.status WHEN 'approved'
                 THEN 'La empresa se va a poner en contacto para coordinar la entrevista.'
                 ELSE 'Seguí completando tu perfil: hay más pasantías en Recomendadas.' END,
            'dashboard-estudiante.html#seccion-postulaciones');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER avisar_postulacion AFTER INSERT OR UPDATE OF status ON applications
  FOR EACH ROW EXECUTE FUNCTION trg_avisar_postulacion();

-- "Materiales que se usan acá": el sugerido tiene que ser un material
-- y el lugar, un salón o laboratorio.
CREATE FUNCTION trg_validar_material_sugerido() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (SELECT type FROM resources WHERE id = NEW.material_id) <> 'equipo' THEN
    RAISE EXCEPTION 'Solo se pueden sugerir materiales (no salones) en "Materiales que se usan acá".'
      USING ERRCODE = 'check_violation';
  END IF;
  IF (SELECT type FROM resources WHERE id = NEW.space_id) = 'equipo' THEN
    RAISE EXCEPTION 'Los materiales sugeridos van en un salón o laboratorio, no en otro material.'
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER validar_material_sugerido BEFORE INSERT OR UPDATE ON resource_materials
  FOR EACH ROW EXECUTE FUNCTION trg_validar_material_sugerido();

-- Reservas: piden profesores, el admin y los estudiantes, pero los
-- estudiantes SOLO materiales (la misma regla que el selector del
-- alumno y solicitarReserva() en js/reservas.js; acá es la que no se
-- puede saltear). El recurso tiene que estar activo, y los equipos
-- con varias unidades se controlan por cantidad (dos proyectores a
-- la misma hora, sí; tres, no).
CREATE FUNCTION trg_validar_reserva() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  rol        TEXT;
  recurso    RECORD;
  ocupadas   INT;
BEGIN
  SELECT role INTO rol FROM users WHERE id = NEW.requested_by;
  IF rol IS NULL OR rol NOT IN ('professor', 'admin', 'student') THEN
    RAISE EXCEPTION 'Solo profesores, estudiantes y la administración pueden pedir reservas.' USING ERRCODE = 'check_violation';
  END IF;

  SELECT * INTO recurso FROM resources WHERE id = NEW.resource_id;
  IF rol = 'student' AND recurso.type <> 'equipo' THEN
    RAISE EXCEPTION 'Los estudiantes solo pueden reservar materiales (proyector, televisión, notebooks, sonido…). "%" lo tiene que pedir un profesor.', recurso.name
      USING ERRCODE = 'insufficient_privilege';
  END IF;
  IF NOT recurso.active THEN
    RAISE EXCEPTION '"%" está dado de baja y no se puede reservar.', recurso.name USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.quantity > recurso.total_quantity THEN
    RAISE EXCEPTION 'Pediste % unidades de "%" y el Polo tiene %.', NEW.quantity, recurso.name, recurso.total_quantity
      USING ERRCODE = 'check_violation';
  END IF;

  NEW.exclusive := (recurso.total_quantity = 1);

  -- Equipos con varias unidades: se suman las unidades ya tomadas en
  -- ese horario. El bloqueo por recurso evita que dos pedidos
  -- simultáneos lean el mismo número y se pasen del total.
  IF NOT NEW.exclusive AND NEW.status IN ('pending', 'approved') THEN
    PERFORM pg_advisory_xact_lock(hashtextextended(NEW.resource_id::text, 0));
    SELECT COALESCE(SUM(quantity), 0) INTO ocupadas
      FROM bookings
     WHERE resource_id = NEW.resource_id
       AND id <> NEW.id
       AND status IN ('pending', 'approved')
       AND tstzrange(starts_at, ends_at, '[)') && tstzrange(NEW.starts_at, NEW.ends_at, '[)');
    IF ocupadas + NEW.quantity > recurso.total_quantity THEN
      RAISE EXCEPTION 'En ese horario ya están tomadas % de % unidades de "%".', ocupadas, recurso.total_quantity, recurso.name
        USING ERRCODE = 'exclusion_violation';
    END IF;
  END IF;

  IF TG_OP = 'UPDATE' AND NEW.status IN ('approved', 'rejected') AND OLD.status IS DISTINCT FROM NEW.status THEN
    NEW.decided_at := COALESCE(NEW.decided_at, now());
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER validar_reserva BEFORE INSERT OR UPDATE ON bookings
  FOR EACH ROW EXECUTE FUNCTION trg_validar_reserva();

CREATE FUNCTION trg_avisar_reserva() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  nombre_recurso TEXT;
BEGIN
  IF NEW.status IN ('approved', 'rejected') AND OLD.status IS DISTINCT FROM NEW.status THEN
    SELECT name INTO nombre_recurso FROM resources WHERE id = NEW.resource_id;
    INSERT INTO notifications (user_id, kind, title, body, link)
    VALUES (NEW.requested_by, 'reserva_decidida',
            CASE NEW.status WHEN 'approved' THEN 'Aprobaron tu reserva de ' ELSE 'Rechazaron tu reserva de ' END || nombre_recurso,
            NEW.title || ' · ' || to_char(NEW.starts_at, 'DD/MM HH24:MI'),
            CASE (SELECT role FROM users WHERE id = NEW.requested_by)
              WHEN 'student' THEN 'dashboard-estudiante-reservas.html#seccion-mis-reservas'
              ELSE 'dashboard-profesor.html#seccion-mis-reservas'
            END);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER avisar_reserva AFTER UPDATE OF status ON bookings
  FOR EACH ROW EXECUTE FUNCTION trg_avisar_reserva();

CREATE FUNCTION trg_avisar_empresa() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IN ('active', 'rejected') AND OLD.status IS DISTINCT FROM NEW.status THEN
    NEW.reviewed_at := COALESCE(NEW.reviewed_at, now());
    INSERT INTO notifications (user_id, kind, title, body, link)
    VALUES (NEW.user_id, 'empresa_revisada',
            CASE NEW.status WHEN 'active' THEN 'El Polo aprobó tu cuenta' ELSE 'El Polo no aprobó tu cuenta' END,
            CASE NEW.status WHEN 'active' THEN 'Ya podés publicar pasantías.' ELSE 'Escribinos para revisar los datos.' END,
            'dashboard-empresa.html');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER avisar_empresa BEFORE UPDATE OF status ON companies
  FOR EACH ROW EXECUTE FUNCTION trg_avisar_empresa();

-- ================================================================
-- 7. FUNCIONES: lo que hace la aplicación, en una sola llamada
-- (cada una es un endpoint de backend/main.py)
-- ================================================================

-- Iniciar sesión: compara contra el hash bcrypt y registra el acceso.
CREATE FUNCTION fn_login(p_email TEXT, p_password TEXT)
RETURNS TABLE (user_id UUID, role TEXT, display_name VARCHAR) LANGUAGE plpgsql AS $$
BEGIN
  RETURN QUERY
  UPDATE users u SET last_login_at = now()
   WHERE u.email = p_email::citext
     AND u.active
     AND u.password_hash = crypt(p_password, u.password_hash)
  RETURNING u.id, u.role, u.display_name;
END $$;

-- Registro de estudiante, profesor o empresa (el admin se crea a mano).
CREATE FUNCTION fn_registrar(p_role TEXT, p_email TEXT, p_password TEXT, p_nombre TEXT,
                             p_apellido TEXT DEFAULT NULL, p_sector TEXT DEFAULT 'servicios')
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
  nuevo UUID;
BEGIN
  IF p_role NOT IN ('student', 'professor', 'company') THEN
    RAISE EXCEPTION 'No se puede registrar una cuenta de rol "%".', p_role USING ERRCODE = 'check_violation';
  END IF;
  IF length(p_password) < 8 THEN
    RAISE EXCEPTION 'La contraseña tiene que tener al menos 8 caracteres.' USING ERRCODE = 'check_violation';
  END IF;

  INSERT INTO users (email, password_hash, role, display_name)
  VALUES (p_email, crypt(p_password, gen_salt('bf', 10)), p_role,
          trim(p_nombre || COALESCE(' ' || p_apellido, '')))
  RETURNING id INTO nuevo;

  IF p_role = 'student' THEN
    INSERT INTO students (user_id, first_name, last_name) VALUES (nuevo, p_nombre, COALESCE(p_apellido, ''));
  ELSIF p_role = 'professor' THEN
    INSERT INTO professors (user_id, first_name, last_name) VALUES (nuevo, p_nombre, COALESCE(p_apellido, ''));
  ELSE
    INSERT INTO companies (user_id, legal_name, sector) VALUES (nuevo, p_nombre, p_sector);
  END IF;
  RETURN nuevo;
END $$;

-- Completitud del perfil, de 0 a 100: los mismos 11 bloques que
-- calcula js/bolsa.js (BLOQUES_DEL_PERFIL), cada uno vale lo mismo.
CREATE FUNCTION fn_bloques_faltantes(p_student UUID) RETURNS TEXT[] LANGUAGE sql STABLE AS $$
  SELECT array_remove(ARRAY[
    CASE WHEN s.orientation_id IS NULL AND COALESCE(s.orientation_other, '') = '' THEN 'Orientación' END,
    CASE WHEN s.level IS NULL THEN 'Año o nivel' END,
    CASE WHEN s.availability IS NULL THEN 'Disponibilidad' END,
    CASE WHEN length(COALESCE(s.about, '')) < 30 THEN 'Sobre vos' END,
    CASE WHEN (SELECT count(*) FROM student_skills k WHERE k.student_id = s.user_id) < 3 THEN 'Capacidades' END,
    CASE WHEN NOT EXISTS (SELECT 1 FROM student_languages l WHERE l.student_id = s.user_id) THEN 'Idiomas' END,
    CASE WHEN NOT EXISTS (SELECT 1 FROM student_titles t WHERE t.student_id = s.user_id) THEN 'Títulos' END,
    CASE WHEN NOT EXISTS (SELECT 1 FROM student_courses c WHERE c.student_id = s.user_id) THEN 'Cursos' END,
    CASE WHEN NOT EXISTS (SELECT 1 FROM student_experiences e WHERE e.student_id = s.user_id) THEN 'Experiencia' END,
    CASE WHEN COALESCE(s.linkedin_url, '') = '' AND COALESCE(s.portfolio_url, '') = '' THEN 'Link a tu trabajo' END,
    CASE WHEN NOT EXISTS (SELECT 1 FROM student_cv v WHERE v.student_id = s.user_id) THEN 'Currículum' END
  ], NULL)
  FROM students s WHERE s.user_id = p_student;
$$;

-- 11 bloques: Math.round(hechos / 11 * 100), igual que el sitio.
CREATE FUNCTION fn_completitud(p_student UUID) RETURNS SMALLINT LANGUAGE sql STABLE AS $$
  SELECT round(100.0 * (11 - COALESCE(cardinality(fn_bloques_faltantes(p_student)), 11)) / 11)::SMALLINT;
$$;

-- Guardar las capacidades de un estudiante de una vez (lo que hace
-- "Guardar perfil" en el editor): reemplaza la lista y crea las
-- etiquetas que no existían.
CREATE FUNCTION fn_guardar_capacidades(p_student UUID, p_capacidades TEXT[]) RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
  i INT := 0;
  nombre TEXT;
  id_skill INT;
BEGIN
  DELETE FROM student_skills WHERE student_id = p_student;
  FOREACH nombre IN ARRAY COALESCE(p_capacidades, '{}') LOOP
    nombre := trim(nombre);
    CONTINUE WHEN nombre = '';
    INSERT INTO skills (name) VALUES (nombre) ON CONFLICT (name) DO NOTHING;
    SELECT id INTO id_skill FROM skills WHERE name = nombre::citext;
    INSERT INTO student_skills (student_id, skill_id, position) VALUES (p_student, id_skill, i)
      ON CONFLICT DO NOTHING;
    i := i + 1;
  END LOOP;
END $$;

-- Subir o reemplazar el currículum (PUT /api/v1/perfil/cv). Los
-- CHECK de student_cv hacen las validaciones; acá se traducen a un
-- mensaje claro.
CREATE FUNCTION fn_guardar_cv(p_student UUID, p_nombre TEXT, p_contenido BYTEA) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  IF p_contenido IS NULL OR octet_length(p_contenido) = 0 THEN
    RAISE EXCEPTION 'El archivo está vacío.' USING ERRCODE = 'check_violation';
  END IF;
  IF octet_length(p_contenido) > 5242880 THEN
    RAISE EXCEPTION 'El currículum pesa % MB y el máximo es 5 MB.', round(octet_length(p_contenido) / 1048576.0, 1)
      USING ERRCODE = 'check_violation';
  END IF;
  IF substring(p_contenido FROM 1 FOR 5) <> '\x255044462d'::bytea THEN
    RAISE EXCEPTION 'Ese archivo no es un PDF (aunque se llame .pdf).' USING ERRCODE = 'check_violation';
  END IF;
  INSERT INTO student_cv (student_id, file_name, content)
  VALUES (p_student, CASE WHEN p_nombre ~* '\.pdf$' THEN left(p_nombre, 200) ELSE left(p_nombre, 196) || '.pdf' END, p_contenido)
  ON CONFLICT (student_id) DO UPDATE
    SET file_name = EXCLUDED.file_name, content = EXCLUDED.content, uploaded_at = now();
END $$;

-- Postularse (botón "Postularme" del panel del estudiante).
CREATE FUNCTION fn_postular(p_student UUID, p_internship UUID) RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
  nueva UUID;
BEGIN
  INSERT INTO applications (student_id, internship_id) VALUES (p_student, p_internship)
  RETURNING id INTO nueva;
  RETURN nueva;
EXCEPTION WHEN unique_violation THEN
  RAISE EXCEPTION 'Ya estás postulado a esta pasantía.' USING ERRCODE = 'unique_violation';
END $$;

-- La empresa acepta, rechaza o selecciona. Si el estudiante no se
-- había postulado (lo encontró en el directorio), se crea la
-- postulación ya decidida, con origen "seleccion_directa".
CREATE FUNCTION fn_decidir_postulacion(p_company UUID, p_student UUID, p_internship UUID, p_estado TEXT)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
  dueno UUID;
  resultado UUID;
BEGIN
  IF p_estado NOT IN ('approved', 'rejected') THEN
    RAISE EXCEPTION 'Estado inválido: "%". Tiene que ser approved o rejected.', p_estado USING ERRCODE = 'check_violation';
  END IF;
  SELECT company_id INTO dueno FROM internships WHERE id = p_internship;
  IF dueno IS DISTINCT FROM p_company THEN
    RAISE EXCEPTION 'Esa pasantía no es de tu empresa.' USING ERRCODE = 'insufficient_privilege';
  END IF;

  INSERT INTO applications (student_id, internship_id, status, origin, decided_by)
  VALUES (p_student, p_internship, p_estado, 'seleccion_directa', p_company)
  ON CONFLICT (student_id, internship_id)
  DO UPDATE SET status = EXCLUDED.status, decided_by = EXCLUDED.decided_by, decided_at = now()
  RETURNING id INTO resultado;
  RETURN resultado;
END $$;

-- Pedir una reserva, con un mensaje claro si el horario ya está tomado.
CREATE FUNCTION fn_solicitar_reserva(p_user UUID, p_resource UUID, p_title TEXT,
                                     p_starts TIMESTAMPTZ, p_ends TIMESTAMPTZ, p_quantity SMALLINT DEFAULT 1)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
  nueva UUID;
BEGIN
  IF p_starts < now() THEN
    RAISE EXCEPTION 'No se puede reservar en el pasado.' USING ERRCODE = 'check_violation';
  END IF;
  INSERT INTO bookings (resource_id, requested_by, title, starts_at, ends_at, quantity)
  VALUES (p_resource, p_user, p_title, p_starts, p_ends, p_quantity)
  RETURNING id INTO nueva;
  RETURN nueva;
EXCEPTION WHEN exclusion_violation THEN
  RAISE EXCEPTION 'Ese horario ya está tomado para ese salón o equipo. Elegí otro horario.'
    USING ERRCODE = 'exclusion_violation';
END $$;

-- Aprobar o rechazar una reserva (panel del admin).
CREATE FUNCTION fn_decidir_reserva(p_admin UUID, p_booking UUID, p_estado TEXT) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  IF (SELECT role FROM users WHERE id = p_admin) <> 'admin' THEN
    RAISE EXCEPTION 'Solo la administración aprueba o rechaza reservas.' USING ERRCODE = 'insufficient_privilege';
  END IF;
  IF p_estado NOT IN ('approved', 'rejected') THEN
    RAISE EXCEPTION 'Estado inválido: "%".', p_estado USING ERRCODE = 'check_violation';
  END IF;
  UPDATE bookings SET status = p_estado, decided_by = p_admin
   WHERE id = p_booking AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Esa reserva no existe o ya fue decidida.' USING ERRCODE = 'no_data_found';
  END IF;
END $$;

-- ================================================================
-- 8. VISTAS: lo que muestra cada pantalla, ya armado
-- ================================================================

-- Agenda pública: reservas aprobadas de hoy en adelante.
CREATE VIEW v_agenda_publica AS
SELECT b.id, r.code AS resource_code, r.name AS recurso, r.type AS tipo,
       b.title AS actividad, b.starts_at AS desde, b.ends_at AS hasta,
       u.display_name || CASE u.role WHEN 'student' THEN ' (alumno)' ELSE '' END AS a_cargo_de
  FROM bookings b
  JOIN resources r ON r.id = b.resource_id
  JOIN users u ON u.id = b.requested_by
 WHERE b.status = 'approved' AND b.ends_at >= now()
 ORDER BY b.starts_at;

-- Cola del admin: pendientes, la más próxima primero. Los pedidos de
-- estudiantes llevan "(alumno)", como en el sitio.
CREATE VIEW v_reservas_pendientes AS
SELECT b.id, r.name AS recurso, r.type AS tipo, b.title AS motivo,
       b.starts_at AS desde, b.ends_at AS hasta, b.quantity AS unidades,
       u.display_name || CASE u.role WHEN 'student' THEN ' (alumno)' ELSE '' END AS pedida_por,
       u.role AS rol_solicitante
  FROM bookings b
  JOIN resources r ON r.id = b.resource_id
  JOIN users u ON u.id = b.requested_by
 WHERE b.status = 'pending'
 ORDER BY b.starts_at;

-- Perfil completo de un estudiante, tal como lo pinta htmlPerfil().
CREATE VIEW v_perfiles AS
SELECT s.user_id AS student_id, u.email, u.display_name AS nombre,
       COALESCE(o.name, s.orientation_other) AS orientacion,
       s.level AS nivel, s.locality AS localidad, s.availability AS disponibilidad,
       s.about AS sobre_mi, s.linkedin_url, s.portfolio_url,
       ARRAY(SELECT k.name::text FROM student_skills ss JOIN skills k ON k.id = ss.skill_id
              WHERE ss.student_id = s.user_id ORDER BY ss.position) AS capacidades,
       ARRAY(SELECT l.label::text FROM student_languages l WHERE l.student_id = s.user_id ORDER BY l.position) AS idiomas,
       (SELECT COALESCE(json_agg(json_build_object('nombre', t.name, 'institucion', t.institution, 'anio', t.year) ORDER BY t.position), '[]')
          FROM student_titles t WHERE t.student_id = s.user_id) AS titulos,
       (SELECT COALESCE(json_agg(json_build_object('nombre', c.name, 'institucion', c.institution, 'detalle', c.detail) ORDER BY c.position), '[]')
          FROM student_courses c WHERE c.student_id = s.user_id) AS cursos,
       (SELECT COALESCE(json_agg(json_build_object('puesto', e.role, 'lugar', e.place, 'periodo', e.period) ORDER BY e.position), '[]')
          FROM student_experiences e WHERE e.student_id = s.user_id) AS experiencia,
       (SELECT json_build_object('nombre', v.file_name, 'tamano', v.size_bytes, 'subido', v.uploaded_at)
          FROM student_cv v WHERE v.student_id = s.user_id) AS curriculum,
       fn_completitud(s.user_id) AS completitud,
       fn_bloques_faltantes(s.user_id) AS faltan
  FROM students s
  JOIN users u ON u.id = s.user_id
  LEFT JOIN orientations o ON o.id = s.orientation_id
 WHERE u.active;

-- Postulantes de cada empresa ("Postulantes" del panel de empresa),
-- los que esperan respuesta primero.
CREATE VIEW v_postulantes AS
SELECT i.company_id, a.id AS application_id, i.id AS internship_id, i.title AS pasantia,
       p.student_id, p.nombre, p.orientacion, p.nivel, p.capacidades[1:3] AS capacidades_principales,
       a.status AS estado, a.origin AS origen, a.created_at AS fecha, a.decided_at AS decidida
  FROM applications a
  JOIN internships i ON i.id = a.internship_id
  JOIN v_perfiles p ON p.student_id = a.student_id
 ORDER BY CASE a.status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, a.created_at;

-- "Mis postulaciones" del estudiante.
CREATE VIEW v_mis_postulaciones AS
SELECT a.student_id, a.id AS application_id, i.title AS pasantia, c.legal_name AS empresa,
       i.modality AS modalidad, i.duration_months AS meses, a.status AS estado, a.origin AS origen, a.created_at AS fecha
  FROM applications a
  JOIN internships i ON i.id = a.internship_id
  JOIN companies c ON c.user_id = i.company_id;

-- Pasantías que ve un estudiante: publicadas y de empresas activas.
CREATE VIEW v_pasantias_visibles AS
SELECT i.id, i.title AS titulo, c.legal_name AS empresa, c.sector, i.modality AS modalidad,
       i.duration_months AS meses, i.description AS descripcion, i.published_at AS publicada
  FROM internships i
  JOIN companies c ON c.user_id = i.company_id
 WHERE i.status = 'published' AND c.status = 'active'
 ORDER BY i.published_at DESC;

-- Panel del admin de pasantías: postulaciones aceptadas que todavía
-- no tienen sala reservada para la entrevista.
CREATE VIEW v_entrevistas_por_agendar AS
SELECT a.id AS application_id, p.nombre AS estudiante, i.title AS pasantia, c.legal_name AS empresa, a.decided_at
  FROM applications a
  JOIN internships i ON i.id = a.internship_id
  JOIN companies c ON c.user_id = i.company_id
  JOIN v_perfiles p ON p.student_id = a.student_id
 WHERE a.status = 'approved'
   AND NOT EXISTS (SELECT 1 FROM bookings b
                    WHERE b.related_application_id = a.id AND b.status IN ('pending', 'approved'));

-- Inventario con sus recursos según la materia (la ficha de cada
-- salón: herramientas, materiales que se usan ahí, Biblioteca Ceibal).
CREATE VIEW v_recursos AS
SELECT r.id, r.code AS codigo, r.name AS nombre, r.type AS tipo, r.total_quantity AS unidades,
       r.capacity AS capacidad, r.subject AS materia, r.tools AS herramientas,
       r.study_room AS biblioteca_ceibal,
       ARRAY(SELECT m.code::text FROM resource_materials rm JOIN resources m ON m.id = rm.material_id
              WHERE rm.space_id = r.id ORDER BY rm.position) AS materiales_sugeridos
  FROM resources r
 WHERE r.active
 ORDER BY CASE r.type WHEN 'espacio' THEN 0 WHEN 'laboratorio' THEN 1 ELSE 2 END, r.name;

-- Los números del tablero del admin de reservas.
CREATE VIEW v_estadisticas_reservas AS
SELECT (SELECT count(*) FROM resources WHERE active)                                  AS salones_y_equipos,
       (SELECT count(*) FROM bookings WHERE status = 'pending')                       AS reservas_pendientes,
       (SELECT count(*) FROM bookings WHERE status = 'approved')                      AS reservas_aprobadas,
       (SELECT count(*) FROM bookings WHERE status = 'approved'
                                        AND starts_at::date = current_date)           AS reservas_de_hoy,
       (SELECT count(*) FROM professors pr JOIN users u ON u.id = pr.user_id WHERE u.active) AS profesores_activos;
