import re

with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

# Replace var(--azul-800) with var(--fondo-oscuro) in backgrounds and gradients
# We only want to replace it when it's used as a background or in a gradient.
# Let's just find "background:" or "background-color:" lines that contain var(--azul-800)
# and replace var(--azul-800) with var(--fondo-oscuro)

def replace_in_background(match):
    return match.group(0).replace('var(--azul-800)', 'var(--fondo-oscuro)')

css = re.sub(r'(?i)background[^;]*var\(--azul-800\)[^;]*;', replace_in_background, css)

# Also replace in the :root definition to add the new variable
css = css.replace('--azul-800: #00213F;', '--azul-800: #00213F;\n  --fondo-oscuro: #00213F;')
css = css.replace('--azul-800: #040A10;', '--azul-800: #F4F6F9;\n    --fondo-oscuro: #040A10;')

with open('css/styles.css', 'w', encoding='utf-8') as f:
    f.write(css)
print("Updated css")
