# ================================================================
#  Polo 2 Gestion - servidor local
#  Sirve la carpeta del proyecto en http://localhost:<puerto>/
#  (solo en esta computadora: escucha en 127.0.0.1, nadie de la
#  red puede entrar).
#
#  Por que hace falta: el microfono (aplausos y dictado por voz)
#  solo funciona en https:// o en localhost. Abriendo el HTML con
#  doble clic (file://) el navegador no deja usarlo.
#
#  Si la computadora tiene Python, se usa su servidor (es mas
#  rapido). Si no, este mismo script hace de servidor, con lo que
#  ya trae Windows: no hay que instalar nada.
# ================================================================
param(
  [int]$Puerto = 8080,
  # Para probar: "tcp" fuerza el servidor minimo, "windows" saltea Python
  [string]$Modo = "auto"
)

$ErrorActionPreference = "Stop"
$raiz = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$sep = [System.IO.Path]::DirectorySeparatorChar

# --- Buscar un puerto libre (8080, 8081, ... 8099) --------------
function Test-PuertoLibre([int]$p) {
  try {
    $prueba = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
    $prueba.Start()
    $prueba.Stop()
    return $true
  } catch {
    return $false
  }
}

$libre = $null
for ($p = $Puerto; $p -lt ($Puerto + 20); $p++) {
  if (Test-PuertoLibre $p) { $libre = $p; break }
}
if (-not $libre) {
  Write-Host "  No encontre un puerto libre entre $Puerto y $($Puerto + 19)." -ForegroundColor Red
  exit 1
}
$Puerto = $libre
$url = "http://localhost:$Puerto/index.html"

Write-Host ""
Write-Host "  Polo 2 Gestion" -ForegroundColor Yellow
Write-Host "  La pagina esta en: $url"
Write-Host "  Para apagarla, cerra esta ventana (o Ctrl+C)."
Write-Host ""

# El navegador se abre un segundo despues, cuando el servidor ya escucha.
Start-Job -ScriptBlock { param($u) Start-Sleep -Milliseconds 1200; Start-Process $u } -ArgumentList $url | Out-Null

# --- Opcion 1: Python, si esta instalado de verdad ---------------
# (Ojo: Windows trae un "python" falso que solo abre la Microsoft
#  Store. Por eso no alcanza con que exista: tiene que responder.)
foreach ($cmd in $(if ($Modo -eq "auto") { @("python", "py") } else { @() })) {
  $exe = Get-Command $cmd -ErrorAction SilentlyContinue
  if ($exe) {
    try {
      $version = & $cmd -c "import sys; print(sys.version_info[0])" 2>$null
      if ($version -eq "3") {
        Write-Host "  (usando el servidor de Python)" -ForegroundColor DarkGray
        Set-Location $raiz
        # servidor.py es http.server + "Cache-Control: no-cache": asi el
        # navegador no sigue usando los .js de una version anterior.
        & $cmd (Join-Path $PSScriptRoot "servidor.py") $Puerto $raiz
        exit $LASTEXITCODE
      }
    } catch { }
  }
}

# --- Tipos de archivo ------------------------------------------
$tipos = @{
  ".html" = "text/html; charset=utf-8"; ".htm" = "text/html; charset=utf-8"
  ".css" = "text/css; charset=utf-8"; ".js" = "text/javascript; charset=utf-8"
  ".json" = "application/json; charset=utf-8"; ".svg" = "image/svg+xml"
  ".png" = "image/png"; ".jpg" = "image/jpeg"; ".jpeg" = "image/jpeg"
  ".gif" = "image/gif"; ".webp" = "image/webp"; ".ico" = "image/x-icon"
  ".woff2" = "font/woff2"; ".woff" = "font/woff"; ".ttf" = "font/ttf"
  ".mp4" = "video/mp4"; ".webm" = "video/webm"; ".mp3" = "audio/mpeg"; ".wav" = "audio/wav"
  ".txt" = "text/plain; charset=utf-8"; ".md" = "text/plain; charset=utf-8"; ".pdf" = "application/pdf"
}

function Resolver-Ruta([string]$rutaPedida) {
  $ruta = [System.Uri]::UnescapeDataString(($rutaPedida -split "\?")[0])
  if ($ruta -eq "/" -or $ruta -eq "") { $ruta = "/index.html" }
  # Nunca salir de la carpeta del proyecto (nada de "../")
  $completa = [System.IO.Path]::GetFullPath((Join-Path $raiz ($ruta.TrimStart("/").Replace([char]"/", $sep))))
  $base = $raiz.TrimEnd($sep) + $sep
  if (-not ($completa + $sep).StartsWith($base, [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
  if (Test-Path $completa -PathType Container) { $completa = Join-Path $completa "index.html" }
  if (Test-Path $completa -PathType Leaf) { return $completa }
  return $null
}

function Tipo-De([string]$archivo) {
  $tipo = $tipos[[System.IO.Path]::GetExtension($archivo).ToLower()]
  if ($tipo) { return $tipo } else { return "application/octet-stream" }
}

$noEncontrado = [System.Text.Encoding]::UTF8.GetBytes("<!doctype html><meta charset='utf-8'><h1>No encontrado</h1><p><a href='/index.html'>Volver al inicio</a></p>")

# --- Opcion 2: HttpListener (lo maneja Windows: varias conexiones
#     a la vez, sin trabarse con las "preconexiones" del navegador)
$escucha = New-Object System.Net.HttpListener
$escucha.Prefixes.Add("http://localhost:$Puerto/")

$usarHttpListener = $Modo -ne "tcp"
if ($usarHttpListener) { try { $escucha.Start() } catch { $usarHttpListener = $false } }

if ($usarHttpListener) {
  Write-Host "  (usando el servidor incorporado de Windows)" -ForegroundColor DarkGray
  try {
    while ($escucha.IsListening) {
      $contexto = $escucha.GetContext()
      $respuesta = $contexto.Response
      try {
        $metodo = $contexto.Request.HttpMethod
        $archivo = Resolver-Ruta $contexto.Request.RawUrl
        $respuesta.Headers.Add("Cache-Control", "no-cache")
        if ($metodo -ne "GET" -and $metodo -ne "HEAD") {
          $respuesta.StatusCode = 405
        } elseif ($archivo) {
          $cuerpo = [System.IO.File]::ReadAllBytes($archivo)
          $respuesta.ContentType = Tipo-De $archivo
          $respuesta.ContentLength64 = $cuerpo.Length
          if ($metodo -eq "GET") { $respuesta.OutputStream.Write($cuerpo, 0, $cuerpo.Length) }
          Write-Host ("  {0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $contexto.Request.Url.AbsolutePath) -ForegroundColor DarkGray
        } else {
          $respuesta.StatusCode = 404
          $respuesta.ContentType = "text/html; charset=utf-8"
          $respuesta.ContentLength64 = $noEncontrado.Length
          if ($metodo -eq "GET") { $respuesta.OutputStream.Write($noEncontrado, 0, $noEncontrado.Length) }
        }
      } catch {
        # Un navegador que corta la conexion no tiene que tirar el servidor
      } finally {
        try { $respuesta.Close() } catch { }
      }
    }
  } finally {
    $escucha.Stop()
  }
  exit 0
}

# --- Opcion 3: servidor minimo con TcpListener -------------------
# Solo si Windows no dejo usar HttpListener (algunas maquinas con
# politicas restringidas). Atiende de a una conexion.
Write-Host "  (usando el servidor minimo de PowerShell)" -ForegroundColor DarkGray

$servidor = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Puerto)
$servidor.Start()

function Enviar($flujo, [int]$codigo, [string]$estado, [string]$tipo, [byte[]]$cuerpo, [bool]$soloCabecera) {
  $cabecera = "HTTP/1.1 $codigo $estado`r`nContent-Type: $tipo`r`nContent-Length: $($cuerpo.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
  $bytes = [System.Text.Encoding]::ASCII.GetBytes($cabecera)
  $flujo.Write($bytes, 0, $bytes.Length)
  if (-not $soloCabecera -and $cuerpo.Length -gt 0) { $flujo.Write($cuerpo, 0, $cuerpo.Length) }
}

try {
  while ($true) {
    $cliente = $servidor.AcceptTcpClient()
    try {
      $cliente.ReceiveTimeout = 2000
      $flujo = $cliente.GetStream()
      # El navegador abre conexiones "por las dudas" que nunca piden
      # nada: si en 800 ms no llega el pedido, se cierra y se sigue.
      $espera = 0
      while (-not $flujo.DataAvailable -and $espera -lt 800) { Start-Sleep -Milliseconds 20; $espera += 20 }
      if (-not $flujo.DataAvailable) { $cliente.Close(); continue }
      $lector = New-Object System.IO.StreamReader($flujo, [System.Text.Encoding]::ASCII, $false, 4096, $true)
      $linea = $lector.ReadLine()
      if (-not $linea) { $cliente.Close(); continue }
      # Se descartan las cabeceras del pedido (no hacen falta)
      while (($h = $lector.ReadLine()) -ne $null -and $h -ne "") { }

      $partes = $linea.Split(" ")
      $metodo = $partes[0]
      if ($metodo -ne "GET" -and $metodo -ne "HEAD") {
        Enviar $flujo 405 "Method Not Allowed" "text/plain" ([System.Text.Encoding]::UTF8.GetBytes("Metodo no permitido")) $false
      } else {
        $archivo = Resolver-Ruta $partes[1]
        if ($archivo) {
          $cuerpo = [System.IO.File]::ReadAllBytes($archivo)
          Enviar $flujo 200 "OK" (Tipo-De $archivo) $cuerpo ($metodo -eq "HEAD")
          Write-Host ("  {0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $partes[1]) -ForegroundColor DarkGray
        } else {
          Enviar $flujo 404 "Not Found" "text/html; charset=utf-8" $noEncontrado ($metodo -eq "HEAD")
        }
      }
      $flujo.Flush()
    } catch {
      # Un navegador que corta la conexion no tiene que tirar el servidor
    } finally {
      $cliente.Close()
    }
  }
} finally {
  $servidor.Stop()
}
