"""
Servidor local de Polo 2 Gestión (lo usa servidor.ps1 cuando la
computadora tiene Python 3).

Es el mismo http.server de Python, con un cambio importante: manda
"Cache-Control: no-cache". Sin eso, el navegador se guarda los .js y
.css y, al pasar a una versión nueva del sitio, puede seguir usando
los viejos durante horas (páginas nuevas con código viejo: por
ejemplo, un estudiante que ve las reservas de un profesor).
Con no-cache el navegador pregunta cada vez si el archivo cambió.

Uso: python servidor.py PUERTO CARPETA
"""

import sys
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


class SinCache(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".html": "text/html; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".woff2": "font/woff2",
        ".svg": "image/svg+xml",
    }

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, formato, *args):
        # Solo los errores: la ventana no se llena de líneas por cada archivo.
        if len(args) > 1 and str(args[1]).startswith(("4", "5")):
            super().log_message(formato, *args)


def main():
    puerto = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    carpeta = sys.argv[2] if len(sys.argv) > 2 else "."
    servidor = ThreadingHTTPServer(("127.0.0.1", puerto), partial(SinCache, directory=carpeta))
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
