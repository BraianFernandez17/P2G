@echo off
rem ================================================================
rem  Polo 2 Gestion - base de datos
rem  Doble clic: muestra un menu para levantar la base PostgreSQL
rem  (con Docker o con un PostgreSQL instalado), correr las pruebas,
rem  resetear los datos de la demo y levantar la API.
rem
rem  Base:    localhost:5432  usuario polotec  clave polotec
rem  Adminer: http://localhost:8081   (solo con Docker)
rem  API:     http://localhost:8000/docs
rem  Cuentas de la demo: clave demo1234 (ver README)
rem ================================================================
setlocal EnableExtensions
chcp 65001 >nul
title Polo 2 Gestion - base de datos
cd /d "%~dp0"
set "PGCLIENTENCODING=UTF8"

:menu
cls
echo.
echo   ==============================================
echo     POLO 2 GESTION  -  Base de datos
echo   ==============================================
echo.
echo     Con Docker Desktop
echo       1. Levantar la base          (y Adminer)
echo       2. Levantar la base + la API
echo       3. Correr las pruebas de la base
echo       4. Abrir una consola SQL      (psql)
echo       5. Resetear: borrar todo y recargar la demo
echo       6. Apagar                     (los datos quedan)
echo.
echo     Sin Docker
echo       7. Cargar en un PostgreSQL instalado
echo       8. Levantar la API con Python
echo.
echo       0. Salir
echo.
choice /c 123456780 /n /m "  Elegi una opcion: "
if errorlevel 9 goto fin
if errorlevel 8 goto api_python
if errorlevel 7 goto local
if errorlevel 6 goto apagar
if errorlevel 5 goto resetear
if errorlevel 4 goto consola
if errorlevel 3 goto pruebas
if errorlevel 2 goto levantar_api
if errorlevel 1 goto levantar
goto menu

rem ----------------------------------------------------------------
:verificar_docker
where docker >nul 2>&1
if errorlevel 1 goto sin_docker
docker info >nul 2>&1
if errorlevel 1 goto docker_apagado
exit /b 0

:sin_docker
echo.
echo   No encontre Docker en esta computadora.
echo   Instala Docker Desktop (gratis): https://www.docker.com/products/docker-desktop/
echo   o usa la opcion 7 si ya tenes PostgreSQL instalado.
exit /b 1

:docker_apagado
echo.
echo   Docker esta instalado pero no esta corriendo.
echo   Abri Docker Desktop, espera a que diga "Engine running" y volve a probar.
exit /b 1

rem ----------------------------------------------------------------
:esperar_base
echo.
echo   Esperando a que la base termine de arrancar...
echo   (la primera vez tarda un poco mas: crea las tablas y carga la demo)
set /a intentos=0
:esperar_base_bucle
set "estado="
for /f "delims=" %%s in ('docker inspect -f "{{.State.Health.Status}}" polotec-db 2^>nul') do set "estado=%%s"
if "%estado%"=="healthy" goto base_lista
set /a intentos+=1
if %intentos% geq 90 goto base_no_arranca
timeout /t 2 /nobreak >nul
goto esperar_base_bucle

:base_no_arranca
echo.
echo   La base no arranco a tiempo. Esto muestra que paso:
echo.
docker compose logs --tail 25 db
exit /b 1

:base_lista
echo.
echo   Base lista:
docker compose exec -T db psql -U polotec -d polotec -Atc "SELECT '    ' || (SELECT count(*) FROM users) || ' cuentas, ' || (SELECT count(*) FROM resources) || ' salones y equipos, ' || (SELECT count(*) FROM bookings) || ' reservas, ' || (SELECT count(*) FROM internships) || ' pasantias'"
echo.
echo     Adminer    http://localhost:8081
echo                (servidor db - usuario polotec - clave polotec - base polotec)
echo     Conexion   localhost:5432  polotec / polotec
exit /b 0

rem ----------------------------------------------------------------
:levantar
call :verificar_docker || goto pausa
docker compose up -d
if errorlevel 1 goto error_compose
call :esperar_base || goto pausa
start "" http://localhost:8081
goto pausa

:levantar_api
call :verificar_docker || goto pausa
docker compose --profile api up -d
if errorlevel 1 goto error_compose
call :esperar_base || goto pausa
call :esperar_api || goto pausa
start "" http://localhost:8000/docs
goto pausa

:esperar_api
echo.
echo   Esperando a la API (la primera vez instala sus dependencias)...
powershell -NoProfile -Command "for($i=0;$i -lt 90;$i++){try{Invoke-WebRequest -UseBasicParsing http://localhost:8000/api/v1/salud -TimeoutSec 2 | Out-Null; exit 0}catch{Start-Sleep 2}}; exit 1"
if errorlevel 1 goto api_no_arranca
echo.
echo     API        http://localhost:8000/docs
echo     El sitio, servido por la API: http://localhost:8000/index.html
exit /b 0

:api_no_arranca
echo.
echo   La API no respondio. Esto muestra que paso:
docker compose --profile api logs --tail 25 api
exit /b 1

:error_compose
echo.
echo   Docker no pudo levantar los servicios. Si dice que el puerto 5432
echo   esta ocupado, probablemente tengas PostgreSQL instalado: usa la opcion 7
echo   o apaga ese servicio. Si es el 8081 o el 8000, cerra lo que lo use.
goto pausa

rem ----------------------------------------------------------------
:pruebas
call :verificar_docker || goto pausa
docker compose exec -T db psql -U polotec -d polotec -f /polotec-db/pruebas.sql
if errorlevel 1 goto pruebas_fallan
echo.
echo   Todas las pruebas pasan. No se modifico ningun dato: corren dentro de
echo   una transaccion que al final se deshace.
goto pausa

:pruebas_fallan
echo.
echo   Algo fallo. Si la base no esta levantada, usa primero la opcion 1.
goto pausa

:consola
call :verificar_docker || goto pausa
echo.
echo   Consola SQL. Para salir escribi \q y Enter.
echo   Ejemplos:  SELECT * FROM v_agenda_publica;
echo              \i /polotec-db/consultas-ejemplo.sql
echo.
docker compose exec db psql -U polotec -d polotec
goto menu

:resetear
call :verificar_docker || goto pausa
echo.
echo   Esto BORRA todos los datos de la base (reservas, cuentas nuevas,
echo   perfiles editados...) y vuelve a cargar la demo desde cero.
choice /c SN /m "  Seguro"
if errorlevel 2 goto menu
docker compose --profile api down -v
docker compose up -d
if errorlevel 1 goto error_compose
call :esperar_base || goto pausa
goto pausa

:apagar
call :verificar_docker || goto pausa
docker compose --profile api down
echo.
echo   Apagado. Los datos quedan guardados para la proxima vez.
goto pausa

rem ----------------------------------------------------------------
rem  Sin Docker: PostgreSQL instalado (14 o mas nuevo)
rem ----------------------------------------------------------------
:local
set "PSQL="
for /f "delims=" %%p in ('where psql 2^>nul') do if not defined PSQL set "PSQL=%%p"
if defined PSQL goto local_encontrado
for /d %%d in ("%ProgramFiles%\PostgreSQL\*") do if exist "%%d\bin\psql.exe" set "PSQL=%%d\bin\psql.exe"
if defined PSQL goto local_encontrado
echo.
echo   No encontre PostgreSQL. Instalalo desde
echo   https://www.postgresql.org/download/windows/  (version 14 o mas nueva)
echo   o usa Docker Desktop con la opcion 1.
goto pausa

:local_encontrado
echo.
echo   Uso: %PSQL%
set "PUERTO=5432"
set /p "PUERTO=  Puerto de PostgreSQL [5432]: "
set "ADMIN=postgres"
set /p "ADMIN=  Usuario administrador [postgres]: "
for /f "usebackq delims=" %%c in (`powershell -NoProfile -Command "$c = Read-Host '  Clave de %ADMIN%' -AsSecureString; [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($c))"`) do set "PGPASSWORD=%%c"
echo.
echo   Se va a crear (o recrear desde cero) la base "polotec" y el usuario
echo   "polotec" con clave "polotec". Si ya existia, se pierden sus datos.
choice /c SN /m "  Seguir"
if errorlevel 2 goto local_fin

"%PSQL%" -h localhost -p %PUERTO% -U %ADMIN% -d postgres -v ON_ERROR_STOP=1 -q -c "DROP DATABASE IF EXISTS polotec WITH (FORCE)"
if errorlevel 1 goto local_error
"%PSQL%" -h localhost -p %PUERTO% -U %ADMIN% -d postgres -v ON_ERROR_STOP=1 -q -c "DO $$BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'polotec') THEN CREATE ROLE polotec LOGIN PASSWORD 'polotec'; END IF; END$$;"
if errorlevel 1 goto local_error
"%PSQL%" -h localhost -p %PUERTO% -U %ADMIN% -d postgres -v ON_ERROR_STOP=1 -q -c "CREATE DATABASE polotec OWNER polotec ENCODING 'UTF8' TEMPLATE template0"
if errorlevel 1 goto local_error

set "PGPASSWORD=polotec"
echo   Creando tablas, reglas y vistas...
"%PSQL%" -h localhost -p %PUERTO% -U polotec -d polotec -v ON_ERROR_STOP=1 -q -f db\schema.sql
if errorlevel 1 goto local_error
echo   Cargando los datos de la demo...
"%PSQL%" -h localhost -p %PUERTO% -U polotec -d polotec -v ON_ERROR_STOP=1 -q -f db\seed.sql
if errorlevel 1 goto local_error
echo   Corriendo las pruebas...
"%PSQL%" -h localhost -p %PUERTO% -U polotec -d polotec -f db\pruebas.sql
if errorlevel 1 goto local_error
echo.
echo   Listo. Base "polotec" en localhost:%PUERTO% - usuario polotec - clave polotec
if not "%PUERTO%"=="5432" echo   Para la API: set POLO_DB_URL=postgresql://polotec:polotec@localhost:%PUERTO%/polotec
goto local_fin

:local_error
echo.
echo   Algo fallo (mira el mensaje de arriba). Lo mas comun: la clave del
echo   usuario administrador no es esa, o PostgreSQL no esta corriendo.

:local_fin
set "PGPASSWORD="
goto pausa

rem ----------------------------------------------------------------
:api_python
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if defined PY goto api_python_ok
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=python"
if defined PY goto api_python_ok
echo.
echo   Hace falta Python 3.9 o mas nuevo: https://www.python.org/downloads/
echo   (al instalarlo, marca "Add python.exe to PATH"). O usa la opcion 2.
goto pausa

:api_python_ok
if exist "backend\.venv\Scripts\python.exe" goto api_python_deps
echo.
echo   Preparando un entorno de Python solo para la API (una sola vez)...
%PY% -m venv backend\.venv
if errorlevel 1 goto api_python_error
:api_python_deps
"backend\.venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r backend\requirements.txt
if errorlevel 1 goto api_python_error
echo.
echo   API en http://localhost:8000/docs  -  para apagarla, Ctrl+C o cerra la ventana.
echo   (la base tiene que estar levantada: opcion 1 o 7)
echo.
start "" /b powershell -NoProfile -Command "for($i=0;$i -lt 60;$i++){try{Invoke-WebRequest -UseBasicParsing http://localhost:8000/api/v1/salud -TimeoutSec 2 | Out-Null; Start-Process 'http://localhost:8000/docs'; break}catch{Start-Sleep 1}}"
pushd backend
".venv\Scripts\python.exe" main.py
popd
goto pausa

:api_python_error
echo.
echo   No se pudieron instalar las dependencias de la API. Revisa tu conexion
echo   a internet y volve a probar.
goto pausa

rem ----------------------------------------------------------------
:pausa
echo.
pause
goto menu

:fin
endlocal
