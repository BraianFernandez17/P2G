import re

with open('css/styles.css', 'r', encoding='utf-8') as f:
    css = f.read()

# 1. Fix the yellow buttons text color (navbar-public and hero)
# Find .navbar-public .btn-primary and .hero .btn-primary blocks and replace color: var(--azul-800); with color: var(--amarillo-tinta);
def fix_button_color(match):
    return match.group(0).replace('color: var(--azul-800);', 'color: var(--amarillo-tinta);')

css = re.sub(r'(?i)(\.navbar-public \.btn-primary[^{]*{[^}]*color:\s*var\(--azul-800\);)', fix_button_color, css)
css = re.sub(r'(?i)(\.hero \.btn-primary[^{]*{[^}]*color:\s*var\(--azul-800\);)', fix_button_color, css)

# 2. Add --azul-100 and --azul-200 to dark mode
dark_colors_addition = """  --azul-50: #1B2B3C;
  --azul-100: #22374E;
  --azul-200: #2D4865;
  --azul-300: #6B9AC9;"""

css = css.replace('--azul-50: #1B2B3C; /* Botones secundarios fondo */\n    --azul-300: #6B9AC9;', dark_colors_addition)
css = css.replace('--azul-50: #1B2B3C; /* Botones secundarios fondo */\n  --azul-300: #6B9AC9;', dark_colors_addition)

# 3. Add .navbar dark background override
navbar_override = """
html[data-tema="oscuro"] .navbar {
  background: rgba(10, 19, 28, 0.85);
}
@media (prefers-color-scheme: dark) {
  html:not([data-tema="claro"]) .navbar {
    background: rgba(10, 19, 28, 0.85);
  }
}
"""

if "html[data-tema=\"oscuro\"] .navbar" not in css:
    css += navbar_override

with open('css/styles.css', 'w', encoding='utf-8') as f:
    f.write(css)
print("Updated css")
