/* ================================================================
   MOVIMIENTO — Polo 2 Gestión
   ----------------------------------------------------------------
   Todo lo que se mueve en el sitio vive acá, y ninguna de estas
   funciones toca datos ni lógica: solo leen lo que ya pintaron
   reservas.js, script.js, empresa.js y calendario.js, y lo animan.

   Piezas:
     1. Maqueta 3D del Polo (portada, ingreso, encabezados de panel
        y los objetos de cada rol).
     2. Paletas de tablero de llegadas (métricas, agenda, portada).
     3. Revelado 3D al entrar en pantalla.
     4. Inclinación hacia el mouse (roles, hub, inventario).
     5. El comprobante que cambia de estado en "Cómo funciona".
     6. El giro de meses al cambiar de año en el calendario.
     7. El tablero "Próximo en el Polo" de la portada.

   Todo respeta "reducir movimiento": sin caídas, giros ni
   desplazamientos; queda lo que comunica (opacidad y color).
   ================================================================ */

const MENOS_MOVIMIENTO = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const HAY_MOUSE = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

/* ================================================================
   1. MAQUETA 3D
   Cada salón es una caja: x, y, ancho (w), profundidad (d) y alto
   (h), en unidades de grilla. z levanta la caja del piso y rot la
   gira (para los papeles apilados del estudiante).
   ================================================================ */
const MAQUETAS = {
  // La planta del Polo, simplificada: el ala de aulas al fondo, el
  // ala de laboratorios adelante, auditorio y cancha a la izquierda.
  polo: {
    u: 27,
    cols: 16,
    filas: 10,
    cajas: [
      { n: "Auditorio", x: 0, y: 0, w: 5, d: 4, h: 3.1 },
      { n: "Biblioteca", x: 5.4, y: 0, w: 3.8, d: 3, h: 2.2 },
      { n: "Sala de Informática", x: 9.4, y: 0, w: 3.4, d: 3, h: 2.2 },
      { n: "Sala de Conferencias", x: 13, y: 0, w: 3, d: 3, h: 2.2 },
      { n: "Laboratorio de Física", x: 5.4, y: 4.2, w: 2.9, d: 3, h: 2 },
      { n: "Laboratorio de Química", x: 8.5, y: 4.2, w: 2.9, d: 3, h: 2 },
      { n: "Laboratorio de Ciencias", x: 11.6, y: 4.2, w: 2.3, d: 3, h: 2 },
      { n: "Laboratorio de Robótica", x: 14.1, y: 4.2, w: 1.9, d: 3, h: 2 },
      { n: "Cancha Techada", x: 0, y: 4.6, w: 5, d: 5.4, h: 1.3, abierta: true },
      { n: "Sala de Reuniones Docentes", x: 5.4, y: 7.8, w: 4, d: 2.2, h: 1.5 },
      { n: "Depósito de equipos", x: 9.8, y: 7.8, w: 3, d: 2.2, h: 1.2 },
    ],
    encendidas: [2, 4, 7],
    ambiente: true,
  },

  // Un ala chica, para la derecha de los encabezados de panel.
  mini: {
    u: 17,
    cols: 11,
    filas: 7,
    cajas: [
      { x: 0, y: 0, w: 3.4, d: 3, h: 2.6 },
      { x: 3.8, y: 0, w: 3.2, d: 2.6, h: 1.9 },
      { x: 7.4, y: 0, w: 3.6, d: 3, h: 2.3 },
      { x: 0, y: 3.6, w: 3.4, d: 3.4, h: 1.2, abierta: true },
      { x: 3.8, y: 3.2, w: 3.2, d: 3.8, h: 2.1 },
      { x: 7.4, y: 3.6, w: 3.6, d: 3.4, h: 1.7 },
    ],
    encendidas: [1, 5],
    ambiente: true,
  },

  // Profesores: un salón con las ventanas encendidas.
  salon: {
    u: 30,
    cols: 6,
    filas: 5,
    cajas: [{ x: 0.8, y: 0.8, w: 4.4, d: 3.4, h: 2.5 }],
    encendidas: [0],
  },

  // Estudiantes: una pila de postulaciones, la de arriba resaltada.
  pila: {
    u: 30,
    cols: 6,
    filas: 5,
    cajas: [
      { x: 1, y: 1, w: 4, d: 3, h: 0.34, z: 0, rot: 0, papel: true },
      { x: 1, y: 1, w: 4, d: 3, h: 0.34, z: 0.42, rot: 7, papel: true },
      { x: 1, y: 1, w: 4, d: 3, h: 0.34, z: 0.84, rot: -5, papel: true },
      { x: 1, y: 1, w: 4, d: 3, h: 0.34, z: 1.26, rot: 3, papel: true },
    ],
    encendidas: [3],
  },

  // Empresas: una torre de oficinas con su anexo bajo.
  torre: {
    u: 30,
    cols: 6,
    filas: 5,
    cajas: [
      { x: 0.6, y: 2.2, w: 3.2, d: 2.2, h: 1.1, abierta: true },
      { x: 2.4, y: 0.6, w: 2.6, d: 2.6, h: 3.9, alta: true },
    ],
    encendidas: [1],
  },
};

function construirMaqueta(contenedor) {
  const plan = MAQUETAS[contenedor.dataset.maqueta];
  if (!plan || contenedor.dataset.construida) return;
  contenedor.dataset.construida = "si";

  contenedor.classList.add("maqueta");
  contenedor.style.setProperty("--u", `${Number(contenedor.dataset.u) || plan.u}px`);
  contenedor.style.setProperty("--cols", plan.cols);
  contenedor.style.setProperty("--filas", plan.filas);

  contenedor.innerHTML = plan.cajas
    .map((c) => {
      const clases = ["caja"];
      if (c.abierta) clases.push("abierta");
      if (c.papel) clases.push("papel");
      if (c.alta) clases.push("alta");
      return `
        <div class="${clases.join(" ")}"
             style="--x:${c.x};--y:${c.y};--w:${c.w};--d:${c.d};--h:${c.h};--z:${c.z || 0};--rot:${c.rot || 0}deg">
          <div class="caja-cuerpo">
            <i class="cara techo"></i><i class="cara frente"></i><i class="cara lado"></i>
          </div>
        </div>`;
    })
    .join("");

  const cajas = [...contenedor.querySelectorAll(".caja")];

  // Quien pidió menos movimiento ve la maqueta ya armada y encendida.
  if (MENOS_MOVIMIENTO) {
    plan.encendidas.forEach((i) => cajas[i] && cajas[i].classList.add("encendida"));
    return;
  }

  // Las cajas crecen desde el piso de a una, y cuando el edificio
  // ya está en pie se encienden las ventanas reservadas. Se usa la
  // Web Animations API (y no @keyframes) porque se puede cortar a
  // mitad de camino sin saltos.
  const retrasoBase = contenedor.dataset.maqueta === "polo" ? 380 : 120;
  cajas.forEach((caja, i) => {
    caja.querySelector(".caja-cuerpo").animate(
      [{ transform: "scale3d(1, 1, 0.02)" }, { transform: "scale3d(1, 1, 1)" }],
      { duration: 900, delay: retrasoBase + i * 70, easing: "cubic-bezier(0.22, 1, 0.36, 1)", fill: "backwards" }
    );
  });

  const finDeObra = retrasoBase + cajas.length * 70 + 600;
  plan.encendidas.forEach((i, orden) => {
    setTimeout(() => cajas[i] && cajas[i].classList.add("encendida"), finDeObra + orden * 260);
  });

  if (plan.ambiente) iniciarAmbiente(contenedor, cajas, plan, finDeObra + 1800);
}

/* Cada tanto, un salón se enciende o se apaga: el edificio está en
   uso. Es lento y es solo color (no hay desplazamiento), y se frena
   cuando la maqueta no está en pantalla o la pestaña está oculta. */
function iniciarAmbiente(contenedor, cajas, plan, demora) {
  const candidatas = cajas.filter((_, i) => !plan.cajas[i].abierta);
  let visible = true;
  new IntersectionObserver(([entrada]) => {
    visible = entrada.isIntersecting;
  }).observe(contenedor);

  setTimeout(() => {
    setInterval(() => {
      if (!visible || document.hidden) return;
      const caja = candidatas[Math.floor(Math.random() * candidatas.length)];
      const encendidas = candidatas.filter((c) => c.classList.contains("encendida")).length;
      // Nunca todo apagado ni todo encendido.
      if (caja.classList.contains("encendida") && encendidas <= 2) return;
      if (!caja.classList.contains("encendida") && encendidas >= Math.ceil(candidatas.length * 0.6)) return;
      caja.classList.toggle("encendida");
    }, 3400);
  }, demora);
}

/* La escena gira apenas hacia el mouse, alrededor del edificio. La
   suavidad la pone la transición de CSS, que retoma desde donde
   está si el mouse cambia de rumbo a mitad de camino. */
function orbitarMaqueta(zona, maqueta, { giro = 38, inclinacion = 58, rango = 12 } = {}) {
  if (!HAY_MOUSE || MENOS_MOVIMIENTO || !zona || !maqueta) return;

  zona.addEventListener("pointermove", (evento) => {
    const caja = zona.getBoundingClientRect();
    const dx = (evento.clientX - caja.left) / caja.width - 0.5;
    const dy = (evento.clientY - caja.top) / caja.height - 0.5;
    maqueta.style.setProperty("--giro", `${(giro + dx * rango).toFixed(2)}deg`);
    maqueta.style.setProperty("--inclinacion", `${(inclinacion - dy * rango * 0.5).toFixed(2)}deg`);
  });

  zona.addEventListener("pointerleave", () => {
    maqueta.style.setProperty("--giro", `${giro}deg`);
    maqueta.style.setProperty("--inclinacion", `${inclinacion}deg`);
  });
}

/* Las capas del fondo de la portada: la foto casi no se corre (está
   lejos), la luz sigue al puntero. Lo lejano se mueve menos que lo
   cercano, y esa diferencia es la que da profundidad. */
function parallaxPortada() {
  const hero = document.querySelector(".hero");
  if (!hero || !HAY_MOUSE || MENOS_MOVIMIENTO) return;
  const foto = hero.querySelector(".hero-foto");
  const luz = hero.querySelector(".hero-luz");

  hero.addEventListener("pointermove", (evento) => {
    const caja = hero.getBoundingClientRect();
    const dx = (evento.clientX - caja.left) / caja.width - 0.5;
    const dy = (evento.clientY - caja.top) / caja.height - 0.5;
    if (foto) {
      foto.style.setProperty("--fx", `${(-dx * 28).toFixed(1)}px`);
      foto.style.setProperty("--fy", `${(-dy * 18).toFixed(1)}px`);
    }
    if (luz) {
      luz.style.setProperty("--lx", `${((dx + 0.5) * 100).toFixed(1)}%`);
      luz.style.setProperty("--ly", `${((dy + 0.5) * 100).toFixed(1)}%`);
    }
  });

  hero.addEventListener("pointerleave", () => {
    if (foto) {
      foto.style.setProperty("--fx", "0px");
      foto.style.setProperty("--fy", "0px");
    }
  });
}

/* ================================================================
   1b. EL TITULAR EN 3D
   El titular de la portada es un letrero de verdad: cada letra es
   una pila de copias apiladas hacia atrás (translateZ), así que con
   perspectiva se ve el volumen. La cara es blanca o amarilla 938 C y
   el canto se hunde en los azules del P 105-8 C.

   Tres movimientos, cada uno con un motivo:
     · Entrada: las letras se paran como las paletas del tablero,
       una detrás de otra.
     · Ola: cada tanto una luz recorre el letrero y cada letra se
       adelanta y cambia de color (blanco ↔ amarillo).
     · Mirada: con el mouse se mueve el punto de fuga, y el canto de
       las letras se ve de otro lado, como si caminaras frente al
       cartel. Sin mouse, el punto de fuga deriva solo.

   Para un lector de pantalla es una sola frase normal: las letras
   sueltas van en un bloque aria-hidden.
   ================================================================ */
const CAPAS_TITULAR = 10;

// Arma el letrero de un título. Si el título trae líneas marcadas
// (<span class="linea">), se respetan; si no, las palabras se
// acomodan solas al ancho disponible.
function armarLetrero(titulo) {
  const lineasMarcadas = [...titulo.querySelectorAll(".linea")];
  const lineas = lineasMarcadas.length
    ? lineasMarcadas.map((linea) => ({ texto: linea.textContent.trim(), tono: linea.dataset.tono }))
    : [{ texto: titulo.textContent.trim(), tono: titulo.dataset.tono }];
  const frase = lineas.map((l) => l.texto).join(" ");
  if (!frase) return;

  // Fuera de la portada (saludos, ingreso) alcanza con menos capas:
  // los títulos son más chicos y el canto se ve igual.
  const capas = Number(titulo.dataset.capas) || (titulo.classList.contains("hero-title") ? CAPAS_TITULAR : 8);

  const leible = document.createElement("span");
  leible.className = "sr-only";
  leible.textContent = frase;

  const letrero = document.createElement("span");
  letrero.className = "titular-3d";
  letrero.setAttribute("aria-hidden", "true");

  let indice = 0;
  lineas.forEach(({ texto, tono }) => {
    const fila = document.createElement("span");
    fila.className = "titular-linea";
    if (tono) fila.dataset.tono = tono;

    const palabras = texto.split(/\s+/);
    palabras.forEach((palabra, n) => {
      const palabraEl = document.createElement("span");
      palabraEl.className = "titular-palabra";

      [...palabra].forEach((caracter) => {
        const letra = document.createElement("span");
        letra.className = "letra";
        // La cascada se corta a las 28 letras: en un saludo largo, la
        // última no puede tardar dos segundos en aparecer.
        letra.style.setProperty("--i", Math.min(indice++, 28));

        const pila = document.createElement("span");
        pila.className = "letra-pila";

        // Las capas van de la más lejana a la más cercana, para que
        // en el orden del documento la cara quede arriba de todo.
        for (let c = capas; c >= 1; c--) {
          const capa = document.createElement("span");
          capa.className = "letra-capa";
          capa.style.setProperty("--c", c);
          capa.textContent = caracter;
          pila.appendChild(capa);
        }
        const cara = document.createElement("span");
        cara.className = "letra-cara";
        cara.textContent = caracter;
        pila.appendChild(cara);

        letra.appendChild(pila);
        palabraEl.appendChild(letra);
      });

      fila.appendChild(palabraEl);
      if (n < palabras.length - 1) fila.appendChild(document.createTextNode(" "));
    });
    letrero.appendChild(fila);
  });

  titulo.dataset.textoLetrero = frase;
  // El CSS achica los saludos largos con esto (un nombre largo no
  // puede romper la portada en tres renglones).
  titulo.style.setProperty("--largo", frase.length);
  titulo.replaceChildren(leible, letrero);
  titulo.classList.add("titular-armado");
  if (!MENOS_MOVIMIENTO && "IntersectionObserver" in window) {
    // Fuera de pantalla la ola se pausa: no tiene sentido repintar
    // letras que nadie está mirando.
    new IntersectionObserver(([entrada]) => {
      letrero.classList.toggle("pausado", !entrada.isIntersecting);
    }).observe(titulo);
  }
}

// El punto de fuga sigue al mouse dentro de la zona del título (la
// portada, el panel de ingreso). Se engancha una vez por zona y
// mueve todos los letreros que haya adentro.
function mirarLetreros(zona) {
  if (!zona || zona.dataset.miraLetreros || MENOS_MOVIMIENTO || !HAY_MOUSE) return;
  zona.dataset.miraLetreros = "si";

  zona.addEventListener("pointermove", (evento) => {
    const caja = zona.getBoundingClientRect();
    const dx = (evento.clientX - caja.left) / caja.width - 0.5;
    const dy = (evento.clientY - caja.top) / caja.height - 0.5;
    zona.querySelectorAll(".titular-3d").forEach((letrero) => {
      letrero.classList.add("con-mouse");
      // El punto de fuga va al lado contrario del mouse: el canto de
      // las letras "mira" hacia donde estás vos.
      letrero.style.setProperty("--po-x", `${(50 - dx * 110).toFixed(1)}%`);
      letrero.style.setProperty("--po-y", `${(70 - dy * 110).toFixed(1)}%`);
      letrero.style.setProperty("--ry", `${(dx * 9).toFixed(2)}deg`);
      letrero.style.setProperty("--rx", `${(-dy * 7).toFixed(2)}deg`);
    });
  });

  zona.addEventListener("pointerleave", () => {
    zona.querySelectorAll(".titular-3d").forEach((letrero) => {
      letrero.classList.remove("con-mouse");
      letrero.style.setProperty("--ry", "0deg");
      letrero.style.setProperty("--rx", "0deg");
    });
  });
}

function tituloEn3D() {
  document.querySelectorAll("[data-titulo-3d]").forEach((titulo) => {
    armarLetrero(titulo);

    // Los saludos los escribe otro script (y "Editar perfil" los
    // reescribe con textContent, que borra el letrero). Si el texto
    // cambia, se vuelve a armar.
    new MutationObserver(() => {
      const texto = titulo.textContent.trim();
      if (titulo.querySelector(".titular-3d") || !texto) return;
      armarLetrero(titulo);
    }).observe(titulo, { childList: true, characterData: true, subtree: true });

    mirarLetreros(titulo.closest(".hero, .portada, .auth-marca, .agenda-page-header"));
  });
}

/* ================================================================
   2. PALETAS DEL TABLERO DE LLEGADAS
   Cada dígito es una paleta que gira sobre su bisagra hasta caer en
   el valor final, como los tableros de las estaciones. Es el gesto
   que dice "esto es un horario" sin explicarlo.
   ================================================================ */
const ES_DIGITO = /[0-9]/;

function digitoAlAzar() {
  return String(Math.floor(Math.random() * 10));
}

// Una vuelta de paleta: la hoja de arriba cae hasta quedar de canto,
// se cambia el carácter y la de abajo termina de bajar.
function girarPaleta(paleta, final, vueltas, demora) {
  if (MENOS_MOVIMIENTO || vueltas <= 0) {
    paleta.textContent = final;
    return;
  }
  let hechas = 0;
  const paso = () => {
    const ultima = hechas >= vueltas;
    const caracter = ultima ? final : digitoAlAzar();
    const cae = paleta.animate(
      [{ transform: "perspective(180px) rotateX(0deg)" }, { transform: "perspective(180px) rotateX(-90deg)" }],
      { duration: 46, easing: "cubic-bezier(0.55, 0, 1, 0.45)" }
    );
    cae.onfinish = () => {
      paleta.textContent = caracter;
      const baja = paleta.animate(
        [{ transform: "perspective(180px) rotateX(90deg)" }, { transform: "perspective(180px) rotateX(0deg)" }],
        { duration: 62, easing: "cubic-bezier(0.22, 1, 0.36, 1)" }
      );
      if (!ultima) {
        hechas += 1;
        baja.onfinish = paso;
      }
    };
  };
  setTimeout(paso, demora);
}

// Convierte un texto en una fila de paletas. Los dígitos giran; los
// separadores (":", "/", espacios, "a") quedan quietos.
function paletear(elemento, texto, { demora = 0, vueltas = 5 } = {}) {
  elemento.textContent = "";

  // El texto completo queda para los lectores de pantalla; las
  // paletas son solo dibujo.
  const leible = document.createElement("span");
  leible.className = "sr-only";
  leible.textContent = texto;
  elemento.appendChild(leible);

  const fila = document.createElement("span");
  fila.className = "flap-fila";
  fila.setAttribute("aria-hidden", "true");
  elemento.appendChild(fila);

  let orden = 0;
  [...texto].forEach((caracter) => {
    const pieza = document.createElement("span");
    if (ES_DIGITO.test(caracter) || caracter === ":" || caracter === "/") {
      pieza.className = "flap";
      pieza.textContent = ES_DIGITO.test(caracter) && !MENOS_MOVIMIENTO ? digitoAlAzar() : caracter;
      if (ES_DIGITO.test(caracter)) {
        girarPaleta(pieza, caracter, vueltas > 0 ? vueltas + Math.min(orden, 4) : 0, demora + orden * 18);
      }
      orden += 1;
    } else {
      pieza.className = "flap-sep";
      pieza.textContent = caracter;
    }
    fila.appendChild(pieza);
  });
}

/* Métricas: cada vez que reservas.js / script.js / empresa.js
   repintan la grilla, los números giran. Si un valor no cambió, se
   pinta quieto: animar lo que no cambió es ruido. */
function vigilarMetricas() {
  document.querySelectorAll(".stats-grid").forEach(vigilarTablero);
}

function vigilarTablero(grilla) {
  const ultimos = new Map();
  const aplicar = () => {
    grilla.querySelectorAll(".stat-card").forEach((tarjeta, i) => {
      const valorEl = tarjeta.querySelector(".stat-card-value");
      if (!valorEl || valorEl.dataset.paleteado) return;
      valorEl.dataset.paleteado = "si";
      const etiqueta = tarjeta.querySelector(".stat-card-label")?.textContent || String(i);
      const valor = valorEl.textContent.trim();
      const cambio = ultimos.get(etiqueta) !== valor;
      ultimos.set(etiqueta, valor);
      paletear(valorEl, valor, { demora: 260 + i * 110, vueltas: cambio ? 6 : 0 });
    });
  };

  aplicar();
  new MutationObserver(aplicar).observe(grilla, { childList: true });
}

/* Agenda pública: los horarios de la primera columna caen en su
   lugar fila por fila, una sola vez, al cargar. */
function vigilarAgenda() {
  const cuerpo = document.getElementById("cuerpo-tabla-agenda");
  if (!cuerpo) return;

  const aplicar = () => {
    cuerpo.querySelectorAll("tr").forEach((fila, i) => {
      const celda = fila.querySelector("td");
      if (!celda || celda.dataset.paleteado) return;
      celda.dataset.paleteado = "si";
      paletear(celda, celda.textContent.trim(), { demora: 260 + i * 70, vueltas: 3 });
    });
  };

  aplicar();
  new MutationObserver(aplicar).observe(cuerpo, { childList: true });
}

/* ================================================================
   3. REVELADO 3D AL ENTRAR EN PANTALLA
   Cada bloque se levanta desde atrás, inclinado, como una hoja que
   se endereza. Lo que ya se ve al cargar entra en secuencia (es la
   única coreografía de la página); lo de más abajo, al llegar.
   Se aplica a bloques, no a cada renglón: si cada tarjeta tuviera
   su propia entrada, la página se vería nerviosa.
   ================================================================ */
function revelarAlEntrar() {
  if (MENOS_MOVIMIENTO || !("IntersectionObserver" in window)) return;

  const bloques = [
    ...document.querySelectorAll(
      "main.container > *, .seccion-inner > *, .site-footer-grid"
    ),
  ].filter((el) => {
    if (el.matches("script, style, .panel-back")) return false;
    // Lo que arranca oculto (formularios que se abren, avisos) no
    // se toca: si no, quedaría transparente al mostrarse.
    return el.getClientRects().length > 0 && getComputedStyle(el).display !== "none";
  });

  const alto = window.innerHeight;
  let enPantalla = 0;

  const observador = new IntersectionObserver(
    (entradas) => {
      entradas.forEach((entrada) => {
        if (!entrada.isIntersecting) return;
        const el = entrada.target;
        el.classList.add("visto");
        observador.unobserve(el);
        // Terminado el revelado se saca la clase: así la transición
        // no queda interfiriendo con los efectos de adentro.
        setTimeout(() => el.classList.remove("revelar", "visto"), 1400 + (parseInt(el.style.getPropertyValue("--retraso")) || 0));
      });
    },
    { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
  );

  bloques.forEach((el) => {
    const arriba = el.getBoundingClientRect().top < alto;
    if (arriba) {
      el.style.setProperty("--retraso", `${Math.min(enPantalla, 6) * 90}ms`);
      enPantalla += 1;
    }
    el.classList.add("revelar");
    observador.observe(el);
  });
}

/* ================================================================
   4. INCLINACIÓN HACIA EL MOUSE
   La tarjeta se levanta del lado por el que se la está mirando y el
   brillo sigue al puntero. Se escucha en el documento (delegación),
   así funciona también con las tarjetas que el JS vuelve a pintar.
   ================================================================ */
function inclinarAlPasar() {
  if (!HAY_MOUSE || MENOS_MOVIMIENTO) return;

  const FUERZA = { "role-card": [6, 8], "hub-option": [4, 6], "inventory-card": [7, 9] };
  const selector = ".role-card, .hub-option, .inventory-card";
  let actual = null;
  let cuadro = null;

  const soltar = (el) => {
    el.style.setProperty("--tarjeta-rx", "0deg");
    el.style.setProperty("--tarjeta-ry", "0deg");
  };

  document.addEventListener("pointermove", (evento) => {
    const el = evento.target.closest(selector);
    if (actual && actual !== el) soltar(actual);
    actual = el;
    if (!el || cuadro) return;

    cuadro = requestAnimationFrame(() => {
      cuadro = null;
      const tipo = Object.keys(FUERZA).find((c) => el.classList.contains(c));
      const [fx, fy] = FUERZA[tipo];
      const caja = el.getBoundingClientRect();
      const dx = (evento.clientX - caja.left) / caja.width - 0.5;
      const dy = (evento.clientY - caja.top) / caja.height - 0.5;
      el.style.setProperty("--tarjeta-rx", `${(-dy * fx).toFixed(2)}deg`);
      el.style.setProperty("--tarjeta-ry", `${(dx * fy).toFixed(2)}deg`);
      el.style.setProperty("--luz-x", `${((dx + 0.5) * 100).toFixed(1)}%`);
      el.style.setProperty("--luz-y", `${((dy + 0.5) * 100).toFixed(1)}%`);
    });
  });

  document.addEventListener("pointerleave", () => actual && soltar(actual));
}

/* ================================================================
   5. EL COMPROBANTE DE "CÓMO FUNCIONA"
   El paso que se está leyendo decide la cara del comprobante:
   1 pendiente · 2 sellado "Aprobada" · 3 da vuelta y muestra la
   línea de la agenda pública.
   ================================================================ */
function comprobanteDelProceso() {
  const ticket = document.getElementById("ticket-demo");
  const pasos = [...document.querySelectorAll(".proceso-paso")];
  if (!ticket || pasos.length === 0) return;

  const hora = ticket.querySelector("[data-paleta]");

  const activar = (paso) => {
    if (ticket.dataset.paso === paso) return;
    ticket.dataset.paso = paso;
    pasos.forEach((p) => p.classList.toggle("activo", p.dataset.paso === paso));
    if (paso === "3" && hora) paletear(hora, hora.dataset.paleta, { demora: 380, vueltas: 6 });
  };

  pasos[0].classList.add("activo");

  const observador = new IntersectionObserver(
    (entradas) => {
      entradas.forEach((e) => e.isIntersecting && activar(e.target.dataset.paso));
    },
    { rootMargin: "-42% 0px -42% 0px" }
  );
  pasos.forEach((p) => observador.observe(p));

  // También se puede tocar un paso para verlo.
  pasos.forEach((p) => p.addEventListener("click", () => activar(p.dataset.paso)));
}

/* ================================================================
   6. CALENDARIO: LOS MESES DAN VUELTA
   Cuando se cambia de año o de filtro, calendario.js repinta todo.
   Los meses nuevos bajan girando desde su borde de arriba, como
   las hojas de un almanaque. La primera pintada no se anima: de esa
   se encarga el revelado del bloque.
   ================================================================ */
function vigilarCalendario() {
  const contenedor = document.getElementById("calendario-anual");
  if (!contenedor) return;
  let primera = contenedor.children.length > 0;

  new MutationObserver(() => {
    if (!primera) {
      primera = true;
      return;
    }
    if (MENOS_MOVIMIENTO) return;
    contenedor.querySelectorAll(".cal-month").forEach((mes, i) => {
      mes.animate(
        [
          { opacity: 0, transform: "perspective(900px) rotateX(-75deg)" },
          { opacity: 1, transform: "perspective(900px) rotateX(0deg)" },
        ],
        { duration: 520, delay: i * 28, easing: "cubic-bezier(0.22, 1, 0.36, 1)", fill: "backwards" }
      );
    });
  }).observe(contenedor, { childList: true });
}

/* ================================================================
   7. "PRÓXIMO EN EL POLO"
   La franja de abajo de la portada muestra las próximas reservas
   aprobadas (las mismas de la agenda pública, salen de reservas.js)
   y va pasando de una a otra.
   ================================================================ */
function tableroDePortada() {
  const hora = document.getElementById("tablero-hora");
  const lugar = document.getElementById("tablero-lugar");
  const actividad = document.getElementById("tablero-actividad");
  if (!hora || typeof reservas === "undefined") return;

  const ahora = new Date();
  const proximas = reservas
    .filter((r) => r.estado === "approved" && new Date(r.desde) >= ahora)
    .sort((a, b) => new Date(a.desde) - new Date(b.desde))
    .slice(0, 5);

  if (proximas.length === 0) {
    hora.closest(".hero-tablero").style.visibility = "hidden";
    return;
  }

  const pad = (n) => String(n).padStart(2, "0");
  let indice = 0;

  const mostrar = (primera) => {
    const r = proximas[indice];
    const d = new Date(r.desde);
    paletear(hora, `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}`, {
      demora: primera ? 900 : 0,
      vueltas: 5,
    });
    lugar.textContent = nombreDelSalon(r.salonId);
    actividad.textContent = r.motivo;
    if (!primera && !MENOS_MOVIMIENTO) {
      [lugar, actividad].forEach((el) =>
        el.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], {
          duration: 420,
          easing: "cubic-bezier(0.22, 1, 0.36, 1)",
        })
      );
    }
  };

  mostrar(true);
  if (proximas.length > 1 && !MENOS_MOVIMIENTO) {
    setInterval(() => {
      if (document.hidden) return;
      indice = (indice + 1) % proximas.length;
      mostrar(false);
    }, 5200);
  }
}

/* ================================================================
   9. EL MOUSE COMO LINTERNA
   Recorrés el edificio a oscuras con una linterna: lo que el mouse
   ilumina es lo que se revela. Cuatro efectos, todos con la misma
   idea y todos apagados en pantallas táctiles (no hay cursor que
   seguir) y con "reducir movimiento":

     · El plano: detrás de la página está la cuadrícula del plano
       del edificio, y solo se ve alrededor del mouse.
     · La luz en los bordes: el borde de cada panel se enciende en
       el punto más cercano al mouse, como una linterna rozándolo.
     · Las portadas: la foto se corre un poco, la luz sigue al mouse
       y la maqueta gira para mirarte.
     · Los botones principales se inclinan apenas hacia el mouse
       (efecto imán) para invitar al clic.
   ================================================================ */

// Paneles que reciben la luz en el borde. Las tarjetas de rol y del
// hub ya tienen su propia luz (y se inclinan), por eso no van acá.
const CON_LUZ = [
  ".booking-form",
  ".booking-list",
  ".internship-list",
  ".company-directory",
  ".stats-grid",
  ".cal-month",
  ".inventory-card",
  ".auth-card",
  ".proceso",
  ".modal",
  ".profile-menu",
  ".mini-stat",
  ".tabla-scroll",
  ".perfil-tarjeta",
  ".perfil-mini",
].join(", ");

const CON_IMAN = ".btn-primary, .hub-option-cta, .hero .btn-secondary, .role-card .btn-secondary";

function planoBajoLinterna() {
  const plano = document.createElement("div");
  plano.className = "plano-linterna";
  plano.setAttribute("aria-hidden", "true");
  document.body.prepend(plano);

  // El plano persigue al mouse con un poco de inercia (no se pega
  // al cursor): se siente como una luz que tiene peso.
  let objetivoX = innerWidth / 2;
  let objetivoY = innerHeight / 2;
  let x = objetivoX;
  let y = objetivoY;
  let cuadro = null;

  const mover = () => {
    x += (objetivoX - x) * 0.16;
    y += (objetivoY - y) * 0.16;
    plano.style.setProperty("--mx", `${x.toFixed(1)}px`);
    plano.style.setProperty("--my", `${y.toFixed(1)}px`);
    cuadro = Math.abs(objetivoX - x) + Math.abs(objetivoY - y) > 0.5 ? requestAnimationFrame(mover) : null;
  };

  document.addEventListener("pointermove", (evento) => {
    if (evento.pointerType !== "mouse") return;
    objetivoX = evento.clientX;
    objetivoY = evento.clientY;
    plano.classList.add("encendido");
    if (!cuadro) cuadro = requestAnimationFrame(mover);
  });
  document.documentElement.addEventListener("pointerleave", () => plano.classList.remove("encendido"));
}

function luzEnLosBordes() {
  let actual = null;
  let cuadro = null;
  let ultimo = null;

  const apagar = (el) => el && el.classList.remove("con-luz");

  document.addEventListener("pointermove", (evento) => {
    if (evento.pointerType !== "mouse") return;
    const el = evento.target.closest(CON_LUZ);
    if (actual !== el) {
      apagar(actual);
      actual = el;
    }
    if (!el) return;
    // Las listas se vuelven a pintar con innerHTML (al filtrar, al
    // aprobar...), y eso borra la luz: se vuelve a poner al pasar.
    if (!el.querySelector(":scope > .luz-borde")) {
      const luz = document.createElement("span");
      luz.className = "luz-borde";
      luz.setAttribute("aria-hidden", "true");
      el.appendChild(luz);
    }
    el.classList.add("con-luz");
    ultimo = evento;
    if (cuadro) return;
    cuadro = requestAnimationFrame(() => {
      cuadro = null;
      const caja = el.getBoundingClientRect();
      el.style.setProperty("--lx", `${(ultimo.clientX - caja.left).toFixed(0)}px`);
      el.style.setProperty("--ly", `${(ultimo.clientY - caja.top).toFixed(0)}px`);
    });
  });
  document.documentElement.addEventListener("pointerleave", () => apagar(actual));
}

function portadasVivas() {
  document.querySelectorAll(".portada, .auth-marca, .agenda-page-header").forEach((zona) => {
    orbitarMaqueta(zona, zona.querySelector("[data-maqueta]"), { rango: 16 });

    zona.addEventListener("pointermove", (evento) => {
      const caja = zona.getBoundingClientRect();
      const dx = (evento.clientX - caja.left) / caja.width;
      const dy = (evento.clientY - caja.top) / caja.height;
      zona.style.setProperty("--zx", `${(dx * 100).toFixed(1)}%`);
      zona.style.setProperty("--zy", `${(dy * 100).toFixed(1)}%`);
      zona.style.setProperty("--fx", `${((0.5 - dx) * 26).toFixed(1)}px`);
      zona.style.setProperty("--fy", `${((0.5 - dy) * 16).toFixed(1)}px`);
      zona.classList.add("iluminada");
    });
    zona.addEventListener("pointerleave", () => {
      zona.classList.remove("iluminada");
      zona.style.setProperty("--fx", "0px");
      zona.style.setProperty("--fy", "0px");
    });
  });
}

function botonesIman() {
  const ALCANCE = 7; // px máximos que se corre un botón

  document.addEventListener("pointermove", (evento) => {
    if (evento.pointerType !== "mouse") return;
    const boton = evento.target.closest(CON_IMAN);
    document.querySelectorAll(".iman-activo").forEach((b) => {
      if (b !== boton) {
        b.classList.remove("iman-activo");
        b.style.translate = "";
      }
    });
    if (!boton) return;
    const caja = boton.getBoundingClientRect();
    const dx = (evento.clientX - (caja.left + caja.width / 2)) / (caja.width / 2);
    const dy = (evento.clientY - (caja.top + caja.height / 2)) / (caja.height / 2);
    boton.classList.add("iman-activo");
    boton.style.translate = `${(dx * ALCANCE).toFixed(1)}px ${(dy * ALCANCE * 0.6).toFixed(1)}px`;
  });
}

function mouseComoLinterna() {
  if (!HAY_MOUSE || MENOS_MOVIMIENTO) return;
  planoBajoLinterna();
  luzEnLosBordes();
  portadasVivas();
  botonesIman();
}

/* ================================================================
   ARRANQUE
   ================================================================ */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-maqueta]").forEach(construirMaqueta);

  const maquetaPortada = document.querySelector(".hero [data-maqueta]");
  orbitarMaqueta(document.querySelector(".hero"), maquetaPortada);
  parallaxPortada();
  tituloEn3D();

  vigilarMetricas();
  vigilarAgenda();
  vigilarCalendario();
  comprobanteDelProceso();
  tableroDePortada();
  inclinarAlPasar();
  mouseComoLinterna();

  // El revelado va último: tiene que medir la página ya armada. Se
  // llama directo (no en el cuadro siguiente) para que no llegue a
  // pintarse un cuadro con todo visible que después desaparece.
  revelarAlEntrar();
});
