/* ============================================================
   CALENDARIO ANUAL DE RESERVAS
   Muestra los 12 meses del año de un saque, con los días que
   tienen reservas marcados. Sirve para lo que las listas no
   sirven: ver de un vistazo cómo viene cargado el año, en qué
   meses se junta la actividad y qué semanas están libres antes
   de pedir un salón.

   Lee el mismo array `reservas` de js/reservas.js (por eso este
   archivo se carga después), así que no duplica datos: si se
   aprueba, cancela o crea una reserva, el calendario se repinta
   con pintarCalendarioAnual() y queda al día.

   En la versión con backend sería algo como
   GET /api/v1/bookings?desde=2026-01-01&hasta=2026-12-31
   ============================================================ */

const NOMBRES_MES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
];

// Empezamos las semanas en lunes (como los calendarios de acá),
// no en domingo como viene por defecto en JavaScript.
const INICIALES_DIA = ["L", "M", "M", "J", "V", "S", "D"];

// Año que se está mirando y filtro de estado. Viven afuera de las
// funciones para que se mantengan al repintar.
let anioCalendario = new Date().getFullYear();
let filtroCalendario = "approved";

// Solo las reservas del profesor logueado, o todas, según la
// pantalla: dashboard-profesor.html pasa soloMias = true.
let soloMisReservasCalendario = false;

function claveDeFecha(fecha) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${fecha.getFullYear()}-${pad(fecha.getMonth() + 1)}-${pad(fecha.getDate())}`;
}

// Agrupa las reservas visibles por día: { "2026-09-08": [reserva, ...] }
function agruparReservasPorDia() {
  const grupos = {};

  reservas
    .filter((reserva) => {
      if (soloMisReservasCalendario && !reserva.esMia) return false;
      if (filtroCalendario !== "todas" && reserva.estado !== filtroCalendario) return false;
      return reserva.desde.slice(0, 4) === String(anioCalendario);
    })
    .forEach((reserva) => {
      const dia = reserva.desde.slice(0, 10);
      if (!grupos[dia]) grupos[dia] = [];
      grupos[dia].push(reserva);
    });

  return grupos;
}

/* ------------------------------------------------------------
   UN MES: la grilla de 7 columnas con sus días
   ------------------------------------------------------------ */
function dibujarMes(mes, grupos, hoyClave) {
  const primerDia = new Date(anioCalendario, mes, 1);
  const diasEnElMes = new Date(anioCalendario, mes + 1, 0).getDate();

  // getDay() devuelve 0 para domingo; lo pasamos a "lunes = 0"
  // para que la primera columna sea el lunes.
  const desplazamiento = (primerDia.getDay() + 6) % 7;

  const cabecera = INICIALES_DIA.map((inicial) => `<span class="cal-dow">${inicial}</span>`).join("");

  // Casillas vacías antes del día 1, para que caiga en su columna.
  let celdas = Array.from({ length: desplazamiento }, () => `<span class="cal-day empty"></span>`);

  for (let dia = 1; dia <= diasEnElMes; dia++) {
    const clave = claveDeFecha(new Date(anioCalendario, mes, dia));
    const delDia = grupos[clave] || [];
    const clases = ["cal-day"];

    if (delDia.length > 0) clases.push("has-bookings");
    if (delDia.length >= 3) clases.push("busy"); // día cargado
    if (clave === hoyClave) clases.push("today");

    const titulo =
      delDia.length > 0
        ? `${delDia.length} reserva${delDia.length === 1 ? "" : "s"}: ${delDia
            .map((r) => r.motivo)
            .join(" · ")}`
        : "Sin reservas";

    celdas.push(
      `<button type="button" class="${clases.join(" ")}" data-dia="${clave}" title="${titulo}">${dia}</button>`
    );
  }

  const totalMes = Object.keys(grupos).filter((clave) => Number(clave.slice(5, 7)) === mes + 1).length;

  return `
    <div class="cal-month">
      <p class="cal-month-name">
        ${NOMBRES_MES[mes]}
        ${totalMes > 0 ? `<span class="cal-month-count">${totalMes}</span>` : ""}
      </p>
      <div class="cal-grid">${cabecera}${celdas.join("")}</div>
    </div>
  `;
}

/* ------------------------------------------------------------
   EL CALENDARIO COMPLETO
   ------------------------------------------------------------ */
function pintarCalendarioAnual() {
  const contenedor = document.getElementById("calendario-anual");
  if (!contenedor || typeof reservas === "undefined") return;

  const grupos = agruparReservasPorDia();
  const hoyClave = claveDeFecha(new Date());
  const totalAnio = Object.values(grupos).reduce((suma, lista) => suma + lista.length, 0);

  const opcionesFiltro = [
    { valor: "approved", etiqueta: "Aprobadas" },
    { valor: "pending", etiqueta: "Pendientes" },
    { valor: "todas", etiqueta: "Todas" },
  ];

  contenedor.innerHTML = `
    <div class="cal-toolbar">
      <div class="cal-year-nav">
        <button type="button" class="cal-nav-btn" data-anio="-1" aria-label="Año anterior">‹</button>
        <span class="cal-year">${anioCalendario}</span>
        <button type="button" class="cal-nav-btn" data-anio="1" aria-label="Año siguiente">›</button>
      </div>

      <div class="filter-chips" style="margin: 0;">
        ${opcionesFiltro
          .map(
            (opcion) => `
          <button type="button" class="filter-chip ${filtroCalendario === opcion.valor ? "active" : ""}" data-estado="${opcion.valor}">
            ${opcion.etiqueta}
          </button>`
          )
          .join("")}
      </div>
    </div>

    <p class="cal-summary">
      ${
        totalAnio === 0
          ? "No hay reservas para mostrar en este año con el filtro elegido."
          : `${totalAnio} reserva${totalAnio === 1 ? "" : "s"} en ${anioCalendario}. Tocá un día marcado para ver el detalle.`
      }
    </p>

    <div class="cal-year-grid">
      ${Array.from({ length: 12 }, (_, mes) => dibujarMes(mes, grupos, hoyClave)).join("")}
    </div>

    <div class="cal-legend">
      <span><i class="cal-dot"></i> Con reservas</span>
      <span><i class="cal-dot busy"></i> 3 o más</span>
      <span><i class="cal-dot today"></i> Hoy</span>
    </div>

    <div id="calendario-detalle"></div>
  `;

  // Cambiar de año
  contenedor.querySelectorAll("button[data-anio]").forEach((boton) => {
    boton.addEventListener("click", () => {
      anioCalendario += Number(boton.dataset.anio);
      pintarCalendarioAnual();
    });
  });

  // Cambiar el filtro de estado
  contenedor.querySelectorAll("button[data-estado]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroCalendario = boton.dataset.estado;
      pintarCalendarioAnual();
    });
  });

  // Tocar un día: mostrar sus reservas debajo
  contenedor.querySelectorAll("button[data-dia]").forEach((boton) => {
    boton.addEventListener("click", () => {
      contenedor.querySelectorAll(".cal-day").forEach((d) => d.classList.remove("selected"));
      boton.classList.add("selected");
      mostrarDetalleDelDia(boton.dataset.dia, grupos[boton.dataset.dia] || []);
    });
  });
}

function mostrarDetalleDelDia(clave, delDia) {
  const detalleEl = document.getElementById("calendario-detalle");
  if (!detalleEl) return;

  const fecha = new Date(`${clave}T00:00:00`);
  const etiqueta = fecha.toLocaleDateString("es-UY", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  if (delDia.length === 0) {
    detalleEl.innerHTML = `
      <div class="cal-detail">
        <p class="cal-detail-date">${etiqueta}</p>
        <p class="empty-state" style="margin: 0;">Sin reservas este día. Está libre para pedir un salón.</p>
      </div>
    `;
    return;
  }

  // formatearRango y nombreDelSalon vienen de js/reservas.js
  const tarjetas = delDia
    .sort((a, b) => new Date(a.desde) - new Date(b.desde))
    .map(
      (reserva) => `
      <div class="booking-card">
        <div>
          <p class="booking-card-title">${reserva.motivo}</p>
          <p class="booking-card-meta">
            ${nombreDelSalon(reserva.salonId)} · ${formatearRango(reserva.desde, reserva.hasta)} · ${reserva.pedidaPor}
          </p>
        </div>
        ${chipDeEstado(reserva.estado)}
      </div>
    `
    )
    .join("");

  detalleEl.innerHTML = `
    <div class="cal-detail">
      <p class="cal-detail-date">${etiqueta}</p>
      <div class="booking-list">${tarjetas}</div>
    </div>
  `;
}

document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.getElementById("calendario-anual");
  if (!contenedor) return;

  // La pantalla decide qué mostrar con data-solo-mias en el contenedor.
  soloMisReservasCalendario = contenedor.dataset.soloMias === "true";
  pintarCalendarioAnual();
});
