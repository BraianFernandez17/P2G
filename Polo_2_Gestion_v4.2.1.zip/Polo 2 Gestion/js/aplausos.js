/* ============================================================
   ASISTENTE A PEDIDO: DOS APLAUSOS Y SE PRESENTA
   Con "Abrir con aplausos" encendido, el sitio escucha el
   micrófono (sin grabar ni mandar nada a ningún lado: el sonido se
   analiza en el momento, en el navegador) y, al oír dos aplausos
   seguidos, abre el asistente en grande en el centro de la
   pantalla, dice "A sus órdenes" y se queda escuchando.

   Dos piezas:
     1. EL OÍDO: detecta aplausos con la Web Audio API.
     2. LA ESCENA: la interfaz grande del centro, con su entrada
        animada y una conversación por voz que se encadena sola
        (habla → escucha → contesta → escucha...).

   Requisitos del navegador (no son caprichos del sitio):
     · El micrófono solo funciona en https:// o en localhost. Por
       eso viene "Abrir Polo 2 Gestion.bat", que sirve la página en
       http://localhost. Abriendo el HTML con doble clic (file://)
       el navegador no deja usarlo.
     · El sonido y la voz arrancan recién después del primer clic o
       tecla en la página (política de los navegadores para que
       ninguna página empiece a hablar sola).
   ============================================================ */

/* ------------------------------------------------------------
   1. EL OÍDO
   Un aplauso es un golpe: sube de golpe, tiene mucho agudo y se
   apaga enseguida (menos de ~150 ms). La voz y la música, en
   cambio, se sostienen. Se busca exactamente eso:
     · se filtran los graves (pasa altos a 1,6 kHz), donde vive la
       mayor parte de la voz y el ruido de fondo;
     · el umbral se adapta al ruido de la sala;
     · un pico solo cuenta si sube de golpe, cae en menos de 40 ms
       y después se queda callado (la voz vuelve a subir enseguida
       con la sílaba siguiente);
     · la "cola" de un aplauso no cuenta como otro aplauso;
     · hacen falta DOS aplausos con 0,18–0,75 s entre sí, y que no
       venga un tercero enseguida (así no lo dispara el teclado ni
       una ronda de aplausos de verdad).
   ------------------------------------------------------------ */
const oido = {
  encendido: false,
  contexto: null,
  flujo: null,
  analizador: null,
  muestras: null,
  intervalo: null,
  piso: 0.004,           // ruido de fondo estimado (RMS)
  esperandoCaida: false, // hubo un pico y vemos si se apaga rápido
  picoEn: 0,
  picoNivel: 0,
  ultimoAplauso: 0,
  confirmacion: null,    // espera corta para descartar un tercer golpe
  enfriarHasta: 0,       // después de abrir, un rato sin escuchar aplausos
  ultimaTecla: 0,
  rmsAnterior: 0,        // para exigir una subida brusca (flanco)
  sordoHasta: 0,         // tras un golpe, su "cola" no cuenta como otro
};

// El detector corre en el hilo de audio del navegador (AudioWorklet):
// recibe TODO el sonido, en bloques de 128 muestras (~2,7 ms), aunque
// la página esté ocupada con animaciones. Si leyéramos el micrófono
// desde la página, un cuadro lento podía saltearse justo el aplauso.
// Solo avisa "hubo un golpe en tal momento"; la lógica del par de
// aplausos sigue en la página.
const CODIGO_DETECTOR = `
class DetectorDeAplausos extends AudioWorkletProcessor {
  constructor() {
    super();
    this.piso = 0.004; this.anterior = 0; this.esperando = false;
    this.inicio = 0; this.nivel = 0; this.sordoHasta = 0;
  }
  process(entradas) {
    const canal = entradas[0] && entradas[0][0];
    if (!canal) return true;
    let suma = 0, pico = 0;
    for (let i = 0; i < canal.length; i++) {
      const v = canal[i]; suma += v * v;
      const a = v < 0 ? -v : v; if (a > pico) pico = a;
    }
    const rms = Math.sqrt(suma / canal.length);
    const ahora = currentTime * 1000;
    const anterior = this.anterior; this.anterior = rms;
    if (!this.esperando) {
      this.piso = rms < this.piso ? this.piso * 0.9 + rms * 0.1 : this.piso * 0.999 + rms * 0.001;
      if (this.piso < 0.0015) this.piso = 0.0015;
      const umbral = Math.max(0.025, this.piso * 8);
      if (ahora >= this.sordoHasta && pico > 0.12 && rms > umbral && rms > anterior * 2.5 && anterior < umbral) {
        this.esperando = true; this.inicio = ahora; this.nivel = rms;
      }
      return true;
    }
    if (this.esperando === "silencio") {
      // Después de caer, un aplauso se queda callado. La voz, en
      // cambio, vuelve a subir enseguida con la sílaba siguiente.
      if (rms > this.nivel * 0.55) {
        this.esperando = false; this.sordoHasta = ahora + 160;
        this.port.postMessage({ tipo: "sostenido" });
      } else if (ahora - this.caida >= 45) {
        this.esperando = false; this.sordoHasta = ahora + 120;
        this.port.postMessage({ tipo: "golpe", t: this.inicio });
      }
      return true;
    }
    if (rms > this.nivel) this.nivel = rms;
    const transcurrido = ahora - this.inicio;
    if (rms < this.nivel * 0.35) {
      // Un aplauso cae en menos de ~45 ms (con eco de sala incluido);
      // algo más lento no lo es.
      if (transcurrido <= 45) { this.esperando = "silencio"; this.caida = ahora; }
      else { this.esperando = false; this.sordoHasta = ahora + 160; }
    } else if (transcurrido > 90) {
      this.esperando = false; this.sordoHasta = ahora + 160;
      this.port.postMessage({ tipo: "sostenido" });
    }
    return true;
  }
}
registerProcessor("detector-de-aplausos", DetectorDeAplausos);
`;

function contextoSeguroParaMicrofono() {
  return window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
}

function preferenciaAplausos() {
  return typeof obtenerPreferencias === "function" && obtenerPreferencias().aplausos === true;
}

function guardarPreferenciaAplausos(valor) {
  if (typeof obtenerPreferencias !== "function") return;
  guardarPreferencias({ ...obtenerPreferencias(), aplausos: valor });
}

async function encenderOido({ avisar = true } = {}) {
  if (oido.encendido) return true;

  if (!contextoSeguroParaMicrofono()) {
    if (avisar && typeof mostrarToast === "function") {
      mostrarToast(
        'El navegador solo deja usar el micrófono en localhost. Abrí la página con "Abrir Polo 2 Gestion.bat".',
        "error"
      );
    }
    return false;
  }

  try {
    // Sin supresión de ruido ni control de ganancia: los dos
    // "aplastan" justamente los golpes cortos que queremos oír.
    oido.flujo = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false },
    });
  } catch (error) {
    if (avisar && typeof mostrarToast === "function") {
      mostrarToast("Sin permiso para el micrófono no puedo oír los aplausos. Habilitalo en el candado de la barra de direcciones.", "error");
    }
    return false;
  }

  const Contexto = window.AudioContext || window.webkitAudioContext;
  oido.contexto = new Contexto();
  const fuente = oido.contexto.createMediaStreamSource(oido.flujo);
  const pasaAltos = oido.contexto.createBiquadFilter();
  pasaAltos.type = "highpass";
  pasaAltos.frequency.value = 1600;
  fuente.connect(pasaAltos);

  let conWorklet = false;
  if (oido.contexto.audioWorklet && window.AudioWorkletNode) {
    try {
      const url = URL.createObjectURL(new Blob([CODIGO_DETECTOR], { type: "text/javascript" }));
      await oido.contexto.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      const detector = new AudioWorkletNode(oido.contexto, "detector-de-aplausos");
      detector.port.onmessage = ({ data }) => {
        if (data.tipo === "golpe") recibirGolpe(data.t);
        else oido.ultimoAplauso = 0; // un sonido sostenido rompe el par
      };
      // El nodo tiene que estar conectado a la salida para que el
      // navegador lo haga trabajar; va con volumen cero.
      const silencio = oido.contexto.createGain();
      silencio.gain.value = 0;
      pasaAltos.connect(detector).connect(silencio).connect(oido.contexto.destination);
      oido.detector = detector;
      conWorklet = true;
    } catch {
      conWorklet = false;
    }
  }

  if (!conWorklet) {
    // Respaldo para navegadores sin AudioWorklet: se lee el sonido
    // desde la página cada 12 ms.
    oido.analizador = oido.contexto.createAnalyser();
    oido.analizador.fftSize = 512; // ~11 ms por ventana a 48 kHz
    pasaAltos.connect(oido.analizador);
    oido.muestras = new Float32Array(oido.analizador.fftSize);
    oido.intervalo = setInterval(analizarSonido, 12);
  }

  oido.encendido = true;
  despertarOidoAlPrimerGesto();
  pintarEstadoOido();
  return true;
}

function apagarOido() {
  clearInterval(oido.intervalo);
  clearTimeout(oido.confirmacion);
  if (oido.flujo) oido.flujo.getTracks().forEach((pista) => pista.stop());
  if (oido.contexto) oido.contexto.close();
  Object.assign(oido, { encendido: false, contexto: null, flujo: null, analizador: null, detector: null, esperandoCaida: false, ultimoAplauso: 0 });
  pintarEstadoOido();
}

// Si el navegador dejó el audio en pausa (todavía nadie tocó la
// página), se despierta con el primer clic o tecla.
function despertarOidoAlPrimerGesto() {
  if (!oido.contexto || oido.contexto.state === "running") return;
  const despertar = () => {
    if (oido.contexto && oido.contexto.state !== "running") oido.contexto.resume().then(pintarEstadoOido);
  };
  ["pointerdown", "keydown", "touchstart"].forEach((tipo) =>
    window.addEventListener(tipo, despertar, { once: true, capture: true })
  );
  oido.contexto.addEventListener("statechange", pintarEstadoOido);
}

function analizarSonido() {
  if (!oido.contexto || oido.contexto.state !== "running") return;
  oido.analizador.getFloatTimeDomainData(oido.muestras);

  let suma = 0;
  let pico = 0;
  for (let i = 0; i < oido.muestras.length; i++) {
    const v = oido.muestras[i];
    suma += v * v;
    const a = v < 0 ? -v : v;
    if (a > pico) pico = a;
  }
  const rms = Math.sqrt(suma / oido.muestras.length);
  const ahora = performance.now();

  // Mientras el asistente habla o escucha, sus propios sonidos (o
  // la voz de la persona) no tienen que contar como aplausos.
  const ocupado =
    escena.abierta ||
    (typeof asistente !== "undefined" && (asistente.hablando || asistente.escuchando)) ||
    document.hidden ||
    ahora < oido.enfriarHasta ||
    ahora - oido.ultimaTecla < 500;

  const anterior = oido.rmsAnterior;
  oido.rmsAnterior = rms;

  if (!oido.esperandoCaida) {
    // El piso de ruido baja rápido y sube despacio: un golpe no lo
    // levanta, pero una sala ruidosa sí.
    oido.piso = rms < oido.piso ? oido.piso * 0.8 + rms * 0.2 : oido.piso * 0.995 + rms * 0.005;
    oido.piso = Math.max(oido.piso, 0.0015);
    const umbral = Math.max(0.02, oido.piso * 7);
    const subidaBrusca = rms > anterior * 3 && anterior < umbral;
    if (!ocupado && ahora >= oido.sordoHasta && pico > 0.1 && rms > umbral && subidaBrusca) {
      oido.esperandoCaida = true;
      oido.picoEn = ahora;
      oido.picoNivel = rms;
    }
    return;
  }

  oido.picoNivel = Math.max(oido.picoNivel, rms);
  const transcurrido = ahora - oido.picoEn;
  if (rms < oido.picoNivel * 0.25) {
    oido.esperandoCaida = false;
    // 160 ms de sordera: lo que queda del golpe (eco, cola) no se
    // cuenta como un segundo aplauso.
    oido.sordoHasta = ahora + 160;
    if (transcurrido <= 70) registrarAplauso(oido.picoEn);
  } else if (transcurrido > 90) {
    // Sonido sostenido: era voz o música. Se descarta y, si venía
    // un aplauso anterior, también (no era un par limpio).
    oido.esperandoCaida = false;
    oido.sordoHasta = ahora + 160;
    oido.ultimoAplauso = 0;
  }
}

// Un golpe que avisó el hilo de audio. La hora viene en el reloj del
// audio (ms); la regla de ocupado se aplica acá, en la página.
function recibirGolpe(momentoAudio) {
  const ahora = performance.now();
  const ocupado =
    escena.abierta ||
    (typeof asistente !== "undefined" && (asistente.hablando || asistente.escuchando)) ||
    document.hidden ||
    ahora < oido.enfriarHasta ||
    ahora - oido.ultimaTecla < 500;
  if (ocupado) {
    oido.ultimoAplauso = 0;
    return;
  }
  registrarAplauso(momentoAudio);
}

function registrarAplauso(momento) {
  marcarAplausoOido();
  const desdeElAnterior = momento - oido.ultimoAplauso;

  // ¿Un tercer golpe mientras confirmábamos el par? Era otra cosa.
  if (oido.confirmacion) {
    clearTimeout(oido.confirmacion);
    oido.confirmacion = null;
    oido.ultimoAplauso = 0;
    return;
  }

  if (oido.ultimoAplauso && desdeElAnterior > 180 && desdeElAnterior < 750) {
    oido.ultimoAplauso = 0;
    oido.confirmacion = setTimeout(() => {
      oido.confirmacion = null;
      oido.enfriarHasta = performance.now() + 2500;
      abrirEscena({ porAplauso: true });
    }, 380);
    return;
  }
  oido.ultimoAplauso = momento;
}

// El botón del borde muestra si el oído está atento, dormido (falta
// un clic en la página) o apagado.
function pintarEstadoOido() {
  const contenedor = document.getElementById("asistente-voz");
  const dormido = oido.encendido && oido.contexto && oido.contexto.state !== "running";
  if (contenedor) {
    contenedor.classList.toggle("oido-activo", oido.encendido && !dormido);
    contenedor.classList.toggle("oido-dormido", !!dormido);
  }
  const interruptor = document.getElementById("asistente-oido");
  if (interruptor) {
    interruptor.setAttribute("aria-pressed", String(oido.encendido));
    interruptor.querySelector(".oido-texto").textContent = !oido.encendido
      ? "Abrir con aplausos: apagado"
      : dormido
      ? "Tocá la página para que te oiga"
      : "Abrir con aplausos: aplaudí dos veces";
  }
  const boton = document.getElementById("asistente-boton");
  if (boton) {
    boton.title = oido.encendido ? "Asistente del Polo · aplaudí dos veces para llamarlo" : "Asistente del Polo";
  }
}

function marcarAplausoOido() {
  const contenedor = document.getElementById("asistente-voz");
  if (!contenedor) return;
  contenedor.classList.remove("oido-golpe");
  void contenedor.offsetWidth; // reinicia la animación
  contenedor.classList.add("oido-golpe");
}

/* ------------------------------------------------------------
   2. LA ESCENA
   ------------------------------------------------------------ */
const escena = {
  abierta: false,
  el: null,
  reconocimiento: null,
  focoAnterior: null,
  despidiendo: false,
  hex: { turbulencia: null, desplazamiento: null, cuadro: null, t: 0, energia: 0 },
};

const CIERRES_ESCENA = ["gracias", "muchas gracias", "eso es todo", "nada mas", "nada más", "cerrar", "chau", "adios", "adiós", "listo gracias", "salir", "terminar"];

// Los seis triángulos que arman el hexágono en la entrada: cada uno
// va del centro a un lado y llega volando desde su dirección.
const VERTICES_HEX = [
  [50, 100], [6.7, 75], [6.7, 25], [50, 0], [93.3, 25], [93.3, 75],
];

function construirEscena() {
  if (escena.el) return escena.el;

  const piezas = VERTICES_HEX.map((v, i) => {
    const w = VERTICES_HEX[(i + 1) % 6];
    const cx = (50 + v[0] + w[0]) / 3 - 50;
    const cy = (50 + v[1] + w[1]) / 3 - 50;
    const largo = Math.hypot(cx, cy) || 1;
    return `<span class="escena-pieza" style="--i:${i}; --dx:${((cx / largo) * 260).toFixed(0)}px; --dy:${((cy / largo) * 260).toFixed(0)}px; --rz:${i % 2 ? 70 : -70}deg; clip-path: polygon(50% 50%, ${v[0]}% ${v[1]}%, ${w[0]}% ${w[1]}%);"></span>`;
  }).join("");

  const titulo = "A sus órdenes";
  const letras = [...titulo]
    .map((c, i) => (c === " " ? " " : `<span style="--i:${i}">${c}</span>`))
    .join("");

  const el = document.createElement("div");
  el.id = "escena-asistente";
  el.className = "escena";
  el.hidden = true;
  el.setAttribute("role", "dialog");
  el.setAttribute("aria-modal", "true");
  el.setAttribute("aria-labelledby", "escena-titulo");
  el.innerHTML = `
    <div class="escena-fondo" aria-hidden="true"></div>
    <div class="escena-ondas" aria-hidden="true">
      <svg class="escena-onda" viewBox="0 0 128 128"><polygon points="${PUNTOS_HEXAGONO}" /></svg>
      <svg class="escena-onda" viewBox="0 0 128 128"><polygon points="${PUNTOS_HEXAGONO}" /></svg>
    </div>

    <button type="button" class="escena-cerrar" id="escena-cerrar" aria-label="Cerrar el asistente">×</button>

    <div class="escena-centro">
      <div class="escena-nucleo">
        <div class="escena-piezas" aria-hidden="true">${piezas}</div>
        <button type="button" class="escena-hex" id="escena-hex" data-estado="reposo" aria-label="Hablar con el asistente">
          <svg viewBox="-16 -16 160 160" aria-hidden="true">
            <filter id="escena-deformar" x="-25%" y="-25%" width="150%" height="150%">
              <feTurbulence type="turbulence" numOctaves="2" baseFrequency="0.006" result="turbulence" />
              <feDisplacementMap in2="turbulence" in="SourceGraphic" scale="4" xChannelSelector="R" yChannelSelector="G" />
            </filter>
            <g filter="url(#escena-deformar)">
              <polygon class="hex-cuerpo" points="${PUNTOS_HEXAGONO}" fill="currentColor" />
              <polygon class="hex-filo" points="${PUNTOS_HEXAGONO}" fill="none" />
            </g>
          </svg>
        </button>
      </div>

      <h2 class="escena-titulo" id="escena-titulo"><span class="sr-only">${titulo}</span><span aria-hidden="true">${letras}</span></h2>
      <p class="escena-estado" id="escena-estado">¿En qué te ayudo?</p>

      <p class="escena-transcripcion" id="escena-transcripcion" aria-live="polite"></p>
      <div class="escena-respuesta" id="escena-respuesta" aria-live="polite"></div>

      <div class="escena-chips" id="escena-chips"></div>

      <form class="escena-entrada" id="escena-entrada">
        <label class="sr-only" for="escena-texto">Escribile al asistente</label>
        <input type="text" id="escena-texto" placeholder="o escribí tu pedido" autocomplete="off" spellcheck="false" />
        <button type="submit" aria-label="Enviar">→</button>
      </form>

      <p class="escena-pie">Decí "gracias" para cerrar · Esc</p>
    </div>
  `;
  document.body.appendChild(el);
  escena.el = el;
  escena.hex.turbulencia = el.querySelector("feTurbulence");
  escena.hex.desplazamiento = el.querySelector("feDisplacementMap");

  el.querySelector("#escena-cerrar").addEventListener("click", () => cerrarEscena());
  el.querySelector("#escena-hex").addEventListener("click", () => {
    if (asistente.escuchando) {
      escena.reconocimiento && escena.reconocimiento.stop();
    } else {
      window.speechSynthesis && window.speechSynthesis.cancel();
      escucharEnEscena();
    }
  });
  el.querySelector("#escena-entrada").addEventListener("submit", (evento) => {
    evento.preventDefault();
    const campo = el.querySelector("#escena-texto");
    const texto = campo.value.trim();
    if (!texto) return;
    campo.value = "";
    if (escena.reconocimiento) escena.reconocimiento.abort();
    atenderPedido(texto);
  });
  el.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape") {
      evento.stopPropagation();
      cerrarEscena();
    }
    // El foco no se escapa del diálogo mientras está abierto.
    if (evento.key === "Tab") {
      const foco = [...el.querySelectorAll("button, input")].filter((b) => !b.disabled && b.offsetParent !== null);
      if (!foco.length) return;
      const primero = foco[0];
      const ultimo = foco[foco.length - 1];
      if (evento.shiftKey && document.activeElement === primero) {
        evento.preventDefault();
        ultimo.focus();
      } else if (!evento.shiftKey && document.activeElement === ultimo) {
        evento.preventDefault();
        primero.focus();
      }
    }
  });
  return el;
}

function pintarChipsEscena() {
  const chipsEl = document.getElementById("escena-chips");
  if (!chipsEl || typeof destinosPermitidos !== "function") return;
  const ejemplos = destinosPermitidos().filter((d) => !d.accion).slice(0, 4);
  chipsEl.innerHTML = ejemplos
    .map((d) => `<button type="button" class="escena-chip" data-id="${d.id}">${d.nombre}</button>`)
    .join("");
  chipsEl.querySelectorAll("button[data-id]").forEach((chip) =>
    chip.addEventListener("click", () => {
      const destino = DESTINOS_ASISTENTE.find((d) => d.id === chip.dataset.id);
      if (!destino) return;
      if (escena.reconocimiento) escena.reconocimiento.abort();
      agregarAlChat(`Llevame a ${destino.nombre}`, "yo");
      mostrarTranscripcion(`Llevame a ${destino.nombre}`, true);
      irADestino(destino);
    })
  );
}

function estadoEscena(estado, texto) {
  const hex = document.getElementById("escena-hex");
  if (hex) hex.dataset.estado = estado;
  if (escena.el) escena.el.dataset.estado = estado;
  const estadoEl = document.getElementById("escena-estado");
  if (estadoEl && texto !== undefined) estadoEl.textContent = texto;
}

function mostrarTranscripcion(texto, final = false) {
  const el = document.getElementById("escena-transcripcion");
  if (!el) return;
  el.textContent = texto ? `“${texto}”` : "";
  el.classList.toggle("en-vivo", !final && !!texto);
}

function abrirEscena({ porAplauso = false } = {}) {
  if (escena.abierta || typeof asistente === "undefined") return;
  const el = construirEscena();
  pintarChipsEscena();

  // Si el panel chico estaba abierto, se cierra: no hacen falta dos.
  const contenedor = document.getElementById("asistente-voz");
  if (contenedor && contenedor.classList.contains("abierto")) document.getElementById("asistente-cerrar")?.click();
  if (asistente.reconocimiento && asistente.escuchando) asistente.reconocimiento.abort();

  escena.abierta = true;
  escena.despidiendo = false;
  escena.focoAnterior = document.activeElement;
  mostrarTranscripcion("");
  document.getElementById("escena-respuesta").innerHTML = "";
  estadoEscena("reposo", porAplauso ? "Te escuché. ¿En qué te ayudo?" : "¿En qué te ayudo?");

  el.hidden = false;
  el.classList.remove("cerrando");
  document.documentElement.classList.add("escena-activa");
  // Un cuadro después, para que la entrada arranque desde el estado
  // inicial (si no, el navegador salta directo al final).
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("visible")));
  setTimeout(() => document.getElementById("escena-cerrar")?.focus({ preventScroll: true }), 60);
  animarHexEscena();

  // La escena toma el control de las respuestas del asistente.
  asistente.alResponder = mostrarRespuestaEscena;
  asistente.despuesDeHablar = () => {
    if (!escena.abierta) return;
    if (escena.despidiendo) {
      cerrarEscena();
      return;
    }
    escucharEnEscena();
  };

  // "A sus órdenes" cuando termina de armarse el hexágono.
  const espera = MENOS_MOVIMIENTO_ASISTENTE ? 150 : 900;
  setTimeout(() => {
    if (!escena.abierta) return;
    estadoEscena("hablando", "¿En qué te ayudo?");
    hablar("A sus órdenes. ¿En qué te ayudo?", { alTerminar: asistente.despuesDeHablar });
  }, espera);
}

function cerrarEscena() {
  if (!escena.abierta) return;
  escena.abierta = false;
  if (escena.reconocimiento) escena.reconocimiento.abort();
  if (!escena.despidiendo && window.speechSynthesis) window.speechSynthesis.cancel();
  escena.despidiendo = false;
  asistente.alResponder = null;
  asistente.despuesDeHablar = null;
  oido.enfriarHasta = performance.now() + 1500;

  const el = escena.el;
  el.classList.remove("visible");
  el.classList.add("cerrando");
  document.documentElement.classList.remove("escena-activa");
  setTimeout(() => {
    if (escena.abierta) return;
    el.hidden = true;
    el.classList.remove("cerrando");
    cancelAnimationFrame(escena.hex.cuadro);
    escena.hex.cuadro = null;
  }, MENOS_MOVIMIENTO_ASISTENTE ? 50 : 320);

  const destino = escena.focoAnterior && document.contains(escena.focoAnterior) ? escena.focoAnterior : document.getElementById("asistente-boton");
  destino && destino.focus && destino.focus({ preventScroll: true });
}

function mostrarRespuestaEscena(texto, conAccion) {
  if (!escena.abierta) return;
  const respuestaEl = document.getElementById("escena-respuesta");
  respuestaEl.innerHTML = "";
  const p = document.createElement("p");
  p.textContent = texto;
  respuestaEl.appendChild(p);
  if (conAccion) {
    const boton = document.createElement("button");
    boton.type = "button";
    boton.className = "escena-accion";
    boton.textContent = conAccion.etiqueta;
    boton.addEventListener("click", () => {
      boton.remove();
      if (escena.reconocimiento) escena.reconocimiento.abort();
      conAccion.alTocar();
    });
    respuestaEl.appendChild(boton);
  }
  // Reinicia la animación de entrada de la respuesta
  respuestaEl.classList.remove("nueva");
  void respuestaEl.offsetWidth;
  respuestaEl.classList.add("nueva");
  estadoEscena("hablando", "");
}

function atenderPedido(texto) {
  mostrarTranscripcion(texto, true);
  const t = normalizarTexto(texto);
  if (CIERRES_ESCENA.some((c) => t === normalizarTexto(c) || t.startsWith(normalizarTexto(c) + " "))) {
    escena.despidiendo = true;
    asistente.pendiente = null;
    agregarAlChat(texto, "yo");
    responderAsistente("Cuando quieras. Aplaudí dos veces y vuelvo.");
    return;
  }
  procesarPedido(texto);
}

function escucharEnEscena() {
  if (!escena.abierta) return;
  if (typeof soportaDictado !== "function" || !soportaDictado()) {
    estadoEscena("reposo", "Este navegador no reconoce la voz. Escribime tu pedido acá abajo.");
    return;
  }
  if (asistente.escuchando) return;

  const Reconocimiento = window.SpeechRecognition || window.webkitSpeechRecognition;
  const reconocimiento = new Reconocimiento();
  reconocimiento.lang = "es-UY";
  reconocimiento.continuous = false;
  reconocimiento.interimResults = true;
  reconocimiento.maxAlternatives = 1;
  escena.reconocimiento = reconocimiento;
  let entendido = false;

  reconocimiento.onstart = () => {
    asistente.escuchando = true;
    estadoEscena("escuchando", "Te escucho…");
  };
  reconocimiento.onresult = (evento) => {
    const resultado = evento.results[evento.results.length - 1];
    const texto = resultado[0].transcript.trim();
    mostrarTranscripcion(texto, resultado.isFinal);
    if (resultado.isFinal && texto) {
      entendido = true;
      atenderPedido(texto);
    }
  };
  reconocimiento.onerror = (evento) => {
    if (evento.error === "aborted") return;
    if (evento.error === "no-speech") {
      estadoEscena("reposo", "No te escuché. Tocá el hexágono para hablar, o escribime.");
    } else if (evento.error === "not-allowed" || evento.error === "service-not-allowed") {
      estadoEscena("reposo", "No tengo permiso para el micrófono. Habilitalo en el navegador o escribime.");
    } else if (evento.error === "network") {
      estadoEscena("reposo", "El reconocimiento de voz necesita internet. Mientras tanto, escribime.");
    } else {
      estadoEscena("reposo", "Hubo un problema con el micrófono. Tocá el hexágono para probar de nuevo.");
    }
  };
  reconocimiento.onend = () => {
    asistente.escuchando = false;
    if (escena.reconocimiento === reconocimiento) escena.reconocimiento = null;
    const hex = document.getElementById("escena-hex");
    if (!entendido && hex && hex.dataset.estado === "escuchando") {
      estadoEscena("reposo", "Tocá el hexágono para hablar, o escribime.");
    }
  };

  try {
    reconocimiento.start();
  } catch {
    estadoEscena("reposo", "Tocá el hexágono para hablar.");
  }
}

// El hexágono grande respira igual que el chico (misma idea que
// dibujarHexagono en asistente.js), con su propio filtro.
function animarHexEscena() {
  if (MENOS_MOVIMIENTO_ASISTENTE || escena.hex.cuadro) return;
  const h = escena.hex;
  const paso = () => {
    if (!escena.abierta && !escena.el.classList.contains("cerrando")) {
      h.cuadro = null;
      return;
    }
    h.t += 0.016;
    const objetivo = asistente.escuchando ? 1 : asistente.hablando ? 0.55 + Math.sin(h.t * 7) * 0.25 : 0.16;
    h.energia += (objetivo - h.energia) * 0.08;
    const E = h.energia;
    const frecuencia = 0.005 + E * 0.005 + Math.sin(h.t * 0.9) * 0.0015 * (0.4 + E);
    h.turbulencia.setAttribute("baseFrequency", frecuencia.toFixed(4));
    h.desplazamiento.setAttribute("scale", (3 + E * 12).toFixed(2));
    h.cuadro = requestAnimationFrame(paso);
  };
  h.cuadro = requestAnimationFrame(paso);
}

/* ------------------------------------------------------------
   ENGANCHE CON EL PANEL CHICO
   En el panel aparece el interruptor "Abrir con aplausos" y un
   botón para abrir la escena sin aplaudir.
   ------------------------------------------------------------ */
function engancharAplausos() {
  const nucleo = document.querySelector(".asistente-nucleo");
  if (!nucleo || document.getElementById("asistente-oido")) return;

  const fila = document.createElement("div");
  fila.className = "asistente-oido-fila";
  fila.innerHTML = `
    <button type="button" id="asistente-oido" class="asistente-oido" aria-pressed="false">
      <span class="oido-luz" aria-hidden="true"></span><span class="oido-texto">Abrir con aplausos: apagado</span>
    </button>
    <button type="button" id="asistente-agrandar" class="asistente-agrandar" title="Abrir en grande" aria-label="Abrir el asistente en grande">⤢</button>
  `;
  nucleo.appendChild(fila);

  document.getElementById("asistente-oido").addEventListener("click", async () => {
    if (oido.encendido) {
      apagarOido();
      guardarPreferenciaAplausos(false);
      mostrarToast("Listo, ya no escucho aplausos.", "info");
      return;
    }
    const ok = await encenderOido();
    if (ok) {
      guardarPreferenciaAplausos(true);
      mostrarToast("Aplaudí dos veces y aparezco en grande.", "success");
    }
  });
  document.getElementById("asistente-agrandar").addEventListener("click", () => abrirEscena());

  pintarEstadoOido();

  // Si ya estaba elegido, se vuelve a encender en cada página (en
  // localhost el navegador recuerda el permiso del micrófono).
  if (preferenciaAplausos() && contextoSeguroParaMicrofono()) encenderOido({ avisar: false });
}

// Para que Configuración pueda prenderlo o apagarlo al guardar.
window.oidoAplausos = (encender) => (encender ? encenderOido() : (apagarOido(), Promise.resolve(false)));

window.addEventListener("keydown", () => {
  oido.ultimaTecla = performance.now();
}, { capture: true });

// Va después de construirAsistente (los dos esperan al DOM, y este
// archivo se carga después de asistente.js).
document.addEventListener("DOMContentLoaded", engancharAplausos);
