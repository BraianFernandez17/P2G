/* ============================================================
   SESIÓN (mock, con localStorage)
   Como todavía no hay backend, "iniciar sesión" acá no genera un
   JWT de verdad (ver sección 9 del documento técnico): guardamos
   un objeto simple en localStorage del navegador, que simula
   "quién soy y qué rol tengo" (mi cuenta). Es SOLO para que el
   mockup se sienta como una app real de principio a fin.

   En la versión con backend, esto se reemplaza por:
     - Guardar el JWT que devuelve POST /api/v1/auth/login
     - Mandar ese JWT en cada pedido (header Authorization)
     - Pedirle al backend "quién sos" en vez de leerlo de acá
   ============================================================ */

const CLAVE_SESION = "poloTecSesion";

// A qué panel va cada rol de cuenta una vez que inició sesión.
const PANEL_POR_ROL = {
  student: "dashboard-estudiante.html",
  company: "dashboard-empresa.html",
  professor: "dashboard-profesor.html",
  admin: "dashboard-admin.html",
};

// Nombre "bonito" de cada rol, para mostrar en la interfaz
// (navbar, saludo, distintivo de cuenta) en vez del código interno.
const NOMBRE_DEL_ROL = {
  student: "Estudiante",
  company: "Empresa",
  professor: "Profesor",
  admin: "Admin",
};

/* ------------------------------------------------------------
   "BASE DE CUENTAS" DE DEMOSTRACIÓN
   Como no hay tabla "users" real todavía, login.html necesita
   algo contra qué validar el email. Estas son las cuentas de
   ejemplo, una por rol (más una empresa y un profesor extra),
   para poder probar el flujo completo. En la versión real esto
   lo resuelve el backend con un SELECT a la tabla users
   (comparando el hash de la contraseña, nunca la contraseña en
   texto plano).
   ------------------------------------------------------------ */
const CUENTAS_DEMO = [
  { email: "maria@estudiante.com", role: "student", name: "María González" },
  { email: "facundo@estudiante.com", role: "student", name: "Facundo Pereira" },
  { email: "valentina@estudiante.com", role: "student", name: "Valentina Silveira" },
  { email: "camila@estudiante.com", role: "student", name: "Camila Núñez" },
  { email: "joaquin@estudiante.com", role: "student", name: "Joaquín Olivera" },
  { email: "sofia@estudiante.com", role: "student", name: "Sofía Pintos" },
  { email: "contacto@techcorp.com", role: "company", name: "TechCorp Tacuarembó", sector: "tecnologia", status: "active" },
  { email: "rrhh@agrotacua.com.uy", role: "company", name: "AgroTacuá S.A.", sector: "agropecuaria", status: "active" },
  { email: "contacto@industriasnorte.com", role: "company", name: "Industrias del Norte", sector: "industria", status: "pending_approval" },
  { email: "ana@polotec.edu.uy", role: "professor", name: "Ana Rodríguez" },
  { email: "diego@polotec.edu.uy", role: "professor", name: "Diego Martínez" },
  { email: "lucia@polotec.edu.uy", role: "professor", name: "Lucía Fernández" },
  { email: "admin@polotec.edu.uy", role: "admin", name: "Admin del Polo" },
];

function guardarSesion(cuenta) {
  localStorage.setItem(CLAVE_SESION, JSON.stringify(cuenta));
}

function obtenerSesion() {
  const datos = localStorage.getItem(CLAVE_SESION);
  if (!datos) return null;
  try {
    return JSON.parse(datos);
  } catch {
    return null;
  }
}

function borrarSesion() {
  localStorage.removeItem(CLAVE_SESION);
}

// Se llama al principio de CADA dashboard (en un <script> chiquito
// en el <head>, antes de que se pinte el contenido). Si no hay
// sesión, o la sesión es de otro rol, manda derecho al login: así
// lo primero que ve alguien sin cuenta iniciada es siempre
// login/registro, nunca el contenido del panel.
function requerirRol(rolEsperado) {
  const sesion = obtenerSesion();
  if (!sesion || sesion.role !== rolEsperado) {
    window.location.href = "login.html";
    return null;
  }
  return sesion;
}

// Se llama en index.html: si ya hay sesión activa, en vez de
// mostrarle de nuevo la landing pública a alguien que ya se
// registró, lo manda directo a su panel.
function redirigirSiHaySesion() {
  const sesion = obtenerSesion();
  if (sesion && PANEL_POR_ROL[sesion.role]) {
    window.location.href = PANEL_POR_ROL[sesion.role];
  }
}

function cerrarSesion() {
  borrarSesion();
  window.location.href = "login.html";
}

/* ------------------------------------------------------------
   BOTÓN DE "CERRAR SESIÓN" Y DISTINTIVO DE ROL
   Todos los dashboards comparten el mismo botón (id="cerrar-sesion")
   y, si existe, un distintivo de rol (id="etiqueta-rol") en el
   navbar, así que los enganchamos acá una sola vez en vez de
   repetir el mismo código en cada página.
   ------------------------------------------------------------ */
/* ------------------------------------------------------------
   PÁGINAS PÚBLICAS CON SESIÓN INICIADA
   La agenda de salones se puede ver sin cuenta, por eso su menú
   ofrece "Iniciar sesión". Pero si ya entraste (desde "Agenda
   pública" de tu panel, por ejemplo), pedirte que inicies sesión
   de nuevo no tiene sentido: el menú y el pie pasan a ofrecer
   volver a tu panel, y se ve con qué cuenta estás.
   ------------------------------------------------------------ */
function adaptarPaginaPublica() {
  const sesion = obtenerSesion();
  const panel = sesion && PANEL_POR_ROL[sesion.role];
  if (!panel) return;

  const acciones = document.querySelector(".navbar-public-actions");
  if (acciones) {
    acciones.querySelectorAll('a[href="login.html"], a[href^="registro-"]').forEach((link) => link.remove());
    const rol = document.createElement("span");
    rol.className = "role-tag role-tag-publico";
    rol.textContent = `${NOMBRE_DEL_ROL[sesion.role]} · ${sesion.name}`;
    const volver = document.createElement("a");
    volver.href = panel;
    volver.className = "btn-primary";
    volver.textContent = "Ir a mi panel";
    acciones.append(rol, volver);
  }

  // En el pie: "Iniciar sesión" lleva al panel y no se ofrece
  // registrarse a quien ya tiene cuenta.
  document.querySelectorAll('.site-footer a[href="login.html"]').forEach((link) => {
    link.href = panel;
    link.textContent = "Ir a mi panel";
  });
  document.querySelectorAll('.site-footer a[href^="registro-"]').forEach((link) => {
    (link.closest("li") || link).remove();
  });

  // El aviso de la agenda ("necesitás iniciar sesión como
  // profesor") cambia según quién está mirando.
  const aviso = document.querySelector(".agenda-page-header .page-subtitle");
  if (aviso) {
    aviso.textContent =
      sesion.role === "professor" || sesion.role === "admin"
        ? "Reservas ya aprobadas por el Polo, de hoy en adelante. Para pedir o aprobar una reserva, volvé a tu panel."
        : sesion.role === "student"
        ? "Reservas ya aprobadas por el Polo, de hoy en adelante. Los materiales (proyector, notebooks, sonido…) los podés pedir desde Reservas, en tu panel."
        : "Reservas ya aprobadas por el Polo, de hoy en adelante. Las reservas las piden los profesores y los alumnos desde su panel.";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  adaptarPaginaPublica();

  const botonCerrarSesion = document.getElementById("cerrar-sesion");
  if (botonCerrarSesion) {
    botonCerrarSesion.addEventListener("click", () => {
      cerrarSesion();
    });
  }

  const etiquetaRol = document.getElementById("etiqueta-rol");
  if (etiquetaRol) {
    const sesion = obtenerSesion();
    if (sesion && NOMBRE_DEL_ROL[sesion.role]) {
      etiquetaRol.textContent = NOMBRE_DEL_ROL[sesion.role];
    } else {
      etiquetaRol.style.display = "none";
    }
  }

  /* ------------------------------------------------------------
     BUSCADOR DEL MENÚ (genérico, para cualquier página)
     No hace falta escribir un buscador distinto por pantalla: con
     que la lista a filtrar tenga el atributo data-buscable en el
     contenedor (ej. <section id="lista-pasantias" data-buscable>),
     este único buscador filtra sus hijos por texto. Sirve tanto
     para tarjetas (pasantías, reservas, empresas) como para filas
     de tabla (agenda pública).
     ------------------------------------------------------------ */
  const buscadorGlobal = document.getElementById("buscador-global");
  if (buscadorGlobal) {
    buscadorGlobal.addEventListener("input", () => {
      const termino = buscadorGlobal.value.trim().toLowerCase();
      document.querySelectorAll("[data-buscable]").forEach((contenedor) => {
        Array.from(contenedor.children).forEach((item) => {
          const texto = item.textContent.toLowerCase();
          item.style.display = texto.includes(termino) ? "" : "none";
        });
      });
    });
  }

  /* ------------------------------------------------------------
     NAVEGACIÓN DEL MENÚ POR SECCIONES (genérico, para cualquier página)
     Los dashboards de estudiante, profesor y empresa son de una
     sola página con varias secciones, así que sus links del menú
     no tienen que ir a otro archivo: apuntan a una sección de la
     misma pantalla (ej. href="#seccion-mis-reservas").

     Con esto, esos links:
       1. hacen scroll suave hasta la sección correspondiente,
       2. y marcan solos cuál está activo según dónde estás parado
          al hacer scroll (clase .active, la misma que ya usaba el
          CSS para pintar el link distinto).

     Los links que apuntan a otro archivo (ej. agenda-publica.html)
     no se tocan: siguen navegando normal.
     ------------------------------------------------------------ */
  const linksDeSeccion = Array.from(
    document.querySelectorAll('.navbar nav .nav-link[href^="#"]')
  ).filter((link) => link.getAttribute("href").length > 1);

  if (linksDeSeccion.length > 0) {
    // Para cada link, guardamos la sección a la que apunta. Si un
    // link apunta a una sección que no existe en esta página, queda
    // afuera (así no rompe nada si se reordenan las secciones).
    const secciones = linksDeSeccion
      .map((link) => ({
        link,
        destino: document.querySelector(link.getAttribute("href")),
      }))
      .filter((par) => par.destino);

    if (secciones.length > 0) {
      secciones.forEach(({ link, destino }) => {
        link.addEventListener("click", (evento) => {
          evento.preventDefault();
          // scroll-margin-top en el CSS se encarga de que el título
          // no quede tapado por el navbar fijo.
          destino.scrollIntoView({ behavior: "smooth", block: "start" });
          linksDeSeccion.forEach((otro) => otro.classList.remove("active"));
          link.classList.add("active");
        });
      });

      // Marcar el link activo según la sección visible. Se recalcula
      // al hacer scroll: la sección "actual" es la última cuyo inicio
      // ya pasó por debajo del navbar.
      const marcarLinkActivo = () => {
        let actual = secciones[0];
        secciones.forEach((par) => {
          if (par.destino.getBoundingClientRect().top <= 120) actual = par;
        });
        linksDeSeccion.forEach((link) => {
          link.classList.toggle("active", link === actual.link);
        });
      };

      window.addEventListener("scroll", marcarLinkActivo, { passive: true });
      marcarLinkActivo();
    }
  }
});
