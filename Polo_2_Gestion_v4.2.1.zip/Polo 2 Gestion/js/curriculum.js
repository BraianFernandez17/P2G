/* ============================================================
   CURRÍCULUM EN PDF
   El estudiante lo sube en "Editar perfil profesional" y las
   empresas lo abren con "Ver currículum" desde su ficha.

   Validaciones (se repiten en la API, ver PUT /api/v1/perfil/cv):
     · solo PDF, hasta 5 MB;
     · que el archivo EMPIECE como un PDF ("%PDF-"): no alcanza con
       que se llame .pdf. Un .exe renombrado no pasa.
   Si no cumple, se avisa en el momento y no se guarda.

   DÓNDE QUEDA (límite del prototipo): el archivo se guarda en el
   IndexedDB de ESTE navegador (localStorage no aguanta 5 MB). En el
   perfil de la bolsa solo va el nombre, el tamaño y la fecha. Una
   empresa que entre desde otra computadora ve "no se encontró el
   archivo". Con el backend, el archivo va al servidor (tabla
   student_cv de db/schema.sql) y esto deja de pasar.

   Los perfiles de ejemplo con CV ("demo": true) no tienen archivo
   guardado: el PDF se arma al vuelo con los datos del perfil, así la
   demo funciona en cualquier computadora.
   ============================================================ */

const TAMANO_MAXIMO_CV = 5 * 1024 * 1024;
const BASE_ARCHIVOS = "poloTecArchivos";
const TABLA_CURRICULUMS = "curriculums";

function formatearTamano(bytes) {
  if (!Number.isFinite(bytes)) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1).replace(".", ",")} MB`;
}

function fechaCorta(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

/* ------------------------------------------------------------
   VALIDAR
   Devuelve null si está todo bien, o el mensaje para mostrar.
   ------------------------------------------------------------ */
async function validarCV(archivo) {
  if (!archivo) return "Elegí un archivo.";
  const pareceElTipo = /\.pdf$/i.test(archivo.name) || archivo.type === "application/pdf";
  if (!pareceElTipo) return `"${archivo.name}" no es un PDF. Exportá tu currículum como PDF y subilo de nuevo.`;
  if (archivo.size === 0) return "El archivo está vacío.";
  if (archivo.size > TAMANO_MAXIMO_CV) {
    return `Pesa ${formatearTamano(archivo.size)} y el máximo es 5 MB. Probá exportarlo con menos calidad de imagen.`;
  }
  // La "firma" de todo PDF: los primeros bytes son %PDF-
  const inicio = new Uint8Array(await archivo.slice(0, 5).arrayBuffer());
  const firma = String.fromCharCode(...inicio);
  if (firma !== "%PDF-") {
    return `"${archivo.name}" se llama .pdf pero por dentro no es un PDF. Volvé a exportarlo desde Word, Docs o Canva como PDF.`;
  }
  return null;
}

/* ------------------------------------------------------------
   GUARDAR Y LEER (IndexedDB)
   ------------------------------------------------------------ */
function abrirBaseArchivos() {
  return new Promise((resolver, rechazar) => {
    if (!("indexedDB" in window)) {
      rechazar(new Error("Este navegador no permite guardar archivos."));
      return;
    }
    const pedido = indexedDB.open(BASE_ARCHIVOS, 1);
    pedido.onupgradeneeded = () => pedido.result.createObjectStore(TABLA_CURRICULUMS, { keyPath: "email" });
    pedido.onsuccess = () => resolver(pedido.result);
    pedido.onerror = () => rechazar(pedido.error);
  });
}

async function operarCurriculums(modo, operar) {
  const base = await abrirBaseArchivos();
  return new Promise((resolver, rechazar) => {
    const transaccion = base.transaction(TABLA_CURRICULUMS, modo);
    const pedido = operar(transaccion.objectStore(TABLA_CURRICULUMS));
    transaccion.oncomplete = () => {
      base.close();
      resolver(pedido ? pedido.result : undefined);
    };
    transaccion.onerror = () => {
      base.close();
      rechazar(transaccion.error);
    };
  });
}

// Versión real: PUT /api/v1/perfil/cv (cuerpo: el PDF)
function guardarArchivoCV(email, archivo) {
  return operarCurriculums("readwrite", (tabla) =>
    tabla.put({ email, archivo, nombre: archivo.name, tamano: archivo.size, subido: new Date().toISOString() })
  );
}

// Versión real: GET /api/v1/perfiles/:id/cv
function leerArchivoCV(email) {
  return operarCurriculums("readonly", (tabla) => tabla.get(email));
}

// Versión real: DELETE /api/v1/perfil/cv
function borrarArchivoCV(email) {
  return operarCurriculums("readwrite", (tabla) => tabla.delete(email));
}

/* ------------------------------------------------------------
   CV DE EJEMPLO (se arma al vuelo con los datos del perfil)
   Un PDF de una página, con Helvetica (una de las 14 fuentes que
   todo lector de PDF trae) y codificación WinAnsi para los acentos.
   ------------------------------------------------------------ */
function textoPDF(texto) {
  const especiales = { "–": "\\226", "—": "\\227", "•": "\\225", "“": "\\223", "”": "\\224", "‘": "\\221", "’": "\\222", "…": "\\205" };
  return [...String(texto)]
    .map((c) => {
      if (c === "\\" || c === "(" || c === ")") return `\\${c}`;
      if (especiales[c]) return especiales[c];
      const codigo = c.charCodeAt(0);
      if (codigo >= 32 && codigo < 127) return c;
      if (codigo >= 160 && codigo <= 255) return `\\${codigo.toString(8).padStart(3, "0")}`;
      return "?";
    })
    .join("");
}

function partirEnLineas(texto, maximo) {
  const lineas = [];
  let actual = "";
  String(texto)
    .split(/\s+/)
    .filter(Boolean)
    .forEach((palabra) => {
      if ((actual + " " + palabra).trim().length > maximo) {
        if (actual) lineas.push(actual);
        actual = palabra;
      } else {
        actual = (actual + " " + palabra).trim();
      }
    });
  if (actual) lineas.push(actual);
  return lineas;
}

function crearPDFDemo(perfil) {
  const renglones = []; // [fuente, tamaño, x, texto]
  let y = 790;
  const poner = (fuente, tamano, texto, x = 56, salto = tamano * 1.45) => {
    renglones.push([fuente, tamano, x, y, texto]);
    y -= salto;
  };
  const seccion = (titulo, lineas) => {
    if (!lineas.length) return;
    y -= 8;
    poner("F2", 11, titulo.toUpperCase(), 56, 17);
    lineas.forEach((linea) => partirEnLineas(linea, 92).forEach((parte, i) => poner("F1", 10, (i ? "   " : "") + parte, 56, 14.5)));
  };

  poner("F2", 22, perfil.nombre || "Estudiante", 56, 28);
  if (perfil.orientacion) poner("F1", 12, perfil.orientacion, 56, 17);
  const datos = [perfil.nivel, perfil.localidad, perfil.disponibilidad, perfil.email].filter(Boolean).join("  ·  ");
  if (datos) poner("F1", 10, datos, 56, 22);

  seccion("Sobre mí", perfil.sobreMi ? [perfil.sobreMi] : []);
  seccion("Capacidades", perfil.capacidades.length ? [perfil.capacidades.join(" · ")] : []);
  seccion("Idiomas", perfil.idiomas.length ? [perfil.idiomas.join(" · ")] : []);
  seccion("Títulos y certificaciones", perfil.titulos.map((t) => `• ${[t.nombre, t.institucion, t.anio].filter(Boolean).join(", ")}`));
  seccion("Cursos y capacitaciones", perfil.cursos.map((c) => `• ${[c.nombre, c.institucion, c.detalle].filter(Boolean).join(", ")}`));
  seccion("Experiencia", perfil.experiencia.map((x) => `• ${[x.puesto, x.lugar, x.periodo].filter(Boolean).join(", ")}`));
  seccion("Links", [perfil.linkedin, perfil.portfolio].filter(Boolean));

  renglones.push(["F1", 8, 56, 40, "Currículum de ejemplo generado por Polo 2 Gestión a partir del perfil profesional."]);

  const contenido = renglones
    .filter(([, , , altura]) => altura > 30)
    .map(([fuente, tamano, x, altura, texto]) => `BT /${fuente} ${tamano} Tf ${x} ${altura.toFixed(1)} Td (${textoPDF(texto)}) Tj ET`)
    .join("\n");

  const objetos = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>",
    `<< /Length ${contenido.length} >>\nstream\n${contenido}\nendstream`,
  ];
  // Todo quedó en ASCII (los acentos van como \ooo), así que cada
  // carácter es un byte y las posiciones del xref son exactas.
  let pdf = "%PDF-1.4\n";
  const posiciones = objetos.map((objeto, i) => {
    const posicion = pdf.length;
    pdf += `${i + 1} 0 obj\n${objeto}\nendobj\n`;
    return posicion;
  });
  const inicioXref = pdf.length;
  pdf += `xref\n0 ${objetos.length + 1}\n0000000000 65535 f \n`;
  pdf += posiciones.map((p) => `${String(p).padStart(10, "0")} 00000 n \n`).join("");
  pdf += `trailer\n<< /Size ${objetos.length + 1} /Root 1 0 R >>\nstartxref\n${inicioXref}\n%%EOF\n`;
  return new Blob([pdf], { type: "application/pdf" });
}

async function obtenerArchivoCV(perfil) {
  if (!perfil || !perfil.cv) return null;
  if (perfil.cv.demo) return { archivo: crearPDFDemo(perfil), nombre: perfil.cv.nombre };
  try {
    const guardado = await leerArchivoCV(perfil.email);
    return guardado ? { archivo: guardado.archivo, nombre: guardado.nombre } : null;
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------
   VER EL CURRÍCULUM (empresa, admin o el propio estudiante)
   Se abre en un visor dentro del sitio, con "Abrir en otra
   pestaña" y "Descargar". Al tocar un enlace la pestaña nueva la
   abre la persona, así el navegador no la bloquea como ventana
   emergente.
   ------------------------------------------------------------ */
let urlCVAbierto = null;

// alVolver: si se abrió desde la ficha de un estudiante, "Volver al
// perfil" la vuelve a abrir en vez de cerrar todo.
async function verCurriculum(email, { alVolver = null } = {}) {
  const perfil = typeof perfilDe === "function" ? perfilDe(email) : null;
  const nombre = perfil ? perfil.nombre : "el estudiante";
  const encontrado = await obtenerArchivoCV(perfil);

  if (urlCVAbierto) URL.revokeObjectURL(urlCVAbierto);
  urlCVAbierto = null;

  if (!encontrado) {
    abrirModal({
      titulo: "No se encontró el archivo",
      texto: perfil && perfil.cv
        ? `${nombre} subió su currículum (${perfil.cv.nombre}), pero el archivo quedó guardado solo en el navegador desde donde lo subió.\n\nEn este prototipo los PDF no viajan a un servidor: si estás en otra computadora o en otro navegador, no lo vas a poder abrir. Con el backend real esto deja de pasar.`
        : `${nombre} todavía no subió su currículum.`,
      textoConfirmar: "Entendido",
      textoCancelar: null,
    });
    return;
  }

  urlCVAbierto = URL.createObjectURL(encontrado.archivo);
  const e = typeof escaparHTML === "function" ? escaparHTML : (t) => t;
  abrirModal({
    titulo: `Currículum de ${nombre}`,
    amplio: true,
    textoConfirmar: null,
    textoCancelar: alVolver ? "Volver al perfil" : "Cerrar",
    cuerpoHTML: `
      <div class="cv-visor">
        <iframe src="${urlCVAbierto}#view=FitH" title="Currículum de ${e(nombre)} (PDF)"></iframe>
      </div>
      <div class="cv-acciones">
        <span class="cv-archivo">${typeof icono === "function" ? icono("documento", 16) : ""}${e(encontrado.nombre)}${
          encontrado.archivo.size ? ` · ${formatearTamano(encontrado.archivo.size)}` : ""
        }</span>
        <a class="btn-secondary" href="${urlCVAbierto}" target="_blank" rel="noopener">Abrir en otra pestaña</a>
        <a class="btn-primary" href="${urlCVAbierto}" download="${e(encontrado.nombre)}">Descargar</a>
      </div>`,
  });
  if (alVolver) {
    document.getElementById("modal-cancelar").addEventListener("click", () => setTimeout(alVolver, 0), { once: true });
  }
}

// Bloque "Currículum" de htmlPerfil() (js/bolsa.js)
function htmlBloqueCV(perfil, propio) {
  const e = escaparHTML;
  if (!perfil.cv) {
    return propio
      ? `<p class="perfil-vacio">Subilo desde "Editar perfil profesional": solo PDF, hasta 5 MB.</p>`
      : `<p class="perfil-vacio">No subió currículum.</p>`;
  }
  const detalle = [perfil.cv.tamano ? formatearTamano(perfil.cv.tamano) : "PDF de ejemplo", perfil.cv.subido ? `subido el ${fechaCorta(perfil.cv.subido)}` : ""]
    .filter(Boolean)
    .join(" · ");
  return `
    <div class="cv-fila">
      <span class="cv-icono" aria-hidden="true">PDF</span>
      <span class="cv-datos"><strong>${e(perfil.cv.nombre)}</strong><small>${e(detalle)}</small></span>
      <button type="button" class="btn-view" data-ver-cv="${e(perfil.email)}">Ver currículum</button>
    </div>`;
}

document.addEventListener("click", (evento) => {
  const boton = evento.target.closest("[data-ver-cv]");
  if (!boton) return;
  const email = boton.dataset.verCv;
  const desdeFicha = boton.closest(".perfil-ficha") && typeof verPerfilEstudiante === "function";
  verCurriculum(email, { alVolver: desdeFicha ? () => verPerfilEstudiante(email) : null });
});
