/* ============================================================
   RECURSOS SEGÚN LA MATERIA
   Cada salón muestra solo lo que le sirve a la materia que se da
   ahí: las herramientas (calculadora, conversor, masa molar…), los
   materiales que se suelen pedir para ese lugar y los enlaces.

   TODO SE EDITA EN UN SOLO LUGAR: RECURSOS_POR_SALON, acá abajo.
     · herramientas → claves de HERRAMIENTAS (o [] para ninguna)
     · materiales   → ids de js/reservas.js (r7 proyector, r8 tele…)
     · estudio      → true muestra el banner de Biblioteca Ceibal
   La base de datos tiene la misma información (resources.tools y
   resource_materials en db/schema.sql): si se cambia acá, hay que
   cambiarla también en db/seed.sql.
   ============================================================ */

const ENLACES_DEL_POLO = {
  // Biblioteca País, la biblioteca digital de Ceibal (libros gratis
  // para estudiantes y docentes, con usuario Ceibal).
  bibliotecaCeibal: "https://bibliotecapais.ceibal.edu.uy/",
  // PETS: todavía falta la dirección. Cuando la tengan, va acá y el
  // botón se activa solo en todos los salones.
  pets: "",
};

const RECURSOS_POR_SALON = {
  r1: { materia: "Lectura y estudio", herramientas: [], materiales: ["r13", "r8"], estudio: true },
  r2: { materia: "Informática", herramientas: ["calculadora", "bases"], materiales: ["r7", "r13"], estudio: true },
  r3: { materia: "Presentaciones y defensas", herramientas: [], materiales: ["r7", "r15"], estudio: true },
  r9: { materia: "Actos y charlas", herramientas: [], materiales: ["r14", "r15", "r7"], estudio: false },
  r10: { materia: "Coordinación docente", herramientas: [], materiales: ["r8", "r7"], estudio: true },
  r11: { materia: "Educación Física", herramientas: [], materiales: ["r14", "r15", "r16"], estudio: false },
  r4: { materia: "Física", herramientas: ["calculadora", "constantes", "conversor"], materiales: ["r7", "r13"], estudio: true },
  r5: { materia: "Química", herramientas: ["calculadora", "masaMolar", "conversor"], materiales: ["r7", "r8"], estudio: true },
  r6: { materia: "Ciencias", herramientas: ["calculadora", "conversor"], materiales: ["r7", "r8"], estudio: true },
  r12: { materia: "Robótica", herramientas: ["calculadora", "ohm", "resistencias", "bases"], materiales: ["r17", "r13"], estudio: true },
};

function recursosDelSalon(salonId) {
  return RECURSOS_POR_SALON[salonId] || { materia: "", herramientas: [], materiales: [], estudio: false };
}

/* ------------------------------------------------------------
   AYUDANTES
   ------------------------------------------------------------ */
function escaparEspacios(texto) {
  return String(texto ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

// Acepta coma o punto decimal ("4,7"), notación científica ("6e-3")
// y prefijos de electrónica ("4.7k", "220m", "2M").
const PREFIJOS = { p: 1e-12, n: 1e-9, u: 1e-6, "µ": 1e-6, m: 1e-3, k: 1e3, K: 1e3, M: 1e6, G: 1e9 };
function leerNumero(texto, { conPrefijo = false } = {}) {
  const limpio = String(texto ?? "").trim().replace(/\s+/g, "").replace(",", ".");
  if (!limpio) return null;
  // Sin bandera "i" a propósito: "M" (mega) y "m" (mili) no son lo mismo.
  const coincide = limpio.match(/^([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)([pnuµmkKMG]?)$/);
  if (!coincide || (coincide[2] && !conPrefijo)) return NaN;
  const valor = parseFloat(coincide[1]) * (coincide[2] ? PREFIJOS[coincide[2]] : 1);
  return Number.isFinite(valor) ? valor : NaN;
}

// 1234.5678 → "1234,568"; muy grandes o muy chicos → "1,23×10⁻⁹"
const SUPERINDICES = { "-": "⁻", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
function formatearNumero(valor, cifras = 6) {
  if (!Number.isFinite(valor)) return "—";
  if (valor === 0) return "0";
  const abs = Math.abs(valor);
  if (abs >= 1e9 || abs < 1e-4) {
    const [mantisa, exponente] = valor.toExponential(cifras - 1).split("e");
    const m = String(parseFloat(mantisa)).replace(".", ",");
    const exp = String(parseInt(exponente, 10)).split("").map((c) => SUPERINDICES[c]).join("");
    return `${m}×10${exp}`;
  }
  return String(parseFloat(valor.toPrecision(cifras))).replace(".", ",");
}

// Valor con prefijo SI, para electrónica: 4700 → "4,7 k"
function conPrefijoSI(valor, unidad) {
  if (!Number.isFinite(valor)) return "—";
  const escalas = [
    [1e9, "G"], [1e6, "M"], [1e3, "k"], [1, ""], [1e-3, "m"], [1e-6, "µ"], [1e-9, "n"], [1e-12, "p"],
  ];
  const abs = Math.abs(valor);
  const [factor, prefijo] = escalas.find(([f]) => abs >= f) || escalas[escalas.length - 1];
  return `${formatearNumero(valor / factor, 4)} ${prefijo}${unidad}`;
}

/* ============================================================
   HERRAMIENTAS
   Cada una tiene un nombre, una línea que explica para qué sirve
   y una función que la arma dentro de un contenedor. No usan
   eval(): la calculadora tiene su propio intérprete.
   ============================================================ */
const HERRAMIENTAS = {
  calculadora: {
    nombre: "Calculadora",
    resumen: "Científica: potencias, raíces, trigonometría y logaritmos.",
    armar: armarCalculadora,
  },
  constantes: {
    nombre: "Constantes físicas",
    resumen: "Los valores de referencia (CODATA) listos para copiar.",
    armar: armarConstantes,
  },
  conversor: {
    nombre: "Conversor de unidades",
    resumen: "Longitud, masa, tiempo, velocidad, temperatura, presión, energía y volumen.",
    armar: armarConversor,
  },
  masaMolar: {
    nombre: "Masa molar",
    resumen: "Escribí una fórmula (H2SO4, Ca(OH)2, CuSO4·5H2O) y te da los g/mol.",
    armar: armarMasaMolar,
  },
  ohm: {
    nombre: "Ley de Ohm",
    resumen: "Completá dos de los cuatro valores y calcula el resto.",
    armar: armarOhm,
  },
  resistencias: {
    nombre: "Colores de resistencias",
    resumen: "De bandas a ohms y de ohms a bandas (código de 4 bandas).",
    armar: armarResistencias,
  },
  bases: {
    nombre: "Bases numéricas",
    resumen: "Binario, octal, decimal y hexadecimal al mismo tiempo.",
    armar: armarBases,
  },
};

/* ------------------------------------------------------------
   CALCULADORA
   Intérprete de expresiones por descenso recursivo:
     expresion := termino (("+"|"-") termino)*
     termino   := potencia (("*"|"/") potencia | potencia)*   ← "2π" multiplica
     potencia  := ("-"|"+") potencia | postfijo ("^" potencia)?
     postfijo  := primario "!"*
     primario  := numero | constante | funcion "(" expresion ")" | "(" expresion ")"
   ------------------------------------------------------------ */
const FUNCIONES_CALC = {
  sin: (x, g) => Math.sin(g ? (x * Math.PI) / 180 : x),
  cos: (x, g) => Math.cos(g ? (x * Math.PI) / 180 : x),
  tan: (x, g) => Math.tan(g ? (x * Math.PI) / 180 : x),
  asin: (x, g) => (g ? (Math.asin(x) * 180) / Math.PI : Math.asin(x)),
  acos: (x, g) => (g ? (Math.acos(x) * 180) / Math.PI : Math.acos(x)),
  atan: (x, g) => (g ? (Math.atan(x) * 180) / Math.PI : Math.atan(x)),
  sqrt: (x) => Math.sqrt(x),
  log: (x) => Math.log10(x),
  ln: (x) => Math.log(x),
  abs: (x) => Math.abs(x),
};
const CONSTANTES_CALC = { pi: Math.PI, e: Math.E };

function evaluarExpresion(texto, enGrados = true) {
  const fuente = String(texto)
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/−/g, "-")
    .replace(/π/g, "pi")
    .replace(/√/g, "sqrt")
    .replace(/,/g, ".");
  const fichas = [];
  const patron = /\s*(\d+\.?\d*(?:e[-+]?\d+)?|\.\d+|[a-z]+|[-+*/^()!])/giy;
  let m;
  let pos = 0;
  while (pos < fuente.length) {
    patron.lastIndex = pos;
    m = patron.exec(fuente);
    if (!m) {
      if (/^\s*$/.test(fuente.slice(pos))) break;
      throw new Error(`No entiendo "${fuente.slice(pos).trim()[0]}".`);
    }
    fichas.push(m[1].toLowerCase());
    pos = patron.lastIndex;
  }
  if (!fichas.length) throw new Error("Escribí una cuenta.");

  let i = 0;
  const ver = () => fichas[i];
  const tomar = (esperada) => {
    const ficha = fichas[i];
    if (esperada && ficha !== esperada) throw new Error(esperada === ")" ? "Falta cerrar un paréntesis." : `Esperaba "${esperada}".`);
    i++;
    return ficha;
  };
  const empiezaFactor = (f) => f !== undefined && (/^[\d.]/.test(f) || /^[a-z]/.test(f) || f === "(");

  function expresion() {
    let valor = termino();
    while (ver() === "+" || ver() === "-") valor = tomar() === "+" ? valor + termino() : valor - termino();
    return valor;
  }
  function termino() {
    let valor = potencia();
    for (;;) {
      if (ver() === "*") { tomar(); valor *= potencia(); }
      else if (ver() === "/") { tomar(); valor /= potencia(); }
      else if (empiezaFactor(ver())) valor *= potencia(); // multiplicación implícita
      else return valor;
    }
  }
  // El signo va por fuera de la potencia: -2^2 = -(2^2) = -4,
  // como en cualquier calculadora científica. 2^-1 también vale.
  function potencia() {
    if (ver() === "-") { tomar(); return -potencia(); }
    if (ver() === "+") { tomar(); return potencia(); }
    const base = postfijo();
    if (ver() === "^") { tomar(); return Math.pow(base, potencia()); }
    return base;
  }
  function postfijo() {
    let valor = primario();
    while (ver() === "!") {
      tomar();
      if (!Number.isInteger(valor) || valor < 0 || valor > 170) throw new Error("El factorial es para enteros de 0 a 170.");
      let r = 1;
      for (let k = 2; k <= valor; k++) r *= k;
      valor = r;
    }
    return valor;
  }
  function primario() {
    const ficha = ver();
    if (ficha === undefined) throw new Error("La cuenta quedó incompleta.");
    if (/^[\d.]/.test(ficha)) { tomar(); return parseFloat(ficha); }
    if (ficha === "(") { tomar(); const v = expresion(); tomar(")"); return v; }
    if (/^[a-z]/.test(ficha)) {
      tomar();
      if (ficha in CONSTANTES_CALC) return CONSTANTES_CALC[ficha];
      if (ficha in FUNCIONES_CALC) {
        if (ver() !== "(") {
          // "sqrt 9" o "√9" también valen
          return FUNCIONES_CALC[ficha](potencia(), enGrados);
        }
        tomar("(");
        const argumento = expresion();
        tomar(")");
        return FUNCIONES_CALC[ficha](argumento, enGrados);
      }
      throw new Error(`No conozco "${ficha}".`);
    }
    throw new Error(`Sobra "${ficha}".`);
  }

  const resultado = expresion();
  if (i < fichas.length) throw new Error(fichas[i] === ")" ? "Sobra un paréntesis." : `Sobra "${fichas[i]}".`);
  if (Number.isNaN(resultado)) throw new Error("El resultado no es un número (¿raíz o logaritmo de un negativo?).");
  if (!Number.isFinite(resultado)) throw new Error("Da infinito (¿dividiste por cero?).");
  return resultado;
}

function armarCalculadora(caja) {
  const teclas = [
    ["sin(", "sin"], ["cos(", "cos"], ["tan(", "tan"], ["log(", "log"], ["ln(", "ln"],
    ["√(", "√"], ["^", "xʸ"], ["(", "("], [")", ")"], ["!", "n!"],
    ["7"], ["8"], ["9"], ["÷"], ["π"],
    ["4"], ["5"], ["6"], ["×"], ["e"],
    ["1"], ["2"], ["3"], ["−"], ["⌫", "⌫", "borrar"],
    ["0"], [","], ["Ans", "Ans", "ans"], ["+"], ["C", "C", "limpiar"],
  ];
  caja.innerHTML = `
    <div class="calc">
      <div class="calc-pantalla">
        <label class="sr-only" for="calc-entrada">Cuenta</label>
        <input id="calc-entrada" class="calc-entrada" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" data-sin-enter placeholder="Ej: 2·π·0,5 o sin(30)" />
        <output class="calc-resultado" aria-live="polite">0</output>
      </div>
      <div class="calc-opciones">
        <div class="view-toggle" role="group" aria-label="Unidad de los ángulos">
          <button type="button" class="view-toggle-btn active" data-angulo="grados">Grados</button>
          <button type="button" class="view-toggle-btn" data-angulo="radianes">Radianes</button>
        </div>
        <span class="calc-ayuda">Enter calcula · se puede escribir con el teclado</span>
      </div>
      <div class="calc-teclado">
        ${teclas
          .map(([valor, rotulo = valor, accion = ""]) => {
            const clase = accion ? "calc-tecla calc-tecla-accion" : /^[\d,]$/.test(valor) ? "calc-tecla calc-tecla-numero" : "calc-tecla";
            return `<button type="button" class="${clase}" data-tecla="${escaparEspacios(valor)}" data-accion="${accion}">${escaparEspacios(rotulo)}</button>`;
          })
          .join("")}
        <button type="button" class="calc-tecla calc-tecla-igual" data-accion="igual">=</button>
      </div>
    </div>`;

  const entrada = caja.querySelector(".calc-entrada");
  const salida = caja.querySelector(".calc-resultado");
  let enGrados = true;
  let anterior = 0;

  const calcular = () => {
    const texto = entrada.value.replace(/ans/gi, `(${anterior})`);
    if (!texto.trim()) {
      salida.textContent = "0";
      salida.classList.remove("calc-error");
      return;
    }
    try {
      anterior = evaluarExpresion(texto, enGrados);
      salida.textContent = `= ${formatearNumero(anterior, 10)}`;
      salida.classList.remove("calc-error");
    } catch (error) {
      salida.textContent = error.message;
      salida.classList.add("calc-error");
    }
  };

  caja.querySelectorAll("[data-angulo]").forEach((boton) =>
    boton.addEventListener("click", () => {
      enGrados = boton.dataset.angulo === "grados";
      caja.querySelectorAll("[data-angulo]").forEach((b) => b.classList.toggle("active", b === boton));
      if (entrada.value.trim()) calcular();
    })
  );

  caja.querySelector(".calc-teclado").addEventListener("click", (evento) => {
    const tecla = evento.target.closest(".calc-tecla");
    if (!tecla) return;
    const accion = tecla.dataset.accion;
    if (accion === "igual") calcular();
    else if (accion === "limpiar") { entrada.value = ""; salida.textContent = "0"; salida.classList.remove("calc-error"); }
    else if (accion === "borrar") entrada.value = entrada.value.slice(0, -1);
    else if (accion === "ans") entrada.value += "Ans";
    else entrada.value += tecla.dataset.tecla;
    entrada.focus();
  });

  entrada.addEventListener("keydown", (evento) => {
    if (evento.key === "Enter") {
      evento.preventDefault();
      calcular();
    }
  });
}

/* ------------------------------------------------------------
   CONSTANTES FÍSICAS (CODATA 2022)
   ------------------------------------------------------------ */
const CONSTANTES_FISICAS = [
  { simbolo: "c", nombre: "Velocidad de la luz en el vacío", valor: "299 792 458", numero: "299792458", unidad: "m/s" },
  { simbolo: "g", nombre: "Gravedad estándar", valor: "9,806 65", numero: "9.80665", unidad: "m/s²" },
  { simbolo: "G", nombre: "Constante de gravitación universal", valor: "6,674 30 × 10⁻¹¹", numero: "6.67430e-11", unidad: "N·m²/kg²" },
  { simbolo: "h", nombre: "Constante de Planck", valor: "6,626 070 15 × 10⁻³⁴", numero: "6.62607015e-34", unidad: "J·s" },
  { simbolo: "e", nombre: "Carga del electrón (elemental)", valor: "1,602 176 634 × 10⁻¹⁹", numero: "1.602176634e-19", unidad: "C" },
  { simbolo: "mₑ", nombre: "Masa del electrón", valor: "9,109 383 7139 × 10⁻³¹", numero: "9.1093837139e-31", unidad: "kg" },
  { simbolo: "mₚ", nombre: "Masa del protón", valor: "1,672 621 925 95 × 10⁻²⁷", numero: "1.67262192595e-27", unidad: "kg" },
  { simbolo: "k_B", nombre: "Constante de Boltzmann", valor: "1,380 649 × 10⁻²³", numero: "1.380649e-23", unidad: "J/K" },
  { simbolo: "N_A", nombre: "Número de Avogadro", valor: "6,022 140 76 × 10²³", numero: "6.02214076e23", unidad: "mol⁻¹" },
  { simbolo: "R", nombre: "Constante de los gases", valor: "8,314 462 618", numero: "8.314462618", unidad: "J/(mol·K)" },
  { simbolo: "ε₀", nombre: "Permitividad del vacío", valor: "8,854 187 8188 × 10⁻¹²", numero: "8.8541878188e-12", unidad: "F/m" },
  { simbolo: "μ₀", nombre: "Permeabilidad del vacío", valor: "1,256 637 061 27 × 10⁻⁶", numero: "1.25663706127e-6", unidad: "N/A²" },
  { simbolo: "atm", nombre: "Atmósfera estándar", valor: "101 325", numero: "101325", unidad: "Pa" },
];

function armarConstantes(caja) {
  caja.innerHTML = `
    <div class="tabla-envoltorio">
      <table class="tabla-herramienta">
        <thead><tr><th scope="col">Símbolo</th><th scope="col">Constante</th><th scope="col">Valor</th><th scope="col"><span class="sr-only">Copiar</span></th></tr></thead>
        <tbody>
          ${CONSTANTES_FISICAS.map(
            (c) => `
            <tr>
              <td class="tabla-simbolo">${escaparEspacios(c.simbolo)}</td>
              <td>${escaparEspacios(c.nombre)}</td>
              <td class="tabla-valor">${escaparEspacios(c.valor)} <span class="tabla-unidad">${escaparEspacios(c.unidad)}</span></td>
              <td><button type="button" class="btn-chico" data-copiar="${c.numero}" aria-label="Copiar ${escaparEspacios(c.nombre)}">Copiar</button></td>
            </tr>`
          ).join("")}
        </tbody>
      </table>
    </div>
    <p class="herramienta-nota">Valores de CODATA 2022. "Copiar" lo deja listo para pegar en la calculadora (6.674e-11).</p>`;

  caja.addEventListener("click", async (evento) => {
    const boton = evento.target.closest("[data-copiar]");
    if (!boton) return;
    try {
      await navigator.clipboard.writeText(boton.dataset.copiar);
      const original = boton.textContent;
      boton.textContent = "Copiado";
      setTimeout(() => (boton.textContent = original), 1400);
    } catch {
      if (typeof mostrarToast === "function") mostrarToast(`No pude copiar. El valor es ${boton.dataset.copiar}.`, "info");
    }
  });
}

/* ------------------------------------------------------------
   CONVERSOR DE UNIDADES
   Cada unidad tiene su factor a la unidad base de la magnitud.
   La temperatura no es proporcional, así que va aparte.
   ------------------------------------------------------------ */
const MAGNITUDES = {
  longitud: { nombre: "Longitud", unidades: { km: 1000, m: 1, cm: 0.01, mm: 0.001, "µm": 1e-6, pulgada: 0.0254, pie: 0.3048, milla: 1609.344 } },
  masa: { nombre: "Masa", unidades: { t: 1000, kg: 1, g: 1e-3, mg: 1e-6, libra: 0.45359237, onza: 0.028349523125 } },
  tiempo: { nombre: "Tiempo", unidades: { día: 86400, h: 3600, min: 60, s: 1, ms: 1e-3 } },
  velocidad: { nombre: "Velocidad", unidades: { "m/s": 1, "km/h": 1 / 3.6, "mi/h": 0.44704, nudo: 1852 / 3600 } },
  temperatura: { nombre: "Temperatura", unidades: { "°C": "C", "°F": "F", K: "K" } },
  presion: { nombre: "Presión", unidades: { Pa: 1, hPa: 100, kPa: 1000, bar: 1e5, atm: 101325, mmHg: 133.322387415, psi: 6894.757293168 } },
  energia: { nombre: "Energía", unidades: { J: 1, kJ: 1000, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3.6e6, eV: 1.602176634e-19 } },
  volumen: { nombre: "Volumen", unidades: { "m³": 1, L: 1e-3, mL: 1e-6, "cm³": 1e-6, galón: 0.003785411784 } },
};

function convertirTemperatura(valor, de, a) {
  const kelvin = de === "C" ? valor + 273.15 : de === "F" ? ((valor - 32) * 5) / 9 + 273.15 : valor;
  return a === "C" ? kelvin - 273.15 : a === "F" ? ((kelvin - 273.15) * 9) / 5 + 32 : kelvin;
}

function convertirUnidad(magnitud, valor, de, a) {
  const unidades = MAGNITUDES[magnitud].unidades;
  if (magnitud === "temperatura") return convertirTemperatura(valor, unidades[de], unidades[a]);
  return (valor * unidades[de]) / unidades[a];
}

function armarConversor(caja) {
  const opcionesMagnitud = Object.entries(MAGNITUDES)
    .map(([clave, m]) => `<option value="${clave}">${m.nombre}</option>`)
    .join("");
  caja.innerHTML = `
    <div class="conversor">
      <div class="form-group">
        <label class="form-label" for="conv-magnitud">Magnitud</label>
        <select id="conv-magnitud" class="form-select">${opcionesMagnitud}</select>
      </div>
      <div class="conversor-fila">
        <div class="form-group">
          <label class="form-label" for="conv-valor">Valor</label>
          <input id="conv-valor" class="form-input" type="text" inputmode="decimal" value="1" data-sin-enter />
        </div>
        <div class="form-group">
          <label class="form-label" for="conv-de">De</label>
          <select id="conv-de" class="form-select"></select>
        </div>
        <button type="button" class="btn-secondary conversor-invertir" aria-label="Invertir unidades" title="Invertir">⇄</button>
        <div class="form-group">
          <label class="form-label" for="conv-a">A</label>
          <select id="conv-a" class="form-select"></select>
        </div>
      </div>
      <output class="herramienta-resultado" aria-live="polite"></output>
    </div>`;

  const magnitudEl = caja.querySelector("#conv-magnitud");
  const valorEl = caja.querySelector("#conv-valor");
  const deEl = caja.querySelector("#conv-de");
  const aEl = caja.querySelector("#conv-a");
  const salida = caja.querySelector(".herramienta-resultado");

  const llenarUnidades = () => {
    const unidades = Object.keys(MAGNITUDES[magnitudEl.value].unidades);
    const opciones = unidades.map((u) => `<option>${escaparEspacios(u)}</option>`).join("");
    deEl.innerHTML = opciones;
    aEl.innerHTML = opciones;
    aEl.selectedIndex = Math.min(1, unidades.length - 1);
  };

  const convertir = () => {
    const valor = leerNumero(valorEl.value);
    if (valor === null) { salida.textContent = ""; return; }
    if (Number.isNaN(valor)) { salida.textContent = "Escribí un número (se puede usar coma)."; salida.classList.add("calc-error"); return; }
    salida.classList.remove("calc-error");
    const resultado = convertirUnidad(magnitudEl.value, valor, deEl.value, aEl.value);
    if (magnitudEl.value === "temperatura" && resultado < -1e-9 && aEl.value === "K") {
      salida.textContent = "Eso queda por debajo del cero absoluto.";
      salida.classList.add("calc-error");
      return;
    }
    salida.textContent = `${formatearNumero(valor, 8)} ${deEl.value} = ${formatearNumero(resultado, 8)} ${aEl.value}`;
  };

  magnitudEl.addEventListener("change", () => { llenarUnidades(); convertir(); });
  [valorEl, deEl, aEl].forEach((el) => el.addEventListener(el === valorEl ? "input" : "change", convertir));
  caja.querySelector(".conversor-invertir").addEventListener("click", () => {
    const de = deEl.value;
    deEl.value = aEl.value;
    aEl.value = de;
    convertir();
  });
  llenarUnidades();
  convertir();
}

/* ------------------------------------------------------------
   MASA MOLAR
   Pesos atómicos estándar (IUPAC, abreviados) de H a U.
   ------------------------------------------------------------ */
const PESOS_ATOMICOS = {
  H: 1.008, He: 4.0026, Li: 6.94, Be: 9.0122, B: 10.81, C: 12.011, N: 14.007, O: 15.999, F: 18.998, Ne: 20.18,
  Na: 22.99, Mg: 24.305, Al: 26.982, Si: 28.085, P: 30.974, S: 32.06, Cl: 35.45, Ar: 39.95, K: 39.098, Ca: 40.078,
  Sc: 44.956, Ti: 47.867, V: 50.942, Cr: 51.996, Mn: 54.938, Fe: 55.845, Co: 58.933, Ni: 58.693, Cu: 63.546, Zn: 65.38,
  Ga: 69.723, Ge: 72.63, As: 74.922, Se: 78.971, Br: 79.904, Kr: 83.798, Rb: 85.468, Sr: 87.62, Y: 88.906, Zr: 91.224,
  Nb: 92.906, Mo: 95.95, Tc: 98, Ru: 101.07, Rh: 102.91, Pd: 106.42, Ag: 107.87, Cd: 112.41, In: 114.82, Sn: 118.71,
  Sb: 121.76, Te: 127.6, I: 126.9, Xe: 131.29, Cs: 132.91, Ba: 137.33, La: 138.91, Ce: 140.12, Pr: 140.91, Nd: 144.24,
  Pm: 145, Sm: 150.36, Eu: 151.96, Gd: 157.25, Tb: 158.93, Dy: 162.5, Ho: 164.93, Er: 167.26, Tm: 168.93, Yb: 173.05,
  Lu: 174.97, Hf: 178.49, Ta: 180.95, W: 183.84, Re: 186.21, Os: 190.23, Ir: 192.22, Pt: 195.08, Au: 196.97, Hg: 200.59,
  Tl: 204.38, Pb: 207.2, Bi: 208.98, Po: 209, At: 210, Rn: 222, Fr: 223, Ra: 226, Ac: 227, Th: 232.04, Pa: 231.04, U: 238.03,
};

// "CuSO4·5H2O" → { Cu: 1, S: 1, O: 9, H: 10 }
function contarAtomos(formula) {
  const texto = String(formula).replace(/\s+/g, "");
  if (!texto) throw new Error("Escribí una fórmula.");
  // Los hidratos (· . *) se suman como partes separadas, cada una
  // con su coeficiente adelante: 5H2O.
  return texto.split(/[·.*•]/).reduce((total, parte) => {
    if (!parte) throw new Error("Sobra un punto en la fórmula.");
    const coef = parte.match(/^\d+/);
    const cuerpo = coef ? parte.slice(coef[0].length) : parte;
    const conteo = contarParte(cuerpo);
    const multiplicador = coef ? parseInt(coef[0], 10) : 1;
    Object.entries(conteo).forEach(([el, n]) => (total[el] = (total[el] || 0) + n * multiplicador));
    return total;
  }, {});
}

function contarParte(cuerpo) {
  const pila = [{}];
  let i = 0;
  const leerCantidad = () => {
    const m = cuerpo.slice(i).match(/^\d+/);
    if (!m) return 1;
    i += m[0].length;
    return parseInt(m[0], 10);
  };
  while (i < cuerpo.length) {
    const c = cuerpo[i];
    if (c === "(" || c === "[") {
      pila.push({});
      i++;
    } else if (c === ")" || c === "]") {
      if (pila.length === 1) throw new Error("Hay un paréntesis que cierra sin abrir.");
      i++;
      const n = leerCantidad();
      const grupo = pila.pop();
      const arriba = pila[pila.length - 1];
      Object.entries(grupo).forEach(([el, k]) => (arriba[el] = (arriba[el] || 0) + k * n));
    } else if (/[A-Z]/.test(c)) {
      const m = cuerpo.slice(i).match(/^[A-Z][a-z]?/);
      let simbolo = m[0];
      // Si el de dos letras no existe, probamos con la mayúscula sola
      // seguida de otra cosa (y si tampoco existe, avisamos con lo escrito).
      if (simbolo.length === 2 && !(simbolo in PESOS_ATOMICOS)) {
        if (!(simbolo[0] in PESOS_ATOMICOS)) throw new Error(`No conozco el elemento "${simbolo}".`);
        simbolo = simbolo[0];
      }
      if (!(simbolo in PESOS_ATOMICOS)) throw new Error(`No conozco el elemento "${simbolo}".`);
      i += simbolo.length;
      const n = leerCantidad();
      const arriba = pila[pila.length - 1];
      arriba[simbolo] = (arriba[simbolo] || 0) + n;
    } else if (/[a-z]/.test(c)) {
      throw new Error(`Los símbolos empiezan con mayúscula: ¿quisiste decir "${c.toUpperCase()}"?`);
    } else {
      throw new Error(`No entiendo "${c}" en la fórmula.`);
    }
  }
  if (pila.length > 1) throw new Error("Falta cerrar un paréntesis.");
  return pila[0];
}

function masaMolar(formula) {
  const atomos = contarAtomos(formula);
  const filas = Object.entries(atomos).map(([el, n]) => ({ el, n, masa: PESOS_ATOMICOS[el] * n }));
  const total = filas.reduce((s, f) => s + f.masa, 0);
  return { total, filas };
}

function armarMasaMolar(caja) {
  caja.innerHTML = `
    <div class="form-group">
      <label class="form-label" for="mm-formula">Fórmula química</label>
      <input id="mm-formula" class="form-input" type="text" autocomplete="off" spellcheck="false" value="H2SO4" data-sin-enter />
      <p class="form-hint">Respetá mayúsculas (Co es cobalto, CO es monóxido). Paréntesis e hidratos valen: Ca(OH)2, CuSO4·5H2O.</p>
    </div>
    <div class="chips-ejemplo">
      ${["H2O", "NaCl", "C6H12O6", "Ca(OH)2", "CuSO4·5H2O", "Al2(SO4)3"]
        .map((f) => `<button type="button" class="filter-chip" data-formula="${f}">${f}</button>`)
        .join("")}
    </div>
    <output class="herramienta-resultado" aria-live="polite"></output>
    <div class="mm-detalle"></div>`;

  const entrada = caja.querySelector("#mm-formula");
  const salida = caja.querySelector(".herramienta-resultado");
  const detalle = caja.querySelector(".mm-detalle");

  const calcular = () => {
    try {
      const { total, filas } = masaMolar(entrada.value);
      salida.classList.remove("calc-error");
      salida.textContent = `M = ${total.toFixed(3).replace(".", ",")} g/mol`;
      detalle.innerHTML = `
        <div class="tabla-envoltorio">
          <table class="tabla-herramienta">
            <thead><tr><th scope="col">Elemento</th><th scope="col">Átomos</th><th scope="col">g/mol</th><th scope="col">% en masa</th></tr></thead>
            <tbody>${filas
              .map(
                (f) => `<tr><td class="tabla-simbolo">${f.el}</td><td>${f.n}</td><td>${f.masa.toFixed(3).replace(".", ",")}</td><td>${((f.masa / total) * 100).toFixed(2).replace(".", ",")} %</td></tr>`
              )
              .join("")}</tbody>
          </table>
        </div>`;
    } catch (error) {
      salida.classList.add("calc-error");
      salida.textContent = error.message;
      detalle.innerHTML = "";
    }
  };

  entrada.addEventListener("input", calcular);
  caja.querySelectorAll("[data-formula]").forEach((boton) =>
    boton.addEventListener("click", () => {
      entrada.value = boton.dataset.formula;
      calcular();
    })
  );
  calcular();
}

/* ------------------------------------------------------------
   LEY DE OHM  (V = I·R, P = V·I)
   ------------------------------------------------------------ */
function resolverOhm({ V, I, R, P }) {
  const dados = [V, I, R, P].filter((x) => x !== null).length;
  if (dados < 2) throw new Error("Completá dos valores.");
  if (dados > 2) throw new Error("Dejá vacíos los que querés calcular (solo dos datos).");
  if (V !== null && I !== null) return { V, I, R: V / I, P: V * I };
  if (V !== null && R !== null) return { V, R, I: V / R, P: (V * V) / R };
  if (V !== null && P !== null) return { V, P, I: P / V, R: (V * V) / P };
  if (I !== null && R !== null) return { I, R, V: I * R, P: I * I * R };
  if (I !== null && P !== null) return { I, P, V: P / I, R: P / (I * I) };
  return { R, P, V: Math.sqrt(P * R), I: Math.sqrt(P / R) };
}

function armarOhm(caja) {
  const campos = [
    ["V", "Tensión (V)", "V", "Ej: 5"],
    ["I", "Corriente (I)", "A", "Ej: 20m"],
    ["R", "Resistencia (R)", "Ω", "Ej: 220"],
    ["P", "Potencia (P)", "W", ""],
  ];
  caja.innerHTML = `
    <div class="ohm-grilla">
      ${campos
        .map(
          ([clave, etiqueta, unidad, ayuda]) => `
        <div class="form-group">
          <label class="form-label" for="ohm-${clave}">${etiqueta}</label>
          <div class="campo-con-unidad">
            <input id="ohm-${clave}" class="form-input" data-ohm="${clave}" type="text" inputmode="decimal" placeholder="${ayuda}" data-sin-enter />
            <span>${unidad}</span>
          </div>
        </div>`
        )
        .join("")}
    </div>
    <div class="herramienta-botones">
      <button type="button" class="btn-primary" data-ohm-accion="calcular">Calcular</button>
      <button type="button" class="btn-secondary" data-ohm-accion="limpiar">Limpiar</button>
    </div>
    <output class="herramienta-resultado" aria-live="polite"></output>
    <p class="herramienta-nota">Se pueden usar prefijos: 4.7k son 4700, 20m son 0,02 (20 miliampere). Si la resistencia es para un LED: R = (V fuente − V LED) / I.</p>`;

  const salida = caja.querySelector(".herramienta-resultado");
  const entradas = [...caja.querySelectorAll("[data-ohm]")];

  caja.querySelector('[data-ohm-accion="calcular"]').addEventListener("click", () => {
    const valores = {};
    for (const entrada of entradas) {
      const v = leerNumero(entrada.value, { conPrefijo: true });
      if (Number.isNaN(v)) {
        salida.textContent = `"${entrada.value}" no es un número.`;
        salida.classList.add("calc-error");
        return;
      }
      valores[entrada.dataset.ohm] = v;
    }
    try {
      const r = resolverOhm(valores);
      if (![r.V, r.I, r.R, r.P].every(Number.isFinite)) throw new Error("Con esos datos no hay solución (¿algún cero?).");
      salida.classList.remove("calc-error");
      salida.textContent = `V = ${conPrefijoSI(r.V, "V")} · I = ${conPrefijoSI(r.I, "A")} · R = ${conPrefijoSI(r.R, "Ω")} · P = ${conPrefijoSI(r.P, "W")}`;
      entradas.forEach((entrada) => {
        if (!entrada.value.trim()) {
          entrada.value = formatearNumero(r[entrada.dataset.ohm], 5).includes("×")
            ? r[entrada.dataset.ohm].toExponential(3)
            : formatearNumero(r[entrada.dataset.ohm], 5);
          entrada.classList.add("campo-calculado");
        }
      });
    } catch (error) {
      salida.classList.add("calc-error");
      salida.textContent = error.message;
    }
  });

  caja.querySelector('[data-ohm-accion="limpiar"]').addEventListener("click", () => {
    entradas.forEach((entrada) => {
      entrada.value = "";
      entrada.classList.remove("campo-calculado");
    });
    salida.textContent = "";
  });
  entradas.forEach((entrada) => entrada.addEventListener("input", () => entrada.classList.remove("campo-calculado")));
}

/* ------------------------------------------------------------
   COLORES DE RESISTENCIAS (código de 4 bandas)
   ------------------------------------------------------------ */
const COLORES_RESISTENCIA = [
  { nombre: "Negro", hex: "#1b1b1b", digito: 0, multiplicador: 1 },
  { nombre: "Marrón", hex: "#7a4a24", digito: 1, multiplicador: 10, tolerancia: 1 },
  { nombre: "Rojo", hex: "#d0312d", digito: 2, multiplicador: 100, tolerancia: 2 },
  { nombre: "Naranja", hex: "#f28a1c", digito: 3, multiplicador: 1e3 },
  { nombre: "Amarillo", hex: "#f5d10f", digito: 4, multiplicador: 1e4 },
  { nombre: "Verde", hex: "#2f9a4a", digito: 5, multiplicador: 1e5, tolerancia: 0.5 },
  { nombre: "Azul", hex: "#2b5fd9", digito: 6, multiplicador: 1e6, tolerancia: 0.25 },
  { nombre: "Violeta", hex: "#8a46c9", digito: 7, multiplicador: 1e7, tolerancia: 0.1 },
  { nombre: "Gris", hex: "#8c8c8c", digito: 8, multiplicador: 1e8, tolerancia: 0.05 },
  { nombre: "Blanco", hex: "#f4f4f4", digito: 9, multiplicador: 1e9 },
  { nombre: "Dorado", hex: "#c9a43b", multiplicador: 0.1, tolerancia: 5 },
  { nombre: "Plateado", hex: "#b8bcc2", multiplicador: 0.01, tolerancia: 10 },
];

function valorDeBandas(b1, b2, mult) {
  return (COLORES_RESISTENCIA[b1].digito * 10 + COLORES_RESISTENCIA[b2].digito) * COLORES_RESISTENCIA[mult].multiplicador;
}

// 4700 → [Amarillo, Violeta, Rojo] (dos cifras significativas)
function bandasDeValor(ohms) {
  if (!(ohms > 0)) throw new Error("Escribí un valor mayor que cero.");
  for (let m = 0; m < COLORES_RESISTENCIA.length; m++) {
    const factor = COLORES_RESISTENCIA[m].multiplicador;
    const cifras = ohms / factor;
    const redondo = Math.round(cifras);
    if (redondo >= 10 && redondo <= 99 && Math.abs(cifras - redondo) < 1e-6 * Math.max(1, cifras)) {
      return [Math.floor(redondo / 10), redondo % 10, m];
    }
  }
  throw new Error("Con 4 bandas solo hay dos cifras significativas (ej.: 4,7 k o 220).");
}

function armarResistencias(caja) {
  const opcion = (lista, seleccionado) =>
    lista.map(({ c, i }) => `<option value="${i}" ${i === seleccionado ? "selected" : ""}>${c.nombre}</option>`).join("");
  const conIndice = COLORES_RESISTENCIA.map((c, i) => ({ c, i }));
  const digitos = conIndice.filter(({ c }) => c.digito !== undefined);
  const primeras = digitos.filter(({ c }) => c.digito !== 0);
  const multiplicadores = conIndice.filter(({ c }) => c.multiplicador <= 1e9);
  const tolerancias = conIndice.filter(({ c }) => c.tolerancia !== undefined);

  caja.innerHTML = `
    <div class="resistencia-dibujo" aria-hidden="true">
      <svg viewBox="0 0 320 70" width="100%" height="70" role="img">
        <line x1="0" y1="35" x2="320" y2="35" stroke="var(--niebla)" stroke-width="4" stroke-linecap="round"/>
        <rect x="70" y="10" width="180" height="50" rx="22" fill="#e9d6ae" stroke="#c9b07e" stroke-width="2"/>
        <rect class="banda" data-banda="0" x="98" y="10" width="14" height="50"/>
        <rect class="banda" data-banda="1" x="126" y="10" width="14" height="50"/>
        <rect class="banda" data-banda="2" x="154" y="10" width="14" height="50"/>
        <rect class="banda" data-banda="3" x="212" y="10" width="14" height="50"/>
      </svg>
    </div>
    <div class="resistencia-grilla">
      <div class="form-group"><label class="form-label" for="res-b1">1.ª banda</label><select id="res-b1" class="form-select" data-banda-sel="0">${opcion(primeras, 4)}</select></div>
      <div class="form-group"><label class="form-label" for="res-b2">2.ª banda</label><select id="res-b2" class="form-select" data-banda-sel="1">${opcion(digitos, 7)}</select></div>
      <div class="form-group"><label class="form-label" for="res-b3">Multiplicador</label><select id="res-b3" class="form-select" data-banda-sel="2">${opcion(multiplicadores, 2)}</select></div>
      <div class="form-group"><label class="form-label" for="res-b4">Tolerancia</label><select id="res-b4" class="form-select" data-banda-sel="3">${opcion(tolerancias, 10)}</select></div>
    </div>
    <output class="herramienta-resultado" aria-live="polite"></output>
    <div class="form-group resistencia-buscar">
      <label class="form-label" for="res-valor">O escribí el valor y te digo los colores</label>
      <div class="campo-con-unidad">
        <input id="res-valor" class="form-input" type="text" inputmode="decimal" placeholder="Ej: 4.7k, 220, 1M" data-sin-enter />
        <span>Ω</span>
      </div>
      <p class="form-hint resistencia-error" aria-live="polite"></p>
    </div>`;

  const selects = [...caja.querySelectorAll("[data-banda-sel]")];
  const bandas = [...caja.querySelectorAll(".banda")];
  const salida = caja.querySelector(".herramienta-resultado");
  const valorEl = caja.querySelector("#res-valor");
  const errorEl = caja.querySelector(".resistencia-error");

  const pintar = () => {
    const [b1, b2, m, t] = selects.map((s) => Number(s.value));
    bandas.forEach((banda, i) => banda.setAttribute("fill", COLORES_RESISTENCIA[[b1, b2, m, t][i]].hex));
    const ohms = valorDeBandas(b1, b2, m);
    const tol = COLORES_RESISTENCIA[t].tolerancia;
    salida.textContent = `${conPrefijoSI(ohms, "Ω")} ± ${String(tol).replace(".", ",")} %  (entre ${conPrefijoSI(ohms * (1 - tol / 100), "Ω")} y ${conPrefijoSI(ohms * (1 + tol / 100), "Ω")})`;
  };

  selects.forEach((s) => s.addEventListener("change", pintar));
  valorEl.addEventListener("input", () => {
    const valor = leerNumero(valorEl.value, { conPrefijo: true });
    if (valor === null) { errorEl.textContent = ""; return; }
    try {
      if (Number.isNaN(valor)) throw new Error("Eso no es un número.");
      const [b1, b2, m] = bandasDeValor(valor);
      selects[0].value = String(conIndice.find(({ c }) => c.digito === b1).i);
      selects[1].value = String(conIndice.find(({ c }) => c.digito === b2).i);
      selects[2].value = String(m);
      errorEl.textContent = `${COLORES_RESISTENCIA[selects[0].value].nombre}, ${COLORES_RESISTENCIA[selects[1].value].nombre}, ${COLORES_RESISTENCIA[m].nombre}.`;
      pintar();
    } catch (error) {
      errorEl.textContent = error.message;
    }
  });
  pintar();
}

/* ------------------------------------------------------------
   BASES NUMÉRICAS (con BigInt: no se pierde precisión)
   ------------------------------------------------------------ */
const BASES = [
  { base: 2, nombre: "Binario", digitos: /^[01]+$/, prefijo: "0b" },
  { base: 8, nombre: "Octal", digitos: /^[0-7]+$/, prefijo: "0o" },
  { base: 10, nombre: "Decimal", digitos: /^\d+$/, prefijo: "" },
  { base: 16, nombre: "Hexadecimal", digitos: /^[0-9a-f]+$/i, prefijo: "0x" },
];

function leerEnBase(texto, base) {
  const limpio = String(texto).trim().replace(/[\s_]/g, "").replace(/^0[box]/i, "");
  if (!limpio) return null;
  const info = BASES.find((b) => b.base === base);
  if (!info.digitos.test(limpio)) throw new Error(`"${texto.trim()}" no es un número ${info.nombre.toLowerCase()} válido.`);
  return [...limpio.toLowerCase()].reduce((acc, c) => acc * BigInt(base) + BigInt(parseInt(c, 16)), 0n);
}

function agruparDigitos(texto, cada) {
  return texto.replace(new RegExp(`\\B(?=(.{${cada}})+$)`, "g"), " ");
}

function armarBases(caja) {
  caja.innerHTML = `
    <div class="conversor-fila conversor-fila-bases">
      <div class="form-group">
        <label class="form-label" for="bases-valor">Número</label>
        <input id="bases-valor" class="form-input" type="text" autocomplete="off" spellcheck="false" value="2026" data-sin-enter />
      </div>
      <div class="form-group">
        <label class="form-label" for="bases-de">Está en</label>
        <select id="bases-de" class="form-select">${BASES.map((b) => `<option value="${b.base}" ${b.base === 10 ? "selected" : ""}>${b.nombre} (base ${b.base})</option>`).join("")}</select>
      </div>
    </div>
    <p class="form-hint bases-error" aria-live="polite"></p>
    <dl class="bases-resultados">
      ${BASES.map((b) => `<div><dt>${b.nombre}</dt><dd data-base="${b.base}">—</dd></div>`).join("")}
    </dl>`;

  const entrada = caja.querySelector("#bases-valor");
  const baseEl = caja.querySelector("#bases-de");
  const errorEl = caja.querySelector(".bases-error");

  const convertir = () => {
    try {
      const valor = leerEnBase(entrada.value, Number(baseEl.value));
      errorEl.textContent = "";
      BASES.forEach((b) => {
        const dd = caja.querySelector(`[data-base="${b.base}"]`);
        if (valor === null) { dd.textContent = "—"; return; }
        let texto = valor.toString(b.base).toUpperCase();
        if (b.base === 2) texto = agruparDigitos(texto.padStart(Math.ceil(texto.length / 4) * 4, "0"), 4);
        else if (b.base === 10) texto = agruparDigitos(texto, 3).replace(/ /g, ".");
        dd.textContent = b.prefijo + texto;
      });
    } catch (error) {
      errorEl.textContent = error.message;
    }
  };

  entrada.addEventListener("input", convertir);
  baseEl.addEventListener("change", convertir);
  convertir();
}

/* ============================================================
   FICHA DEL SALÓN
   Se abre con "Ver recursos" desde Reservas (alumno y profesor) y
   desde el inventario del admin. Muestra las herramientas de la
   materia (con pestañas), los materiales que se usan ahí y los
   enlaces. Si en la página hay formulario de reserva y la cuenta
   puede pedir materiales, cada material trae su botón "Pedir".
   ============================================================ */
function htmlEnlacesDelSalon(recursos) {
  const ceibal = recursos.estudio
    ? `
      <a class="banner-ceibal" href="${ENLACES_DEL_POLO.bibliotecaCeibal}" target="_blank" rel="noopener noreferrer">
        <span class="banner-ceibal-icono" aria-hidden="true">${typeof icono === "function" ? icono("libro", 22) : ""}</span>
        <span>
          <strong>Biblioteca Ceibal (Biblioteca País)</strong>
          <span>Libros y textos de estudio gratis, entrando con tu usuario Ceibal.</span>
        </span>
        <span class="banner-ceibal-flecha" aria-hidden="true">↗</span>
      </a>`
    : "";
  const pets = ENLACES_DEL_POLO.pets
    ? `<a class="enlace-pets" href="${escaparEspacios(ENLACES_DEL_POLO.pets)}" target="_blank" rel="noopener noreferrer"><strong>PETS</strong><span>Abrir</span></a>`
    : `<span class="enlace-pets enlace-pendiente" aria-disabled="true"><strong>PETS</strong><span>Enlace pendiente</span></span>`;
  return `<div class="ficha-enlaces">${ceibal}${pets}</div>`;
}

function abrirFichaSalon(salonId, { puedePedirMateriales = false } = {}) {
  const salon = (typeof salones !== "undefined" ? salones : []).find((s) => s.id === salonId);
  if (!salon) return;
  const recursos = recursosDelSalon(salonId);

  const herramientas = recursos.herramientas.filter((h) => HERRAMIENTAS[h]);
  const pestanas = herramientas.length
    ? `
      <div class="tabs ficha-pestanas" role="tablist" aria-label="Herramientas de ${escaparEspacios(salon.nombre)}">
        ${herramientas
          .map(
            (h, i) => `<button type="button" class="tab ${i === 0 ? "active" : ""}" role="tab" id="pestana-${h}" aria-controls="panel-herramienta" aria-selected="${i === 0}" data-herramienta="${h}">${HERRAMIENTAS[h].nombre}</button>`
          )
          .join("")}
      </div>
      <p class="herramienta-resumen"></p>
      <div id="panel-herramienta" class="herramienta" role="tabpanel"></div>`
    : `<p class="perfil-vacio">Este espacio no tiene herramientas de materia: se usa para ${escaparEspacios((recursos.materia || "otras actividades").toLowerCase())}.</p>`;

  const materiales = recursos.materiales
    .map((id) => salones.find((s) => s.id === id))
    .filter(Boolean)
    .map(
      (m) => `
      <li class="ficha-material">
        <span class="ficha-material-icono" aria-hidden="true">${typeof icono === "function" ? icono("equipo", 18) : ""}</span>
        <span class="ficha-material-nombre">${escaparEspacios(m.nombre)}<small>${m.cantidad || 1} ${m.cantidad === 1 ? "unidad" : "unidades"}</small></span>
        ${puedePedirMateriales ? `<button type="button" class="btn-view" data-pedir-material="${m.id}">Pedir</button>` : ""}
      </li>`
    )
    .join("");

  const tipo = typeof ETIQUETA_TIPO_SALON !== "undefined" ? ETIQUETA_TIPO_SALON[salon.tipo] : salon.tipo;
  abrirModal({
    titulo: salon.nombre,
    amplio: true,
    textoConfirmar: null,
    textoCancelar: "Cerrar",
    cuerpoHTML: `
      <div class="ficha-salon">
        <p class="ficha-salon-tipo">${typeof icono === "function" && typeof ICONO_TIPO_SALON !== "undefined" ? icono(ICONO_TIPO_SALON[salon.tipo], 15) : ""}${escaparEspacios(tipo)}${recursos.materia ? ` · ${escaparEspacios(recursos.materia)}` : ""}</p>

        <section class="ficha-bloque" aria-labelledby="ficha-titulo-herramientas">
          <h3 id="ficha-titulo-herramientas" class="perfil-subtitulo">Herramientas de la materia</h3>
          ${pestanas}
        </section>

        <section class="ficha-bloque" aria-labelledby="ficha-titulo-materiales">
          <h3 id="ficha-titulo-materiales" class="perfil-subtitulo">Materiales que se usan acá</h3>
          ${materiales ? `<ul class="ficha-materiales">${materiales}</ul>` : `<p class="perfil-vacio">No hay materiales sugeridos para este espacio.</p>`}
        </section>

        ${htmlEnlacesDelSalon(recursos)}
      </div>`,
  });

  const cuerpo = document.getElementById("modal-cuerpo");
  const resumen = cuerpo.querySelector(".herramienta-resumen");
  // Cada herramienta se arma de cero en un contenedor nuevo: así no
  // quedan enganchados los listeners de la anterior.
  const mostrarHerramienta = (clave) => {
    const actual = cuerpo.querySelector("#panel-herramienta");
    const nuevo = actual.cloneNode(false);
    nuevo.setAttribute("aria-labelledby", `pestana-${clave}`);
    actual.replaceWith(nuevo);
    HERRAMIENTAS[clave].armar(nuevo);
    resumen.textContent = HERRAMIENTAS[clave].resumen;
    cuerpo.querySelectorAll("[data-herramienta]").forEach((b) => {
      const activa = b.dataset.herramienta === clave;
      b.classList.toggle("active", activa);
      b.setAttribute("aria-selected", String(activa));
    });
  };
  cuerpo.querySelectorAll("[data-herramienta]").forEach((boton) =>
    boton.addEventListener("click", () => mostrarHerramienta(boton.dataset.herramienta))
  );
  if (herramientas.length) mostrarHerramienta(herramientas[0]);

  cuerpo.querySelectorAll("[data-pedir-material]").forEach((boton) =>
    boton.addEventListener("click", () => {
      cerrarModal();
      if (typeof elegirRecursoEnFormulario === "function") elegirRecursoEnFormulario(boton.dataset.pedirMaterial);
    })
  );
}
