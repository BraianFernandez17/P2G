/* ============================================================
   DASHBOARD DEL ESTUDIANTE
   Las pasantías, las postulaciones y el perfil profesional ya no
   viven acá: salen de la bolsa compartida (js/bolsa.js), la misma
   que lee el panel de empresa. Así, cuando una empresa acepta a
   un estudiante, el estudiante lo ve en "Mis postulaciones".

   En la versión real, cada lectura sería un fetch al backend:
     fetch("/api/v1/students/me/profile").then((r) => r.json())
   ============================================================ */

// Para cuando se abre el archivo directo, sin pasar por el login.
const ESTUDIANTE_DEMO = { email: "maria@estudiante.com", name: "María González" };

function estudianteActual() {
  const sesion = obtenerSesion();
  return sesion && sesion.role === "student" ? sesion : ESTUDIANTE_DEMO;
}

function miPerfil() {
  const yo = estudianteActual();
  return perfilDe(yo.email, yo.name);
}

/* ============================================================
   SALUDO, BARRA DE PERFIL Y NÚMEROS
   ============================================================ */
function pintarSaludo() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;
  saludoEl.textContent = `Hola, ${estudianteActual().name}`;
}

// La barra ya no es un 70 % fijo: se calcula con lo que el
// estudiante completó de verdad en su perfil profesional.
function pintarBarraDePerfil() {
  const fillEl = document.getElementById("barra-perfil-relleno");
  const porcentajeEl = document.getElementById("barra-perfil-porcentaje");
  if (!fillEl || !porcentajeEl) return;

  const perfil = miPerfil();
  const porcentaje = completitudPerfil(perfil);
  fillEl.style.width = `${porcentaje}%`;
  porcentajeEl.textContent = `${porcentaje}%`;

  const faltaEl = document.getElementById("perfil-falta");
  if (faltaEl) {
    const faltan = faltantesDelPerfil(perfil);
    faltaEl.textContent = faltan.length
      ? `Te falta: ${faltan.slice(0, 3).join(", ").toLowerCase()}${faltan.length > 3 ? "…" : "."}`
      : "Tu perfil está completo: las empresas ven todo lo que sabés hacer.";
  }
}

function pintarEstadisticas() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const postulaciones = postulacionesDeEstudiante(estudianteActual().email);
  const enRevision = postulaciones.filter((p) => p.estado === "pending").length;
  const seleccionado = postulaciones.filter((p) => p.estado === "approved").length;

  const estadisticas = [
    { icono: icono("documento"), tono: "accent", etiqueta: "Postulaciones", valor: postulaciones.length },
    { icono: icono("lupa"), tono: "warning", etiqueta: "En revisión", valor: enRevision },
    { icono: icono("tilde"), tono: "success", etiqueta: "Te seleccionaron", valor: seleccionado },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PERFIL PROFESIONAL
   ============================================================ */
function pintarPerfilProfesional() {
  const tarjetaEl = document.getElementById("perfil-profesional");
  if (!tarjetaEl) return;
  tarjetaEl.innerHTML = htmlPerfil(miPerfil(), { propio: true });
  pintarBarraDePerfil();
}

// Una fila editable de una lista (título, curso o experiencia).
function filaEditable(tipo, campos, valores = {}) {
  return `
    <div class="editor-fila" data-tipo="${tipo}">
      ${campos
        .map(
          ([clave, etiqueta, ayuda]) => `
        <label class="editor-campo">
          <span class="form-label">${etiqueta}</span>
          <input type="text" class="form-input" data-clave="${clave}" data-sin-enter
                 value="${escaparHTML(valores[clave] || "")}" placeholder="${ayuda}" />
        </label>`
        )
        .join("")}
      <button type="button" class="editor-quitar" data-quitar aria-label="Quitar esta fila" title="Quitar">×</button>
    </div>`;
}

const CAMPOS_EDITOR = {
  titulos: [
    ["nombre", "Título o certificación", "Ej: Bachillerato Tecnológico"],
    ["institucion", "Institución", "Ej: UTU Tacuarembó"],
    ["anio", "Año", "2025"],
  ],
  cursos: [
    ["nombre", "Curso", "Ej: Introducción a Python"],
    ["institucion", "Dónde", "Ej: Ceibal"],
    ["detalle", "Duración o año", "40 horas"],
  ],
  experiencia: [
    ["puesto", "Puesto o tarea", "Ej: Ayudante de laboratorio"],
    ["lugar", "Dónde", "Ej: Cooperativa local"],
    ["periodo", "Cuándo", "2024 – 2025"],
  ],
};

// Las capacidades e idiomas se escriben y se suman con Enter (o
// coma); cada una queda como un chip con su botón para quitarla.
function campoDeChips(id, etiqueta, valores, ayuda) {
  return `
    <div class="form-group editor-chips" data-chips="${id}">
      <label class="form-label" for="chips-${id}">${etiqueta}</label>
      <div class="chips-caja">
        <ul class="perfil-chips perfil-chips-editables">
          ${valores.map((v) => chipEditable(v)).join("")}
        </ul>
        <input type="text" id="chips-${id}" class="chips-entrada" data-sin-enter placeholder="${ayuda}" />
      </div>
      <p class="form-hint">Escribí y apretá Enter para sumar.</p>
    </div>`;
}

function chipEditable(valor) {
  return `<li><span>${escaparHTML(valor)}</span><button type="button" data-quitar-chip aria-label="Quitar ${escaparHTML(valor)}">×</button></li>`;
}

function opciones(lista, actual, vacia) {
  return (
    `<option value="">${vacia}</option>` +
    lista.map((v) => `<option ${v === actual ? "selected" : ""}>${escaparHTML(v)}</option>`).join("")
  );
}

/* ------------------------------------------------------------
   CURRÍCULUM EN EL EDITOR
   Se valida apenas se elige el archivo (js/curriculum.js): si no es
   un PDF de verdad o pasa de 5 MB, se avisa ahí mismo y no se
   guarda. El cambio (subir, reemplazar o quitar) se aplica recién
   al tocar "Guardar perfil", como el resto del editor.
   ------------------------------------------------------------ */
function htmlCampoCV() {
  return `
    <fieldset class="editor-seccion editor-cv">
      <legend class="editor-legend">Currículum (PDF)</legend>
      <div id="cv-estado" class="cv-estado"></div>
      <div class="cv-botones">
        <label class="btn-secondary cv-subir">
          <input type="file" id="cv-archivo" class="sr-only" accept="application/pdf,.pdf" data-sin-enter />
          <span id="cv-subir-texto">Subir PDF</span>
        </label>
        <button type="button" id="cv-quitar" class="btn-reject">Quitar</button>
      </div>
      <p class="form-hint">Solo PDF, hasta 5 MB. Suma a la barra de tu perfil. Por ahora el archivo queda guardado en este navegador.</p>
      <p id="cv-error" class="cv-error" role="alert"></p>
    </fieldset>`;
}

function engancharCampoCV(cuerpo, perfil, cambio) {
  const estado = cuerpo.querySelector("#cv-estado");
  const entrada = cuerpo.querySelector("#cv-archivo");
  const textoSubir = cuerpo.querySelector("#cv-subir-texto");
  const quitar = cuerpo.querySelector("#cv-quitar");
  const error = cuerpo.querySelector("#cv-error");

  const pintar = () => {
    const actual = cambio.accion === "subir" ? cambio.meta : cambio.accion === "quitar" ? null : perfil.cv;
    if (actual) {
      const detalle = cambio.accion === "subir" ? `${formatearTamano(actual.tamano)} · se guarda al tocar "Guardar perfil"` : htmlDetalleCV(actual);
      estado.innerHTML = `<span class="cv-icono" aria-hidden="true">PDF</span><span class="cv-datos"><strong>${escaparHTML(actual.nombre)}</strong><small>${escaparHTML(detalle)}</small></span>`;
    } else {
      estado.innerHTML = `<p class="perfil-vacio">${cambio.accion === "quitar" ? 'Se va a quitar al tocar "Guardar perfil".' : "Todavía no subiste tu currículum."}</p>`;
    }
    textoSubir.textContent = actual ? "Reemplazar PDF" : "Subir PDF";
    quitar.style.display = actual ? "" : "none"; // (los estilos de .btn-reject le ganan a [hidden])
  };

  entrada.addEventListener("change", async () => {
    const archivo = entrada.files[0];
    entrada.value = ""; // permite volver a elegir el mismo archivo
    if (!archivo) return;
    const problema = await validarCV(archivo);
    if (problema) {
      error.textContent = problema;
      mostrarToast(problema, "error");
      return;
    }
    error.textContent = "";
    cambio.accion = "subir";
    cambio.archivo = archivo;
    cambio.meta = { nombre: archivo.name, tamano: archivo.size, subido: new Date().toISOString() };
    pintar();
  });

  quitar.addEventListener("click", () => {
    error.textContent = "";
    cambio.accion = "quitar";
    cambio.archivo = null;
    pintar();
  });

  pintar();
}

function htmlDetalleCV(cv) {
  return [cv.tamano ? formatearTamano(cv.tamano) : "PDF de ejemplo", cv.subido ? `subido el ${fechaCorta(cv.subido)}` : ""]
    .filter(Boolean)
    .join(" · ");
}

function abrirEditorPerfil() {
  const perfil = miPerfil();
  // Lo que se hizo con el currículum mientras el editor está abierto
  const cambioCV = { accion: "mantener", archivo: null, meta: null };
  const seccionLista = (tipo, titulo, boton) => `
    <fieldset class="editor-seccion" data-lista="${tipo}">
      <legend class="editor-legend">${titulo}</legend>
      <div class="editor-filas">
        ${perfil[tipo].map((item) => filaEditable(tipo, CAMPOS_EDITOR[tipo], item)).join("")}
      </div>
      <button type="button" class="btn-secondary editor-agregar" data-agregar="${tipo}">${boton}</button>
    </fieldset>`;

  abrirModal({
    titulo: "Tu perfil profesional",
    amplio: true,
    textoConfirmar: "Guardar perfil",
    cuerpoHTML: `
      <p class="form-hint editor-intro">Esto es lo que ven las empresas cuando te postulás o cuando buscan perfiles como el tuyo.</p>

      <div class="editor-grilla">
        <div class="form-group">
          <label class="form-label" for="perfil-orientacion">Orientación que cursás</label>
          <input type="text" id="perfil-orientacion" class="form-input" list="lista-orientaciones"
                 value="${escaparHTML(perfil.orientacion)}" placeholder="Elegí o escribí la tuya" />
          <datalist id="lista-orientaciones">${ORIENTACIONES.map((o) => `<option value="${o}"></option>`).join("")}</datalist>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-nivel">Año o nivel</label>
          <select id="perfil-nivel" class="form-select">${opciones(NIVELES, perfil.nivel, "Elegí")}</select>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-disponibilidad">Disponibilidad</label>
          <select id="perfil-disponibilidad" class="form-select">${opciones(DISPONIBILIDADES, perfil.disponibilidad, "Elegí")}</select>
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-localidad">Localidad</label>
          <input type="text" id="perfil-localidad" class="form-input" value="${escaparHTML(perfil.localidad)}" placeholder="Ej: Tacuarembó" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="perfil-sobre">Sobre vos</label>
        <textarea id="perfil-sobre" class="form-input form-textarea" rows="3" maxlength="400"
                  placeholder="Qué te interesa, qué sabés hacer y qué buscás en una pasantía.">${escaparHTML(perfil.sobreMi)}</textarea>
      </div>

      <div class="editor-grilla editor-grilla-2">
        ${campoDeChips("capacidades", "Capacidades", perfil.capacidades, "Ej: Excel, Arduino, atención al público")}
        ${campoDeChips("idiomas", "Idiomas", perfil.idiomas, "Ej: Inglés B1")}
      </div>

      ${seccionLista("titulos", "Títulos y certificaciones", "Agregar título")}
      ${seccionLista("cursos", "Cursos y capacitaciones", "Agregar curso")}
      ${seccionLista("experiencia", "Experiencia y pasantías anteriores", "Agregar experiencia")}

      <div class="editor-grilla editor-grilla-2">
        <div class="form-group">
          <label class="form-label" for="perfil-linkedin">LinkedIn</label>
          <input type="text" id="perfil-linkedin" class="form-input" value="${escaparHTML(perfil.linkedin)}" placeholder="linkedin.com/in/…" />
        </div>
        <div class="form-group">
          <label class="form-label" for="perfil-portfolio">GitHub o portfolio</label>
          <input type="text" id="perfil-portfolio" class="form-input" value="${escaparHTML(perfil.portfolio)}" placeholder="github.com/…" />
        </div>
      </div>

      ${typeof validarCV === "function" ? htmlCampoCV() : ""}
    `,
    alConfirmar: (cuerpo) => {
      const leerChips = (id) =>
        [...cuerpo.querySelectorAll(`[data-chips="${id}"] li span`)].map((s) => s.textContent.trim()).filter(Boolean);
      const leerLista = (tipo) =>
        [...cuerpo.querySelectorAll(`[data-lista="${tipo}"] .editor-fila`)]
          .map((fila) =>
            Object.fromEntries([...fila.querySelectorAll("input")].map((i) => [i.dataset.clave, i.value.trim()]))
          )
          .filter((item) => Object.values(item).some(Boolean));

      // Lo que quedó escrito en un campo de chips sin apretar Enter
      // también cuenta: si no, se perdería en silencio.
      cuerpo.querySelectorAll(".chips-entrada").forEach((entrada) => sumarChip(entrada));

      const nuevo = {
        ...perfil,
        nombre: estudianteActual().name,
        orientacion: cuerpo.querySelector("#perfil-orientacion").value.trim(),
        nivel: cuerpo.querySelector("#perfil-nivel").value,
        disponibilidad: cuerpo.querySelector("#perfil-disponibilidad").value,
        localidad: cuerpo.querySelector("#perfil-localidad").value.trim(),
        sobreMi: cuerpo.querySelector("#perfil-sobre").value.trim(),
        capacidades: leerChips("capacidades"),
        idiomas: leerChips("idiomas"),
        titulos: leerLista("titulos"),
        cursos: leerLista("cursos"),
        experiencia: leerLista("experiencia"),
        linkedin: cuerpo.querySelector("#perfil-linkedin").value.trim(),
        portfolio: cuerpo.querySelector("#perfil-portfolio").value.trim(),
        cv: cambioCV.accion === "subir" ? cambioCV.meta : cambioCV.accion === "quitar" ? null : perfil.cv,
      };

      // Versión real: PUT /api/v1/perfil (y PUT o DELETE /api/v1/perfil/cv)
      const email = estudianteActual().email;
      guardarPerfil(email, nuevo);
      pintarPerfilProfesional();

      if (cambioCV.accion === "subir") {
        guardarArchivoCV(email, cambioCV.archivo)
          .then(() => mostrarToast("Perfil y currículum guardados. Las empresas ya ven la versión nueva.", "success"))
          .catch(() => {
            // Si el navegador no dejó guardar el archivo, el perfil no
            // puede decir que hay CV: se vuelve al que había.
            guardarPerfil(email, { ...nuevo, cv: perfil.cv });
            pintarPerfilProfesional();
            mostrarToast("Se guardó el perfil, pero el navegador no dejó guardar el PDF. Probá de nuevo.", "error");
          });
      } else {
        if (cambioCV.accion === "quitar") borrarArchivoCV(email).catch(() => {});
        mostrarToast(
          cambioCV.accion === "quitar" ? "Perfil guardado y currículum quitado." : "Perfil guardado. Las empresas ya ven la versión nueva.",
          "success"
        );
      }
    },
  });

  const cuerpoEditor = document.getElementById("modal-cuerpo");
  engancharEditor(cuerpoEditor);
  if (cuerpoEditor.querySelector("#cv-archivo")) engancharCampoCV(cuerpoEditor, perfil, cambioCV);
}

function sumarChip(entrada) {
  const caja = entrada.closest(".editor-chips");
  const lista = caja.querySelector("ul");
  entrada.value
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean)
    .forEach((valor) => {
      const repetido = [...lista.querySelectorAll("li span")].some((s) => s.textContent.toLowerCase() === valor.toLowerCase());
      if (!repetido) lista.insertAdjacentHTML("beforeend", chipEditable(valor.slice(0, 40)));
    });
  entrada.value = "";
}

function engancharEditor(cuerpo) {
  cuerpo.querySelectorAll(".chips-entrada").forEach((entrada) => {
    entrada.addEventListener("keydown", (evento) => {
      if (evento.key === "Enter" || evento.key === ",") {
        evento.preventDefault();
        sumarChip(entrada);
      } else if (evento.key === "Backspace" && !entrada.value) {
        // Borrar con el campo vacío quita el último chip, como en
        // cualquier campo de etiquetas.
        entrada.closest(".editor-chips").querySelector("li:last-child")?.remove();
      }
    });
  });

  // Un solo manejador para quitar chips y filas y para agregar filas
  // (también sirve para las filas que se agregan después).
  cuerpo.addEventListener("click", (evento) => {
    const quitarChip = evento.target.closest("[data-quitar-chip]");
    if (quitarChip) {
      quitarChip.closest("li").remove();
      return;
    }
    const quitarFila = evento.target.closest("[data-quitar]");
    if (quitarFila) {
      quitarFila.closest(".editor-fila").remove();
      return;
    }
    const agregar = evento.target.closest("[data-agregar]");
    if (agregar) {
      const tipo = agregar.dataset.agregar;
      const filas = cuerpo.querySelector(`[data-lista="${tipo}"] .editor-filas`);
      filas.insertAdjacentHTML("beforeend", filaEditable(tipo, CAMPOS_EDITOR[tipo]));
      filas.lastElementChild.querySelector("input").focus();
    }
  });
}

/* ============================================================
   MIS POSTULACIONES
   ============================================================ */
function pintarMisPostulaciones() {
  const listaEl = document.getElementById("lista-postulaciones");
  if (!listaEl) return;

  const postulaciones = postulacionesDeEstudiante(estudianteActual().email);

  if (postulaciones.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no te postulaste a ninguna pasantía. Elegí una de las recomendadas.</p>`;
    return;
  }

  listaEl.innerHTML = postulaciones
    .map(
      (postulacion) => `
      <div class="booking-card${postulacion.estado === "approved" ? " booking-card-destacada" : ""}">
        <div>
          <p class="booking-card-title">${escaparHTML(postulacion.pasantia.titulo)}</p>
          <p class="booking-card-meta">
            ${escaparHTML(postulacion.pasantia.empresa)}${
              postulacion.estado === "approved" ? " · La empresa te eligió para esta pasantía" : ""
            }
          </p>
        </div>
        <span class="status-badge ${postulacion.estado}">${ESTADO_POSTULACION[postulacion.estado]}</span>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   PASANTÍAS RECOMENDADAS (con filtro por modalidad)
   ============================================================ */
let filtroModalidad = "todas";

function pintarFiltrosModalidad() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-modalidad");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-modalidad";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const modalidades = ["todas", ...new Set(pasantiasVisibles().map((p) => p.modalidad))];
  filtrosEl.innerHTML = modalidades
    .map(
      (modalidad) => `
      <button type="button" class="filter-chip ${filtroModalidad === modalidad ? "active" : ""}" data-modalidad="${modalidad}">
        ${modalidad === "todas" ? "Todas" : escaparHTML(modalidad)}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-modalidad]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroModalidad = boton.dataset.modalidad;
      pintarPasantiasRecomendadas();
    });
  });
}

function pintarPasantiasRecomendadas() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  pintarFiltrosModalidad();

  const todas = pasantiasVisibles();
  const pasantias = filtroModalidad === "todas" ? todas : todas.filter((p) => p.modalidad === filtroModalidad);

  if (pasantias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">No hay pasantías ${filtroModalidad.toLowerCase()} por ahora.</p>`;
    return;
  }

  listaEl.innerHTML = pasantias
    .map(
      (pasantia) => `
      <div class="internship-card">
        <div>
          <p class="internship-title">${escaparHTML(pasantia.titulo)}</p>
          <p class="internship-meta">
            ${escaparHTML(pasantia.empresa)} · ${escaparHTML(pasantia.modalidad)} · ${pasantia.duracionMeses} meses
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">
          Ver
        </button>
      </div>
    `
    )
    .join("");

  listaEl.querySelectorAll(".btn-view").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPasantia(boton.dataset.pasantiaId);
    });
  });
}

/* ============================================================
   VER UNA PASANTÍA Y POSTULARSE
   ============================================================ */
function verPasantia(pasantiaId) {
  const pasantia = pasantiaPorId(pasantiaId);
  if (!pasantia) return;

  const yo = estudianteActual();
  const postulacion = postulacionDe(yo.email, pasantia.id);
  const completitud = completitudPerfil(miPerfil());

  let texto = `${pasantia.empresa} · ${pasantia.modalidad} · ${pasantia.duracionMeses} meses.`;
  if (postulacion) {
    texto += ` Ya estás postulado: ${ESTADO_POSTULACION[postulacion.estado].toLowerCase()}.`;
  } else {
    texto += " La empresa va a ver tu perfil profesional.";
    if (completitud < 60) texto += ` Tu perfil está al ${completitud} %: completalo para tener más chances.`;
    texto += " ¿Querés postularte?";
  }

  pedirConfirmacion(
    pasantia.titulo,
    texto,
    postulacion ? null : () => postularme(pasantia),
    postulacion ? "Entendido" : "Postularme",
    postulacion ? null : "Cerrar"
  );
}

function postularme(pasantia) {
  // Versión real: POST /api/v1/internships/:id/applications
  postular(estudianteActual().email, pasantia.id);
  pintarMisPostulaciones();
  pintarEstadisticas();
  mostrarToast(`Te postulaste a "${pasantia.titulo}". Queda en revisión.`, "success");
}

/* ============================================================
   PUNTO DE ENTRADA
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  pintarSaludo();
  pintarPerfilProfesional();
  pintarEstadisticas();
  pintarMisPostulaciones();
  pintarPasantiasRecomendadas();

  const botonEditar = document.getElementById("editar-perfil-profesional");
  if (botonEditar) botonEditar.addEventListener("click", abrirEditorPerfil);

  // Si la empresa cambió algo desde otra pestaña (aceptó la
  // postulación, por ejemplo), se refleja sin recargar.
  window.addEventListener("storage", (evento) => {
    if (evento.key !== CLAVE_BOLSA) return;
    pintarPerfilProfesional();
    pintarEstadisticas();
    pintarMisPostulaciones();
    pintarPasantiasRecomendadas();
  });
});
