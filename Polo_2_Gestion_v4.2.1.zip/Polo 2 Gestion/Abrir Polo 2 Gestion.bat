@echo off
rem ================================================================
rem  Polo 2 Gestion - abrir la pagina en localhost
rem  Doble clic en este archivo: levanta un servidor local y abre
rem  el navegador en http://localhost:8080/index.html
rem
rem  Hace falta abrirla asi (y no con doble clic en index.html)
rem  para que funcionen el microfono, los aplausos y el dictado:
rem  los navegadores solo los permiten en https o en localhost.
rem
rem  Para apagar el servidor, cerra la ventana negra.
rem ================================================================
setlocal
title Polo 2 Gestion - servidor local
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0herramientas\servidor.ps1" -Puerto 8080

if errorlevel 1 (
  echo.
  echo   No se pudo levantar el servidor.
  echo   Si ves un error de PowerShell arriba, sacale una captura y revisala.
  echo.
  pause
)
endlocal
