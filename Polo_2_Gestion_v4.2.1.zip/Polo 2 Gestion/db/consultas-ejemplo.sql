-- ================================================================
-- POLO 2 GESTIÓN · CONSULTAS DE EJEMPLO
-- ----------------------------------------------------------------
-- Lo que pide cada pantalla del sitio, escrito en SQL. Sirven para
-- mirar los datos en Adminer o psql, y son exactamente lo que
-- ejecuta backend/main.py en cada endpoint.
-- Todas usan las cuentas de prueba de seed.sql.
-- ================================================================
SET client_encoding TO 'UTF8';   -- los acentos se leen bien aunque psql corra en una consola de Windows
SET timezone TO 'America/Montevideo';

-- ---------------------------------------------------------------
-- INICIAR SESIÓN (login.html)
-- ---------------------------------------------------------------
SELECT * FROM fn_login('ana@polotec.edu.uy', 'demo1234');

-- Preferencias de la cuenta (Configuración del menú de perfil)
SELECT p.* FROM user_preferences p JOIN users u ON u.id = p.user_id
 WHERE u.email = 'ana@polotec.edu.uy';

-- ---------------------------------------------------------------
-- AGENDA PÚBLICA (agenda-publica.html)
-- ---------------------------------------------------------------
SELECT to_char(desde, 'DD/MM · HH24:MI') || ' a ' || to_char(hasta, 'HH24:MI') AS cuando,
       recurso AS salon, actividad, a_cargo_de
  FROM v_agenda_publica;

-- ---------------------------------------------------------------
-- PANEL DEL PROFESOR (dashboard-profesor.html)
-- ---------------------------------------------------------------
-- Mis reservas
SELECT r.name AS salon, b.title AS motivo, b.starts_at, b.ends_at, b.status
  FROM bookings b JOIN resources r ON r.id = b.resource_id
 WHERE b.requested_by = (SELECT id FROM users WHERE email = 'ana@polotec.edu.uy')
 ORDER BY b.starts_at;

-- Tablero: aprobadas, esperando aprobación y la próxima
SELECT count(*) FILTER (WHERE status = 'approved') AS aprobadas,
       count(*) FILTER (WHERE status = 'pending')  AS esperando,
       (SELECT r.name || ' · ' || to_char(b2.starts_at, 'DD/MM HH24:MI')
          FROM bookings b2 JOIN resources r ON r.id = b2.resource_id
         WHERE b2.requested_by = b.requested_by AND b2.status = 'approved' AND b2.starts_at >= now()
         ORDER BY b2.starts_at LIMIT 1) AS proxima
  FROM bookings b
 WHERE b.requested_by = (SELECT id FROM users WHERE email = 'ana@polotec.edu.uy')
 GROUP BY b.requested_by;

-- ¿Está libre? (lo que avisa el formulario antes de enviar)
SELECT NOT EXISTS (
  SELECT 1 FROM bookings
   WHERE resource_id = (SELECT id FROM resources WHERE code = 'r3')
     AND status IN ('pending', 'approved')
     AND tstzrange(starts_at, ends_at) && tstzrange((current_date + 2) + time '10:30', (current_date + 2) + time '11:30')
) AS esta_libre;

-- Pedir una reserva (si el horario está tomado, la base la rechaza)
-- SELECT fn_solicitar_reserva(
--   (SELECT id FROM users WHERE email = 'ana@polotec.edu.uy'),
--   (SELECT id FROM resources WHERE code = 'r4'),
--   'Práctico de Física - 2do año',
--   (current_date + 3) + time '14:00', (current_date + 3) + time '16:00');

-- ---------------------------------------------------------------
-- PANEL DEL ADMIN DE RESERVAS (dashboard-admin-reservas.html)
-- ---------------------------------------------------------------
SELECT * FROM v_estadisticas_reservas;
SELECT * FROM v_reservas_pendientes;
SELECT code, name, type, total_quantity, active FROM resources ORDER BY type, name;

-- Aprobar una pendiente
-- SELECT fn_decidir_reserva((SELECT id FROM users WHERE email = 'admin@polotec.edu.uy'),
--                           (SELECT id FROM v_reservas_pendientes LIMIT 1), 'approved');

-- Calendario anual: cuántas reservas aprobadas hay por día
SELECT starts_at::date AS dia, count(*) AS reservas
  FROM bookings WHERE status = 'approved' AND date_part('year', starts_at) = date_part('year', now())
 GROUP BY 1 ORDER BY 1;

-- ---------------------------------------------------------------
-- RESERVAS: SALONES Y MATERIALES (alumno y profesor, v4.2)
-- ---------------------------------------------------------------
-- 1. Salones y laboratorios, con sus herramientas ("Ver recursos")
SELECT codigo, nombre, materia, herramientas, biblioteca_ceibal, materiales_sugeridos
  FROM v_recursos WHERE tipo <> 'equipo';

-- 2. Materiales para reserva (lo único que puede pedir un alumno)
SELECT codigo, nombre, unidades FROM v_recursos WHERE tipo = 'equipo';

-- Un alumno pide 5 notebooks (si pidiera un salón, la base lo rechaza)
-- SELECT fn_solicitar_reserva(
--   (SELECT id FROM users WHERE email = 'maria@estudiante.com'),
--   (SELECT id FROM resources WHERE code = 'r13'),
--   'Trabajo en grupo de Química',
--   (current_date + 6) + time '14:00', (current_date + 6) + time '16:00', 5::smallint);

-- 3. Las reservas ya hechas por un alumno (cada uno ve solo las suyas)
SELECT r.name AS material, b.title AS motivo, b.starts_at, b.status
  FROM bookings b JOIN resources r ON r.id = b.resource_id
 WHERE b.requested_by = (SELECT id FROM users WHERE email = 'maria@estudiante.com')
 ORDER BY b.starts_at;

-- ---------------------------------------------------------------
-- PANEL DEL ESTUDIANTE: PASANTÍAS (dashboard-estudiante-pasantias.html)
-- ---------------------------------------------------------------
-- Tu perfil profesional, con la completitud y lo que falta
SELECT nombre, orientacion, nivel, disponibilidad, capacidades, idiomas, titulos, cursos, experiencia,
       curriculum, completitud || ' %' AS perfil_completo, faltan
  FROM v_perfiles WHERE email = 'maria@estudiante.com';

-- Mis postulaciones
SELECT pasantia, empresa, estado, origen
  FROM v_mis_postulaciones
 WHERE student_id = (SELECT id FROM users WHERE email = 'maria@estudiante.com');

-- Pasantías recomendadas (filtro por modalidad: 'remoto', 'presencial', 'hibrido')
SELECT titulo, empresa, modalidad, meses FROM v_pasantias_visibles;

-- Postularse
-- SELECT fn_postular((SELECT id FROM users WHERE email = 'maria@estudiante.com'),
--                    (SELECT id FROM internships WHERE title = 'Desarrollador Frontend Jr'));

-- Avisos sin leer
SELECT title, body, created_at FROM notifications
 WHERE user_id = (SELECT id FROM users WHERE email = 'maria@estudiante.com') AND read_at IS NULL
 ORDER BY created_at DESC;

-- ---------------------------------------------------------------
-- PANEL DE EMPRESA (dashboard-empresa.html)
-- ---------------------------------------------------------------
-- Postulantes, los que esperan respuesta primero
SELECT pasantia, nombre, orientacion, capacidades_principales, estado, origen
  FROM v_postulantes
 WHERE company_id = (SELECT id FROM users WHERE email = 'contacto@techcorp.com');

-- Directorio de perfiles: buscar por capacidad, orientación o curso
SELECT nombre, orientacion, capacidades, completitud
  FROM v_perfiles
 WHERE 'JavaScript' ILIKE ANY (capacidades)
    OR orientacion ILIKE '%informática%'
 ORDER BY completitud DESC;

-- Quién subió currículum en PDF (el archivo lo sirve GET /api/v1/perfiles/:id/cv)
SELECT u.display_name AS estudiante, v.file_name, pg_size_pretty(v.size_bytes::bigint) AS tamano, v.uploaded_at
  FROM student_cv v JOIN users u ON u.id = v.student_id;

-- Aceptar (o seleccionar desde el directorio, aunque no se haya postulado)
-- SELECT fn_decidir_postulacion(
--   (SELECT id FROM users WHERE email = 'contacto@techcorp.com'),
--   (SELECT id FROM users WHERE email = 'maria@estudiante.com'),
--   (SELECT id FROM internships WHERE title = 'Soporte de Datos'),
--   'approved');

-- ---------------------------------------------------------------
-- PANEL DEL ADMIN DE PASANTÍAS (dashboard-admin-pasantias.html)
-- ---------------------------------------------------------------
SELECT legal_name, sector FROM companies WHERE status = 'pending_approval';
SELECT * FROM v_entrevistas_por_agendar;
-- Embudo completo: cuántas postulaciones hay en cada estado
SELECT estado, count(*) FROM v_postulantes GROUP BY estado ORDER BY 1;
