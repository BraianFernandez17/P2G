-- ================================================================
-- POLO 2 GESTIÓN · DATOS DE PRUEBA (seed) · v4.2
-- ----------------------------------------------------------------
-- Los mismos datos que muestra la demo del sitio:
--   · cuentas de js/sesion.js (CUENTAS_DEMO),
--   · perfiles, pasantías y postulaciones de js/bolsa.js,
--   · salones, profesores y reservas de js/reservas.js.
-- Generado a partir de esos archivos, así no se desincronizan.
--
-- Contraseña de TODAS las cuentas de prueba: demo1234
-- (se guarda con bcrypt de verdad: crypt('demo1234', gen_salt('bf'))).
--
-- Las reservas tienen fechas RELATIVAS a hoy (como fechaRelativa()
-- en reservas.js): la demo nunca se queda sin agenda futura.
-- Corre después de schema.sql.
-- ================================================================
SET client_encoding TO 'UTF8';   -- los acentos se leen bien aunque psql corra en una consola de Windows
SET timezone TO 'America/Montevideo';
BEGIN;

-- ---------- CUENTAS ----------
INSERT INTO users (id, email, password_hash, role, display_name) VALUES
  ('00000000-0000-0000-0000-000000000001', 'admin@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'admin', 'Admin del Polo'),
  ('00000000-0000-0000-0000-000000000002', 'ana@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'professor', 'Ana Rodríguez'),
  ('00000000-0000-0000-0000-000000000003', 'diego@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'professor', 'Diego Martínez'),
  ('00000000-0000-0000-0000-000000000004', 'lucia@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'professor', 'Lucía Fernández'),
  ('00000000-0000-0000-0000-000000000005', 'ruben@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'professor', 'Rubén Acosta'),
  ('00000000-0000-0000-0000-000000000006', 'valentina.silveira@polotec.edu.uy', crypt('demo1234', gen_salt('bf', 8)), 'professor', 'Valentina Silveira'),
  ('00000000-0000-0000-0000-000000000010', 'contacto@techcorp.com', crypt('demo1234', gen_salt('bf', 8)), 'company', 'TechCorp Tacuarembó'),
  ('00000000-0000-0000-0000-000000000011', 'rrhh@agrotacua.com.uy', crypt('demo1234', gen_salt('bf', 8)), 'company', 'AgroTacuá S.A.'),
  ('00000000-0000-0000-0000-000000000012', 'contacto@industriasnorte.com', crypt('demo1234', gen_salt('bf', 8)), 'company', 'Industrias del Norte'),
  ('00000000-0000-0000-0000-000000000013', 'contacto@clinicasalud.com.uy', crypt('demo1234', gen_salt('bf', 8)), 'company', 'Clínica Salud Tacuarembó'),
  ('00000000-0000-0000-0000-000000000020', 'maria@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'María González'),
  ('00000000-0000-0000-0000-000000000021', 'facundo@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'Facundo Pereira'),
  ('00000000-0000-0000-0000-000000000022', 'valentina@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'Valentina Silveira'),
  ('00000000-0000-0000-0000-000000000023', 'camila@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'Camila Núñez'),
  ('00000000-0000-0000-0000-000000000024', 'joaquin@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'Joaquín Olivera'),
  ('00000000-0000-0000-0000-000000000025', 'sofia@estudiante.com', crypt('demo1234', gen_salt('bf', 8)), 'student', 'Sofía Pintos');

-- Preferencias: el trigger ya creó las de por defecto; algunas cuentas
-- con elecciones distintas, para que se vea que se guardan.
UPDATE user_preferences SET theme = 'oscuro' WHERE user_id = '00000000-0000-0000-0000-000000000002';
UPDATE user_preferences SET clap_to_open = true WHERE user_id = '00000000-0000-0000-0000-000000000001';
UPDATE user_preferences SET agenda_view = 'dia', assistant_voice = false WHERE user_id = '00000000-0000-0000-0000-000000000010';

-- ---------- PROFESORES ----------
INSERT INTO professors (user_id, first_name, last_name, department) VALUES
  ('00000000-0000-0000-0000-000000000002', 'Ana', 'Rodríguez', 'Física'),
  ('00000000-0000-0000-0000-000000000003', 'Diego', 'Martínez', 'Informática'),
  ('00000000-0000-0000-0000-000000000004', 'Lucía', 'Fernández', 'Ciencias'),
  ('00000000-0000-0000-0000-000000000005', 'Rubén', 'Acosta', 'Educación Física'),
  ('00000000-0000-0000-0000-000000000006', 'Valentina', 'Silveira', 'Gestión de Empresas');

-- ---------- EMPRESAS ----------
-- TechCorp y AgroTacuá ya aprobadas; las otras dos esperan al admin.
INSERT INTO companies (user_id, legal_name, sector, status, phone, reviewed_by, reviewed_at) VALUES
  ('00000000-0000-0000-0000-000000000010', 'TechCorp Tacuarembó', 'tecnologia', 'active', '+598 463 20000', '00000000-0000-0000-0000-000000000001', now() - interval '60 days'),
  ('00000000-0000-0000-0000-000000000011', 'AgroTacuá S.A.', 'agropecuaria', 'active', '+598 463 21111', '00000000-0000-0000-0000-000000000001', now() - interval '60 days'),
  ('00000000-0000-0000-0000-000000000012', 'Industrias del Norte', 'industria', 'pending_approval', NULL, NULL, NULL),
  ('00000000-0000-0000-0000-000000000013', 'Clínica Salud Tacuarembó', 'salud', 'pending_approval', NULL, NULL, NULL);

-- ---------- ORIENTACIONES (las que sugiere el editor de perfil) ----------
INSERT INTO orientations (id, name) VALUES
  (1, 'Bachillerato Tecnológico en Informática'),
  (2, 'Bachillerato Tecnológico en Electromecánica'),
  (3, 'Bachillerato Tecnológico en Química'),
  (4, 'Bachillerato Tecnológico Agrario'),
  (5, 'Bachillerato Tecnológico en Electrónica'),
  (6, 'Tecnólogo en Informática'),
  (7, 'Tecnicatura en Robótica'),
  (8, 'Tecnicatura en Energías Renovables');
DO $$ BEGIN PERFORM setval('orientations_id_seq', 8); END $$;

-- ---------- ESTUDIANTES Y SUS PERFILES PROFESIONALES ----------
-- María González
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000020', 'María', 'González', 1, NULL, 'tercero', 'Tacuarembó', 'medio_tiempo', 'Me gusta armar páginas web y entender cómo funcionan los datos detrás. Busco mi primera pasantía para aprender a trabajar en equipo en un proyecto real.', NULL, 'github.com/mariagonzalez');
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000020', ARRAY['HTML y CSS', 'JavaScript', 'Python', 'Trabajo en equipo']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000020', 'Español nativo', 0);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000020', 'Inglés B1', 1);
INSERT INTO student_titles (student_id, name, institution, year, position) VALUES ('00000000-0000-0000-0000-000000000020', 'Ciclo Básico Tecnológico', 'UTU Tacuarembó', 2023, 0);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000020', 'Introducción a Python', 'Ceibal', '40 horas', 0);

-- Facundo Pereira
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000021', 'Facundo', 'Pereira', 6, NULL, 'segundo', 'Tacuarembó', 'tiempo_completo', 'Programo en JavaScript y estoy aprendiendo React. Hice la web del club de fútbol del barrio y la mantengo desde hace un año.', NULL, 'facundopereira.dev');
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000021', ARRAY['JavaScript', 'React', 'Git', 'Diseño responsive', 'Bases de datos SQL']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Español nativo', 0);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Inglés B2', 1);
INSERT INTO student_titles (student_id, name, institution, year, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Bachillerato Tecnológico en Informática', 'UTU Tacuarembó', 2024, 0);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Desarrollo web full stack', 'Jóvenes a Programar', '2025', 0);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Git y GitHub', 'Plataforma Ceibal', '20 horas', 1);
INSERT INTO student_experiences (student_id, role, place, period, position) VALUES ('00000000-0000-0000-0000-000000000021', 'Desarrollador web voluntario', 'Club Atlético Barrio Centro', '2025 – hoy', 0);

-- Valentina Silveira
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000022', 'Valentina', 'Silveira', 1, NULL, 'egresado', 'Paso de los Toros', 'medio_tiempo', 'Me interesa el diseño de interfaces y la accesibilidad. Armo prototipos en Figma antes de programar.', 'linkedin.com/in/valentinasilveira', NULL);
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000022', ARRAY['Figma', 'HTML y CSS', 'Accesibilidad web', 'Comunicación']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Español nativo', 0);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Portugués B2', 1);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Inglés A2', 2);
INSERT INTO student_titles (student_id, name, institution, year, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Bachillerato Tecnológico en Informática', 'UTU Paso de los Toros', 2025, 0);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Diseño UX', 'Google (Coursera)', '6 meses', 0);
INSERT INTO student_experiences (student_id, role, place, period, position) VALUES ('00000000-0000-0000-0000-000000000022', 'Pasante de diseño', 'Intendencia de Tacuarembó', 'Verano 2025', 0);

-- Camila Núñez
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000023', 'Camila', 'Núñez', 3, NULL, 'tercero', 'Tacuarembó', 'a_coordinar', 'Trabajo ordenada en el laboratorio y llevo bien los registros. Quiero aplicar lo que sé en una planta o en control de calidad.', NULL, NULL);
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000023', ARRAY['Análisis de laboratorio', 'Excel', 'Control de calidad', 'Normas de seguridad']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000023', 'Español nativo', 0);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000023', 'Inglés A2', 1);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000023', 'Buenas prácticas de laboratorio', 'LATU', '16 horas', 0);

-- Joaquín Olivera
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000024', 'Joaquín', 'Olivera', 4, NULL, 'egresado', 'Ansina', 'tiempo_completo', 'Crecí en el campo y me especialicé en producción ganadera. Manejo registros de rodeo y maquinaria básica.', NULL, NULL);
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000024', ARRAY['Manejo de ganado', 'Registros productivos', 'Maquinaria agrícola', 'Excel']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000024', 'Español nativo', 0);
INSERT INTO student_titles (student_id, name, institution, year, position) VALUES ('00000000-0000-0000-0000-000000000024', 'Bachillerato Tecnológico Agrario', 'Escuela Agraria de Tacuarembó', 2025, 0);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000024', 'Inseminación artificial', 'INIA', '2025', 0);
INSERT INTO student_experiences (student_id, role, place, period, position) VALUES ('00000000-0000-0000-0000-000000000024', 'Ayudante de campo', 'Establecimiento La Aurora', '2024 – 2025', 0);

-- Sofía Pintos
INSERT INTO students (user_id, first_name, last_name, orientation_id, orientation_other, level, locality, availability, about, linkedin_url, portfolio_url) VALUES
  ('00000000-0000-0000-0000-000000000025', 'Sofía', 'Pintos', 2, NULL, 'tercero', 'Tacuarembó', 'medio_tiempo', 'Me gusta el mantenimiento de equipos y la automatización. Armé un brazo robótico con Arduino para la feria de clubes.', NULL, NULL);
DO $$ BEGIN PERFORM fn_guardar_capacidades('00000000-0000-0000-0000-000000000025', ARRAY['Arduino', 'Electricidad industrial', 'AutoCAD', 'Mantenimiento preventivo']); END $$;
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000025', 'Español nativo', 0);
INSERT INTO student_languages (student_id, label, position) VALUES ('00000000-0000-0000-0000-000000000025', 'Inglés A2', 1);
INSERT INTO student_courses (student_id, name, institution, detail, position) VALUES ('00000000-0000-0000-0000-000000000025', 'Automatización con PLC', 'UTU', '60 horas', 0);

-- ---------- PASANTÍAS (las de js/bolsa.js) ----------
INSERT INTO internships (id, company_id, title, description, modality, duration_months, status, published_at) VALUES
  ('30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000010', 'Desarrollador Frontend Jr', 'Maquetado de pantallas con HTML, CSS y JavaScript junto al equipo de producto.', 'remoto', 6, 'published', now() - interval '16 days'),
  ('30000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000010', 'Soporte de Datos', 'Carga, limpieza y control de datos de clientes; reportes semanales en planillas.', 'presencial', 4, 'published', now() - interval '12 days'),
  ('30000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000011', 'Asistente de Agroindustria', 'Apoyo en registros productivos, trazabilidad y control de calidad en planta.', 'hibrido', 5, 'published', now() - interval '8 days');

-- ---------- POSTULACIONES ----------
-- Se cargan como 'pending' y después se deciden con UPDATE, igual que
-- en la vida real: así los triggers generan los avisos correspondientes.
INSERT INTO applications (id, student_id, internship_id, created_at) VALUES
  ('40000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000020', '30000000-0000-0000-0000-000000000002', now() - interval '10 days'),
  ('40000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000021', '30000000-0000-0000-0000-000000000001', now() - interval '9 days'),
  ('40000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000022', '30000000-0000-0000-0000-000000000001', now() - interval '8 days'),
  ('40000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000025', '30000000-0000-0000-0000-000000000001', now() - interval '7 days'),
  ('40000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000023', '30000000-0000-0000-0000-000000000002', now() - interval '6 days'),
  ('40000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000024', '30000000-0000-0000-0000-000000000003', now() - interval '5 days');
UPDATE applications SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000010' WHERE id = '40000000-0000-0000-0000-000000000003';
UPDATE applications SET status = 'rejected', decided_by = '00000000-0000-0000-0000-000000000010' WHERE id = '40000000-0000-0000-0000-000000000004';

-- ---------- SALONES, LABORATORIOS Y EQUIPOS (js/reservas.js) ----------
INSERT INTO resources (id, code, name, type, total_quantity, capacity) VALUES
  ('50000000-0000-0000-0000-000000000001', 'r1', 'Biblioteca', 'espacio', 1, 40),
  ('50000000-0000-0000-0000-000000000002', 'r2', 'Sala de Informática', 'espacio', 1, 30),
  ('50000000-0000-0000-0000-000000000003', 'r3', 'Sala de Conferencias', 'espacio', 1, 60),
  ('50000000-0000-0000-0000-000000000009', 'r9', 'Auditorio', 'espacio', 1, 200),
  ('50000000-0000-0000-0000-00000000000a', 'r10', 'Sala de Reuniones Docentes', 'espacio', 1, 16),
  ('50000000-0000-0000-0000-00000000000b', 'r11', 'Cancha Techada', 'espacio', 1, 80),
  ('50000000-0000-0000-0000-000000000004', 'r4', 'Laboratorio de Física', 'laboratorio', 1, 24),
  ('50000000-0000-0000-0000-000000000005', 'r5', 'Laboratorio de Química', 'laboratorio', 1, 24),
  ('50000000-0000-0000-0000-000000000006', 'r6', 'Laboratorio de Ciencias', 'laboratorio', 1, 24),
  ('50000000-0000-0000-0000-00000000000c', 'r12', 'Laboratorio de Robótica', 'laboratorio', 1, 20),
  ('50000000-0000-0000-0000-000000000007', 'r7', 'Proyector', 'equipo', 2, NULL),
  ('50000000-0000-0000-0000-000000000008', 'r8', 'Televisión', 'equipo', 1, NULL),
  ('50000000-0000-0000-0000-00000000000d', 'r13', 'Notebooks (carro móvil)', 'equipo', 15, NULL),
  ('50000000-0000-0000-0000-00000000000e', 'r14', 'Equipo de sonido', 'equipo', 1, NULL),
  ('50000000-0000-0000-0000-00000000000f', 'r15', 'Micrófono inalámbrico', 'equipo', 2, NULL),
  ('50000000-0000-0000-0000-000000000010', 'r16', 'Parlante portátil', 'equipo', 2, NULL),
  ('50000000-0000-0000-0000-000000000011', 'r17', 'Kits de Arduino', 'equipo', 10, NULL);

-- ---------- RECURSOS SEGÚN LA MATERIA (= RECURSOS_POR_SALON de js/espacios.js) ----------
UPDATE resources AS r SET subject = v.materia, tools = v.herramientas, study_room = v.estudio
  FROM (VALUES
    ('r1',  'Lectura y estudio',          '{}'::text[],                                   true),
    ('r2',  'Informática',                '{calculadora,bases}'::text[],                  true),
    ('r3',  'Presentaciones y defensas',  '{}'::text[],                                   true),
    ('r9',  'Actos y charlas',            '{}'::text[],                                   false),
    ('r10', 'Coordinación docente',       '{}'::text[],                                   true),
    ('r11', 'Educación Física',           '{}'::text[],                                   false),
    ('r4',  'Física',                     '{calculadora,constantes,conversor}'::text[],   true),
    ('r5',  'Química',                    '{calculadora,masaMolar,conversor}'::text[],    true),
    ('r6',  'Ciencias',                   '{calculadora,conversor}'::text[],              true),
    ('r12', 'Robótica',                   '{calculadora,ohm,resistencias,bases}'::text[], true)
  ) AS v(codigo, materia, herramientas, estudio)
 WHERE r.code = v.codigo;

INSERT INTO resource_materials (space_id, material_id, position)
SELECT s.id, m.id, v.orden
  FROM (VALUES
    ('r1', 'r13', 0), ('r1', 'r8', 1),
    ('r2', 'r7', 0),  ('r2', 'r13', 1),
    ('r3', 'r7', 0),  ('r3', 'r15', 1),
    ('r9', 'r14', 0), ('r9', 'r15', 1), ('r9', 'r7', 2),
    ('r10', 'r8', 0), ('r10', 'r7', 1),
    ('r11', 'r14', 0), ('r11', 'r15', 1), ('r11', 'r16', 2),
    ('r4', 'r7', 0),  ('r4', 'r13', 1),
    ('r5', 'r7', 0),  ('r5', 'r8', 1),
    ('r6', 'r7', 0),  ('r6', 'r8', 1),
    ('r12', 'r17', 0), ('r12', 'r13', 1)
  ) AS v(salon, material, orden)
  JOIN resources s ON s.code = v.salon
  JOIN resources m ON m.code = v.material;

-- ---------- CURRÍCULUM EN PDF (los dos perfiles de ejemplo que tienen CV) ----------
-- PDF mínimos y válidos (empiezan con %PDF-, como exige student_cv).
INSERT INTO student_cv (student_id, file_name, content, uploaded_at) VALUES
  ('00000000-0000-0000-0000-000000000021', 'CV Facundo Pereira.pdf', '\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203420302052202f4632203520302052203e3e203e3e202f436f6e74656e7473203620302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c7665746963612d426f6c64202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a362030206f626a0a3c3c202f4c656e67746820343336203e3e0a73747265616d0a4254202f4632203232205466203536203739302054642028466163756e646f20506572656972612920546a2045540a4254202f46312031312054662035362037363020546420285465636e5c3336336c6f676f20656e20496e666f726d5c33343174696361205c3236372032646f20615c3336316f205c32363720546163756172656d625c3336332920546a2045540a4254202f46312031312054662035362037343220546420284a6176615363726970742c2052656163742c204769742c20446973655c3336316f20726573706f6e736976652c204261736573206465206461746f732053514c2920546a2045540a4254202f46312031312054662035362037323420546420284465736172726f6c6c61646f722077656220766f6c756e746172696f202d20436c75622041746c5c3335317469636f2042617272696f2043656e74726f205c2832303235202d20686f795c292920546a2045540a4254202f4631203131205466203536203730362054642028437572725c33353563756c756d20646520656a656d706c6f206465206c612064656d6f20646520506f6c6f20322047657374695c3336336e2e2920546a2045540a656e6473747265616d0a656e646f626a0a787265660a3020370a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323531203030303030206e200a30303030303030333438203030303030206e200a30303030303030343530203030303030206e200a747261696c65720a3c3c202f53697a652037202f526f6f74203120302052203e3e0a7374617274787265660a3933370a2525454f460a'::bytea, '2026-09-02 10:00-03'),
  ('00000000-0000-0000-0000-000000000022', 'CV Valentina Silveira.pdf', '\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203420302052202f4632203520302052203e3e203e3e202f436f6e74656e7473203620302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c7665746963612d426f6c64202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a362030206f626a0a3c3c202f4c656e67746820343336203e3e0a73747265616d0a4254202f463220323220546620353620373930205464202856616c656e74696e612053696c76656972612920546a2045540a4254202f463120313120546620353620373630205464202842616368696c6c657261746f205465636e6f6c5c3336336769636f20656e20496e666f726d5c33343174696361205c323637204567726573616461205c323637205061736f206465206c6f7320546f726f732920546a2045540a4254202f46312031312054662035362037343220546420284669676d612c2048544d4c2079204353532c2041636365736962696c69646164207765622c20436f6d756e69636163695c3336336e2920546a2045540a4254202f4631203131205466203536203732342054642028506173616e746520646520646973655c3336316f202d20496e74656e64656e63696120646520546163756172656d625c333633205c28566572616e6f20323032355c292920546a2045540a4254202f4631203131205466203536203730362054642028437572725c33353563756c756d20646520656a656d706c6f206465206c612064656d6f20646520506f6c6f20322047657374695c3336336e2e2920546a2045540a656e6473747265616d0a656e646f626a0a787265660a3020370a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323531203030303030206e200a30303030303030333438203030303030206e200a30303030303030343530203030303030206e200a747261696c65720a3c3c202f53697a652037202f526f6f74203120302052203e3e0a7374617274787265660a3933370a2525454f460a'::bytea, '2026-08-20 18:30-03');

-- ---------- RESERVAS (fechas relativas a hoy, en hora de Uruguay) ----------
-- Las decididas se cargan como 'pending' y se deciden después (mismo
-- motivo que las postulaciones: que corran los triggers).
INSERT INTO bookings (id, resource_id, requested_by, title, starts_at, ends_at, created_at) VALUES
  ('60000000-0000-0000-0000-000000000001', '50000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000002', 'Práctico de mecánica - 2do año', (current_date + -33) + time '14:00', (current_date + -33) + time '16:00', (current_date + -36) + time '08:00'),
  ('60000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000002', 'Reunión de coordinación docente', (current_date + 2) + time '10:00', (current_date + 2) + time '11:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000003', '50000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000003', 'Taller de programación', (current_date + 1) + time '09:00', (current_date + 1) + time '12:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000004', '50000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000002', 'Práctico de titulación', (current_date + 5) + time '14:00', (current_date + 5) + time '17:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000005', '50000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000004', 'Práctico de biología - Bach. Agrario', (current_date + 1) + time '14:00', (current_date + 1) + time '16:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000006', '50000000-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000005', 'Charla de egresados de Electromecánica', (current_date + 3) + time '18:00', (current_date + 3) + time '20:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000007', '50000000-0000-0000-0000-00000000000a', '00000000-0000-0000-0000-000000000006', 'Reunión de coordinación de Gestión de Empresas', (current_date + -2) + time '09:00', (current_date + -2) + time '10:00', (current_date + -5) + time '08:00'),
  ('60000000-0000-0000-0000-000000000008', '50000000-0000-0000-0000-00000000000c', '00000000-0000-0000-0000-000000000003', 'Introducción a Arduino - 3er año', (current_date + 6) + time '14:00', (current_date + 6) + time '16:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000009', '50000000-0000-0000-0000-00000000000d', '00000000-0000-0000-0000-000000000002', 'Evaluación con notebooks - Informática', (current_date + 7) + time '08:00', (current_date + 7) + time '10:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000a', '50000000-0000-0000-0000-00000000000b', '00000000-0000-0000-0000-000000000005', 'Clase de Educación Física - Torneo interno', (current_date + 2) + time '15:00', (current_date + 2) + time '17:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000b', '50000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000002', 'Presentación de proyectos finales', (current_date + -5) + time '10:00', (current_date + -5) + time '12:00', (current_date + -8) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000c', '50000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'Charla de orientación vocacional', (current_date + 8) + time '10:00', (current_date + 8) + time '11:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000d', '50000000-0000-0000-0000-00000000000e', '00000000-0000-0000-0000-000000000004', 'Acto de bienvenida a nuevos estudiantes', (current_date + 9) + time '09:00', (current_date + 9) + time '10:30', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000e', '50000000-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000004', 'Feria de clubes de ciencia', (current_date + 24) + time '09:00', (current_date + 24) + time '17:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-00000000000f', '50000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000003', 'Capacitación docente en herramientas digitales', (current_date + 38) + time '14:00', (current_date + 38) + time '18:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000010', '50000000-0000-0000-0000-00000000000b', '00000000-0000-0000-0000-000000000005', 'Torneo interliceal de futsal', (current_date + 52) + time '08:00', (current_date + 52) + time '13:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000011', '50000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000002', 'Defensa de proyectos de Electromecánica', (current_date + 67) + time '09:00', (current_date + 67) + time '12:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000012', '50000000-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000006', 'Acto de fin de cursos', (current_date + 95) + time '19:00', (current_date + 95) + time '22:00', (current_date + -3) + time '08:00'),
  ('60000000-0000-0000-0000-000000000013', '50000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000004', 'Mesa de exámenes - Ciencias', (current_date + -58) + time '08:00', (current_date + -58) + time '12:00', (current_date + -61) + time '08:00'),
  ('60000000-0000-0000-0000-000000000014', '50000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'Jornada de inducción a primer año', (current_date + -92) + time '09:00', (current_date + -92) + time '12:00', (current_date + -95) + time '08:00'),
  -- Pedidos de estudiantes: solo materiales (el trigger rechaza salones).
  ('60000000-0000-0000-0000-000000000015', '50000000-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000020', 'Presentación del proyecto final de Programación', (current_date + 3) + time '10:00', (current_date + 3) + time '12:00', (current_date + -1) + time '19:00'),
  ('60000000-0000-0000-0000-000000000016', '50000000-0000-0000-0000-000000000008', '00000000-0000-0000-0000-000000000021', 'Ensayo de la defensa del club de ciencias', (current_date + 4) + time '16:00', (current_date + 4) + time '17:00', (current_date + -2) + time '20:00');
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000001';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000005';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000006';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000008';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-00000000000a';
UPDATE bookings SET status = 'rejected', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-00000000000b';
UPDATE bookings SET status = 'cancelled' WHERE id = '60000000-0000-0000-0000-00000000000c';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-00000000000e';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-00000000000f';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000010';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000011';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000012';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000013';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000014';
UPDATE bookings SET status = 'approved', decided_by = '00000000-0000-0000-0000-000000000001' WHERE id = '60000000-0000-0000-0000-000000000016';

-- Los avisos que generaron los triggers al cargar la historia, se
-- marcan como leídos (salvo los de los últimos días), para que la
-- demo arranque con pocos avisos nuevos, no con todo el historial.
UPDATE notifications SET read_at = now() WHERE kind = 'reserva_decidida';

COMMIT;
