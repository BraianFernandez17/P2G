/* ============================================================
   DASHBOARD DE EMPRESA (mock)
   Mismo patrón que estudiante.js y reservas.js: datos de ejemplo
   a mano + funciones que pintan el HTML, para poder ver la
   pantalla funcionando sin backend todavía.
   ============================================================ */

// Rubros posibles de una empresa (mismo CHECK que companies.sector
// en db/schema.sql), con una etiqueta linda para mostrar en pantalla.
const ETIQUETA_SECTOR = {
  tecnologia: "Tecnología",
  industria: "Industria",
  agropecuaria: "Agropecuaria",
  comercio: "Comercio",
  servicios: "Servicios",
  educacion: "Educación",
  salud: "Salud",
  construccion: "Construcción",
  turismo: "Turismo",
  logistica: "Logística",
};

const ETIQUETA_ESTADO_POSTULANTE = {
  pending: "En revisión",
  approved: "Aprobado",
  rejected: "Rechazado",
};

let misPasantias = [
  {
    id: 1,
    titulo: "Desarrollador Frontend Jr",
    modalidad: "Remoto",
    duracionMeses: 6,
  },
  {
    id: 2,
    titulo: "Soporte de Datos",
    modalidad: "Presencial",
    duracionMeses: 4,
  },
];

// Antes "postulantes" era un número fijo adentro de misPasantias.
// Ahora son personas de verdad (aunque sea mock), agrupadas por
// pasantía, para poder aprobar/rechazar cada una desde el modal
// de "Ver postulantes" y que el contador se actualice solo.
let postulantesPorPasantia = {
  1: [
    { id: "q1", nombre: "María González", estado: "pending" },
    { id: "q2", nombre: "Facundo Pereira", estado: "pending" },
    { id: "q3", nombre: "Valentina Silveira", estado: "approved" },
    { id: "q4", nombre: "Rubén Acosta", estado: "rejected" },
  ],
  2: [
    { id: "q5", nombre: "Lucía Fernández", estado: "pending" },
    { id: "q6", nombre: "Diego Martínez", estado: "pending" },
    { id: "q7", nombre: "Ana Rodríguez", estado: "approved" },
  ],
};

function pintarSaludoEmpresa() {
  const saludoEl = document.getElementById("saludo");
  if (!saludoEl) return;

  const sesion = obtenerSesion();
  const nombre = sesion ? sesion.name : "TechCorp Tacuarembó";
  saludoEl.textContent = `Hola, ${nombre}`;
}

// Muestra el rubro de la empresa como chip, al lado del saludo.
function pintarSectorEmpresa() {
  const sectorEl = document.getElementById("sector-empresa");
  if (!sectorEl) return;

  const sesion = obtenerSesion();
  const sector = sesion && sesion.sector ? sesion.sector : "servicios";
  sectorEl.textContent = ETIQUETA_SECTOR[sector] || sector;
}

// Este banner es el mismo caso de "pending_approval" que ya
// describe schema.sql para companies: mientras el admin no
// apruebe la cuenta, se lo recordamos en vez de escondérselo.
function pintarAvisoPendiente() {
  const avisoEl = document.getElementById("aviso-pendiente");
  if (!avisoEl) return;

  const sesion = obtenerSesion();
  avisoEl.style.display =
    sesion && sesion.status === "pending_approval" ? "block" : "none";
}

// Antes estos tres números venían fijos a mano. Ahora "Pasantías
// publicadas", "Postulantes nuevos" y "Entrevistas agendadas" se
// calculan a partir de misPasantias y postulantesPorPasantia, así
// que se actualizan solos al publicar una pasantía nueva o al
// revisar postulantes.
function pintarEstadisticasEmpresa() {
  const grillaEl = document.getElementById("grilla-estadisticas");
  if (!grillaEl) return;

  const todosLosPostulantes = Object.values(postulantesPorPasantia).flat();
  const postulantesNuevos = todosLosPostulantes.filter((p) => p.estado === "pending").length;
  const entrevistasAgendadas = todosLosPostulantes.filter((p) => p.estado === "approved").length;

  const estadisticas = [
    { icono: "📢", tono: "accent", etiqueta: "Pasantías publicadas", valor: misPasantias.length },
    { icono: "🧑‍🎓", tono: "info", etiqueta: "Postulantes nuevos", valor: postulantesNuevos },
    { icono: "🗓️", tono: "success", etiqueta: "Entrevistas agendadas", valor: entrevistasAgendadas },
  ];

  grillaEl.innerHTML = estadisticas
    .map(
      (item) => `
      <div class="stat-card" data-tone="${item.tono}">
        <div class="stat-card-icon">${item.icono}</div>
        <p class="stat-card-label">${item.etiqueta}</p>
        <p class="stat-card-value">${item.valor}</p>
      </div>
    `
    )
    .join("");
}

/* ============================================================
   MIS PASANTÍAS (con filtro por modalidad, igual idea que el
   dashboard del estudiante)
   ============================================================ */
let filtroModalidadEmpresa = "todas";

function pintarFiltrosModalidadEmpresa() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  let filtrosEl = document.getElementById("filtros-modalidad-empresa");
  if (!filtrosEl) {
    filtrosEl = document.createElement("div");
    filtrosEl.id = "filtros-modalidad-empresa";
    filtrosEl.className = "filter-chips";
    listaEl.parentElement.insertBefore(filtrosEl, listaEl);
  }

  const modalidades = ["todas", ...new Set(misPasantias.map((p) => p.modalidad))];
  filtrosEl.innerHTML = modalidades
    .map(
      (modalidad) => `
      <button type="button" class="filter-chip ${filtroModalidadEmpresa === modalidad ? "active" : ""}" data-modalidad="${modalidad}">
        ${modalidad === "todas" ? "Todas" : modalidad}
      </button>
    `
    )
    .join("");

  filtrosEl.querySelectorAll("button[data-modalidad]").forEach((boton) => {
    boton.addEventListener("click", () => {
      filtroModalidadEmpresa = boton.dataset.modalidad;
      pintarMisPasantias();
    });
  });
}

function pintarMisPasantias() {
  const listaEl = document.getElementById("lista-pasantias");
  if (!listaEl) return;

  pintarFiltrosModalidadEmpresa();

  const pasantias =
    filtroModalidadEmpresa === "todas"
      ? misPasantias
      : misPasantias.filter((p) => p.modalidad === filtroModalidadEmpresa);

  if (pasantias.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">Todavía no publicaste ninguna pasantía ${
      filtroModalidadEmpresa === "todas" ? "" : filtroModalidadEmpresa.toLowerCase()
    }.</p>`;
    return;
  }

  listaEl.innerHTML = pasantias
    .map((pasantia) => {
      const postulantes = postulantesPorPasantia[pasantia.id] || [];
      return `
      <div class="internship-card">
        <div>
          <p class="internship-title">${pasantia.titulo}</p>
          <p class="internship-meta">
            ${pasantia.modalidad} · ${pasantia.duracionMeses} meses · ${postulantes.length} postulante${postulantes.length === 1 ? "" : "s"}
          </p>
        </div>
        <button class="btn-view" data-pasantia-id="${pasantia.id}">Ver postulantes</button>
      </div>
    `;
    })
    .join("");

  listaEl.querySelectorAll("button[data-pasantia-id]").forEach((boton) => {
    boton.addEventListener("click", () => {
      verPostulantes(Number(boton.dataset.pasantiaId));
    });
  });
}

/* ============================================================
   VER POSTULANTES (modal informativo, con detalle por candidato)
   ============================================================ */
function verPostulantes(pasantiaId) {
  // Versión real: GET /api/v1/internships/:id/applications
  const pasantia = misPasantias.find((p) => p.id === pasantiaId);
  if (!pasantia) return;

  const postulantes = postulantesPorPasantia[pasantiaId] || [];

  if (postulantes.length === 0) {
    pedirConfirmacion(pasantia.titulo, "Todavía no tiene postulantes.", null, "Entendido", null);
    return;
  }

  const detalle = postulantes
    .map((p) => `${p.nombre} — ${ETIQUETA_ESTADO_POSTULANTE[p.estado]}`)
    .join("\n");

  pedirConfirmacion(`Postulantes: ${pasantia.titulo}`, detalle, null, "Cerrar", null);
}

/* ============================================================
   PUBLICAR PASANTÍA (formulario real, en vez del alert() de antes)
   ============================================================ */
function alternarFormularioPasantia() {
  const formulario = document.getElementById("form-nueva-pasantia");
  const boton = document.getElementById("publicar-pasantia");
  if (!formulario || !boton) return;

  const abierto = formulario.style.display !== "none";
  formulario.style.display = abierto ? "none" : "block";
  boton.textContent = abierto ? "Publicar pasantía" : "Cancelar";
  if (!abierto) {
    document.getElementById("pasantia-titulo").focus();
  }
}

function manejarNuevaPasantia(evento) {
  evento.preventDefault();
  const formulario = evento.target;

  const titulo = formulario.querySelector("#pasantia-titulo").value.trim();
  const modalidad = formulario.querySelector("#pasantia-modalidad").value;
  const duracionMeses = Number(formulario.querySelector("#pasantia-duracion").value);

  if (!titulo || !modalidad || !duracionMeses) {
    mostrarToast("Completá todos los campos para publicar la pasantía.", "error");
    return;
  }

  // Versión real: POST /api/v1/internships
  const nuevaPasantia = {
    id: misPasantias.length ? Math.max(...misPasantias.map((p) => p.id)) + 1 : 1,
    titulo,
    modalidad,
    duracionMeses,
  };
  misPasantias.push(nuevaPasantia);
  postulantesPorPasantia[nuevaPasantia.id] = [];

  formulario.reset();
  alternarFormularioPasantia();
  pintarMisPasantias();
  pintarEstadisticasEmpresa();
  mostrarToast(`"${titulo}" publicada. Ya es visible para los estudiantes.`, "success");
}

document.addEventListener("DOMContentLoaded", () => {
  pintarSaludoEmpresa();
  pintarSectorEmpresa();
  pintarAvisoPendiente();
  pintarEstadisticasEmpresa();
  pintarMisPasantias();

  const botonPublicar = document.getElementById("publicar-pasantia");
  if (botonPublicar) botonPublicar.addEventListener("click", alternarFormularioPasantia);

  const formNuevaPasantia = document.getElementById("form-nueva-pasantia");
  if (formNuevaPasantia) formNuevaPasantia.addEventListener("submit", manejarNuevaPasantia);
});
